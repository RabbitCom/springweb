package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.annotation.Id;

public class CategoryRelation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 379678985596263637L;

	// 关系表主键
	private Long categoryRelationId;

	// spId
	private Long customId;

	// 分类ID
	private Long customCategoryId;

	// 分类名称
	private String customCategoryName;
	
	//大分类的标识
	private Integer categoryDicValue;

	// icms栏目ID
	private Long icmsCategoryId;

	// icms栏目名称
	private String icmsCategoryName;

	//
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	//
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;

	private String MAM_NodeID;

	private String MAM_NodeName;

	private String cms_column_id;

	private String cms_column_name;

	private Long spId;

	private Long createUserId;

	private Long updateUserId;

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	@Id
	public Long getCategoryRelationId() {
		return categoryRelationId;
	}

	public void setCategoryRelationId(Long categoryRelationId) {
		this.categoryRelationId = categoryRelationId;
	}

	public Long getCustomCategoryId() {
		return customCategoryId;
	}

	public void setCustomCategoryId(Long customCategoryId) {
		this.customCategoryId = customCategoryId;
	}

	public String getCustomCategoryName() {
		return customCategoryName;
	}

	public void setCustomCategoryName(String customCategoryName) {
		this.customCategoryName = customCategoryName;
	}

	public Long getIcmsCategoryId() {
		return icmsCategoryId;
	}

	public void setIcmsCategoryId(Long icmsCategoryId) {
		this.icmsCategoryId = icmsCategoryId;
	}

	public String getIcmsCategoryName() {
		return icmsCategoryName;
	}

	public void setIcmsCategoryName(String icmsCategoryName) {
		this.icmsCategoryName = icmsCategoryName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public String getMAM_NodeID() {
		return MAM_NodeID;
	}

	public void setMAM_NodeID(String mAM_NodeID) {
		MAM_NodeID = mAM_NodeID;
	}

	public String getMAM_NodeName() {
		return MAM_NodeName;
	}

	public void setMAM_NodeName(String mAM_NodeName) {
		MAM_NodeName = mAM_NodeName;
	}

	public String getCms_column_id() {
		return cms_column_id;
	}

	public void setCms_column_id(String cms_column_id) {
		this.cms_column_id = cms_column_id;
	}

	public String getCms_column_name() {
		return cms_column_name;
	}

	public void setCms_column_name(String cms_column_name) {
		this.cms_column_name = cms_column_name;
	}

	public Integer getCategoryDicValue() {
		return categoryDicValue;
	}

	public void setCategoryDicValue(Integer categoryDicValue) {
		this.categoryDicValue = categoryDicValue;
	}
	
}
