package com.cnlive.mam.vo;import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class MenuTree implements Serializable {

	private static final long serialVersionUID = 3290969854808173438L;

	private String id;
	private String text;
	private String state = "closed";// open,closed
	private boolean checked = false;
	private Object attributes;
	private List<MenuTree> children =  new LinkedList<MenuTree>();
	private String pid;

	public MenuTree(){

	}

	public MenuTree(String id,String pid,String text,String state,List<MenuTree> children,Object attributes){
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.state = state;
		this.children = children;
		this.attributes = attributes;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public Object getAttributes() {
		return attributes;
	}
	public void setAttributes(Object attributes) {
		this.attributes = attributes;
	}
	public List<MenuTree> getChildren() {
		return children;
	}
	public void setChildren(List<MenuTree> children) {
		this.children = children;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
}
