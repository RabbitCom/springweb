package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;

@JSONType(asm=false)
public class PublishTaskModel implements Serializable {

    /**
	 * 发布任务表
	 */
	private static final long serialVersionUID = -2903333851929420076L;
	
	private Long taskId;

	private Long videoId;

    private Long customId;

    private Integer publishState;//0立即发布，1定时发布

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date publishTime;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date prePublishedTime;
    
    private Long releaseId;
    
    private Long releasePid;
    
    private String releaseColumnId;
    
    private String releaseTitle;

    private String mamNodeId;

    private String mamNodeName;

    private String cmsColumnId;
    private String cmsColumnName;

    public String getMamNodeId() {
        return mamNodeId;
    }

    public void setMamNodeId(String mamNodeId) {
        this.mamNodeId = mamNodeId;
    }

    public String getMamNodeName() {
        return mamNodeName;
    }

    public void setMamNodeName(String mamNodeName) {
        this.mamNodeName = mamNodeName;
    }

    public String getCmsColumnId() {
        return cmsColumnId;
    }

    public void setCmsColumnId(String cmsColumnId) {
        this.cmsColumnId = cmsColumnId;
    }

    public String getCmsColumnName() {
        return cmsColumnName;
    }

    public void setCmsColumnName(String cmsColumnName) {
        this.cmsColumnName = cmsColumnName;
    }

    @Id
    public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public void setPrePublishedTime(Date prePublishedTime)
    {
        this.prePublishedTime = prePublishedTime;
    }
	
	public Date getPrePublishedTime()
    {
        return prePublishedTime;
    }

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public Date getPublishTime()
    {
        return publishTime;
    }

    public void setPublishTime(Date publishTime)
    {
        this.publishTime = publishTime;
    }

	public Integer getPublishState() {
		return publishState;
	}

	public void setPublishState(Integer publishState) {
		this.publishState = publishState;
	}

	public Long getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(Long releaseId) {
		this.releaseId = releaseId;
	}

	public Long getReleasePid() {
		return releasePid;
	}

	public void setReleasePid(Long releasePid) {
		this.releasePid = releasePid;
	}

	public void setReleaseColumnId(String releaseColumnId) {
		this.releaseColumnId = releaseColumnId;
	}

	public String getReleaseTitle() {
		return releaseTitle;
	}

	public void setReleaseTitle(String releaseTitle) {
		this.releaseTitle = releaseTitle;
	}

	public String getReleaseColumnId() {
		return releaseColumnId;
	}
	
}
