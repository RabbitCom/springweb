package com.cnlive.mam.model;

import java.io.Serializable;

import com.cnlive.mam.common.annotation.Id;

public class CustomCategoryModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4397832351069966797L;
	private Long customCategoryId;
    private Long customId;
    private String customCategoryName;
    private Integer category;
    private Long parentCustomCategoryId;
    private Integer level;
    private Integer auditSetting ; //免审核设置   0:关闭 1:打开     默认关闭
    private Long spId;

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    @Id
    public Long getCustomCategoryId() {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId) {
        this.customCategoryId = customCategoryId;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public String getCustomCategoryName() {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName) {
        this.customCategoryName = customCategoryName;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Long getParentCustomCategoryId() {
        return parentCustomCategoryId;
    }

    public void setParentCustomCategoryId(Long parentCustomCategoryId) {
        this.parentCustomCategoryId = parentCustomCategoryId;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }


    public boolean isLeafLevel(){
        return getLevel() != null &&  getLevel().intValue() == 3;
    }

    
    public Integer getAuditSetting() {
        return auditSetting;
    }

    public void setAuditSetting(Integer auditSetting) {
        this.auditSetting = auditSetting;
    }
    
    @Override
    public String toString(){
    	
    	return "CustomCategory{" +
                "customId=" + customId + '\'' +
                ", customCategoryName='" + customCategoryName + '\'' +
                ", category=" + category + '\'' +
                ", customCategoryId=" + customCategoryId +
                ", parentCustomCategoryId='" + parentCustomCategoryId + '\'' +
                ", level=" + level+ '\'' +
                ", auditSetting=" + auditSetting +
                '}';
    	
    }

}
