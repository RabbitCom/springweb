package com.cnlive.mam.service;

import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.condition.CustomCategoryCondition;
import com.cnlive.mam.model.CategoryRelation;
import com.cnlive.mam.model.CustomCategoryModel;
import com.cnlive.mam.vo.CustomCategoryTree;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;
import java.util.Map;

/**
 * @author zhangxiaobin
 */
public interface CustomCategoryService {

    List<CustomCategoryModel> getInfosByCondition(CustomCategoryCondition customCategoryCondition);

    List<CustomCategoryModel> getParentCustomCategory(Long spid);

    Boolean checkContent(CustomCategoryModel customCategoryModel);

    List<CustomCategoryVo> integratedData(CustomCategoryCondition customCategoryCondition, Long customId);

    List<CustomCategoryModel> getCustomCategoryByCustomId(Long customId);


    public void checkCustomCategoryCanAddVideo(Long customId, Long customCategoryId) throws BusinessException;

    public CustomCategoryModel getById(Long id);


    public CustomCategoryModel save(CustomCategoryModel t);

    public CustomCategoryModel create(CustomCategoryModel t);
    public CustomCategoryModel modify(CustomCategoryModel t);

    public void delete(CustomCategoryModel t);

    Map<String, CustomCategoryTree> getCustomCategoryData(List<CustomCategoryVo> list, Map<String, CustomCategoryTree> map);

    CustomCategoryModel create(CustomCategoryModel customCategoryModel, Long customId) throws  BusinessException;

    public void customCategoryFreeAuditSettingByIds(Map<String,String []> parameterMap);

    void closeFreeAudit(String[] offids);

    void openFreeAudit(String[] openids);

    Long getCountByCondition(CustomCategoryCondition customCategoryCondition);

    DataGrid dataGrid(CustomCategoryCondition customCategoryCondition);

    List<CustomCategoryModel> getPageByCondition(CustomCategoryCondition customCategoryCondition);

    List<CustomCategoryModel> getCustomCategorysByParentIds(List<String> customCategoryIds);

    CustomCategoryModel getParentCustomCategoryByLeafCustomCategory(CustomCategoryModel customCategoryModel);

	void saveCategoryRelation(CategoryRelation categoryRelation);

	CategoryRelation getRelationBySpidAndCustomCategory(Long customCategoryId,Long spId);

	void updateCategoryRelation(CategoryRelation categoryRelation);

	CategoryRelation getRelationBySpidAndCategory(Integer categoryDicValue,Long spId);

	CategoryRelation getPublishCategoryRelation(CategoryRelation categoryRelation);

	void deleteByCustomCategoryId(Long customCategoryId);

	void deleteByCategoryRelationId(Long categoryRelationId);
}
