package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
@JSONType(asm=false)
public class PublishHistory implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3504701590893959107L;

	private Long publishHistoryId;

    private Long videoId;

    private Long customId;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date publishTime;

    private String publishUser;

    private Integer publishState;//0发布成功，1系统异常，2接口错误
    
    private String description;

    public Long getPublishHistoryId()
    {
        return publishHistoryId;
    }

    public void setPublishHistoryId(Long publishHistoryId)
    {
        this.publishHistoryId = publishHistoryId;
    }

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public Date getPublishTime()
    {
        return publishTime;
    }

    public void setPublishTime(Date publishTime)
    {
        this.publishTime = publishTime;
    }


    public String getPublishUser()
    {
        return publishUser;
    }

    public void setPublishUser(String publishUser)
    {
        this.publishUser = publishUser;
    }

	public Integer getPublishState() {
		return publishState;
	}

	public void setPublishState(Integer publishState) {
		this.publishState = publishState;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
