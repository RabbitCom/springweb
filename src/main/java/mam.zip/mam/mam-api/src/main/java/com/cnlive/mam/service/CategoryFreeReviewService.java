package com.cnlive.mam.service;

import com.cnlive.mam.model.CategoryFreeReviewModel;

/**
 * Created by zhangxiaobin
 */
public interface CategoryFreeReviewService {

    int create(CategoryFreeReviewModel t);

    int modify(CategoryFreeReviewModel t);

    int delete(CategoryFreeReviewModel t);

    CategoryFreeReviewModel getByCustomId(Long customId);

    Boolean isCategoryFreeReview(Long customId, String category);
}
