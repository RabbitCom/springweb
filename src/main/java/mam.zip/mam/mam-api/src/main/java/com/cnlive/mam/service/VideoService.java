package com.cnlive.mam.service;

import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;
import java.util.Map;

/**
 * @author zhangxiaobin
 */
public interface VideoService {

	/**
	 * 根据条件分页获取视频信息--不包含删除的视频信息
	 *
	 * @param condition
	 * @return
	 */
	DataGrid getPageByCondition(VideoCondition condition);

	/**
	 * superSP seach
	 *
	 * @param condition
	 * @return
	 */
	DataGrid getPageByCondition(SuperSpCondition condition);

	/**
	 * 根据专辑id获取视频列表--不包含删除的视频信息
	 *
	 * @param aLong
	 * @return
	 */
	List<VideoModel> getByAlbumId(Long aLong);

	/**
	 * 获取视频信息不包含扩展信息--不包含删除的视频信息
	 *
	 * @param id
	 * @return
	 */
	VideoModel getById(Long id);

	/**
	 * 获取视频信息包含扩展的视频信息,比如专辑名称/客户名称--不包含删除的视频信息
	 *
	 * @param id
	 * @return
	 */
//	VideoModel getAllInfoById(Long id);

	VideoModel save(VideoModel t);

	VideoModel create(VideoModel t);

	VideoModel modify(VideoModel t);

	/**
	 * 根据客户分类id获取当前分类下视频的数量--不包含删除的视频信息
	 *
	 * @param customCatgroyId
	 * @return
	 */
	int getVideoByCustomCategory(Long customCatgroyId);

	/**
	 * 根据多个客户分类id分组获取当前客户分类下视频的数量--不包含删除的视频信息
	 *
	 * @param list
	 * @return
	 */
	Map<Long, Long> getVideoCountByCustomCategoryId(List<CustomCategoryVo> list);

	/**
	 * 根据条件获取视频信息不分页--不包含删除的视频信息
	 *
	 * @param condition
	 * @return
	 */
	List<VideoModel> getVideoInfoByCondition(VideoCondition condition);

	void deleteVideo(Long videoId);

	Long getVideoCountByCondition(VideoCondition condition);

	VideoModel getbyChouZhenTaskId(String taskId);

	VideoModel getByBusinessUUID(String businessUUID);

//	VideoModel getAllInfoByBusinessUUID(String businessUUID);

	/**
	 * 根据视频id，对当前用户转码失败的视频添加重新转码任务
	 *
	 * @param videoId
	 *            视频id
	 * @param codeRates
	 *            需要重转的码率，多个时逗号","分隔
	 * @param transCodeFmts
	 *            文件格式mp4或hls。多个时逗号“,”分隔
	 * @param customId
	 *            当前用户id，请确保从session中获取
	 * @return true 添加重新转码任务成功，false 添加重新转码任务失败
	 * @author wangchaojie 2017年3月22日
	 */
	boolean createTranscodeTask(Long videoId, String codeRates, String transCodeFmts, Long customId,Long spId);

	/**
	 * 根据视频id，获取已转码的文件中标清文件的转码状态。
	 *
	 * @param videoId
	 *            视频id
	 */
	FileStatus transcodeSuccessCheck(Long videoId);

	void songShen(Long videoId, CustomModel customModel);

	List<VideoModel> getUploadFaildVideos();

	/**
	 * 向表中插入从老媒资同步的数据
	 *
	 * @param t
	 * @return
	 */
	VideoModel createIcms2MamModel(VideoModel t);

	List<Integer> getVideoInfoForSolr(VideoCondition condition);

	String returnLayerPicAllpicScale(String picOriginal,String picFinishedImg,Integer storageImgId);

    void updateStorageBySpid(VideoModel t);
}
