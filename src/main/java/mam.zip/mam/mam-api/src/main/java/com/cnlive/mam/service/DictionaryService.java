package com.cnlive.mam.service;

import com.cnlive.mam.condition.DictionaryCondition;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;
import java.util.Map;

/**
 * @author zhangxiaobin
 */
public interface DictionaryService
{

    List<Dictionary> getDictionaryByDicWord(String dicWord);

    List<Dictionary> getDictionary(String dicWord, Integer category);

    List<Integer> getDictionaryValues(String dicWord, Integer category);

    List<Dictionary> getCategorys();

    List<Dictionary> getAllDictionary();

    List<Dictionary> getDictionary(String dicWord, Integer category, String language);

    List<Dictionary> getCategorys(String language);

    List<Dictionary> getByCondition(DictionaryCondition condition);

    Long getByConditionCount(DictionaryCondition condition);

    Dictionary getById(Long id);

    void save(Dictionary t);

    void create(Dictionary t);

    void modify(Dictionary t);

    void delete(Integer dicId);

    Map<String, String> getDicInfo(String dicWord, String dicValues, Integer category);

    Dictionary getDictionaryByDicValue(String dicWord, Integer dicValue);

    List<Dictionary> getALLDictionaryInCategory(Integer category);

    DataGrid getPageByCondition(DictionaryCondition condition);

    Integer getMaxdicValue(Dictionary t);

}
