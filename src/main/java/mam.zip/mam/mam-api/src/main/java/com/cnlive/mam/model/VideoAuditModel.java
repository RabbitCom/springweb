package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.VideoAuditStatus;
import com.cnlive.mam.common.web.CustomStringSerializer;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhangxiaobin
 */

public class VideoAuditModel  implements Serializable{
    
    private static final long serialVersionUID = 5413327065879890062L;
    
    private Long id;
    private Long videoId;
    private String videoName;
    private Long customId;
    //1:乐视通过 ；2乐视不通过； 3客户通过； 4客户不通过
    private Integer action; 
    private String auditUser;
    private Integer auditReason;
    @JSONField(deserializeUsing = CustomStringSerializer.class)
    private String auditMessage;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date auditTime;
    //1:客户  2:乐视后台
    private Integer auditType; 
    //审核之前的状态
    private VideoAuditStatus videoPreStatus;
    //审核后的状态
    private VideoAuditStatus videoStatus;
    
    private String[] videoIds;
    
    @Id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getVideoId() {
        return videoId;
    }
    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }
    public Integer getAction() {
        return action;
    }
    public void setAction(Integer action) {
        this.action = action;
    }

    public VideoAuditStatus getVideoPreStatus() {
        return videoPreStatus;
    }

    public void setVideoPreStatus(VideoAuditStatus videoPreStatus) {
        this.videoPreStatus = videoPreStatus;
    }

    public VideoAuditStatus getVideoStatus() {
        return videoStatus;
    }

    public void setVideoStatus(VideoAuditStatus videoStatus) {
        this.videoStatus = videoStatus;
    }

    public String getAuditUser() {
        return auditUser;
    }
    public void setAuditUser(String auditUser) {
        this.auditUser = auditUser;
    }
    public Integer getAuditReason() {
        return auditReason;
    }
    public void setAuditReason(Integer auditReason) {
        this.auditReason = auditReason;
    }
    public String getAuditMessage() {
        return auditMessage;
    }
    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getAuditTime() {
        return auditTime;
    }
    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }
    public Integer getAuditType() {
        return auditType;
    }
    public void setAuditType(Integer auditType) {
        this.auditType = auditType;
    }
    public String getVideoName() {
        return videoName;
    }
    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }
    public Long getCustomId() {
        return customId;
    }
    public void setCustomId(Long customId) {
        this.customId = customId;
    }
    public String[] getVideoIds() {
        return videoIds;
    }
    public void setVideoIds(String[] videoIds) {
        this.videoIds = videoIds;
    }
}
