package com.cnlive.mam.service;

import com.cnlive.mam.model.StorageConfigsModel;

import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public interface StorageConfigsService {

    void save(StorageConfigsModel storageConfigsModel);

    void delete(Integer id);

    void modify(StorageConfigsModel storageConfigsModel);

    StorageConfigsModel getById(Integer id);

    List<StorageConfigsModel> getByStorageId(Integer storageId);

    List<Map<String,String>> getOutDomainWeightByStorageId(Integer storageId);
}
