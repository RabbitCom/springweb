package com.cnlive.mam.condition;

public class DictionaryCondition extends BaseCondition {
	private static final long serialVersionUID = -4058982028568123134L;
	
	private Integer category ; //分类
	
	private String showName; //'显示时需要多语言转化成真正语言显示值,该值是固定值'
    
    private String dicWord;  //'字典word，可以通过该值获取全部该word字典列表'
    
    
    private Integer dicValue; //'真正保存到其他表字段中的值。要制定自己的规则，按照规则去创建，不能自动增长'
    
    private String language;
    
	public String getLanguage() {
		return language;
	}


	public void setLanguage(String language) {
		this.language = language;
	}


	public Integer getCategory() {
		return category;
	}


	public void setCategory(Integer category) {
		this.category = category;
	}


	public String getShowName() {
		return showName;
	}


	public void setShowName(String showName) {
		this.showName = showName;
	}


	public String getDicWord() {
		return dicWord;
	}


	public void setDicWord(String dicWord) {
		this.dicWord = dicWord;
	}


	public Integer getDicValue() {
		return dicValue;
	}


	public void setDicValue(Integer dicValue) {
		this.dicValue = dicValue;
	}
    
	
}
