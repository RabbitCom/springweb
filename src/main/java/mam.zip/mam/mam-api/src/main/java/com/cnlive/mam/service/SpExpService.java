package com.cnlive.mam.service;

import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.model.SpExpModel;

import java.util.List;

/**
 * Created by zhangxiaobin on 2017/8/16.
 */
public interface SpExpService {

    SpExpModel save(SpExpModel model);

    SpExpModel create(SpExpModel model);

    SpExpModel modify(SpExpModel model);

    SpExpModel getById(Long id);

    List<SpExpModel> getBySpId(Long spId);

    /**
     * 根据spid、存储类型获取扩展信息
     * @param spId
     * @param type
     * @return
     */
    List<SpExpModel> getBySpIdAndStorageType(Long spId, StorageTypeEnum type);

    /**
     * 根据spid、存储类型、内容类型 获取扩展信息
     * @param spId
     * @param type
     * @param ContenType
     * @return
     */
    SpExpModel getBySpIdAndStorageTypeAndContentType(Long spId, StorageTypeEnum type, Integer ContenType);

}
