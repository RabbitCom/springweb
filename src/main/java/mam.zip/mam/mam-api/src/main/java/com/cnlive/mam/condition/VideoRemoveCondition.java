package com.cnlive.mam.condition;

public class VideoRemoveCondition extends BaseCondition{
	private static final long serialVersionUID = 1L;
	private Long videoId;
	private String videoName;
	private Long removeUserId;
    private String removeUser;
    private String businessUUID;
    private Long removeSpId;
	public String getBusinessUUID() {
		return businessUUID;
	}
	public void setBusinessUUID(String businessUUID) {
		this.businessUUID = businessUUID;
	}
	public Long getVideoId() {
		return videoId;
	}
	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}
	public String getVideoName() {
		return videoName;
	}
	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}
	public Long getRemoveUserId() {
		return removeUserId;
	}
	public void setRemoveUserId(Long removeUserId) {
		this.removeUserId = removeUserId;
	}
	public String getRemoveUser() {
		return removeUser;
	}
	public void setRemoveUser(String removeUser) {
		this.removeUser = removeUser;
	}
	public Long getRemoveSpId() {
		return removeSpId;
	}
	public void setRemoveSpId(Long removeSpId) {
		this.removeSpId = removeSpId;
	}
}
