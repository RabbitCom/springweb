package com.cnlive.mam.service;


import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.model.TranscodeTaskModel;
import com.cnlive.mam.vo.JsonResult;

public interface RemoteService {

	/**
	 * 转码服务
	 * @param cbMethod 回调方法 GET/POST
	 * @param cbUrl 回调地址
	 * @param task 转码任务对象
	 * @return 任务id
	 */
	String remoteTransCode(String cbMethod,  String cbUrl, TranscodeTaskModel task,String bucketName,String domain);
	
	/**
	 * 抽帧服务
	 * @param videoOriginUri
	 * @param spId
	 * @param cbMethod
	 * @param cbUrl
	 * @return 任务id
	 */
	String remoteChouZhen(String videoOriginUri, String spId,String cbMethod,  String cbUrl,String bucketName,Integer plat,String domain);

	/**
	 * 请求播控接口
	 * @param videoId
	 * @return
	 */
	JsonResult remoteDianBoPlay(Long videoId, ModelStatus status);

	/**
	 * 下线cms
	 * @param businessUUID
	 * @param spId
	 * @return
	 */
	JsonResult remoteCmsOffLine(String businessUUID,Long spId);

}
