package com.cnlive.mam.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author ZHANGXIAOBIN
 * 
 */
public class ShenHeMessageVo implements Serializable {

	private String video_id;//spId_videoId
	private Integer state;//3:已审核;4:未通过
	private String msg;//审核备注
	private String attr_tags;//审核意见标签

	public String getVideo_id() {
		return video_id;
	}

	public void setVideo_id(String video_id) {
		this.video_id = video_id;
	}

	public ShenHeMessageVo() {
	}



	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getAttr_tags() {
		return attr_tags;
	}

	public void setAttr_tags(String attr_tags) {
		this.attr_tags = attr_tags;
	}

	@Override
	public String toString() {
		return "ShenHeMessageVo [video_id=" + video_id + ", state=" + state + ", msg=" + msg + ", attr_tags="
				+ attr_tags + "]";
	}

}
