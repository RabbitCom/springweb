package com.cnlive.mam.service;

import com.cnlive.mam.model.CustomPermissionModel;
import com.cnlive.mam.model.CustomRoleModel;
import com.cnlive.mam.vo.CustomPermissionVo;

import java.util.List;

/**
 * Created by cuilongcan on 2017/5/10.
 */
public interface CustomPermissionService {

    CustomPermissionVo getCustomRolesByRoleId(Integer roleId);

    List<CustomPermissionModel> getPermissionByRoleId(Integer roleId);

    void insertCustomPermission(CustomRoleModel customRoleModel, List<String> menus);

    void delCustomPermission(Integer roleId);

    void updateCustomPermission(Integer roleId, String roleName, String description, List<String> menus);
}
