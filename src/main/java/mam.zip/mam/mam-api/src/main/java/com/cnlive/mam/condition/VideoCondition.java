package com.cnlive.mam.condition;

import java.util.Date;

import com.cnlive.mam.common.utils.Const;

public class VideoCondition extends BaseCondition
{

    /**
     *
     */
    private static final long serialVersionUID = 2297621606373827554L;
    // 视频ID
    private Long videoId;
    // 视频名称
    private String videoName;
    //客户审核状态
    private String[] customAuditStatusArray;
    private Integer customAuditStatus;
    //乐视审核状态
    private String[] letvAuditStatusArray;
    private Integer letvAuditStatus;
    // 客户分类ID
    private Long customCategoryId;
    private String[] customCategoryIds;
    // 视频所属客户
    private Long customId;

    private Long albumId;

    private String startTime;

    private String endTime;
    
    private String publishStartTime;//发布的开始时间
    
    private String publishEndTime;//发布的结束时间
  
    //播放地址
    private String videoPlyUrl;
    
    private Integer spAdmin;  //1 是   0 否

    //上下线状态
    private String[] onoffStatusArray;

    private String onoffStatus;

    //前端视频的审核状态
    private Integer auditStatus;

    private Integer videoType;

    private Long originVideoId;
    private Long category;

    private String videoIds;

    private String [] videoIdArray;

    private String videoSource;

    private Integer mmsType;
    
    private Integer fileStatus;
    
    private Date publishTime;
    
    private String businessUUID;
    
    private Integer publishState;
    
    // spId
    private Long spid;
    // 视频状态
    private Integer status;
    // 创建时间
    private Date createTime;

    private String institutionId ;//机构id

    private String createCustomName;

    private String [] customIds;

    private Integer sucai;

    private boolean publishList = false; //是否发布列表

    public boolean isPublishList() {
        return publishList;
    }

    public void setPublishList(boolean publishList) {
        this.publishList = publishList;
    }

    public Integer getSucai() {
        return sucai;
    }

    public void setSucai(Integer sucai) {
        this.sucai = sucai;
    }

    public String[] getCustomIds() {
        return customIds;
    }

    public void setCustomIds(String[] customIds) {
        this.customIds = customIds;
    }

    public String getCreateCustomName() {
        return createCustomName;
    }

    public void setCreateCustomName(String createCustomName) {
        this.createCustomName = createCustomName;
    }

    public Integer getSpAdmin() {
        return spAdmin;
    }

    public void setSpAdmin(Integer spAdmin) {
        this.spAdmin = spAdmin;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public Integer getPublishState() {
		return publishState;
	}

	public void setPublishState(Integer publishState) {
		this.publishState = publishState;
	}

	public String getBusinessUUID() {
		return businessUUID;
	}

	public void setBusinessUUID(String businessUUID) {
		this.businessUUID = businessUUID;
	}

	public String getVideoPlyUrl() {
		return videoPlyUrl;
	}

	public void setVideoPlyUrl(String videoPlyUrl) {
		this.videoPlyUrl = videoPlyUrl;
	}


	public Date getPublishTime() {
		return publishTime;
	}

	public void setPublishTime(Date publishTime) {
		this.publishTime = publishTime;
	}

	public Integer getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(Integer fileStatus) {
		this.fileStatus = fileStatus;
	}

	public Integer getMmsType() {
        return mmsType;
    }

    public void setMmsType(Integer mmsType) {
        this.mmsType = mmsType;
    }

    public String[] getVideoIdArray()
    {
        return videoIdArray;
    }

    public void setVideoIdArray(String[] videoIdArray)
    {
        this.videoIdArray = videoIdArray;
    }

    public String getVideoIds()
    {
        return videoIds;
    }

    public void setVideoIds(String videoIds) {
        this.videoIds = videoIds;
    }

    public String getVideoSource()
    {
        return videoSource;
    }

    public void setVideoSource(String videoSource)
    {
        this.videoSource = videoSource;
    }

    public Long getCategory()
    {
        return category;
    }

    public void setCategory(Long category)
    {
        this.category = category;
    }

    public VideoCondition()
    {
    }

    public VideoCondition(Long customId, int page, int rows, String onoffStatus,
                          Long customCategoryId, Long videoId, String videoName,
                          Integer customAuditStatus, Integer letvAuditStatus)
    {
        this.customId = customId;
        this.setPage(page);
        this.setRows(rows);
        this.onoffStatusArray = onoffStatus.split(Const.VALUE_DECOLLATOR);
        this.customCategoryId = (customCategoryId == 0L) ? null : customCategoryId;
        this.videoId = (videoId == 0L) ? null : videoId;
        this.videoName = videoName;
        this.customAuditStatus = customAuditStatus;
        this.letvAuditStatus = letvAuditStatus;
    }

    public Long getOriginVideoId()
    {
        return originVideoId;
    }

    public void setOriginVideoId(Long originVideoId)
    {
        this.originVideoId = originVideoId;
    }

    public Integer getVideoType()
    {
        return videoType;
    }

    public void setVideoType(Integer videoType)
    {
        this.videoType = videoType;
    }

    public Integer getAuditStatus()
    {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus)
    {
        this.auditStatus = auditStatus;
    }

    public String[] getCustomAuditStatusArray()
    {
        return customAuditStatusArray;
    }

    public void setCustomAuditStatusArray(String[] customAuditStatusArray)
    {
        this.customAuditStatusArray = customAuditStatusArray;
    }

    public String[] getLetvAuditStatusArray()
    {
        return letvAuditStatusArray;
    }

    public void setLetvAuditStatusArray(String[] letvAuditStatusArray)
    {
        this.letvAuditStatusArray = letvAuditStatusArray;
    }

    public String getStartTime()
    {
        return startTime;
    }

    public void setStartTime(String startTime)
    {
        this.startTime = startTime;
    }

    public String getEndTime()
    {
        return endTime;
    }

    public void setEndTime(String endTime)
    {
        this.endTime = endTime;
    }

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public String getVideoName()
    {
        return videoName;
    }

    public void setVideoName(String videoName)
    {
        this.videoName = videoName;
    }

    public Long getCustomCategoryId()
    {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId)
    {
        this.customCategoryId = customCategoryId;
    }

    public String[] getCustomCategoryIds()
    {
        return customCategoryIds;
    }

    public void setCustomCategoryIds(String[] customCategoryIds)
    {
        this.customCategoryIds = customCategoryIds;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public Long getAlbumId()
    {
        return albumId;
    }

    public void setAlbumId(Long albumId)
    {
        this.albumId = albumId;
    }

    public String[] getOnoffStatusArray()
    {
        return onoffStatusArray;
    }

    public void setOnoffStatusArray(String[] onoffStatusArray)
    {
        this.onoffStatusArray = onoffStatusArray;
    }

    public String getOnoffStatus()
    {
        return onoffStatus;
    }

    public void setOnoffStatus(String onoffStatus)
    {
        this.onoffStatus = onoffStatus;
    }

    public Integer getCustomAuditStatus()
    {
        return customAuditStatus;
    }

    public void setCustomAuditStatus(Integer customAuditStatus)
    {
        this.customAuditStatus = customAuditStatus;
    }

    public Integer getLetvAuditStatus()
    {
        return letvAuditStatus;
    }

    public void setLetvAuditStatus(Integer letvAuditStatus)
    {
        this.letvAuditStatus = letvAuditStatus;
    }

	public String getPublishStartTime() {
		return publishStartTime;
	}

	public void setPublishStartTime(String publishStartTime) {
		this.publishStartTime = publishStartTime;
	}

	public String getPublishEndTime() {
		return publishEndTime;
	}

	public void setPublishEndTime(String publishEndTime) {
		this.publishEndTime = publishEndTime;
	}

	public Long getSpid() {
		return spid;
	}

	public void setSpid(Long spid) {
		this.spid = spid;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
    
}
