package com.cnlive.mam.condition;

/**
 * Created by zhangxiaobin on 2017/6/6.
 */
public class AdminCondition extends BaseCondition{

    private Integer spId;

    public Integer getSpId() {
        return spId;
    }

    public void setSpId(Integer spId) {
        this.spId = spId;
    }
}
