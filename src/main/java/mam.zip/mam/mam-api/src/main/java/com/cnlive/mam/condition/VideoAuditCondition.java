package com.cnlive.mam.condition;


public class VideoAuditCondition extends BaseCondition{
    private static final long serialVersionUID = 5131141701593318105L;
    
    private Long videoId;
    
    private String videoName;
    //审核人
    private String auditUser;
    
    //审核开始时间
    private String auditTimeStart; 
    //审核结束时间
    private String auditTimeEnd;
    
    private Long customId;
    
    private Integer action;
    
    public Integer getAction() {
        return action;
    }
    public void setAction(Integer action) {
        this.action = action;
    }
    public Long getCustomId() {
        return customId;
    }
    public void setCustomId(Long customId) {
        this.customId = customId;
    }
    public Long getVideoId() {
        return videoId;
    }
    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }
    public String getAuditUser() {
        return auditUser;
    }
    public void setAuditUser(String auditUser) {
        this.auditUser = auditUser;
    }
    public String getAuditTimeStart() {
        return auditTimeStart;
    }
    public void setAuditTimeStart(String auditTimeStart) {
        this.auditTimeStart = auditTimeStart;
    }
    public String getAuditTimeEnd() {
        return auditTimeEnd;
    }
    public void setAuditTimeEnd(String auditTimeEnd) {
        this.auditTimeEnd = auditTimeEnd;
    }
    public String getVideoName() {
        return videoName;
    }
    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }
}
