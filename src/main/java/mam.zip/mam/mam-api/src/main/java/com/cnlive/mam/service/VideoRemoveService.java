package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.condition.VideoRemoveCondition;
import com.cnlive.mam.model.VideoRemoveModel;
import com.cnlive.mam.vo.DataGrid;

/**
 * Created by zhangxiaobin on 16/7/12.
 */
public interface VideoRemoveService {

    void create(VideoRemoveModel model);

    List<VideoRemoveModel> getRemoveVideo(VideoRemoveCondition video);

    VideoRemoveModel getOne(long id);

    void deleteRemoveVideo(long id);

    /**
     * 彻底删除视频及相关数据
     *
     * @param videoRemoveModel 视频回收站数据
     * @param curSpId          点击彻底删除操作的用户spId
     * @param curCustomId      点击彻底删除操作的用户customId
     * @param customId         视频所属人customId
     */
    void removeVideo(VideoRemoveModel videoRemoveModel, long curSpId, long curCustomId, long customId);

    /**
     * 彻底删除视频及相关数据
     *
     * @param videoId
     * @param videoName
     * @param curCustomId 操作人的customId
     * @param curSpId     操作人所属的spId
     * @param customId    视频所属人customId
     * @param delMsg      删除说明
     */
    void removeVideo(Long videoId, String videoName, Long curCustomId, Long curSpId, Long customId, String delMsg);

    DataGrid pageRemoveVideo(VideoRemoveCondition removeCondition);
}
