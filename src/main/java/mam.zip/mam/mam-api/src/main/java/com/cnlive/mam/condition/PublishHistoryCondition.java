package com.cnlive.mam.condition;

import java.io.Serializable;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
public class PublishHistoryCondition implements Serializable
{
    private Long publishHistoryId ;

    private Long videoId;

    private Long customId;

    private Integer blockId;

    private Integer publishState;

    private Integer publishType;

    private String publishUser;

    private String publishStartTime;

    private String publishEndTime;

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public Integer getBlockId()
    {
        return blockId;
    }

    public void setBlockId(Integer blockId)
    {
        this.blockId = blockId;
    }

    public Integer getPublishState()
    {
        return publishState;
    }

    public void setPublishState(Integer publishState)
    {
        this.publishState = publishState;
    }

    public Integer getPublishType()
    {
        return publishType;
    }

    public void setPublishType(Integer publishType)
    {
        this.publishType = publishType;
    }

    public String getPublishUser()
    {
        return publishUser;
    }

    public void setPublishUser(String publishUser)
    {
        this.publishUser = publishUser;
    }

    public String getPublishStartTime()
    {
        return publishStartTime;
    }

    public void setPublishStartTime(String publishStartTime)
    {
        this.publishStartTime = publishStartTime;
    }

    public String getPublishEndTime()
    {
        return publishEndTime;
    }

    public void setPublishEndTime(String publishEndTime)
    {
        this.publishEndTime = publishEndTime;
    }

    public Long getPublishHistoryId()
    {
        return publishHistoryId;
    }

    public void setPublishHistoryId(Long publishHistoryId)
    {
        this.publishHistoryId = publishHistoryId;
    }
}
