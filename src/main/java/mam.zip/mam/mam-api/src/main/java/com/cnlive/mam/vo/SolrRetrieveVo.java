package com.cnlive.mam.vo;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.model.VideoModel;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by cuilongcan on 7/12/2017.
 */
public class SolrRetrieveVo implements Serializable{
    public String id;
    public Long videoId;
    public String institutionId;
    public Integer contentType;
    public String contentName;
    public String contentTag;
    public String contentDes;
    public String contentSubtitle;
    public Long spId;
    public String customName;
    public Long albumId;
    public Integer episodeNow;
    public Integer sourceFrom;
    public Integer categoryId;
    public String director;
    public String actor;
    public String lecturer;
    public String anchor;
    public String compere;
    public String guest;
    public String screenwriter;
    public String filmProduce;
    public String singer;
    public String language;
    public String area;
    public Integer videoType;
    public Long videoDuration;
    public String original;
    public Date createTime;
    public Date updateTime;
    public Date publishTime;
    public String videoPlayUrl;
    public String videoPublishUrl;
    public String weigh;

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getContentType() {
        return contentType;
    }

    public void setContentType(Integer contentType) {
        this.contentType = contentType;
    }

    public String getContentName() {
        return contentName;
    }

    public void setContentName(String contentName) {
        this.contentName = contentName;
    }

    public String getContentTag() {
        return contentTag;
    }

    public void setContentTag(String contentTag) {
        this.contentTag = contentTag;
    }

    public String getContentDes() {
        return contentDes;
    }

    public void setContentDes(String contentDes) {
        this.contentDes = contentDes;
    }

    public String getContentSubtitle() {
        return contentSubtitle;
    }

    public void setContentSubtitle(String contentSubtitle) {
        this.contentSubtitle = contentSubtitle;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public Long getAlbumId() {
        return albumId;
    }

    public void setAlbumId(Long albumId) {
        this.albumId = albumId;
    }

    public Integer getEpisodeNow() {
        return episodeNow;
    }

    public void setEpisodeNow(Integer episodeNow) {
        this.episodeNow = episodeNow;
    }

    public Integer getSourceFrom() {
        return sourceFrom;
    }

    public void setSourceFrom(Integer sourceFrom) {
        this.sourceFrom = sourceFrom;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public String getAnchor() {
        return anchor;
    }

    public void setAnchor(String anchor) {
        this.anchor = anchor;
    }

    public String getCompere() {
        return compere;
    }

    public void setCompere(String compere) {
        this.compere = compere;
    }

    public String getGuest() {
        return guest;
    }

    public void setGuest(String guest) {
        this.guest = guest;
    }

    public String getScreenwriter() {
        return screenwriter;
    }

    public void setScreenwriter(String screenwriter) {
        this.screenwriter = screenwriter;
    }

    public String getFilmProduce() {
        return filmProduce;
    }

    public void setFilmProduce(String filmProduce) {
        this.filmProduce = filmProduce;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Integer getVideoType() {
        return videoType;
    }

    public void setVideoType(Integer videoType) {
        this.videoType = videoType;
    }

    public Long getVideoDuration() {
        return videoDuration;
    }

    public void setVideoDuration(Long videoDuration) {
        this.videoDuration = videoDuration;
    }

    public String getOriginal() {
        return original;
    }

    public void setOriginal(String original) {
        this.original = original;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getVideoPlayUrl() {
        return videoPlayUrl;
    }

    public void setVideoPlayUrl(String videoPlayUrl) {
        this.videoPlayUrl = videoPlayUrl;
    }

    public String getVideoPublishUrl() {
        return videoPublishUrl;
    }

    public void setVideoPublishUrl(String videoPublishUrl) {
        this.videoPublishUrl = videoPublishUrl;
    }

    public String getWeigh() {
        return weigh;
    }

    public void setWeigh(String weigh) {
        this.weigh = weigh;
    }

    //点播云model转换solrModel
    public SolrRetrieveVo videoToSolr(VideoModel videoModel) {

        this.setId(videoModel.getBusinessUUID());
        this.setVideoId(videoModel.getVideoId());
        this.setInstitutionId(videoModel.getInstitutionId());
        this.setContentType(1);//视频1 图片2 文本3
        this.setContentName(videoModel.getVideoName());
        this.setContentTag(videoModel.getTag());
        this.setContentDes(videoModel.getSynopsis());
        this.setContentSubtitle(videoModel.getSubTitle());
        this.setSpId(videoModel.getSpid());
        this.setAlbumId(videoModel.getAlbumId());
        this.setEpisodeNow(videoModel.getEpisode());//当前集数
        this.setSourceFrom(1);//1点播 2直播 3发布云  4用户云  5互动云
        this.setCategoryId(videoModel.getCategory());

        String extendStr = videoModel.getExtendProperties();
        if (StringUtils.isNotEmpty(extendStr)) {
            JSONObject extendObj = JSONObject.parseObject(extendStr);//扩展信息
            String actor = extendObj.getString("actor");
            String director = extendObj.getString("director");
            String lecturer = extendObj.getString("lecturer");
            String anchor = extendObj.getString("anchor");
            String compere = extendObj.getString("compere");
            String guest = extendObj.getString("guest");
            String screenwriter = extendObj.getString("screenwriter");
            String filmProduce = extendObj.getString("filmProduce");
            String singer = extendObj.getString("singer");
            String original = extendObj.getString("original");
            this.setDirector(StringUtils.isEmpty(director) ? "" : director);
            this.setActor(StringUtils.isEmpty(actor) ? "" : actor);
            this.setLecturer(StringUtils.isEmpty(lecturer) ? "" : lecturer);
            this.setAnchor(StringUtils.isEmpty(anchor) ? "" : anchor);
            this.setCompere(StringUtils.isEmpty(compere) ? "" : compere);
            this.setGuest(StringUtils.isEmpty(guest) ? "" : guest);
            this.setScreenwriter(StringUtils.isEmpty(screenwriter) ? "" : screenwriter);
            this.setFilmProduce(StringUtils.isEmpty(filmProduce) ? "" : filmProduce);
            this.setSinger(StringUtils.isEmpty(singer) ? "" : singer);
            this.setOriginal(StringUtils.isEmpty(original) ? "" : original);
        }
        this.setLanguage(videoModel.getLanguage());
        this.setArea(videoModel.getArea());
        this.setVideoType(videoModel.getVideoType());//正片1、预告片2、片花3
        this.setVideoDuration(videoModel.getDuration());
        this.setCreateTime(videoModel.getCreateTime());
        this.setUpdateTime(videoModel.getUpdateTime());
        this.setPublishTime(videoModel.getPublishTime());
        this.setVideoPlayUrl(videoModel.getVideoPlyUrl());
//        this.setVideoPublishUrl();
//        this.setWeigh();
        return this;
    }

    //solrModel转换点播云model
    public VideoModel solrToVideo(VideoModel videoModel) {

        videoModel.setBusinessUUID(this.getId());
//        this.getContentType(1);//视频1 图片2 文本3
        videoModel.setInstitutionId(this.getInstitutionId());
        videoModel.setVideoId(this.getVideoId());
        videoModel.setVideoName(this.getContentName());
        videoModel.setTag(this.getContentTag());
        videoModel.setSynopsis(this.getContentDes());
        videoModel.setSubTitle(this.getContentSubtitle());
        videoModel.setSpid(this.getSpId());
        videoModel.setAlbumId(this.getAlbumId());
        videoModel.setEpisode(this.getEpisodeNow());//当前集数
        videoModel.setCategory(this.getCategoryId());

        Map<String,Object> extendProperties = new HashMap<>();
        extendProperties.put("actor",this.getActor());
        extendProperties.put("director",this.getDirector());
        extendProperties.put("lecturer",this.getLecturer());
        extendProperties.put("anchor",this.getAnchor());
        extendProperties.put("compere",this.getCompere());
        extendProperties.put("guest",this.getGuest());
        extendProperties.put("screenwriter",this.getScreenwriter());
        extendProperties.put("filmProduce",this.getFilmProduce());
        extendProperties.put("singer",this.getSinger());
        extendProperties.put("original",this.getOriginal());
        videoModel.setExtendProperties(JSONObject.toJSONString(extendProperties));
        videoModel.setLanguage(this.getLanguage());
        videoModel.setArea(this.getArea());
        videoModel.setVideoType(this.getVideoType());//正片1、预告片2、片花3
        videoModel.setDuration(this.getVideoDuration());
        videoModel.setCreateTime(this.getCreateTime());
        videoModel.setUpdateTime(this.getUpdateTime());
        videoModel.setPublishTime(this.getPublishTime());
        videoModel.setVideoPlyUrl(this.getVideoPlayUrl());
        return videoModel;
    }
}
