package com.cnlive.mam.vo;

import java.util.List;

public class UnrealLiveResult implements java.io.Serializable {

    private static final long serialVersionUID = 4956998501845933642L;

    private String done;

    private Integer total;

    private List list;

    public String getDone() {
        return done;
    }

    public void setDone(String done) {
        this.done = done;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public UnrealLiveResult() {
        this.done = "ok";
    }
}
