package com.cnlive.mam.model;

import com.cnlive.mam.common.annotation.Id;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhangxiaobin
 */
public class CustomModel implements Serializable {

    private static final long serialVersionUID = 4055856491016769969L;
    private Long customId;
    private Integer letvApprove; // 内容是否需要letv审核，1需要，0不需要。管理系统配置默认1
    private String language;// 只能存3个值，en英文cn中文tw繁体中文 和国际化中的language对应 默认cn
    private List<String> rate;

    private String playDomain; // 管理系统配置
    private String name; // 客户名称，来自用户中心
    private String phone; // 联系方式，来自用户中心
    private String email; // 邮件

    private Integer flag; // 建站状态

    private String openedBusinessLine; // 已开通业务线

    private Long spId; // 入驻SP_ID
    private String contacts; // 联系人
    private Integer status; // 大网用户状态：1启用，2禁用
    private Integer isParent; // 是否主账号 0否，1是

    private String institutionId;
    private String institutionName;

    private Integer roleId; //用户所属角色
    private String roleName; //所属角色名称
    private String roleDescription;//所属角色描述

    private Integer menuId; //该用户下要显示的菜单id
    private String menuName; //该用户下要显示的菜单名称

    private Long tm;    //用户数据最近更新时间点

    public CustomModel() {
    }

    /**
     * 用户对接，用户数据初始值：<br>
     * 1、自动发布，自动上线，自动送审都是否；<br>
     * 2、水印默认开启，默认左上角；<br>
     * 3、默认码率标清800。
     *
     * @param customId 客户id
     * @param name     客户名称
     * @param contacts 联系人
     * @param status   大网用户状态：1启用，2禁用
     * @param phone    手机号
     */
    public CustomModel(Long customId, String name, String contacts, Integer status, String phone) {
        this.customId = customId;
        this.name = name;
        this.contacts = contacts;
        this.status = status;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPlayDomain() {
        return playDomain;
    }

    public void setPlayDomain(String playDomain) {
        this.playDomain = playDomain;
    }

    @Id
    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public Integer getLetvApprove() {
        return letvApprove;
    }

    public void setLetvApprove(Integer letvApprove) {
        this.letvApprove = letvApprove;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public List<String> getRate() {
        return rate;
    }

    public void setRate(List<String> rate) {
        this.rate = rate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getOpenedBusinessLine() {
        return openedBusinessLine;
    }

    public void setOpenedBusinessLine(String openedBusinessLine) {
        this.openedBusinessLine = openedBusinessLine;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsParent() {
        return isParent;
    }

    public void setIsParent(Integer isParent) {
        this.isParent = isParent;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public Long getTm() {
        return tm;
    }

    public void setTm(Long tm) {
        this.tm = tm;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }
}
