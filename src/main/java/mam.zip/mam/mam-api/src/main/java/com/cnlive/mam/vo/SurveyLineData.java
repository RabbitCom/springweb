package com.cnlive.mam.vo;

import com.alibaba.fastjson.JSONArray;

/**
 * Created by Administrator on 2017/6/7.
 */
public class SurveyLineData {

    private JSONArray data;
    private String name;

    public void setData(JSONArray data) {
        this.data = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getData() {
        return data;
    }

}
