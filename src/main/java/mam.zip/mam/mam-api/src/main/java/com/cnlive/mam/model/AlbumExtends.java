package com.cnlive.mam.model;

/**
 * Created by zhangxiaobin on 16/3/8.
 */
public class AlbumExtends
{
    private String customCategoryName; //

    private String customName; // 客户名称

    private Long videoCount;// 视频数量临时属性

    private String categoryName; // 数据分类名称展示

    private String institutionName; //机构名称

    private String updateCustomName; //最后修改人

    private String listPicUrl ;

    // 列表展示的图片
    public String getListPicUrl() {
        return listPicUrl;
    }

    public void setListPicUrl(String listPicUrl){
        this.listPicUrl = listPicUrl;
    }

    public String getUpdateCustomName() {
        return updateCustomName;
    }

    public void setUpdateCustomName(String updateCustomName) {
        this.updateCustomName = updateCustomName;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getCustomCategoryName()
    {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName)
    {
        this.customCategoryName = customCategoryName;
    }

    public String getCustomName()
    {
        return customName;
    }

    public void setCustomName(String customName)
    {
        this.customName = customName;
    }

    public Long getVideoCount()
    {
        return videoCount;
    }

    public void setVideoCount(Long videoCount)
    {
        this.videoCount = videoCount;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
