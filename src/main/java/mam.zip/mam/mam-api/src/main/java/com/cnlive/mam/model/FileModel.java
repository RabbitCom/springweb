package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.FileStatus;


//必须加注解 如果asm为true无法使用自定义的序列化类
@JSONType(asm=false)
public class FileModel implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -2239519881661854078L;
	private Long fileId;
    private String videoName;
    private Long videoId;
    private Integer codeRate; //码率
    private String codeRateName; //码率名称
    private Long fileSize;
    private String md5;
    private Long duration; //时长
    private FileStatus status; 
    private String storeUri; //转码后的地址
    private Date pubTime;
    private String interfaceTypes;

    // 补充扩展属性，以供 weboutapi 使用
    private Long gbr;
    private Integer videoHeight;
    private Integer videoWidth;
    private String gfmt;   //文件类型,文件扩展名,mp4,flv
    
    private boolean deleted;
    
    private String originUri; //上传源地址
    private String taskId; //转码任务ID
    
    private String res; //分辨率
    private String muuid; //媒资id
    private String transCodeFmt; //转码后的文件扩展名

    private String storeUriDomain;
    private String originUriDomain;
    private Integer storageType;

    private String transCodeFailMsg;


    private String resOrigin; //原视频分辨率
    private String vbrOrigin; //原视频码流
    private String sizeOrigin;//原视频大小
    private String ratioOrigin;//原视频比例

    private Integer storageTranscode;
    private Integer storageDistribute;

    public Integer getStorageType() {
        return storageType;
    }

    public void setStorageType(Integer storageType) {
        this.storageType = storageType;
    }

    public Integer getStorageTranscode() {
        return storageTranscode;
    }

    public void setStorageTranscode(Integer storageTranscode) {
        this.storageTranscode = storageTranscode;
    }

    public Integer getStorageDistribute() {
        return storageDistribute;
    }

    public void setStorageDistribute(Integer storageDistribute) {
        this.storageDistribute = storageDistribute;
    }

    public String getResOrigin() {
        return resOrigin;
    }

    public void setResOrigin(String resOrigin) {
        this.resOrigin = resOrigin;
    }

    public String getVbrOrigin() {
        return vbrOrigin;
    }

    public void setVbrOrigin(String vbrOrigin) {
        this.vbrOrigin = vbrOrigin;
    }

    public String getSizeOrigin() {
        return sizeOrigin;
    }

    public void setSizeOrigin(String sizeOrigin) {
        this.sizeOrigin = sizeOrigin;
    }

    public String getRatioOrigin() {
        return ratioOrigin;
    }

    public void setRatioOrigin(String ratioOrigin) {
        this.ratioOrigin = ratioOrigin;
    }

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date transcodeBtime;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date transcodeEtime;
    private String transcodeHaoshi;

    public String getTranscodeHaoshi() {
        return transcodeHaoshi;
    }

    public void setTranscodeHaoshi(String transcodeHaoshi) {
        this.transcodeHaoshi = transcodeHaoshi;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getTranscodeBtime() {
        return transcodeBtime;
    }

    public void setTranscodeBtime(Date transcodeBtime) {
        this.transcodeBtime = transcodeBtime;
    }

    public Date getTranscodeEtime() {
        return transcodeEtime;
    }

    public void setTranscodeEtime(Date transcodeEtime) {
        this.transcodeEtime = transcodeEtime;
    }

    public String getTransCodeFailMsg() {
        return transCodeFailMsg;
    }

    public void setTransCodeFailMsg(String transCodeFailMsg) {
        this.transCodeFailMsg = transCodeFailMsg;
    }

    public String getStoreUriDomain() {
		return storeUriDomain;
	}

	public void setStoreUriDomain(String storeUriDomain) {
		this.storeUriDomain = storeUriDomain;
	}

	public String getOriginUriDomain() {
		return originUriDomain;
	}

	public void setOriginUriDomain(String originUriDomain) {
		this.originUriDomain = originUriDomain;
	}

	public String getCodeRateName() {
        return codeRateName;
    }

    public void setCodeRateName(String codeRateName) {
        this.codeRateName = codeRateName;
    }

    public String getTransCodeFmt() {
		return transCodeFmt;
	}

	public void setTransCodeFmt(String transCodeFmt) {
		this.transCodeFmt = transCodeFmt;
	}

	public String getRes() {
		return res;
	}

	public void setRes(String res) {
		this.res = res;
	}

	public String getMuuid() {
		return muuid;
	}

	public void setMuuid(String muuid) {
		this.muuid = muuid;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getOriginUri() {
		return originUri;
	}

	public void setOriginUri(String originUri) {
		this.originUri = originUri;
	}

	public FileModel( Long videoId, String videoName) {
        this.videoId = videoId;
        this.videoName = videoName;
        this.status = FileStatus.New;
    }

    public FileModel( Long videoId, Integer codeRate,Long fileSize) {
        this.videoId = videoId;
        this.codeRate = codeRate;
        this.status = FileStatus.New;
        this.fileSize = fileSize;
    }
    
    public FileModel(String transCodeFmt,Integer codeRate, Long videoId, String videoName,String originUri,String gfmt,String md5,Long fileSize) {
        this.videoId = videoId;
        this.videoName = videoName;
        this.status = FileStatus.New;
        this.originUri = originUri;
        this.gfmt = gfmt;
        this.md5 = md5;
        this.createTime = new Date();
        this.fileSize = fileSize;
        this.codeRate = codeRate;
        this.transCodeFmt = transCodeFmt;
    }

    public FileModel() {
    }

    @Id
    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Integer getCodeRate() {
        return codeRate;
    }

    public void setCodeRate(Integer codeRate) {
        this.codeRate = codeRate;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public FileStatus getStatus() {
        return status;
    }

    public void setStatus(FileStatus status) {
        this.status = status;
    }

    public String getStoreUri() {
        return storeUri;
    }

    public void setStoreUri(String storeUri) {
        this.storeUri = storeUri;
    }

    public Date getPubTime() {
        return pubTime;
    }

    public void setPubTime(Date pubTime) {
        this.pubTime = pubTime;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getInterfaceTypes() {
        return interfaceTypes;
    }

    public void setInterfaceTypes(String interfaceTypes) {
        this.interfaceTypes = interfaceTypes;
    }

    public Long getGbr() {
        return gbr;
    }

    public void setGbr(Long gbr) {
        this.gbr = gbr;
    }

    public Integer getVideoHeight() {
        return videoHeight;
    }

    public void setVideoHeight(Integer videoHeight) {
        this.videoHeight = videoHeight;
    }

    public Integer getVideoWidth() {
        return videoWidth;
    }

    public void setVideoWidth(Integer videoWidth) {
        this.videoWidth = videoWidth;
    }
    public String getGfmt() {
        return gfmt;
    }

    public void setGfmt(String gfmt) {
        this.gfmt = gfmt;
    }

	public Long getVideoId() {
		return videoId;
	}

	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}
    
    
}
