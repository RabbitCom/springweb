package com.cnlive.mam.vo;

import java.io.Serializable;

/**
 * Created by zhangxiaobin on 16/11/24.
 */
public class TranCodeResult implements Serializable {

    private Integer busId;
    //码率code
    private Integer codeRate;

    //码率名称
    private String codeRateText;

    //进度
    private String process;

    //错误信息
    private String errorMsg;

    private Integer errorCode;

    //预估剩余时间
    private String surplusTime;

    //分发状态 -1无任务/0分发中/1分发成功/2分发失败
    private Integer distributState;

    //0上传中 1上传成功 2 上传失败
    private Integer uploadState;

    public Integer getBusId()
    {
        return busId;
    }

    public void setBusId(Integer busId)
    {
        this.busId = busId;
    }

    public Integer getUploadState()
    {
        return uploadState;
    }

    public void setUploadState(Integer uploadState)
    {
        this.uploadState = uploadState;
    }

    public Integer getDistributState()
    {
        return distributState;
    }

    public void setDistributState(Integer distributState)
    {
        this.distributState = distributState;
    }

    public String getSurplusTime()
    {
        return surplusTime;
    }

    public void setSurplusTime(String surplusTime)
    {
        this.surplusTime = surplusTime;
    }

    public Integer getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode)
    {
        this.errorCode = errorCode;
    }

    public Integer getCodeRate()
    {
        return codeRate;
    }

    public void setCodeRate(Integer codeRate)
    {
        this.codeRate = codeRate;
    }

    public String getCodeRateText()
    {
        return codeRateText;
    }

    public void setCodeRateText(String codeRateText)
    {
        this.codeRateText = codeRateText;
    }

    public String getProcess()
    {
        return process;
    }

    public void setProcess(String process)
    {
        this.process = process;
    }

    public String getErrorMsg()
    {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg)
    {
        this.errorMsg = errorMsg;
    }


}
