package com.cnlive.mam.condition;

public class AlbumCondition extends BaseCondition
{

    private static final long serialVersionUID = 7758670212045856886L;

    private Long albumId;

    private String albumName;

    private String eqAlbumName;

    private Long customCategoryId;
    private String[] customCategoryIds;
    private Long customId;

    private String startTime;

    private String endTime;

    private String[] albumStatusArray;

    private String albumStatus;
    private Long category;

    private String albumIds;

    private Long spId;

    private String institutionId;

    private Integer spAdmin;  //1 是   0 否

    public Integer getSpAdmin() {
        return spAdmin;
    }

    public void setSpAdmin(Integer spAdmin) {
        this.spAdmin = spAdmin;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    private String [] albumIdArray;

    public String[] getAlbumIdArray()
    {
        return albumIdArray;
    }

    public void setAlbumIdArray(String[] albumIdArray)
    {
        this.albumIdArray = albumIdArray;
    }

    public String getAlbumIds()
    {
        return albumIds;
    }

    public void setAlbumIds(String albumIds)
    {
        this.albumIds = albumIds;
    }

    public Long getCategory()
    {
        return category;
    }

    public void setCategory(Long category)
    {
        this.category = category;
    }

    public String[] getAlbumStatusArray()
    {
        return albumStatusArray;
    }

    public void setAlbumStatusArray(String[] albumStatusArray)
    {
        this.albumStatusArray = albumStatusArray;
    }

    public String getAlbumStatus()
    {
        return albumStatus;
    }

    public void setAlbumStatus(String albumStatus)
    {
        this.albumStatus = albumStatus;
    }

    public String getStartTime()
    {
        return startTime;
    }

    public void setStartTime(String startTime)
    {
        this.startTime = startTime;
    }

    public String getEndTime()
    {
        return endTime;
    }

    public void setEndTime(String endTime)
    {
        this.endTime = endTime;
    }

    public String[] getCustomCategoryIds()
    {
        return customCategoryIds;
    }

    public void setCustomCategoryIds(String[] customCategoryIds)
    {
        this.customCategoryIds = customCategoryIds;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public Long getAlbumId()
    {
        return albumId;
    }

    public void setAlbumId(Long albumId)
    {
        this.albumId = albumId;
    }

    public String getAlbumName()
    {
        return albumName;
    }

    public void setAlbumName(String albumName)
    {
        this.albumName = albumName;
    }

    public Long getCustomCategoryId()
    {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId)
    {
        this.customCategoryId = customCategoryId;
    }

    public String getEqAlbumName()
    {
        return eqAlbumName;
    }

    public void setEqAlbumName(String eqAlbumName)
    {
        this.eqAlbumName = eqAlbumName;
    }
}
