package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.model.OptionsInfo;

public interface OptionsInfoService {

	  void create(OptionsInfo optionsInfo);
	  
	  OptionsInfo selectByMd5(String md5);
	  
	  List<OptionsInfo> getPage();
	  
	  void delete(Long id);
}
