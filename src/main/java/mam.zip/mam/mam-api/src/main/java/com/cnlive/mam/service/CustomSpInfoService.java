package com.cnlive.mam.service;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.condition.AdminCondition;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.vo.DataGrid;

import java.util.Map;

public interface CustomSpInfoService {

	CustomSpInfoModel getBySpId(Long spId);

    void save(CustomSpInfoModel customSpInfoModel);

    void create(CustomSpInfoModel customSpInfoModel);

    void modify(CustomSpInfoModel customSpInfoModel);

    DataGrid pageSpInfoForAdmin(AdminCondition condition);

    /**
     * 获取当前存储下的logoURL {'path':'xxxx','bucket':'xxxx','domain':'xxxx'}
     * @param spId
     * @return
     */
    JSONObject getLogoUrl(Long spId);

    /**
     * 获取当前存储下的片头片尾  {'pt':'xxx','pw':'xxx','bucket':'xxx','domain':'xxxx'}
     * @param spId
     * @return
     */
    JSONObject getPtPw(Long spId);

}
