package com.cnlive.mam.condition;

import com.cnlive.mam.common.enums.PublishStateEnum;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 用以接受视频发布相关属性的VO
 * Created by zhangxiaobin
 */
public class VideoPublishCondition extends BaseCondition {

    //视频相关查询
    private Long categoryId;
    private Long customCategoryId;
    private String videoName;
    private Long videoId;
    //任务相关查询
    private Integer publishState;
    private String publishTimeStart;
    private String publishTimeEnd;

    private String onoffstatus;
    private String[] onoffStatusArray;
    private Long customId;

    public String getOnoffstatus()
    {
        return onoffstatus;
    }

    public void setOnoffstatus(String onoffstatus)
    {
        this.onoffstatus = onoffstatus;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public Long getCustomCategoryId() {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId) {
        this.customCategoryId = customCategoryId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Integer getPublishState() {
        return publishState;
    }

    public void setPublishState(Integer publishState) {
        this.publishState = publishState;
    }

    public String getPublishTimeStart() {
        return publishTimeStart;
    }

    public void setPublishTimeStart(String publishTimeStart) {
        this.publishTimeStart = publishTimeStart;
    }

    public String getPublishTimeEnd() {
        return publishTimeEnd;
    }

    public void setPublishTimeEnd(String publishTimeEnd) {
        this.publishTimeEnd = publishTimeEnd;
    }

    public String[] getOnoffStatusArray() {
        return onoffStatusArray;
    }

    public void setOnoffStatusArray(String[] onoffStatusArray) {
        this.onoffStatusArray = onoffStatusArray;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

}
