package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.utils.Const;
@JSONType(asm=false)
public class TranscodeTaskModel implements Serializable{

	private static final long serialVersionUID = -4400314099837309633L;
	
	private Long id;
	// 视频ID
    private Long videoId;
    // 客户ID
    private Long customId;
    // 客户spId
    private Long spId;
    //创建时间
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    // 视频文件源地址
    private String fileOriginUri;
    // 转码码率 多个时逗号分隔
    private String codeRate;
    // 转码任务id
    private String fileTaskId;
    // 转码进行状态：0初始化，1转码中
    private Integer status;
    // 是否为重新转码的任务：0否，1是
    private Integer isReTranscode;
    // 转码的文件格式
    private String transCodeFmt;
    // 水印图片地址
    private String logoPicUrl;
    // 水印位置 左上角:0 右上角:1 左下角:2 右上角:3
    private Integer logoSite;

    private Integer plat;

    private String headFile;

    private String endFile;

	public String getHeadFile() {
		return headFile;
	}

	public void setHeadFile(String headFile) {
		this.headFile = headFile;
	}

	public String getEndFile() {
		return endFile;
	}

	public void setEndFile(String endFile) {
		this.endFile = endFile;
	}

	public Integer getPlat() {
		return plat;
	}

	public void setPlat(Integer plat) {
		this.plat = plat;
	}

	public TranscodeTaskModel() {
    }

    /**
     * @param videoId 视频id
     * @param customId 客户id
     * @param codeRate 转码码率
     * @param fileOriginUri 视频源地址
     */
    public TranscodeTaskModel(Long videoId, Long customId, Long spId, String codeRate, String fileOriginUri) {
		this.videoId = videoId;
		this.customId = customId;
		this.spId = spId;
		this.codeRate = codeRate;
		this.fileOriginUri = fileOriginUri;
		this.status = Const.TRANSCODETASK_INIT;
		this.isReTranscode = Const.IS_RETRANSCODE_NO;
		this.createTime = new Date();
	}

	@Id
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public String getCodeRate() {
		return codeRate;
	}

	public void setCodeRate(String codeRate) {
		this.codeRate = codeRate;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

	public String getFileOriginUri() {
		return fileOriginUri;
	}

	public void setFileOriginUri(String fileOriginUri) {
		this.fileOriginUri = fileOriginUri;
	}

	public String getFileTaskId() {
		return fileTaskId;
	}

	public void setFileTaskId(String fileTaskId) {
		this.fileTaskId = fileTaskId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIsReTranscode() {
		return isReTranscode;
	}

	public void setIsReTranscode(Integer isReTranscode) {
		this.isReTranscode = isReTranscode;
	}

	public String getTransCodeFmt() {
		return transCodeFmt;
	}

	public void setTransCodeFmt(String transCodeFmt) {
		this.transCodeFmt = transCodeFmt;
	}

	public String getLogoPicUrl() {
		return logoPicUrl;
	}

	public void setLogoPicUrl(String logoPicUrl) {
		this.logoPicUrl = logoPicUrl;
	}

	public Integer getLogoSite() {
		return logoSite;
	}

	public void setLogoSite(Integer logoSite) {
		this.logoSite = logoSite;
	}
}
