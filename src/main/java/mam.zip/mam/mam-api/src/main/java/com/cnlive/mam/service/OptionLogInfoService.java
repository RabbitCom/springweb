package com.cnlive.mam.service;

import com.cnlive.mam.condition.LogInfoCondition;
import com.cnlive.mam.model.OptionLogInfo;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;

/**
 * Created by zhangxiaobin on 2017/5/2.
 */
public interface OptionLogInfoService {

//    void save (OptionLogInfo optionLogInfo);

    void create(OptionLogInfo optionLogInfo);

    DataGrid dataGrid(LogInfoCondition condition);

    List<OptionLogInfo> getByVideoBusinessId(String videoBusinessId);

}
