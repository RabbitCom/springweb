package com.cnlive.mam.service;

import com.cnlive.mam.model.VideoDeleteHistoryModel;

public interface VideoDeleteHistoryService {

    VideoDeleteHistoryModel create(VideoDeleteHistoryModel task);

}
