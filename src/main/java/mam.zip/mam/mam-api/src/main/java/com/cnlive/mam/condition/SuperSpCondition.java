package com.cnlive.mam.condition;

/**
 * Created by zhangxiaobin on 2017/3/31.
 */
public class SuperSpCondition extends BaseCondition{

    private Long videoId;
    private String videoName;
    private Long spId;
    private Long customId;
    private String uploadStartTime;
    private String uploadEndTime;
    private String publishStartTime;
    private String publishEndTime;
    private Integer fileStatus;
    private String onoffStatus;
    private Long category;
    // 客户分类ID
    private Long customCategoryId;
    //上下线状态
    private String[] onoffStatusArray;
    private String businessUUID;

    private String institutionId ;//机构id

    private Integer spAdmin;  //1 是   0 否

    private Integer isIcms2MamForLiveFalse;// 虚拟直播用，处理 wideo01 wideo02 wideo03 的数据

    public Integer getIsIcms2MamForLiveFalse() {
        return isIcms2MamForLiveFalse;
    }

    public void setIsIcms2MamForLiveFalse(Integer isIcms2MamForLiveFalse) {
        this.isIcms2MamForLiveFalse = isIcms2MamForLiveFalse;
    }

    public Integer getSpAdmin() {
        return spAdmin;
    }

    public void setSpAdmin(Integer spAdmin) {
        this.spAdmin = spAdmin;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public String getBusinessUUID() {
        return businessUUID;
    }

    public void setBusinessUUID(String businessUUID) {
        this.businessUUID = businessUUID;
    }

    public Long getCustomCategoryId() {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId) {
        this.customCategoryId = customCategoryId;
    }

    public String[] getOnoffStatusArray() {
        return onoffStatusArray;
    }

    public void setOnoffStatusArray(String[] onoffStatusArray) {
        this.onoffStatusArray = onoffStatusArray;
    }

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getUploadStartTime() {
        return uploadStartTime;
    }

    public void setUploadStartTime(String uploadStartTime) {
        this.uploadStartTime = uploadStartTime;
    }

    public String getUploadEndTime() {
        return uploadEndTime;
    }

    public void setUploadEndTime(String uploadEndTime) {
        this.uploadEndTime = uploadEndTime;
    }

    public String getPublishStartTime() {
        return publishStartTime;
    }

    public void setPublishStartTime(String publishStartTime) {
        this.publishStartTime = publishStartTime;
    }

    public String getPublishEndTime() {
        return publishEndTime;
    }

    public void setPublishEndTime(String publishEndTime) {
        this.publishEndTime = publishEndTime;
    }

    public Integer getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(Integer fileStatus) {
        this.fileStatus = fileStatus;
    }

    public String getOnoffStatus() {
        return onoffStatus;
    }

    public void setOnoffStatus(String onoffStatus) {
        this.onoffStatus = onoffStatus;
    }

    public Long getCategory() {
        return category;
    }

    public void setCategory(Long category) {
        this.category = category;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }
}
