package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.model.VideoDeleteTaskModel;

public interface VideoDeleteTaskService {

    VideoDeleteTaskModel create(VideoDeleteTaskModel task);

    /**
     * 删除任务及相关视频文件信息，并记录在历史表中
     *
     * @param task 视频彻底删除任务
     */
    void delete(VideoDeleteTaskModel task);

    /**
     * 删除任务
     *
     * @param id 任务id
     */
    void delete(Long id);

    List<VideoDeleteTaskModel> getAll();

    void delVideoAndFile(Long videoId);

}
