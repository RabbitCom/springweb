package com.cnlive.mam.vo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class CustomCategoryTree implements Serializable {

    private static final long serialVersionUID = 3290969854808173438L;

    private String id;
    private String text;
    private List<CustomCategoryTree> children =  new LinkedList<CustomCategoryTree>();
    private String pid;
    private Long videoCount = 0L;
    private Long albumCount = 0L;
    private String categoryName;
    private Integer category;
    private Integer auditSetting;
    private String categoryRelation;

    public CustomCategoryTree(){

    }

    public CustomCategoryTree(String id, String pid, String text, List<CustomCategoryTree> children){
        this.id = id;
        this.pid = pid;
        this.text = text;
        this.children = children;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getVideoCount() {
        return videoCount;
    }

    public void setVideoCount(Long videoCount) {
        this.videoCount = videoCount;
    }

    public Long getAlbumCount() {
        return albumCount;
    }

    public void setAlbumCount(Long albumCount) {
        this.albumCount = albumCount;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
    public List<CustomCategoryTree> getChildren() {
        return children;
    }
    public void setChildren(List<CustomCategoryTree> children) {
        this.children = children;
    }
    public String getPid() {
        return pid;
    }
    public void setPid(String pid) {
        this.pid = pid;
    }

    public Integer getCategory()
    {
        return category;
    }

    public void setCategory(Integer category)
    {
        this.category = category;
    }

    public Integer getAuditSetting()
    {
        return auditSetting;
    }

    public void setAuditSetting(Integer auditSetting)
    {
        this.auditSetting = auditSetting;
    }

	public String getCategoryRelation() {
		return categoryRelation;
	}

	public void setCategoryRelation(String categoryRelation) {
		this.categoryRelation = categoryRelation;
	}
    
}