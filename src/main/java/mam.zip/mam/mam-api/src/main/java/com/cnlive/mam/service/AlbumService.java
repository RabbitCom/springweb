package com.cnlive.mam.service;

import java.util.List;
import java.util.Map;

import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;

/**
 * @author zhangxiaobin
 *
 */
public interface AlbumService {
	DataGrid getPageByCondition(AlbumCondition condition);

	Map<String, Object> getVideoList(Long aId, String videoType);

	AlbumModel getById(Long id);

	AlbumModel save(AlbumModel t);

	AlbumModel create(AlbumModel t);

	AlbumModel modify(AlbumModel t);

	void delete(AlbumModel t);

	int getAlbumByCustomCategory(Long customCatgroyId);

	Map<Long, Long> getAlbumCountByCustomCategoryId(List<CustomCategoryVo> customCategoryList);

	boolean checkCanAddVideo(Long albumId);

	List<AlbumModel> getAlbumInfoByCondition(AlbumCondition condition);

	List<Map<String, String>> getAlbumAll(Long customId);

	Long checkAlbumNameExist(Long spId, String albumName, Long albumId);

	void setCustomCategory(AlbumModel albumModel);

	AlbumModel selectByOriginAlbumIdAndCustomId(Long albumId, Long customId);

	List returnLayerPicAllpicScale(String picFinishedImg,Integer storageImgId);

}
