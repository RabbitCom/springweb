package com.cnlive.mam.vo;

import java.util.List;

/**
 * Created by Administrator on 2017/6/7.
 */
public class SurveyLineDataList {
    private List dataTime;
    private List<SurveyLineData> jsonList;

    public List getDataTime() {
        return dataTime;
    }

    public void setDataTime(List dataTime) {
        this.dataTime = dataTime;
    }

    public List<SurveyLineData> getJsonList() {

        return jsonList;
    }

    public void setJsonList(List<SurveyLineData> jsonList) {
        this.jsonList = jsonList;
    }
}
