package com.cnlive.mam.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
@JSONType(asm=false)
public class VideoPublishInfo implements Serializable {

    private Long videoId;

    private String videoName;

    private Long customId;

    private String publishUser; //发布人

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date publishTime; //发布时间

    private Integer status; // 视频上下线状态 参照 ModelStatus

    private Integer auditStatus ; //视频审核状态 参照 VideoAuditStatus
    private Integer letvAuditStatus;
    private Integer customAuditStatus;

    private String tobePublishBlockIds; //待发布栏目
    private String tobePublishBlockNames;

    private String publishBlockIds;  //已发布栏目
    private String publishBlockNames;

    private Integer publishStatus; //发布状态

    private Integer publishType; //发布类型

    public Integer getPublishType()
    {
        return publishType;
    }

    public void setPublishType(Integer publishType)
    {
        this.publishType = publishType;
    }

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date prePublishedTime;

    public String getTobePublishBlockNames()
    {
        return tobePublishBlockNames;
    }

    public void setTobePublishBlockNames(String tobePublishBlockNames)
    {
        this.tobePublishBlockNames = tobePublishBlockNames;
    }

    public String getPublishBlockNames()
    {
        return publishBlockNames;
    }

    public void setPublishBlockNames(String publishBlockNames)
    {
        this.publishBlockNames = publishBlockNames;
    }

    public Date getPrePublishedTime()
    {
        return prePublishedTime;
    }

    public void setPrePublishedTime(Date prePublishedTime)
    {
        this.prePublishedTime = prePublishedTime;
    }

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public String getVideoName()
    {
        return videoName;
    }

    public void setVideoName(String videoName)
    {
        this.videoName = videoName;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public String getPublishUser()
    {
        return publishUser;
    }

    public void setPublishUser(String publishUser)
    {
        this.publishUser = publishUser;
    }

    public Date getPublishTime()
    {
        return publishTime;
    }

    public void setPublishTime(Date publishTime)
    {
        this.publishTime = publishTime;
    }

    public Integer getStatus()
    {
        return status;
    }

    public void setStatus(Integer status)
    {
        this.status = status;
    }

    public Integer getAuditStatus()
    {
        return auditStatus;
    }

    public void setAuditStatus(Integer auditStatus)
    {
        this.auditStatus = auditStatus;
    }

    public String getTobePublishBlockIds()
    {
        return tobePublishBlockIds;
    }

    public void setTobePublishBlockIds(String tobePublishBlocks)
    {
        this.tobePublishBlockIds = tobePublishBlocks;
    }

    public String getPublishBlockIds()
    {
        return publishBlockIds;
    }

    public void setPublishBlockIds(String publishBlocks)
    {
        this.publishBlockIds = publishBlocks;
    }

    public Integer getPublishStatus()
    {
        return publishStatus;
    }

    public void setPublishStatus(Integer publishStatus)
    {
        this.publishStatus = publishStatus;
    }

    public Integer getLetvAuditStatus() {
        return letvAuditStatus;
    }

    public void setLetvAuditStatus(Integer letvAuditStatus) {
        this.letvAuditStatus = letvAuditStatus;
    }

    public Integer getCustomAuditStatus() {
        return customAuditStatus;
    }

    public void setCustomAuditStatus(Integer customAuditStatus) {
        this.customAuditStatus = customAuditStatus;
    }
}
