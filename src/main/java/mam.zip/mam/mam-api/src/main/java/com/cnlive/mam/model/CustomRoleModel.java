package com.cnlive.mam.model;

import java.io.Serializable;

public class CustomRoleModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 8860101755921160928L;

    private Integer roleId;
    private String roleName;
    private Integer pId;
    private Integer spId;
    private String description;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSpId() {
        return spId;
    }

    public void setSpId(Integer spId) {
        this.spId = spId;
    }
}
