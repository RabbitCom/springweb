package com.cnlive.mam.service;

import com.cnlive.mam.condition.VideoCondition;

import java.util.List;
import java.util.Map;

/**
 * @author GuoYaqi
 */
public interface StatService {
	/**
	 * 统计前7天，每天上传量
	 * @param spid
	 * @return
	 */
	public Map<String, Long> count7DayUploadVideoBySpId(Long spid,String jigouId,boolean isSpAdmin);
	
	/**
	 * 统计前7天，每天发布成功量
	 * @param spid
	 * @return
	 */
	public Map<String, Long> count7DayPublishSucceedVideoBySpId(Long spid,String jigouId,boolean isSpAdmin);
	
	/**
	 * 统计前7天，每天发布失败量
	 * @param spid
	 * @return
	 */
	public Map<String, Long> count7DayPublishFailureVideoBySpId(Long spid,String jigouId,boolean isSpAdmin);

	Long countAlbumBySpId(Long spId,String jigouId,boolean isSpAdmin);

	List<Map<String,Object>> getCountGroupByCategory(Long spId, String institutionId, boolean isAdmin);

	List<Map<String,Object>> getCountGroupByStatus(VideoCondition condition);
	
}
