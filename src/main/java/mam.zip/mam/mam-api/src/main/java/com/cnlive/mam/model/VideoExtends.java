package com.cnlive.mam.model;

/**
 * Created by zhangxiaobin on 16/3/8.
 */
public class VideoExtends
{
    private String albumName;

    private String customCategoryName; //

    private String customName; // 视频所有人

    private Long showFileSize; // 文件大小

    private String categoryName; // 数据分类名称展示

    private String institutionName; //机构名称

    private String updateCustomName; //最后修改人

    private Integer storageType; //1 金山  2七牛  3 自建

    private String picOriginDomain;

    private String listPicUrl ;

    // 列表展示的图片
    public String getListPicUrl() {
        return listPicUrl;
    }

    public void setListPicUrl(String listPicUrl){
        this.listPicUrl = listPicUrl;
    }

    public String getPicOriginDomain() {
        return picOriginDomain;
    }

    public void setPicOriginDomain(String picOriginDomain) {
        this.picOriginDomain = picOriginDomain;
    }

    public Integer getStorageType() {
        return storageType;
    }

    public void setStorageType(Integer storageType) {
        this.storageType = storageType;
    }

    public String getUpdateCustomName() {
        return updateCustomName;
    }

    public void setUpdateCustomName(String updateCustomName) {
        this.updateCustomName = updateCustomName;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getAlbumName()
    {
        return albumName;
    }

    public void setAlbumName(String albumName)
    {
        this.albumName = albumName;
    }

    public String getCustomCategoryName()
    {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName)
    {
        this.customCategoryName = customCategoryName;
    }

    public String getCustomName()
    {
        return customName;
    }

    public void setCustomName(String customName)
    {
        this.customName = customName;
    }

    public Long getShowFileSize() {
        return showFileSize;
    }

    public void setShowFileSize(Long showFileSize) {
        this.showFileSize = showFileSize;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
