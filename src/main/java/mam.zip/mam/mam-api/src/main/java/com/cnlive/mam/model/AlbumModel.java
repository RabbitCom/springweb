package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.Const;

import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

public class AlbumModel extends AlbumExtends implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long albumId;

    private String albumName;

    private Integer category;

    private Float score;

    private Boolean isEnd;

    private Integer canSearch;

    private Long customId;

    private String subCategory;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    private String tag;

    private Integer episodeCount;
    private Integer episodeNow;

    private Long createUserId;

    private Long updateUserId;

    private Long customCategoryId;

    // 成品图片
    private String picFinishedImg;

    private String extendProperties;

    private String subTitle;// 副标题
    private String language;
    private String area;

    // 版权信息
    private String copyrightCompany;// 版权公司
    private Integer copyrightType;// 版权类型
    @JSONField(format="yyyy-MM-dd")
    private Date copyrightStart;// 版权开始日期
    @JSONField(format="yyyy-MM-dd")
    private Date copyrightEnd;// 版权结束日期

    // 屏蔽规则
    private Integer shieldingRule;

    private String playPlatform;// 播放平台
    private String downloadPlatform;// 下载平台
    private String contentRating;// 内容分级
    private Integer barrageSet;// 弹幕设置

    private String synopsis;// 简介

    private ModelStatus status;

    //customCategory的分类级别
    private Integer level;
    private Long parentCustomCategoryId;

    //来源专辑编号 默认值0标示自建专辑，其他通过购买获取的专辑，保存源专辑编号
    private Long originAlbumId;

    //是否付费
    private Integer isFee;
    //付费平台
    private String payPlatform;

    private Long spId;

    private String institutionId;

    private Integer storageImgId;

    public Integer getStorageImgId() {
        return storageImgId;
    }

    public void setStorageImgId(Integer storageImgId) {
        this.storageImgId = storageImgId;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getPayPlatform() {
        return payPlatform;
    }

    public void setPayPlatform(String payPlatform) {
        this.payPlatform = payPlatform;
    }

    public Integer getIsFee() {
        return isFee;
    }

    public void setIsFee(Integer isFee) {
        this.isFee = isFee;
    }

    public ModelStatus getStatus() {
        return status;
    }

    public void setStatus(ModelStatus status) {
        this.status = status;
    }

    @Id
    public Long getAlbumId() {
        return albumId;
    }

    public void setAlbumId(Long albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    public Boolean getIsEnd() {
        return isEnd;
    }

    public void setIsEnd(Boolean isEnd) {
        this.isEnd = isEnd;
    }

    public Integer getCanSearch() {
        return canSearch;
    }

    public void setCanSearch(Integer canSearch) {
        this.canSearch = canSearch;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getEpisodeCount() {
		return episodeCount;
	}

	public void setEpisodeCount(Integer episodeCount) {
		this.episodeCount = episodeCount;
	}

	public Integer getEpisodeNow() {
		return episodeNow;
	}

	public void setEpisodeNow(Integer episodeNow) {
		this.episodeNow = episodeNow;
	}

	public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Long getCustomCategoryId() {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId) {
        this.customCategoryId = customCategoryId;
    }

    public String getPicFinishedImg() {
        return picFinishedImg;
    }

    public void setPicFinishedImg(String picFinishedImg) {
        this.picFinishedImg = picFinishedImg;
    }

    public String getExtendProperties() {
        return extendProperties;
    }

    public void setExtendProperties(String extendProperties) {
        this.extendProperties = extendProperties;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCopyrightCompany() {
        return copyrightCompany;
    }

    public void setCopyrightCompany(String copyrightCompany) {
        this.copyrightCompany = copyrightCompany;
    }

    public Integer getCopyrightType() {
        return copyrightType;
    }

    public void setCopyrightType(Integer copyrightType) {
        this.copyrightType = copyrightType;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date getCopyrightStart() {
        return copyrightStart;
    }

    public void setCopyrightStart(Date copyrightStart) {
        this.copyrightStart = copyrightStart;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date getCopyrightEnd() {
        return copyrightEnd;
    }

    public void setCopyrightEnd(Date copyrightEnd) {
        this.copyrightEnd = copyrightEnd;
    }

    public Integer getShieldingRule() {
        return shieldingRule;
    }

    public void setShieldingRule(Integer shieldingRule) {
        this.shieldingRule = shieldingRule;
    }

    public String getPlayPlatform() {
        return playPlatform;
    }

    public void setPlayPlatform(String playPlatform) {
        this.playPlatform = playPlatform;
    }

    public String getDownloadPlatform() {
        return downloadPlatform;
    }

    public void setDownloadPlatform(String downloadPlatform) {
        this.downloadPlatform = downloadPlatform;
    }

    public String getContentRating() {
        return contentRating;
    }

    public void setContentRating(String contentRating) {
        this.contentRating = contentRating;
    }

    public Integer getBarrageSet() {
        return barrageSet;
    }

    public void setBarrageSet(Integer barrageSet) {
        this.barrageSet = barrageSet;
    }

    public Integer getLevel() {
        return level;
    }

    public Long getParentCustomCategoryId() {
        return parentCustomCategoryId;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Long getOriginAlbumId() {
        return originAlbumId;
    }

    public void setOriginAlbumId(Long originAlbumId) {
        this.originAlbumId = originAlbumId;
    }

    public void setParentCustomCategoryId(Long parentCustomCategoryId) {
        this.parentCustomCategoryId = parentCustomCategoryId;
    }

    public void fullProperty(){
        if(status == ModelStatus.Edit)
        status = ModelStatus.EditOver;
    }

    @Override
    public String toString() {
        return "AlbumModel{" +
                "customId=" + customId +
                ", albumId=" + albumId +
                ", albumName='" + albumName + '\'' +
                ", category=" + category +
                ", customCategoryId=" + customCategoryId +
                ", payPlatform='" + payPlatform + '\'' +
                ", isFee=" + isFee +
                ", status=" + status +
                '}';
    }

}
