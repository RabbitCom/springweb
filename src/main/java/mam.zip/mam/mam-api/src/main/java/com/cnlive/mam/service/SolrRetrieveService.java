package com.cnlive.mam.service;

import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.vo.SolrRetrieveVo;

import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 7/17/2017.
 */
public interface SolrRetrieveService {

    String getByKeyWord(String keyWord, Integer page, Integer rows, Long spId, String institutionId);

    void add(VideoModel videoModel);

}
