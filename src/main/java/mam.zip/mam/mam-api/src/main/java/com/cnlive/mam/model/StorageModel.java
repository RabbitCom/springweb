package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.enums.StorageUsageEnum;
import com.cnlive.mam.common.enums.StorageUseStateEnum;

import java.io.Serializable;

/**
 * Created by cuilongcan on 7/28/2017.
 */
@JSONType(asm = false)
public class StorageModel implements Serializable {

    public Integer id;
    public String name;
    public String showName;
    public StorageTypeEnum type;
    public StorageUsageEnum yongtu;
    public StorageUseStateEnum useState;
    public Long spid;
    public StorageContentTypeEnum contentType;
    public Integer defaultStorage;

    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public StorageTypeEnum getType() {
        return type;
    }

    public void setType(StorageTypeEnum type) {
        this.type = type;
    }

    public StorageUsageEnum getYongtu() {
        return yongtu;
    }

    public void setYongtu(StorageUsageEnum yongtu) {
        this.yongtu = yongtu;
    }

    public StorageUseStateEnum getUseState() {
        return useState;
    }

    public void setUseState(StorageUseStateEnum useState) {
        this.useState = useState;
    }

    public Long getSpid() {
        return spid;
    }

    public void setSpid(Long spid) {
        this.spid = spid;
    }

    public StorageContentTypeEnum getContentType() {
        return contentType;
    }

    public void setContentType(StorageContentTypeEnum contentType) {
        this.contentType = contentType;
    }

    public Integer getDefaultStorage() {
        return defaultStorage;
    }

    public void setDefaultStorage(Integer defaultStorage) {
        this.defaultStorage = defaultStorage;
    }
}
