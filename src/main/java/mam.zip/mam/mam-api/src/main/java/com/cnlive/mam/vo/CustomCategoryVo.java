package com.cnlive.mam.vo;

import java.io.Serializable;

/**
 * Created by zhangxiaobin
 */
public class CustomCategoryVo implements Serializable {
    private Long customCategoryId;
    private Long customId;
    private String customCategoryName;
    private String category;
    private Integer categoryId;
    private String parentCustomCategory;
    private Long parentCustomCategoryId;
    private Integer level;
    private Integer auditSetting;
    private Long spId;

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public Long getCustomCategoryId() {
        return customCategoryId;
    }

    public void setCustomCategoryId(Long customCategoryId) {
        this.customCategoryId = customCategoryId;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public String getCustomCategoryName() {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName) {
        this.customCategoryName = customCategoryName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getParentCustomCategory() {
        return parentCustomCategory;
    }

    public void setParentCustomCategory(String parentCustomCategory) {
        this.parentCustomCategory = parentCustomCategory;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Long getParentCustomCategoryId() {
        return parentCustomCategoryId;
    }

    public void setParentCustomCategoryId(Long parentCustomCategoryId) {
        this.parentCustomCategoryId = parentCustomCategoryId;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
    public Integer getAuditSetting()
    {
        return auditSetting;
    }

    public void setAuditSetting(Integer auditSetting)
    {
        this.auditSetting = auditSetting;
    }
}
