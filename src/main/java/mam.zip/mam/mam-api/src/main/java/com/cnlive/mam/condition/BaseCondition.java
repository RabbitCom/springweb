package com.cnlive.mam.condition;

import java.io.Serializable;

/**
 * @author zhangxiaobin
 * @date 15/9/9
 */

public class BaseCondition implements Serializable {
	
	private static final long serialVersionUID = 4295761921996749356L;
	/** 页码，从1开始 */
	private int page;//pageNum  当前页
	/** 页面大小 */
	private int rows;//pageSize 每页显示记录数
	/** 起始行 */
	private int startRow;
	/** 末行 */
	private int endRow;
	/** 用于排序的字段 **/
	private String sort;
	/** 排序的方式 **/
	private String order = "desc";

	public BaseCondition() {

	}

	public BaseCondition(int page, int rows) {

		this.page = page;
		this.rows = rows;
		calculateStartAndEndRow();
	}

	public int getEndRow() {
		return endRow;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
		calculateStartAndEndRow();
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
		calculateStartAndEndRow();
	}

	public int getStartRow() {

		return startRow;
	}

	/**
	 * 计算起止行号
	 */
	private void calculateStartAndEndRow() {
		this.startRow = (this.page > 0 ? this.page-1 : 0 ) * this.rows;
		this.endRow = this.rows ;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
