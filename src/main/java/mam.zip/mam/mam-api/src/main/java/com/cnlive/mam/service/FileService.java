package com.cnlive.mam.service;

import com.cnlive.mam.model.FileModel;

import java.util.List;

/**
 * zhangxiaobin
 */
public interface FileService {

    void save(FileModel t);

    void create(FileModel t);

    void modify(FileModel t);

    FileModel getById(Long id);

    List<FileModel> getByVid(Long vid);

    List<FileModel> getFileByVidAndCoderate(Long vid, Integer codeRate);

    void deleteFile(FileModel file);

    List<FileModel> getByTaskId(String taskId);

    FileModel getByTaskIdAndTransCodeFmtAndCodeRate(String taskId, String transCodeFmt, Integer codeRate);

    /**
     * 根据文件id，获取该文件最新一次转码的错误信息。如果最新一次转码成功，返回空字符串
     *
     * @param fileId 文件id
     * @return 错误信息
     * @author wangchaojie　2017年4月6日
     */
    String getTranscodeErrorShowMsg(Long fileId, String taskId);

    void saveFileList(List<FileModel> fileModels);

    FileModel getFileByVidAndCoderateAndTransCodeFmt(Long videoId,Integer codeRate,String transCodeFmt);

    List<FileModel> getByVidAndTransCodeFmt(Long vid, String transCodeFmt);

    void deleteFileByVideoId(Long videoId);

}
