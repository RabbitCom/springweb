package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.ModelStatus;

/**
 * Created by zhangxiaobin on 16/7/12.
 */
@JSONType(asm=false)
public class VideoRemoveModel implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 7653490614542762445L;

	private Long id;
	
	private Long videoId;

    private String videoName;

    private Long removeUserId;
    
    private String removeUser;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date removeTime;

    private String removeMsg;

    private ModelStatus oldStatus;
    
    private String businessUUID;
    
    private Long removeSpId;

	public String getBusinessUUID() {
		return businessUUID;
	}

	public void setBusinessUUID(String businessUUID) {
		this.businessUUID = businessUUID;
	}

	public ModelStatus getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(ModelStatus oldStatus) {
		this.oldStatus = oldStatus;
	}

	public VideoRemoveModel(){}

    @Id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
	public Long getVideoId() {
		return videoId;
	}

	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Long getRemoveUserId() {
		return removeUserId;
	}

	public void setRemoveUserId(Long removeUserId) {
		this.removeUserId = removeUserId;
	}

	public String getRemoveUser() {
		return removeUser;
	}

	public void setRemoveUser(String removeUser) {
		this.removeUser = removeUser;
	}

	public Date getRemoveTime() {
		return removeTime;
	}

	public void setRemoveTime(Date removeTime) {
		this.removeTime = removeTime;
	}

	public String getRemoveMsg() {
		return removeMsg;
	}

	public void setRemoveMsg(String removeMsg) {
		this.removeMsg = removeMsg;
	}

	public Long getRemoveSpId() {
		return removeSpId;
	}

	public void setRemoveSpId(Long removeSpId) {
		this.removeSpId = removeSpId;
	}

	@Override
	public String toString() {
		return "VideoRemoveModel [id=" + id + ", videoId=" + videoId + ", videoName=" + videoName + ", removeUserId="
				+ removeUserId + ", removeUser=" + removeUser + ", removeTime=" + removeTime + ", removeMsg="
				+ removeMsg + ", oldStatus=" + oldStatus + "]";
	}
	
	
}
