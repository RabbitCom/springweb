package com.cnlive.mam.service;

import com.cnlive.mam.model.PublishTaskModel;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ReleaseObj;

public interface VideoPublishService {


    JsonResult checkCategory(long videoIds, Long customId);

    JsonResult toReleaseVideo(Long videoId, Long customId);

    JsonResult releaseFail(Long videoId,Long customId);

    void addPublishHistory(Long videoId, Long customId, Integer status, String description);

    JsonResult publishVideo(Long videoId, Long customId);

}
