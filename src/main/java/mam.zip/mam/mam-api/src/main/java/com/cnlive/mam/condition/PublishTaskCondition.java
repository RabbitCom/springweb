package com.cnlive.mam.condition;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
public class PublishTaskCondition extends BaseCondition {

    private Long videoId;

    private Long customId;

    private String publishBlockIds;

    private Integer publishState;

    private Integer publishType;

    private String publishUser;

    private String publishStartTime;

    private String publishEndTime;

    private String updateStartTime;

    private String updateEndTime;

    public Long getVideoId()
    {
        return videoId;
    }

    public void setVideoId(Long videoId)
    {
        this.videoId = videoId;
    }

    public Long getCustomId()
    {
        return customId;
    }

    public void setCustomId(Long customId)
    {
        this.customId = customId;
    }

    public String getPublishBlockIds()
    {
        return publishBlockIds;
    }

    public void setPublishBlockIds(String publishBlockIds)
    {
        this.publishBlockIds = publishBlockIds;
    }

    public String getPublishUser()
    {
        return publishUser;
    }

    public void setPublishUser(String publishUser)
    {
        this.publishUser = publishUser;
    }

    public Integer getPublishState()
    {
        return publishState;
    }

    public void setPublishState(Integer publishState)
    {
        this.publishState = publishState;
    }

    public Integer getPublishType()
    {
        return publishType;
    }

    public void setPublishType(Integer publishType)
    {
        this.publishType = publishType;
    }

    public String getPublishStartTime()
    {
        return publishStartTime;
    }

    public void setPublishStartTime(String publishStartTime)
    {
        this.publishStartTime = publishStartTime;
    }

    public String getPublishEndTime()
    {
        return publishEndTime;
    }

    public void setPublishEndTime(String publishEndTime)
    {
        this.publishEndTime = publishEndTime;
    }

    public String getUpdateStartTime()
    {
        return updateStartTime;
    }

    public void setUpdateStartTime(String updateStartTime)
    {
        this.updateStartTime = updateStartTime;
    }

    public String getUpdateEndTime()
    {
        return updateEndTime;
    }

    public void setUpdateEndTime(String updateEndTime)
    {
        this.updateEndTime = updateEndTime;
    }
}
