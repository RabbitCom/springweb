package com.cnlive.mam.vo;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.TransCodeType;

public class ReqTransCodeVo {
	
	private String path; //视频源地址
	
	private String dstBucket;//输出bucket
	
	private String dstDir;//输出文件key的路径、不允许以/开头
	
	/**
	 *  avop 转码  
	 *  avlogo 加水印
	 *  avsample 采样截图
	 *  avsnapshot 单张截图
	 */
	private TransCodeType type;
	
	private String spId; //服务商ID
	
	private String rates;//客户设置的码率 多个时逗号分隔
	
	private String formats;//非必填，视频格式 多个时逗号分隔；为空时默认mp4和hls
	
	private Integer level; //非必填
	
	/**
	 * 是否添加logo标识,该参数只针对type=avop
	 * 有效 0:不添加 1:添加 默认 0
	 */
	private Integer addLogoFlag ;//非必填
	
	/**
	 * 附带参数 addLogoFlag=0 && type=avop 非必填 格式:json
	 */
	private String attach ;
	
	private String cbMethod ; //回调方法 GET/POST
	
	private String cbUrl; //回调地址
	
	private JSONObject extParam ;//非必填

	private Integer plat ; //0 金山 1 七牛

	public Integer getPlat() {
		return plat;
	}

	public void setPlat(Integer plat) {
		this.plat = plat;
	}

	public ReqTransCodeVo(){}
	
	public ReqTransCodeVo(String path,TransCodeType type,Integer addLogoFlag,
			String spId,String cbMethod,String cbUrl){
		this.path = path;
		this.spId = spId;
		this.cbMethod = cbMethod;
		this.cbUrl = cbUrl;
		this.type = type;
		this.addLogoFlag = addLogoFlag;
	}
	

	public String getDstBucket() {
		return dstBucket;
	}

	public void setDstBucket(String dstBucket) {
		this.dstBucket = dstBucket;
	}

	public String getDstDir() {
		return dstDir;
	}

	public void setDstDir(String dstDir) {
		this.dstDir = dstDir;
	}

	public TransCodeType getType() {
		return type;
	}

	public void setType(TransCodeType type) {
		this.type = type;
	}

	public String getFormats() {
		return formats;
	}

	public void setFormats(String formats) {
		this.formats = formats;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getAddLogoFlag() {
		return addLogoFlag;
	}

	public void setAddLogoFlag(Integer addLogoFlag) {
		this.addLogoFlag = addLogoFlag;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

	public JSONObject getExtParam() {
		return extParam;
	}

	public void setExtParam(JSONObject extParam) {
		this.extParam = extParam;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSpId() {
		return spId;
	}

	public void setSpId(String spId) {
		this.spId = spId;
	}

	public String getCbMethod() {
		return cbMethod;
	}

	public void setCbMethod(String cbMethod) {
		this.cbMethod = cbMethod;
	}

	public String getCbUrl() {
		return cbUrl;
	}

	public void setCbUrl(String cbUrl) {
		this.cbUrl = cbUrl;
	}

	public String getRates() {
		return rates;
	}

	public void setRates(String rates) {
		this.rates = rates;
	}
	
}
