package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.model.TranscodeTaskModel;

/**
 * 转码请求任务业务方法类
 */
public interface TranscodeTaskService {

    TranscodeTaskModel create(TranscodeTaskModel task);

    void modify(TranscodeTaskModel task);

    void delete(TranscodeTaskModel task);

    TranscodeTaskModel findById(Long id);

    TranscodeTaskModel findByFileTaskId(String fileTaskId);

    /**
     * 获取所有待转码任务列表（status=0）
     *
     * @return
     * @author wangchaojie　2017年3月22日
     */
    List<TranscodeTaskModel> getAll();

}
