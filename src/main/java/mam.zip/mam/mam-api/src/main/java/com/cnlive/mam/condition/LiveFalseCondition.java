package com.cnlive.mam.condition;

import java.util.List;

public class LiveFalseCondition extends BaseCondition {

    private static final long serialVersionUID = -4613314242944462470L;

    private Integer spId;

    private Integer category;

    private String keyword;

    private List<String> keyWordList;

    private Integer codeRate;

    private String gfmt;

    public List<String> getKeyWordList() {
        return keyWordList;
    }

    public void setKeyWordList(List<String> keyWordList) {
        this.keyWordList = keyWordList;
    }

    public Integer getCodeRate() {
        return codeRate;
    }

    public void setCodeRate(Integer codeRate) {
        this.codeRate = codeRate;
    }

    public String getGfmt() {
        return gfmt;
    }

    public void setGfmt(String gfmt) {
        this.gfmt = gfmt;
    }

    public Integer getSpId() {
        return spId;
    }

    public void setSpId(Integer spId) {
        this.spId = spId;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public LiveFalseCondition(Integer spId, Integer category, int page, int rows, int codeRate, String gfmt) {
        super(page, rows);
        this.spId = spId;
        this.category = category;
        this.codeRate = codeRate;
        this.gfmt = gfmt;
    }

    public LiveFalseCondition(Integer spId, List<String> keyWordList, int page, int rows, int codeRate, String gfmt) {
        super(page, rows);
        this.spId = spId;
        this.keyWordList = keyWordList;
        this.codeRate = codeRate;
        this.gfmt = gfmt;
    }
}
