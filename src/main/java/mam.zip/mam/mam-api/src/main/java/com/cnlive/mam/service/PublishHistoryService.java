package com.cnlive.mam.service;

import com.cnlive.mam.model.PublishHistory;
import com.cnlive.mam.model.PublishTaskModel;

public interface PublishHistoryService {


    void insert(PublishHistory publishHistory);

    PublishHistory selectByVideoIdAndCustomId(PublishHistory publishHistory);

    void update(PublishHistory publishHistory);

    PublishHistory selectByVideoId(Long videoId);

}
