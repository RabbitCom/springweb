package com.cnlive.mam.service;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.enums.StorageUsageEnum;
import com.cnlive.mam.condition.StorageCondition;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public interface StorageService {

    StorageModel save(StorageModel storageModel);

    void delete(Integer id);

    void modify(StorageModel storageModel);

    StorageModel getById(Integer id);

    DataGrid getPageByCondition(StorageCondition condition);

    //返回全部的存储
    List<StorageModel> getStorageAllBySpid(Long spid);

    //返回启用的存储
    List<StorageModel> getStorageEnableBySpid(Long spid);

    List<StorageModel> getByStorage(StorageModel storageModel);

    Boolean checkStorageComplete(Long spid);

    void insertDefaultStorage(Long spId);

    /**
     * 根据spid获取输入存储 区分内容
     * @param spId
     * @param contentType
     * @return
     */
    StorageModel getStorageInBySpId(Long spId, StorageContentTypeEnum contentType);

    /**
     * 根据spid获取输出存储 区分内容
     * @param spId
     * @param contentType
     * @return
     */
    StorageModel getStorageOutBySpId(Long spId, StorageContentTypeEnum contentType);

    /**
     * 根据spid获取所有的输入域名
     * @param spId
     * @return
     */
    List<String> getDomainAllInBySpId(Long spId,StorageContentTypeEnum contentType)  ;

    /**
     * 根据spid获取所有的输出域名
     * @param spId
     * @return
     */
    List<String> getDomainAllOutBySpId(Long spId,StorageContentTypeEnum contentType)  ;

    /**
     * 根据spid获取单个输入域名
     * @param spId
     * @return
     */
    String getDomainSimpleInBySpId(Long spId,StorageContentTypeEnum contentType) ;

    /**
     * 根据spid获取单个输出域名
     * @param spId
     * @return
     */
    String getDomainSimpleOutBySpId(Long spId,StorageContentTypeEnum contentType) ;

    /**
     * 根据存储id获取单个输入域名
     * @param storageId
     * @return
     */
    String getDomainSimpleInByStorageId(Integer storageId);

    /**
     * 根据存储id获取单个输出域名
     * @param storageId
     * @return
     */
    String getDomainSimpleOutByStorageId(Integer storageId);

    /**
     * 根据存储id获取所有输入域名
     * @param storageId
     * @return
     */
    List<String> getDomainAllInByStorageId(Integer storageId);

    /**
     * 根据存储id获取所有输出域名
     * @param storageId
     * @return
     */
    List<String> getDomainAllOutByStorageId(Integer storageId);

    /**
     * 根据spid,存储类型、内容类型、名称获取存储信息
     * @param typeEnum
     * @param contentTypeEnum
     * @param bucketName
     * @return
     */
    StorageModel getStorageByTypeAndContentTypeAndName(StorageTypeEnum typeEnum,
                                                       StorageContentTypeEnum contentTypeEnum,
                                                       String bucketName,
                                                       Long spId);

    /**
     * 根据spid、存储类型、内容类型校验名称是否存在
     * @param bucketName
     * @param typeEnum
     * @param contentTypeEnum
     * @param spId
     * @return
     */
    boolean checkNameExtis(String bucketName, StorageTypeEnum typeEnum, StorageContentTypeEnum contentTypeEnum,
                                                       Long spId,
                                                       StorageUsageEnum usageEnum);

    /**
     * 获取当前使用的存储类型；默认金山
     * @param spId
     * @return
     */
    StorageTypeEnum getStorageTypeBySpId(Long spId,StorageContentTypeEnum contentTypeEnum);
}
