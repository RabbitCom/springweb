package com.cnlive.mam.service;

import com.cnlive.mam.model.TranscodeHistoryModel;

/**
 * 转码任务记录业务方法类
 */
public interface TranscodeHistoryService {

    TranscodeHistoryModel create(TranscodeHistoryModel task);

}
