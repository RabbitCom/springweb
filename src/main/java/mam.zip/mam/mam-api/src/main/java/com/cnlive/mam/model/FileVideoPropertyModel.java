package com.cnlive.mam.model;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;

/**
 * zhangxiaobin
 */

public class FileVideoPropertyModel implements Serializable{
    private Long fileId;
    private Long mid;
    private Integer codeRate;

    private String gfmt;   //文件类型,文件扩展名,mp4,flv
    private Long gsize;  //视频文件大小
    private Integer gdur;  //时长
    private Long gbr;//总体码率

    private Integer vwidth;  //视频宽
    private Integer vheight;  //视频高
    private Float vfps;      //视频帧率
    private Long vbr;       //视频码率


    private String afmt;   //音频编码方式
    private Integer abr;   //音频码率
    private String achannel;  //音频声道数
    private String asample;  //音频采样率

    private String mediaInfo;   //下载地址
    private String compressionMode;  //压缩方式

    public FileVideoPropertyModel() {
    }

    @Id
    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }


    public Long getVbr() {
        return vbr;
    }

    public void setVbr(Long vbr) {
        this.vbr = vbr;
    }

    public Integer getCodeRate() {
        return codeRate;
    }

    public void setCodeRate(Integer codeRate) {
        this.codeRate = codeRate;
    }

    public Long getMid() {
        return mid;
    }

    public void setMid(Long mid) {
        this.mid = mid;
    }

    public String getGfmt() {
        return gfmt;
    }

    public void setGfmt(String gfmt) {
        this.gfmt = gfmt;
    }

    public Long getGsize() {
        return gsize;
    }

    public void setGsize(Long gsize) {
        this.gsize = gsize;
    }

    public Integer getGdur() {
        return gdur;
    }

    public void setGdur(Integer gdur) {
        this.gdur = gdur;
    }

    public Long getGbr() {
        return gbr;
    }

    public void setGbr(Long gbr) {
        this.gbr = gbr;
    }

    public Integer getVwidth() {
        return vwidth;
    }

    public void setVwidth(Integer vwidth) {
        this.vwidth = vwidth;
    }

    public Integer getVheight() {
        return vheight;
    }

    public void setVheight(Integer vheight) {
        this.vheight = vheight;
    }

    public Float getVfps() {
        return vfps;
    }

    public void setVfps(Float vfps) {
        this.vfps = vfps;
    }

    public String getAfmt() {
        return afmt;
    }

    public void setAfmt(String afmt) {
        this.afmt = afmt;
    }

    public Integer getAbr() {
        return abr;
    }

    public void setAbr(Integer abr) {
        this.abr = abr;
    }

    public String getAchannel() {
        return achannel;
    }

    public void setAchannel(String achannel) {
        this.achannel = achannel;
    }

    public String getAsample() {
        return asample;
    }

    public void setAsample(String asample) {
        this.asample = asample;
    }


    public String getMediaInfo() {
        return mediaInfo;
    }

    public void setMediaInfo(String mediaInfo) {
        this.mediaInfo = mediaInfo;
    }

    public String getCompressionMode() {
        return compressionMode;
    }

    public void setCompressionMode(String compressionMode) {
        this.compressionMode = compressionMode;
    }
}
