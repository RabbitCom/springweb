package com.cnlive.mam.condition;

public class CustomCategoryCondition extends BaseCondition {
    private static final long serialVersionUID = -4058982028568123134L;
    private String customCategoryName;
    private Integer category;
    private String parentCustomCategoryId;
    private Long customId;
    private Integer categorys;
    private Integer level;
    private Long spId;

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public CustomCategoryCondition(){}

    public CustomCategoryCondition(Long customId){
        this.customId = customId;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public String getCustomCategoryName() {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName) {
        this.customCategoryName = customCategoryName;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public String getParentCustomCategoryId() {
        return parentCustomCategoryId;
    }

    public void setParentCustomCategoryId(String parentCustomCategoryId) {
        this.parentCustomCategoryId = parentCustomCategoryId;
    }

    public Integer getCategorys()
    {
        return categorys;
    }

    public void setCategorys(Integer categorys)
    {
        this.categorys = categorys;
    }

    public Integer getLevel()
    {
        return level;
    }

    public void setLevel(Integer level)
    {
        this.level = level;
    }
}
