package com.cnlive.mam.vo;

import com.cnlive.mam.common.enums.DefinitionEnum;

/**
 * 清晰度VO
 * Created by zhangxiaobin
 */
public class DefinitionVo {
    // 显示名称
    String showName;
    // 显示名称
    String showValue;
    // 清晰度字典值 同之前的码率字典值
    Integer dicValue;
    // 用户是否已经勾选，true：已勾选，false：未勾选
    boolean selected;

    public DefinitionVo() {
    }

    public DefinitionVo(DefinitionEnum definitionEnum) {
        this.dicValue = definitionEnum.getDefinitionId();
        this.showName = definitionEnum.getShowName(definitionEnum.getDefinitionId())+"("+ definitionEnum.getDefinitionId() +")";
        this.showValue = definitionEnum.getShowName(definitionEnum.getDefinitionId())+"("+ definitionEnum.getDefinitionId() +")";
        this.selected = false;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getShowValue() {
        return showValue;
    }

    public void setShowValue(String showValue) {
        this.showValue = showValue;
    }

    public Integer getDicValue() {
        return dicValue;
    }

    public void setDicValue(Integer dicValue) {
        this.dicValue = dicValue;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
