package com.cnlive.mam.model;

/**
 * @author zhangxiaobin
 */
public enum DicWord {
    category("分类",true),language("语言",true),contentRating("内容分级",false),copyrightType("版权类型",true),platform("平台",true),
    rate("码率",false),subCategory("子分类",false),videoType("视频类型",false),area("地区",false),auditReason("审核不通过原因",true),source("视频来源",true),
    playArea("可播放区域",true);

    DicWord(String cnName,boolean isAll){
        this.cnName = cnName;
        this.isAll = isAll;
    }

   private String cnName;
   private  boolean isAll;

    public String getCnName() {
        return cnName;
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

    public boolean isAll() {
        return isAll;
    }

    public void setAll(boolean all) {
        isAll = all;
    }

}
