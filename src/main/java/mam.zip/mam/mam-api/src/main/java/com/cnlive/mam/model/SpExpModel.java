package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.StorageTypeEnum;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhangxiaobin on 2017/8/15.
 */
@JSONType(asm = false)
public class SpExpModel implements Serializable {

    private Long id;
    private Long spId; // 入驻SP_ID
    private StorageTypeEnum storageType;//存储类型
    private Integer storageId;// 存储id
    private Integer spExpContentType;// 1 logo  2片头片尾
    private String logUrl;//
    private String startUrl;//
    private String endUrl;//
    private Long createUserId;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    private Long updateUserId;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @Id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public StorageTypeEnum getStorageType() {
        return storageType;
    }

    public void setStorageType(StorageTypeEnum storageType) {
        this.storageType = storageType;
    }

    public Integer getStorageId() {
        return storageId;
    }

    public void setStorageId(Integer storageId) {
        this.storageId = storageId;
    }

    public String getLogUrl() {
        return logUrl;
    }

    public void setLogUrl(String logUrl) {
        this.logUrl = logUrl;
    }

    public String getStartUrl() {
        return startUrl;
    }

    public void setStartUrl(String startUrl) {
        this.startUrl = startUrl;
    }

    public String getEndUrl() {
        return endUrl;
    }

    public void setEndUrl(String endUrl) {
        this.endUrl = endUrl;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSpExpContentType() {
        return spExpContentType;
    }

    public void setSpExpContentType(Integer spExpContentType) {
        this.spExpContentType = spExpContentType;
    }
}
