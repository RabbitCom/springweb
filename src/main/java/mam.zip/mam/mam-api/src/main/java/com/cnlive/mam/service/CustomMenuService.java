package com.cnlive.mam.service;

import com.cnlive.mam.model.CustomMenuModel;

import java.util.List;

/**
 * Created by cuilongcan on 2017/5/10.
 */
public interface CustomMenuService {

    List<CustomMenuModel> selectAll();

    CustomMenuModel selectById(Integer menuId);

    List<CustomMenuModel> selectByIds(List<Integer> ids);
}
