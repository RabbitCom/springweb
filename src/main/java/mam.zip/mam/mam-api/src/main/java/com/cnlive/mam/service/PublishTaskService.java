package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.condition.VideoPublishCondition;
import com.cnlive.mam.model.PublishTaskModel;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;

public interface PublishTaskService {

    void insert(PublishTaskModel publishTaskModel);

    List<PublishTaskModel> getAll();

    List<PublishTaskModel> getTaskListByState(PublishTaskModel publishTaskModel);

    void update(PublishTaskModel publishTaskModel);

    void delete(Long taskId);

    List<PublishTaskModel> getTaskByCondition(PublishTaskModel publishTaskModel);

    JsonResult cancelPublish(PublishTaskModel publishTaskModel);

    List<PublishTaskModel> PagePublishTaskInfos(VideoPublishCondition condition);

    Long PageCountPublishTaskInfos(VideoPublishCondition condition);

}
