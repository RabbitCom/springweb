package com.cnlive.mam.condition;

public class MmsCondition extends BaseCondition {
	private static final long serialVersionUID = 8758670212045856886L;


}
