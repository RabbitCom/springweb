package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.google.common.base.Splitter;

import java.io.Serializable;
import java.util.Date;

/**
 * 数据分类免审关系表
 * Created by zhangxiaoinb
 */
public class CategoryFreeReviewModel  implements Serializable{
    private static final long serialVersionUID = -7866442216006129638L;

    private Long customId;

    private String categoryIds;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public String getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(String categoryIds) {
        this.categoryIds = categoryIds;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public boolean isCategoryFreeReview(String category) {
        return Splitter.on(",")
                .omitEmptyStrings()
                .trimResults()
                .splitToList(categoryIds)
                .stream()
                .anyMatch(dbcategory -> dbcategory.equals(category));
    }

    @Override
    public String toString() {
        return "CategoryFreeReviewModel{" +
                "customId=" + customId +
                ", categoryIds='" + categoryIds + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
