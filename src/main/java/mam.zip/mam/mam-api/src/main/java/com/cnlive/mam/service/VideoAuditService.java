package com.cnlive.mam.service;

import java.util.List;

import com.cnlive.mam.common.enums.VideoAuditStatus;
import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.model.VideoAuditModel;
import com.cnlive.mam.vo.DataGrid;

/**
 * zhangxiaobin
 */
public interface VideoAuditService {


    void create(VideoAuditModel model);

    void save(VideoAuditModel model);

    DataGrid getByCondition(VideoAuditCondition condition);

    List<VideoAuditModel> getVideoAuditInfoByCondition(VideoAuditCondition condition);

    void update(VideoAuditModel videoAuditModel);

}
