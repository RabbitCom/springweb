package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.OptionType;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhangxiaobin on 2017/5/2.
 */
public class OptionLogInfo implements Serializable {

    private Long id;
    private OptionType optionType;
    private Long optionUserId;
    private String optionUserName;
    private String optionComent;
    private Long spId;
    private String videoId;
    private String videoName;

    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public OptionLogInfo(){}

    public OptionLogInfo(OptionType optionType,Long optionUserId,String optionUserName,String optionComent,Long spId,String videoId,String videoName){
        this.optionType = optionType;
        this.optionUserId = optionUserId;
        this.optionUserName = optionUserName;
        this.optionComent = optionComent;
        this.spId = spId;
        this.videoId = videoId;
        this.videoName = videoName;
        this.createTime = new Date();
    }

    @Id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OptionType getOptionType() {
        return optionType;
    }

    public void setOptionType(OptionType optionType) {
        this.optionType = optionType;
    }

    public Long getOptionUserId() {
        return optionUserId;
    }

    public void setOptionUserId(Long optionUserId) {
        this.optionUserId = optionUserId;
    }

    public String getOptionUserName() {
        return optionUserName;
    }

    public void setOptionUserName(String optionUserName) {
        this.optionUserName = optionUserName;
    }

    public String getOptionComent() {
        return optionComent;
    }

    public void setOptionComent(String optionComent) {
        this.optionComent = optionComent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }
}
