package com.cnlive.mam.model;

/**
 * @author zhangxiaobin
 */
public interface Status {
    public void updateStatus(int updateStatusAction);
    public boolean canbeUsedStatus();
}
