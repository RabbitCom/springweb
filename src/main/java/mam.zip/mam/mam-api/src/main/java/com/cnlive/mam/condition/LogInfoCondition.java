package com.cnlive.mam.condition;


/**
 * Created by zhangxiaobin on 2017/5/2.
 */
public class LogInfoCondition extends BaseCondition {

    private Integer optionType;
    private String starTime;
    private String endTime;
    private Long optionUserId;
    private String optionUserName;
    private Long spId;
    private String videoId;
    private String videoName;

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public Integer getOptionType() {
        return optionType;
    }

    public void setOptionType(Integer optionType) {
        this.optionType = optionType;
    }

    public String getStarTime() {
        return starTime;
    }

    public void setStarTime(String starTime) {
        this.starTime = starTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Long getOptionUserId() {
        return optionUserId;
    }

    public void setOptionUserId(Long optionUserId) {
        this.optionUserId = optionUserId;
    }

    public String getOptionUserName() {
        return optionUserName;
    }

    public void setOptionUserName(String optionUserName) {
        this.optionUserName = optionUserName;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }
}
