package com.cnlive.mam.vo;

import com.cnlive.mam.model.CustomMenuModel;

import java.io.Serializable;
import java.util.List;

/**
 * Created by cuilongcan on 2017/5/17.
 */
public class CustomPermissionVo implements Serializable {
    private Integer roleId;//角色id
    private String roleName;//角色名称
    private List<CustomMenuModel> menus;//菜单名称
    private String description; //描述

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public List<CustomMenuModel> getMenus() {
        return menus;
    }

    public void setMenus(List<CustomMenuModel> menus) {
        this.menus = menus;
    }
}
