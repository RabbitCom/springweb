package com.cnlive.mam.model;

import java.io.Serializable;

import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.utils.Const;

public class Dictionary implements Serializable{

    /**
	 *
	 */
	private static final long serialVersionUID = 2246939009348575330L;
	public final static String CATEGORY_DIC_WORD ="category";
    public final static String RATE_DIC_WORD ="rate";
    public final static String DICTIONARY_KEY_HEAD = "d";

    private Long  dicId;
    private String showValue; //'显示时需要多语言转化成真正语言显示值,该值是固定值'
    private String showName;  //'帮助记忆的中文名'

    private String dicWord;  //'字典word，可以通过该值获取全部该word字典列表'
    private Integer dicValue; //'真正保存到其他表字段中的值。要制定自己的规则，按照规则去创建，不能自动增长'
    private String categorys;  //'字典生效的分类，可以保存多值',分类也是字典中的一个值，分类的分类值为-1，分类的字典word为Category
    private String language; //当前语言

    public String getShowValueI18nKey(){
       return  DICTIONARY_KEY_HEAD+Const.KEY_DECOLLATOR+dicWord+Const.KEY_DECOLLATOR+dicValue;
    }

    @Id
    public Long getDicId() {
        return dicId;
    }

    public void setDicId(Long dicId) {
        this.dicId = dicId;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }
    public String getDicWord() {
        return dicWord;
    }

    public void setDicWord(String dicWord) {
        this.dicWord = dicWord;
    }
    public Integer getDicValue() {
        return dicValue;
    }

    public void setDicValue(Integer dicValue) {
        this.dicValue = dicValue;
    }
    public String getCategorys() {
        return categorys;
    }

    public void setCategorys(String categorys) {
        this.categorys = categorys;
    }

    public boolean inCategory(Integer Category) {
        DicWord dicWord1 = DicWord.valueOf(dicWord);
        if(dicWord1.isAll()) return true;
        String[] CategorysStr = categorys.split(Const.VALUE_DECOLLATOR);
        for(String CategoryStr: CategorysStr){
            int CategoryInt = Integer.parseInt(CategoryStr);
            if(CategoryInt == Category){
                return true;
            }
        }
        return false;
    }

    public String getShowValue(){
        return showValue == null ? showName : showValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Dictionary that = (Dictionary) o;

        return !(dicId != null ? !dicId.equals(that.dicId) : that.dicId != null);

    }

    @Override
    public int hashCode() {
        return dicId != null ? dicId.hashCode() : 0;
    }
}
