package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.MmsProductionStatus;
import com.cnlive.mam.common.enums.MmsTypeEnum;

import java.io.Serializable;
import java.util.Date;

//必须加注解 如果asm为true无法使用自定义的序列化类
@JSONType(asm=false)
public class MmsModel  implements Serializable,Status {
    private Long mid;
    private String name;
    //上传视频时生产平台返回的id
    private Long uploadId;
    private String md5;
    //创建日期
    private Date createTime;
    //发布时间
    private Date publicTime;
    private String videoCodes;
    private Long fileSize;
    // 时长
    private Integer duration;
    private String transCodePicPrefix;
    private Integer transCodeFlag;   // 0,1次上传，1重传
    private Long createCustomId;
    private Integer sourceId;
    private Date updateTime;
    private String token;
    private Integer uploadType;
    private String businessLine;//业务线来源
    private MmsProductionStatus status;   // 0初始状态,3上传完成，4有内容已经转码完成，5所有内容都转码完成,9下线
    private Integer schedule;
    //源文件URL地址
    private String srcFileUrl;
    //媒资类型
    private MmsTypeEnum mmsType;


    public MmsModel(Long vid, String md5, Long  fileSize, Integer sourceId,Long customId) {
        this.md5 = md5;
        this.fileSize = fileSize;
        this.sourceId = sourceId;
        this.transCodeFlag = 0;
        this.status = MmsProductionStatus.New;
        this.createTime = new Date();
        this.updateTime = new Date();
        this.createCustomId = customId;
    }

    public MmsModel(String md5,Long fileSize,Integer sourceId,Long createCustomId,String businessLine){
        this.md5 = md5;
        this.fileSize = fileSize;
        this.sourceId = sourceId;
        this.createCustomId = createCustomId;
        this.businessLine = businessLine;
        this.status = MmsProductionStatus.New;
        this.createTime = new Date();
        this.updateTime = new Date();
        this.mmsType = MmsTypeEnum.COMMON;
        this.transCodeFlag = 0;
    }

    public MmsModel() {
    }

    public MmsModel(Long mid) {
        this.mid = mid;
    }

    public Integer getTransCodeFlag() {
        return transCodeFlag;
    }

    public void setTransCodeFlag(Integer transCodeFlag) {
        this.transCodeFlag = transCodeFlag;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getUploadType() {
        return uploadType;
    }

    public void setUploadType(Integer uploadType) {
        this.uploadType = uploadType;
    }

    @Id
    public Long getMid() {
        return mid;
    }

    public void setMid(Long mid) {
        this.mid = mid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getPublicTime() {
        return publicTime;
    }

    public void setPublicTime(Date publicTime) {
        this.publicTime = publicTime;
    }

    public String getVideoCodes() {
        return videoCodes;
    }

    public void setVideoCodes(String videoCodes) {
        this.videoCodes = videoCodes;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getTransCodePicPrefix() {
        return transCodePicPrefix;
    }

    public void setTransCodePicPrefix(String transCodePicPrefix) {
        this.transCodePicPrefix = transCodePicPrefix;
    }

    public MmsProductionStatus getStatus() {
        return status;
    }

    public void setStatus(MmsProductionStatus status) {
        this.status = status;
    }

    public Long getCreateCustomId() {
        return createCustomId;
    }

    public void setCreateCustomId(Long createCustomId) {
        this.createCustomId = createCustomId;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSchedule() {
        return schedule;
    }

    public void setSchedule(Integer schedule) {
        this.schedule = schedule;
    }

    @Override
    public void updateStatus(int updateStatusAction) {

        switch (status){
            case New:
                switch (updateStatusAction) {
                    case Const.StartUploading:
                        setStatus(MmsProductionStatus.New);
                        break;
                    case Const.UploadingFail:
                        setStatus(MmsProductionStatus.UploadingFail);
                        break;
                    case Const.UploadingSuccess:
                        setStatus(MmsProductionStatus.uploaded);
                        break;
                    case Const.TrancodingPartSuccess:
                        setStatus(MmsProductionStatus.TranscodePDone);
                        break;
                    case Const.TranscodingSuccess:
                        setStatus(MmsProductionStatus.TranscodeDone);
                        break;
                    default:
                }
                break;
            case UploadingFail:
                switch (updateStatusAction) {
                    case Const.UploadingSuccess:
                        setStatus(MmsProductionStatus.uploaded);
                        break;
                    case Const.TrancodingPartSuccess:
                        setStatus(MmsProductionStatus.TranscodePDone);
                        break;
                    case Const.TranscodingSuccess:
                        setStatus(MmsProductionStatus.TranscodeDone);
                        break;
                    default:
                }
                break;
            case uploaded:
                switch (updateStatusAction) {
                    case Const.TrancodingPartSuccess:
                        setStatus(MmsProductionStatus.TranscodePDone);
                        break;
                    case Const.TranscodingSuccess:
                        setStatus(MmsProductionStatus.TranscodeDone);
                        break;
                    default:

                }

                break;
            case TranscodePDone:
                switch (updateStatusAction) {
                    case Const.TranscodingSuccess:
                        setStatus(MmsProductionStatus.TranscodeDone);
                        break;
                    default:

                }
                break;
            case TranscodeDone:

                break;
        }
    }

    @Override
    public boolean canbeUsedStatus() {
        return status == MmsProductionStatus.TranscodeDone || status == MmsProductionStatus.TranscodePDone;
    }

    public Long getUploadId() {
        return uploadId;
    }

    public void setUploadId(Long uploadId) {
        this.uploadId = uploadId;
    }

    public String getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(String businessLine) {
        this.businessLine = businessLine;
    }

    public String getSrcFileUrl() {
        return srcFileUrl;
    }

    public void setSrcFileUrl(String srcFileUrl) {
        this.srcFileUrl = srcFileUrl;
    }

    public MmsTypeEnum getMmsType() {
        if(mmsType == null){
            return MmsTypeEnum.COMMON;
        }
        return mmsType;
    }

    public void setMmsType(MmsTypeEnum mmsType) {
        if(mmsType == null){
            this.mmsType = MmsTypeEnum.COMMON;
        }
        this.mmsType = mmsType;
    }

    public MmsTypeEnum returnMmsType(){
        MmsTypeEnum mmsTypeEnum =  this.getMmsType();
        if(mmsTypeEnum == null){
            return MmsTypeEnum.COMMON;
        }
        return this.getMmsType();
    }
}
