package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.DefinitionEnum;

/**
 * 用户sp信息表
 */
public class CustomSpInfoModel implements Serializable {

	private static final long serialVersionUID = 2013232652586209630L;
	private Long id;
	private Long spId; // 入驻SP_ID
	private String codeRate;//码率，多个时逗号分隔
	private Integer autoOnlie;// 自动上线：0,否；1，是
	private Integer autoAudit;// 自动送审：0,否；1，是
	private Integer autoPublish;// 自动发布：0，否；1，是
	private Integer logoStatus;// logo启用状态 0:禁用;1:启用
	private Integer logoSite;// logo显示的位置 左上角:0;右上角:1;左下角:2;右下角:3
	private String cmsReqUrl;//cms栏目Url地址
	private String publishUrl;//自定义发布地址
	private String offLineUrl;//自定义下线地址
	private Integer isStartCategory;//是否启用栏目  0否 1是
	private Long createUserId;
	@JSONField(format="yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	private Long updateUserId;
	@JSONField(format="yyyy-MM-dd HH:mm:ss")
	private Date updateTime;

	private String logoDomainUrl;
	private String ptDomainUrl;
	private String pwDomainUrl;

	public String getLogoDomainUrl() {
		return logoDomainUrl;
	}

	public void setLogoDomainUrl(String logoDomainUrl) {
		this.logoDomainUrl = logoDomainUrl;
	}

	public String getPtDomainUrl() {
		return ptDomainUrl;
	}

	public void setPtDomainUrl(String ptDomainUrl) {
		this.ptDomainUrl = ptDomainUrl;
	}

	public String getPwDomainUrl() {
		return pwDomainUrl;
	}

	public void setPwDomainUrl(String pwDomainUrl) {
		this.pwDomainUrl = pwDomainUrl;
	}

	public CustomSpInfoModel() {
	}

	@Id
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodeRate() {
		return codeRate;
	}

	public void setCodeRate(String codeRate) {
		this.codeRate = codeRate;
	}

	public Long getSpId() {
		return spId;
	}

	public void setSpId(Long spId) {
		this.spId = spId;
	}

	public Integer getAutoOnlie() {
		return autoOnlie;
	}

	public void setAutoOnlie(Integer autoOnlie) {
		this.autoOnlie = autoOnlie;
	}

	public Integer getAutoAudit() {
		return autoAudit;
	}

	public void setAutoAudit(Integer autoAudit) {
		this.autoAudit = autoAudit;
	}

	public Integer getAutoPublish() {
		return autoPublish;
	}

	public void setAutoPublish(Integer autoPublish) {
		this.autoPublish = autoPublish;
	}

	public Integer getLogoSite() {
		return logoSite;
	}

	public void setLogoSite(Integer logoSite) {
		this.logoSite = logoSite;
	}

	public Integer getLogoStatus() {
		return logoStatus;
	}

	public void setLogoStatus(Integer logoStatus) {
		this.logoStatus = logoStatus;
	}

	public String getCmsReqUrl() {
		return cmsReqUrl;
	}

	public void setCmsReqUrl(String cmsReqUrl) {
		this.cmsReqUrl = cmsReqUrl;
	}

	public String getRealCodeRate() {
		if (StringUtils.isEmpty(this.codeRate)) {
			return codeRate;
		}
		return StringUtils.join(DefinitionEnum.getRateByIds(codeRate), ",");
	}

	public String getPublishUrl() {
		return publishUrl;
	}

	public void setPublishUrl(String publishUrl) {
		this.publishUrl = publishUrl;
	}

	public String getOffLineUrl() {
		return offLineUrl;
	}

	public void setOffLineUrl(String offLineUrl) {
		this.offLineUrl = offLineUrl;
	}

	public Integer getIsStartCategory() {
		return isStartCategory;
	}

	public void setIsStartCategory(Integer isStartCategory) {
		this.isStartCategory = isStartCategory;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}
	
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
