package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
@JSONType(asm=false)
public class TranscodeHistoryModel implements Serializable{

    private static final long serialVersionUID = 3239296568336635856L;
    private Long id;
	// 视频ID
    private Long videoId;
    // 客户ID
    private Long customId;
    // 转码状态 1成功，2失败
    private Integer status;
    // 文件id
    private Long fileId;
    // 文件转码任务id
    private String fileTaskId;
    private String errorCode;
    private String errorMsg;
    //创建时间
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public TranscodeHistoryModel() {
    }

    public TranscodeHistoryModel(Long videoId, Long customId, Integer status, Long fileId, String fileTaskId) {
		this.videoId = videoId;
		this.customId = customId;
		this.status = status;
		this.fileId = fileId;
		this.fileTaskId = fileTaskId;
		this.createTime = new Date();
	}

	@Id
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getFileTaskId() {
		return fileTaskId;
	}

	public void setFileTaskId(String fileTaskId) {
		this.fileTaskId = fileTaskId;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

}
