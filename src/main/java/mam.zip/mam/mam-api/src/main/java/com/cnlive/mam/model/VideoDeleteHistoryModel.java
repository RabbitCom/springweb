package com.cnlive.mam.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;

@JSONType(asm=false)
public class VideoDeleteHistoryModel implements Serializable{

	private static final long serialVersionUID = 2587366817009673114L;

	private Long id;
	
	private Long customId;
	
	private Long videoId;

    private String videoName;

    private Long deleteCustomId;
    
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    private Date deleteTime;

    private Long deleteSpId;

	public VideoDeleteHistoryModel(){}
	
	@JSONField(format="yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	private String deleteMsg;

    @Id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
	public Long getVideoId() {
		return videoId;
	}

	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public Long getDeleteCustomId() {
		return deleteCustomId;
	}

	public void setDeleteCustomId(Long deleteCustomId) {
		this.deleteCustomId = deleteCustomId;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public Long getDeleteSpId() {
		return deleteSpId;
	}

	public void setDeleteSpId(Long deleteSpId) {
		this.deleteSpId = deleteSpId;
	}
	
	public Date getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getDeleteMsg() {
		return deleteMsg;
	}

	public void setDeleteMsg(String deleteMsg) {
		this.deleteMsg = deleteMsg;
	}
}
