package com.cnlive.mam.condition;

import java.io.Serializable;

/**
 * @author zhangxiaobin
 */

public class Page implements Serializable {

	private static final long serialVersionUID = 4295761921996749356L;
	/** 页码，从1开始 */
	private int page;// pageNum 当前页
	/** 页面大小 */
	private int rows;// pageSize 每页显示记录数
	/** 起始行 */
	private int startRow;
	/** 末行 */
	private int endRow;
	/** 总数 */
	private int total;
	/** 总页数 */
	private int pages;
	/** 用于排序的字段 **/
	private String sort;
	/** 排序的方式 **/
	private String order = "desc";

	public Page() {

	}

	public Page(int page, int rows) {

		this.page = page;
		this.rows = rows;
		calculateStartAndEndRow();
	}

	public Page(int page, int rows, int total) {

		this.page = page;
		this.rows = rows;
		this.total = total;
		calculateStartAndEndRow();
	}

	public int getPages() {

		return pages;
	}

	public int getEndRow() {

		return endRow;
	}

	public int getPage() {

		return page;
	}

	public void setPage(int page) {

		this.page = page <= 0 ? 1 : page;
	}

	public int getRows() {

		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
		calculateStartAndEndRow();
	}

	public int getStartRow() {

		return startRow;
	}

	public int getTotal() {

		return total;
	}

	public void setTotal(int total) {
		this.total = total;
		calculateStartAndEndRow();
	}

	/**
	 * 计算起止行号
	 */
	private void calculateStartAndEndRow() {

		if (total > 0 && rows > 0) {
			pages = (int) (total / rows + ((total % rows == 0) ? 0 : 1));
			this.startRow = this.page > 0 ? (this.page - 1) * this.rows : 0;
			this.endRow = this.startRow + this.rows * (this.page > 0 ? 1 : 0);
		} else {
			pages = 0;
			this.startRow = this.page > 0 ? (this.page - 1) * this.rows : 0;
			this.endRow = this.startRow + this.rows * (this.page > 0 ? 1 : 0);
		}

	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
