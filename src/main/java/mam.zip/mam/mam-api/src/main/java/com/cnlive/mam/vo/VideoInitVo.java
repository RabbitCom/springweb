package com.cnlive.mam.vo;

public class VideoInitVo {
	
	 private String videoName;
	 
	 private Integer category;
	 
	 private Long customCategoryId;
	 
	 private Long albumId;
	 
	 private Long fileSize;
	 
	 private String md5;
	 
	 private Integer mmsType;
	 
	 private String gfmt;

	 private Integer logosite;

	 private Integer ptpwVal;
	public Integer getLogosite() {
		return logosite;
	}

	public void setLogosite(Integer logosite) {
		this.logosite = logosite;
	}

	public String getGfmt() {
		return gfmt;
	}

	public void setGfmt(String gfmt) {
		this.gfmt = gfmt;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public Long getCustomCategoryId() {
		return customCategoryId;
	}

	public void setCustomCategoryId(Long customCategoryId) {
		this.customCategoryId = customCategoryId;
	}

	public Long getAlbumId() {
		return albumId;
	}

	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getMd5() {
		return md5;
	}

	public void setMd5(String md5) {
		this.md5 = md5;
	}

	public Integer getMmsType() {
		return mmsType;
	}

	public void setMmsType(Integer mmsType) {
		this.mmsType = mmsType;
	}

	public Integer getPtpwVal() {
		return ptpwVal;
	}

	public void setPtpwVal(Integer ptpwVal) {
		this.ptpwVal = ptpwVal;
	}
}
