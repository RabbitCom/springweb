package com.cnlive.mam.vo;

import java.util.Map;

public class ExcelVo {
	/****视频信息***/
	// 视频ID
    private Long videoId;
    // 视频名称
    private String videoName;
    // 标签 
    private String tag;
    // 简介
    private String synopsis; 
    // 时长
    private String duration;
    // 所属数据分类
    private Integer category;
    // 所属客户分类
    private String customCategoryName;
    //审核状态
    private String auditStatus;
    //视频状态
    private String status;
    // 所属专辑
    private String albumName;
    // 版权类型
    private String copyrightType;
    // 播放平台，取字典值，多值用逗号分隔
    private String playPlatform;
    // 版权信息
    private String copyrightCompany;// 版权公司
    // 版权开始日期
    private String copyrightStart;
    // 版权结束日期
    private String copyrightEnd;
    // 内容分级
    private String contentRating;
    // 屏蔽规则
    private String shieldingRule;
    // 视频所属客户
    private Long customId;
    // 客户名称
    private String customName;
	// 媒资类型
	private String mmsType;
	// 视频图片信息
	private Map<String, String> videoImageType;
	/****专辑信息***/
    private Long albumId; 
    private Integer episodeCount;//总期数 
    /****视频审核日志信息***/
    private String auditUser; //审核人
    private String auditTime; //审核时间
    private String action;//审核结果
    private String auditReason;//不通过原因
    private String auditMessage;//备注

	private String videoBusinessId;

	private String categoryName;

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getVideoBusinessId() {
		return videoBusinessId;
	}

	public void setVideoBusinessId(String videoBusinessId) {
		this.videoBusinessId = videoBusinessId;
	}

	public Long getVideoId() {
		return videoId;
	}
	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}
	public String getVideoName() {
		return videoName;
	}
	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Integer getCategory() {
		return category;
	}
	public void setCategory(Integer category) {
		this.category = category;
	}
	public String getCustomCategoryName() {
		return customCategoryName;
	}
	public void setCustomCategoryName(String customCategoryName) {
		this.customCategoryName = customCategoryName;
	}
	public String getAuditStatus() {
		return auditStatus;
	}
	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public String getCopyrightType() {
		return copyrightType;
	}
	public void setCopyrightType(String copyrightType) {
		this.copyrightType = copyrightType;
	}
	public String getPlayPlatform() {
		return playPlatform;
	}
	public void setPlayPlatform(String playPlatform) {
		this.playPlatform = playPlatform;
	}
	public String getCopyrightCompany() {
		return copyrightCompany;
	}
	public void setCopyrightCompany(String copyrightCompany) {
		this.copyrightCompany = copyrightCompany;
	}
	public String getCopyrightStart() {
		return copyrightStart;
	}
	public void setCopyrightStart(String copyrightStart) {
		this.copyrightStart = copyrightStart;
	}
	public String getCopyrightEnd() {
		return copyrightEnd;
	}
	public void setCopyrightEnd(String copyrightEnd) {
		this.copyrightEnd = copyrightEnd;
	}
	public String getContentRating() {
		return contentRating;
	}
	public void setContentRating(String contentRating) {
		this.contentRating = contentRating;
	}
	public String getShieldingRule() {
		return shieldingRule;
	}
	public void setShieldingRule(String shieldingRule) {
		this.shieldingRule = shieldingRule;
	}
	public Long getCustomId() {
		return customId;
	}
	public void setCustomId(Long customId) {
		this.customId = customId;
	}
	public String getCustomName() {
		return customName;
	}
	public void setCustomName(String customName) {
		this.customName = customName;
	}
	public Long getAlbumId() {
		return albumId;
	}
	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}
	public Integer getEpisodeCount() {
		return episodeCount;
	}
	public void setEpisodeCount(Integer episodeCount) {
		this.episodeCount = episodeCount;
	}
	public String getAuditUser() {
		return auditUser;
	}
	public void setAuditUser(String auditUser) {
		this.auditUser = auditUser;
	}
	public String getAuditTime() {
		return auditTime;
	}
	public void setAuditTime(String auditTime) {
		this.auditTime = auditTime;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getAuditReason() {
		return auditReason;
	}
	public void setAuditReason(String auditReason) {
		this.auditReason = auditReason;
	}
	public String getAuditMessage() {
		return auditMessage;
	}
	public void setAuditMessage(String auditMessage) {
		this.auditMessage = auditMessage;
	}

	public Map<String, String> getVideoImageType() {
		return videoImageType;
	}

	public void setVideoImageType(Map<String, String> videoImageType) {
		this.videoImageType = videoImageType;
	}

	public String getMmsType() {
		return mmsType;
	}

	public void setMmsType(String mmsType) {
		this.mmsType = mmsType;
	}
}
