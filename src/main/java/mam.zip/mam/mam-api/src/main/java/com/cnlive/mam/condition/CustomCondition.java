package com.cnlive.mam.condition;

public class CustomCondition extends BaseCondition {

	private static final long serialVersionUID = 7758670212045856886L;

	private Long customId;
	private String name;
	private String codeRate;
	private String letvApprove;
	private String auditIP; // 审核IP地址
	private String email;
	private String openedBusinessLine;
	private String contacts;
	private Integer status;
	private Integer isParent;
	private Integer spId;

	public String getOpenedBusinessLine() {
		return openedBusinessLine;
	}

	public void setOpenedBusinessLine(String openedBusinessLine) {
		this.openedBusinessLine = openedBusinessLine;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;

	}

	private String phone;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCodeRate() {
		return codeRate;
	}

	public void setCodeRate(String codeRate) {
		this.codeRate = codeRate;
	}

	public String getLetvApprove() {
		return letvApprove;
	}

	public void setLetvApprove(String letvApprove) {
		this.letvApprove = letvApprove;
	}

	public String getAuditIP() {
		return auditIP;
	}

	public void setAuditIP(String auditIP) {
		this.auditIP = auditIP;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIsParent() {
		return isParent;
	}

	public void setIsParent(Integer isParent) {
		this.isParent = isParent;
	}

	public Integer getSpId() {
		return spId;
	}

	public void setSpId(Integer spId) {
		this.spId = spId;
	}

}
