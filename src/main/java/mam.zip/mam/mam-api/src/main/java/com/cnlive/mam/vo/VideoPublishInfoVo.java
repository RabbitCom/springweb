package com.cnlive.mam.vo;


import com.cnlive.mam.common.enums.PublishTypeEnum;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhangxiaobin
 */
public class VideoPublishInfoVo implements Serializable{
    private String videoIds;
    private String columnIds;
    private PublishTypeEnum publishType;
    private Long customId;
    private Date publishTime;

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getVideoIds() {
        return videoIds;
    }

    public void setVideoIds(String videoIds) {
        this.videoIds = videoIds;
    }

    public String getColumnIds() {
        return columnIds;
    }

    public void setColumnIds(String columnIds) {
        this.columnIds = columnIds;
    }

    public PublishTypeEnum getPublishType() {
        return publishType;
    }

    public void setPublishType(PublishTypeEnum publishType) {
        this.publishType = publishType;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    @Override
    public String toString() {
        return "VideoPublishInfoVo{" +
                "videoIds='" + videoIds + '\'' +
                ", columnIds='" + columnIds + '\'' +
                ", publishType=" + publishType +
                ", customId=" + customId +
                ", publishTime=" + publishTime +
                '}';
    }
}
