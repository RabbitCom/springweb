package com.cnlive.mam.vo;

import java.io.Serializable;

public class ReleaseObj implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8546236592711235972L;
	private long videoIds;
	private String title;
	private String columnId;
	private long id;
	private long pId;
	private String videoPlyUrl;
	private String MAM_NodeID;
	private String MAM_NodeName;
	private String cms_column_id;
	private String cms_column_name;
	private String businessUUID;
	public String getVideoPlyUrl() {
		return videoPlyUrl;
	}
	public void setVideoPlyUrl(String videoPlyUrl) {
		this.videoPlyUrl = videoPlyUrl;
	}
	public long getVideoIds() {
		return videoIds;
	}
	public void setVideoIds(long videoIds) {
		this.videoIds = videoIds;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getColumnId() {
		return columnId;
	}
	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getpId() {
		return pId;
	}
	public void setpId(long pId) {
		this.pId = pId;
	}
	public String getMAM_NodeID() {
		return MAM_NodeID;
	}
	public void setMAM_NodeID(String mAM_NodeID) {
		MAM_NodeID = mAM_NodeID;
	}
	public String getMAM_NodeName() {
		return MAM_NodeName;
	}
	public void setMAM_NodeName(String mAM_NodeName) {
		MAM_NodeName = mAM_NodeName;
	}
	public String getCms_column_id() {
		return cms_column_id;
	}
	public void setCms_column_id(String cms_column_id) {
		this.cms_column_id = cms_column_id;
	}
	public String getCms_column_name() {
		return cms_column_name;
	}
	public void setCms_column_name(String cms_column_name) {
		this.cms_column_name = cms_column_name;
	}
	public String getBusinessUUID() {
		return businessUUID;
	}
	public void setBusinessUUID(String businessUUID) {
		this.businessUUID = businessUUID;
	}
	
}
