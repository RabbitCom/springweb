package com.cnlive.mam.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin
 */
public class DictionaryVo implements Serializable {
    private String propertyName;
    private List<Map<String, String>> dicData;

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public List<Map<String, String>> getDicData() {
        return dicData;
    }

    public void setDicData(List<Map<String, String>> dicData) {
        this.dicData = dicData;
    }
}
