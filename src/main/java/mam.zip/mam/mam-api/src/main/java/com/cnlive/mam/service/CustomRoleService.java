package com.cnlive.mam.service;

import com.cnlive.mam.model.CustomRoleModel;

import java.util.List;

/**
 * @author liyi
 */
public interface CustomRoleService {

    CustomRoleModel selectById(Integer id);

    List<CustomRoleModel> selectBySpId(Integer spId);

    List<CustomRoleModel> selectByRoleNameAndSpid(CustomRoleModel customRoleModel);

    void insert(CustomRoleModel customRoleModel);

    void update(CustomRoleModel customRoleModel);

    void delete(Integer roleId);
}
