package com.cnlive.mam.vo;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.resultMessage.CnliveResultMessage;

/**
 * 
 * JSON模型
 * 
 * 用户后台向前台返回的JSON对象
 * 
 * @author ZhangXiaoBin
 * 
 */
public class JsonResult implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean success = false;
	
	private Integer code ;

	private String msg = "";

	private Object obj = null;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
	
	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public JsonResult(){}

	public JsonResult(int code,String msg,boolean flag){
		this.code = code;
		this.msg = msg;
		this.success = flag;
	}

	public JsonResult(int code,String msg,boolean flag,Object obj){
		this.code = code;
		this.msg = msg;
		this.success = flag;
		this.obj = obj;
	}

	public static JsonResult createInstance(CnliveResultMessage resultMessage,boolean flag){
		return new JsonResult(resultMessage.getCode(),resultMessage.getMessage(),flag);
	}

	public static JsonResult createInstance(CnliveResultMessage resultMessage,boolean flag, Object object){
		return new JsonResult(resultMessage.getCode(),resultMessage.getMessage(),flag,object);
	}


	public static JsonResult createSuccessInstance(Object data) {
		return JsonResult.createInstance(CnliveResultMessage.SUCCESS,true,data);
	}

	public static JsonResult createSuccessInstance(String sucMsg, Object data) {
		JsonResult ret = new JsonResult();
		ret.setSuccess(Boolean.TRUE);
		ret.setObj(data);
		ret.setMsg(sucMsg);
		ret.setCode(0);
		return ret;
	}

	public static JsonResult createErrorInstance(String errorMsg) {
		JsonResult ret = new JsonResult();
		ret.setSuccess(Boolean.FALSE);
		ret.setMsg(errorMsg);
		ret.setCode(-1);
		return ret;
	}

	public static JsonResult createSuccessInstance(String showMsg) {
		JsonResult ret = new JsonResult();
		ret.setSuccess(Boolean.TRUE);
		ret.setMsg(showMsg);
		ret.setCode(0);
		return ret;
	}

}
