package com.cnlive.mam.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author ZHANGXIAOBIN
 * 
 */
@SuppressWarnings("rawtypes")
public class DataGrid implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4433514756307457736L;
	
	private Long total = 0L;
	private List rows = new ArrayList();

	public DataGrid(){}
	
	public DataGrid(Long total,List rows){
	    this.total = total;
	    this.rows = rows;
	}
	
	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public List getRows() {
		return rows;
	}

	public void setRows(List rows) {
		this.rows = rows;
		if(rows!=null && rows.size() > 0 && this.total == 0 ){
			this.total = (long) rows.size();
		}
	}

}
