package com.cnlive.mam.service;

import com.cnlive.mam.condition.CustomCondition;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.vo.DataGrid;

import java.util.List;

/**
 * @author zhangxiaobin
 */
public interface CustomService {


    CustomModel getById(Long id);

    void save(CustomModel t);

    void create(CustomModel t);

    void modify(CustomModel t);

    DataGrid getCustomInfoList(CustomCondition customCondition);

    List<CustomModel> getCustomsInfoByRoleId(Long roleId);

    long findMaxTm();

    Long getParentCutsomerBySpId(Long spId);

    Long countByCustom(CustomModel t);

    List<CustomModel> getByCustomName(String customName,Long spId);
}
