package com.cnlive.mam.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;
import com.cnlive.mam.common.annotation.Id;
import com.cnlive.mam.common.enums.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

@JSONType(asm = false)
public class VideoModel extends VideoExtends implements Serializable {

	private static final long serialVersionUID = 3239296568336635856L;

	// 视频ID
	private Long videoId;
	// 媒资id
	// private Long mid ;
	// private Long fid ;
	// 视频名称
	private String videoName;
	// 所属分类
	private Integer category;
	// 所属专辑
	private Long albumId;

	// 标签 使用逗号分隔
	private String tag;
	// 当前集数
	private Integer episode;

	// 时长
	private Long duration;
	// 播放平台，取字典值，多值用逗号分隔
	private String playPlatform;
	//
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	//
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;

	// 下载平台，取字典值，多值用逗号分隔
	private String downloadPlatform;
	// 付费平台，取字典值，多值用逗号分隔
	private String payPlatform;

	// 转码时从视频内部抓取的图片
	private String picOriginal;
	// 0不加片头片尾，1加片头片尾
	private Integer canSearch;

	// 手工后台编辑的图片
	private String picFinishedImg;
	// 视频所属客户
	private Long customId;
	// 子分类
	private String subCategory;
	// 片头时间，单位秒
	private Integer btime;
	// 片尾时间，单位秒
	private Integer etime;
	//
	private Long createUserId;
	//
	private Long updateUserId;
	// 客户分类ID
	private Long customCategoryId;
	// 扩展属性
	private String extendProperties;

	private Integer videoType;
	private String subTitle;

	private Float score; // 评分
	private String language;
	private String area;

	// 版权信息
	private String copyrightCompany;// 版权公司
	private Integer copyrightType;// 版权类型
	@JSONField(format = "yyyy-MM-dd")
	private Date copyrightStart;// 版权开始日期
	@JSONField(format = "yyyy-MM-dd")
	private Date copyrightEnd;// 版权结束日期

	private Integer shieldingRule;// 屏蔽规则
	private String contentRating;// 内容分级
	private Integer barrageSet;// 弹幕设置

	private String synopsis; // 简介
	// 视频发布地址
	private String videoPlyUrl;

	@JSONField(format = "yyyy-MM-dd")
	private Date releaseDate;

	private ModelStatus status;
	/**
	 * 0初始状态,1可审核状态,2审核通过,3审核不通过
	 */
	private VideoAuditStatus auditStatus;
	private FileStatus fileStatus;

	private String playArea; // 可播放区域 字典值
	/**
	 * 默认0客户自有视频，其他为视频编号，客户购买视频
	 */
	// private Long originVideoId;

	private String chouzhenTaskId;// chouzhenrenwuID

	private String videoSource;

	private String businessUUID;// 业务主键 customId+uuid

	private MmsTypeEnum mmsType;

	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date publishTime;

	private String playUrl; // 列表播放地址

	private Integer autoPublish;

	private Integer autoOnline;

	private Long spid;

	private String cancelPrePublishFlag;// 取消预发布标志

	private Integer publishState;// 发布标志 0立即发布，1定时发布

	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date prePublishedTime;// 预发布时间

	private String uploadId;

	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date uploadBtime;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date uploadEtime;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date chouzhenBtime;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date chouzhenEtime;
	private VideoSources isIcms2Mam;// 1表示：从老媒资同步的数据

	private Integer logosite; //转码标识

	private String institutionId ;

    private Integer storageId;

    private Integer storageImgId;

    private String description;

	private Map<String, String> allPicScale ;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStorageId() {
        return storageId;
    }

    public void setStorageId(Integer storageId) {
        this.storageId = storageId;
    }

    public Integer getStorageImgId() {
        return storageImgId;
    }

    public void setStorageImgId(Integer storageImgId) {
        this.storageImgId = storageImgId;
    }

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public Integer getLogosite() {
		return logosite;
	}

	public void setLogosite(Integer logosite) {
		this.logosite = logosite;
	}

	public Date getChouzhenBtime() {
		return chouzhenBtime;
	}

	public void setChouzhenBtime(Date chouzhenBtime) {
		this.chouzhenBtime = chouzhenBtime;
	}

	public Date getChouzhenEtime() {
		return chouzhenEtime;
	}

	public void setChouzhenEtime(Date chouzhenEtime) {
		this.chouzhenEtime = chouzhenEtime;
	}

	public Date getUploadBtime() {
		return uploadBtime;
	}

	public void setUploadBtime(Date uploadBtime) {
		this.uploadBtime = uploadBtime;
	}

	public Date getUploadEtime() {
		return uploadEtime;
	}

	public void setUploadEtime(Date uploadEtime) {
		this.uploadEtime = uploadEtime;
	}

	public String getUploadId() {
		return uploadId;
	}

	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	public Integer getPublishState() {
		return publishState;
	}

	public void setPublishState(Integer publishState) {
		this.publishState = publishState;
	}

	public Date getPrePublishedTime() {
		return prePublishedTime;
	}

	public void setPrePublishedTime(Date prePublishedTime) {
		this.prePublishedTime = prePublishedTime;
	}

	public String getCancelPrePublishFlag() {
		return cancelPrePublishFlag;
	}

	public void setCancelPrePublishFlag(String cancelPrePublishFlag) {
		this.cancelPrePublishFlag = cancelPrePublishFlag;
	}

	public Long getSpid() {
		return spid;
	}

	public void setSpid(Long spid) {
		this.spid = spid;
	}

	public Integer getAutoPublish() {
		return autoPublish;
	}

	public void setAutoPublish(Integer autoPublish) {
		this.autoPublish = autoPublish;
	}

	public Integer getAutoOnline() {
		return autoOnline;
	}

	public void setAutoOnline(Integer autoOnline) {
		this.autoOnline = autoOnline;
	}

	public String getPlayUrl() {
		return playUrl;
	}

	public void setPlayUrl(String playUrl) {
		this.playUrl = playUrl;
	}

	public Date getPublishTime() {
		return publishTime;
	}

	public void setPublishTime(Date publishTime) {
		this.publishTime = publishTime;
	}

	public String getVideoPlyUrl() {
		return videoPlyUrl;
	}

	public void setVideoPlyUrl(String videoPlyUrl) {
		this.videoPlyUrl = videoPlyUrl;
	}

	public VideoAuditStatus getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(VideoAuditStatus auditStatus) {
		this.auditStatus = auditStatus;
	}

	public FileStatus getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(FileStatus fileStatus) {
		this.fileStatus = fileStatus;
	}

	public MmsTypeEnum getMmsType() {
		return mmsType;
	}

	public void setMmsType(MmsTypeEnum mmsType) {
		this.mmsType = mmsType;
	}

	public String getVideoSource() {
		return videoSource;
	}

	public void setVideoSource(String videoSource) {
		this.videoSource = videoSource;
	}

	public String getPlayArea() {
		return playArea;
	}

	public void setPlayArea(String playArea) {
		this.playArea = playArea;
	}

	public VideoModel(String videoName, Integer category, Long customId, Long customCategoryId) {
		this.videoName = videoName;
		this.category = category;
		this.customId = customId;
		this.createUserId = customId;
		this.customCategoryId = customCategoryId;
	}

	public VideoModel(Long videoId) {
		this.videoId = videoId;
	}

	public VideoModel() {
	}

	public ModelStatus getStatus() {
		return status;
	}

	public void setStatus(ModelStatus status) {
		this.status = status;
	}

	@Id
	public Long getVideoId() {
		return videoId;
	}

	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public Long getAlbumId() {
		return albumId;
	}

	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Integer getEpisode() {
		return episode;
	}

	public void setEpisode(Integer episode) {
		this.episode = episode;
	}

	public Long getDuration() {
		return duration;
	}

	public String getChouzhenTaskId() {
		return chouzhenTaskId;
	}

	public void setChouzhenTaskId(String chouzhenTaskId) {
		this.chouzhenTaskId = chouzhenTaskId;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public String getPlayPlatform() {
		return playPlatform;
	}

	public void setPlayPlatform(String playPlatform) {
		this.playPlatform = playPlatform;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getDownloadPlatform() {
		return downloadPlatform;
	}

	public void setDownloadPlatform(String downloadPlatform) {
		this.downloadPlatform = downloadPlatform;
	}

	public String getPayPlatform() {
		return payPlatform;
	}

	public void setPayPlatform(String payPlatform) {
		this.payPlatform = payPlatform;
	}

	public String getPicOriginal() {
		return picOriginal;
	}

	public void setPicOriginal(String picOriginal) {
		this.picOriginal = picOriginal;
	}

	public Integer getCanSearch() {
		return canSearch;
	}

	public void setCanSearch(Integer canSearch) {
		this.canSearch = canSearch;
	}

	public String getPicFinishedImg() {
		return picFinishedImg;
	}

	public void setPicFinishedImg(String picFinishedImg) {
		this.picFinishedImg = picFinishedImg;
	}

	public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public Integer getBtime() {
		return btime;
	}

	public void setBtime(Integer btime) {
		this.btime = btime;
	}

	public Integer getEtime() {
		return etime;
	}

	public void setEtime(Integer etime) {
		this.etime = etime;
	}

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Long getCustomCategoryId() {
		return customCategoryId;
	}

	public void setCustomCategoryId(Long customCategoryId) {
		this.customCategoryId = customCategoryId;
	}

	public String getExtendProperties() {
		return extendProperties;
	}

	public void setExtendProperties(String extendProperties) {
		this.extendProperties = extendProperties;
	}

	public String getCopyrightCompany() {
		return copyrightCompany;
	}

	public void setCopyrightCompany(String copyrightCompany) {
		this.copyrightCompany = copyrightCompany;
	}

	public Integer getCopyrightType() {
		return copyrightType;
	}

	public void setCopyrightType(Integer copyrightType) {
		this.copyrightType = copyrightType;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date getCopyrightStart() {
		return copyrightStart;
	}

	public void setCopyrightStart(Date copyrightStart) {
		this.copyrightStart = copyrightStart;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date getCopyrightEnd() {
		return copyrightEnd;
	}

	public void setCopyrightEnd(Date copyrightEnd) {
		this.copyrightEnd = copyrightEnd;
	}

	public Integer getShieldingRule() {
		return shieldingRule;
	}

	public void setShieldingRule(Integer shieldingRule) {
		this.shieldingRule = shieldingRule;
	}

	public String getContentRating() {
		return contentRating;
	}

	public void setContentRating(String contentRating) {
		this.contentRating = contentRating;
	}

	public Integer getBarrageSet() {
		return barrageSet;
	}

	public void setBarrageSet(Integer barrageSet) {
		this.barrageSet = barrageSet;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Integer getVideoType() {
		return videoType;
	}

	public void setVideoType(Integer videoType) {
		this.videoType = videoType;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public Float getScore() {
		return score;
	}

	public void setScore(Float score) {
		this.score = score;
	}

	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getBusinessUUID() {
		return businessUUID;
	}

	public void setBusinessUUID(String businessUUID) {
		this.businessUUID = businessUUID;
	}

	public void fullProperty() {

		if (status == null || status.getDbValue() == ModelStatus.Edit.getDbValue()) {
			status = ModelStatus.EditOver;
		}
	}

	/**
	 * @throws @Title:
	 *             getAllPicScale
	 * @Description:返回所有分辨率的图片 {400*300 ： http://xxxxxxx_400_300.jpg}
	 */
	public Map<String, String> getAllPicScale() {
		return allPicScale;
	}

	public void setAllPicScale(Map<String, String> allPicScale){
		this.allPicScale = allPicScale;
	}

	public MmsTypeEnum returnMmsType() {
		MmsTypeEnum mmsTypeEnum = this.getMmsType();
		if (mmsTypeEnum == null) {
			return MmsTypeEnum.COMMON;
		}
		return this.getMmsType();
	}

	public VideoSources getIsIcms2Mam() {
		return isIcms2Mam;
	}

	public void setIsIcms2Mam(VideoSources isIcms2Mam) {
		this.isIcms2Mam = isIcms2Mam;
	}

}
