package com.cnlive.mam.common.utils;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Joiner;
import com.google.common.base.Predicates;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;

/**
 * Created by zhangxiaobin
 */
public class DataProcessorUtil {
    private static Logger _log = LoggerFactory.getLogger(DataProcessorUtil.class);
    /**
     * 去掉重复标签
     * @param tags
     * @return
     */
    public static String processTag(String tags) {
        return Joiner.on("/").join(removeDuplicate(Splitter.on("/").omitEmptyStrings().trimResults().splitToList(tags)));
    }

    /**
     * 去掉重复部分元素
     * @param list
     * @param <T>
     * @return
     */
    public static <T> List<T> removeDuplicate(List<T> list) {
        return ImmutableSet.copyOf(Iterables.filter(list, Predicates.not(Predicates.isNull()))).asList();
        //return new ArrayList<T>(new LinkedHashSet<T>(list));
    }

    public static void main(String[] args) {
        _log.info(processTag("tag1/null  /  tag1/ tag22/ tag2/ tag2 /tag4"));

        List<String> list=new ArrayList<>();
        list.add("a");
        list.add("b");
        list.add("c");
        list.add("b");
        list.add("c");
        list.add(null);
        list = removeDuplicate(list);
        _log.info(list.toString());

    }

}
