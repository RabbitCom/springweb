package com.cnlive.mam.common.enums;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public enum StorageTypeEnum implements EnumDB {
    NotSet(0),//未设置

    KSYUN(1),//金山云

    QINIUYUN(2),//七牛云

    Definition(3);//自建存储

    private int type;

    StorageTypeEnum(Integer str) {
        this.type = str;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public int getDbValue() {
        return type;
    }
}
