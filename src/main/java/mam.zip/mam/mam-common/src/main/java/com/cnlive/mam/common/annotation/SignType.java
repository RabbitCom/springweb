package com.cnlive.mam.common.annotation;


/**
 * Created by zhangxiaobin
 */
public enum SignType {
    TRUSTSYS,OPENAPI
}
