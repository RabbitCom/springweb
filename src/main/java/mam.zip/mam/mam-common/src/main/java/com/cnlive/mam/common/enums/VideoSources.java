package com.cnlive.mam.common.enums;

/**
 * Created by zhangxiaobin on 2017/7/24.
 * 视频来源
 */
public enum VideoSources implements EnumDB {

    mam(0), //自建
    old2mam(1),  //老素材数据
    live2mam(2) //直播转点播
    ;

    VideoSources(int i){
        this.value = i;
    }

    int value;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public int getDbValue() {
        return this.value;
    }
}
