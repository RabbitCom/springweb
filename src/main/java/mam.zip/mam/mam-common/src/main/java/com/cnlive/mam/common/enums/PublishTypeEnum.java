package com.cnlive.mam.common.enums;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
public enum PublishTypeEnum implements EnumDB
{
    ImmediatelyPublish(1),//立即发布
    TimingPublish(2),//定时发布
    PrePublish(3); //预发布

    Integer publishType;

    private PublishTypeEnum(Integer publishType){
        this.publishType = publishType;
    }

    @Override
    public int getDbValue()
    {
        return publishType;
    }

    public Integer getPublishType()
    {
        return publishType;
    }

    public void setPublishType(Integer publishType)
    {
        this.publishType = publishType;
    }

    public static PublishTypeEnum IsDefined(Integer publishType){
        if(publishType==null){
            return null;
        }
        for (PublishTypeEnum publishTypeEnum:PublishTypeEnum.values()){
            if(publishTypeEnum.publishType==publishType){
                return publishTypeEnum;
            }
        }
        return null;
    }
}
