package com.cnlive.mam.common.annotation;

import com.google.common.base.Strings;

/**
 * Created by zhangxiaobin
 */
public enum SignPlatform {

    TRANSCODE("10011348"),
    AUDIT("10011438"),
    ICMS("10011148"),
    LIVECONTROL("1497863613"),
    LIVECOULD("1498012466"),
    CATEGORY("10011606"),
    LIVE2MAM("10011451"),
    THIRDPARTY("8111751");

    private String code;

    /**
     * @param name
     * @return
     */
    public static SignPlatform getInstanceByName(String name) {
        if (Strings.isNullOrEmpty(name)) return null;
        for(SignPlatform item : SignPlatform.values()){
            if(item.name().equalsIgnoreCase(name)){
                return item;
            }
        }
        return null;
    }

    SignPlatform(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
