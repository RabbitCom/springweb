package com.cnlive.mam.common.enums;

/**
 * @author zhangxiaobin
 * @date 15/10/26
 */
public interface EnumDB {
    public int getDbValue();

}
