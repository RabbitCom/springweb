package com.cnlive.mam.common.exception;

/**
 * @author zhangxiaobin
 */

public class ValidateException extends RuntimeException {


    public ValidateException() {
    }

    public ValidateException(String msg) {
        super(msg);
    }

    public ValidateException(String message, Throwable cause) {
        super(message, cause);
    }

    public ValidateException(Throwable cause) {
        super(cause);
    }

}
