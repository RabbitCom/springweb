package com.cnlive.mam.common.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

public class OpenUtil {

	/**
	 * 验证签名
	 * 用于服务端
	 * @param request
	 * @param sp_key
	 * @return
	 */
	@SuppressWarnings("all")
	public static boolean validateSign(ServletRequest request,String sp_key){
		return validateSign(request,sp_key,null);
	}

	/**
	 * 验证签名
	 * 用于服务端
	 * @param request
	 * @param sp_key
	 * @return
	 */
	public static boolean validateSign(ServletRequest request,String sp_key,String... ignore){
		Map<String,String> map = getRequestParam(request);
		String sign = map.get("sign");
		map.remove("sign");
		if(ignore!=null){
			for(String key : ignore){
				map.remove(key);
			}
		}
		map = order(map);
		String str = mapJoin(map, true, false);
		String mySign = SHA1.SHA1Digest(str+"&key="+sp_key).toUpperCase();
		return mySign.equals(sign);
	}

	/**
	 * 生成get 请求 URL
	 * @param url
	 * @param params
	 * @param sp_key
	 * @return
	 */
	public static String buildURL(String url,Map<String,String> params,String sp_key){
		Map<String,String> map = order(params);
		if(map.containsKey("sign")){
			map.remove("sign");
		}
		String str = mapJoin(map,true,false);
		//System.out.println("参与签名SHA1的字符串:");
		//System.out.println(str+"&key="+sp_key);
		
		String sign = SHA1.SHA1Digest(str+"&key="+sp_key).toUpperCase();
		map.put("sign", sign);
		return url+"?"+mapJoin(map, false, true);
	}

	/**
	 * 生成签名 sign
	 * @param params
	 * @param sp_key
	 * @return
	 */
	public static String sign(Map<String,String> params,String sp_key){
		Map<String,String> map = order(params);
		if(map.containsKey("sign")){
			map.remove("sign");
		}
		String str = mapJoin(map,true,false);
		return SHA1.SHA1Digest(str+"&key="+sp_key).toUpperCase();
	}

	/**
	 * 获取请求参数
	 * @param request
	 * @return
	 */
	public static Map<String,String> getRequestParam(ServletRequest request){
		Map<String, String> map = new LinkedHashMap<String, String>();
		Map<String, String[]> map2 = request.getParameterMap();
		for(String key : map2.keySet()){
			if(map2.get(key)==null||map2.get(key).length==0){
				map.put(key,null);
			}else{
				try {
					//String value = URLDecoder.decode(new String(map2.get(key)[0].getBytes("iso-8859-1"),"utf-8"), "utf-8");
					String value = URLDecoder.decode(map2.get(key)[0],"utf-8");
					map.put(key,value);
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		return map;
	}

	/**
	 * 获取附加参数
	 * @param servletRequest
	 * @param attachKey 返回的map key是否以 attach. 开头
	 * @return
	 */
	public static Map<String, String> getAttachParam(ServletRequest servletRequest,boolean attachKey){
		Map<String,String[]> maps = servletRequest.getParameterMap();
		Map<String, String> map = new LinkedHashMap<String, String>();
		for(String key : maps.keySet()){
			String[] vk = key.split("\\.");
			if(vk.length==2&&vk[0].equals("attach")){
				map.put(attachKey?key:vk[1],maps.get(key)[0]);
			}
		}
		return map;
	}


	/**
	 * url 参数串连
	 * @param map
	 * @param keyLower
	 * @param valueUrlencode
	 * @return
	 */
	private static String mapJoin(Map<String, String> map,boolean keyLower,boolean valueUrlencode){
		StringBuilder stringBuilder = new StringBuilder();
		for(String key :map.keySet()){
			if(map.get(key)!=null&&!"".equals(map.get(key))){
				try {
					stringBuilder.append(key)
								 .append("=")
								 .append(valueUrlencode?URLEncoder.encode(map.get(key),"utf-8").replace("+", "%20"):map.get(key))
								 .append("&");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		if(stringBuilder.length()>0){
			stringBuilder.deleteCharAt(stringBuilder.length()-1);
		}
		return stringBuilder.toString();
	}


	/**
	 * Map key 排序
	 * @param map
	 * @return
	 */
	private static Map<String,String> order(Map<String, String> map){
		HashMap<String, String> tempMap = new LinkedHashMap<String, String>();
		List<Map.Entry<String, String>> infoIds = new ArrayList<Map.Entry<String, String>>(	map.entrySet());

		Collections.sort(infoIds, new Comparator<Map.Entry<String, String>>() {
			public int compare(Map.Entry<String, String> o1,Map.Entry<String, String> o2) {
				return (o1.getKey()).toString().compareTo(o2.getKey());
			}
		});

		for (int i = 0; i < infoIds.size(); i++) {
			Map.Entry<String, String> item = infoIds.get(i);
			tempMap.put(item.getKey(), item.getValue());
		}
		return tempMap;
	}
	
}
