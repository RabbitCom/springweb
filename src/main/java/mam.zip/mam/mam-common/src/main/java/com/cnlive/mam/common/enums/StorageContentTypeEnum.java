package com.cnlive.mam.common.enums;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public enum StorageContentTypeEnum implements EnumDB {

    NotSet(0),//未设置

    Media(1),//1视音频

    Picture(2),//2图片

    MediaAndPicture(3),//3视音频+图片+wenjian

    File(4);//文件

    private int contentType;

    StorageContentTypeEnum(Integer str) {
        this.contentType = str;
    }

    public int getContentType() {
        return contentType;
    }

    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    @Override
    public int getDbValue() {
        return contentType;
    }
}
