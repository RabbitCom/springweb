package com.cnlive.mam.common.resultMessage;

import java.io.Serializable;

/**
 * Created by zhangxiaobin
 */
public class ValidateResult<T> implements Serializable {

    private static final long serialVersionUID = -4483947215955969032L;
    private boolean success;

    private String errorCode;

    private String errorMsg;

    private T data;

    public static ValidateResult createSuccessInstance() {
        ValidateResult result = new ValidateResult();
        result.setSuccess(true);
        return result;
    }

    public static <T> ValidateResult<T> createSuccessInstance(String successCode,String successMessage,T data) {
        ValidateResult<T> result = new ValidateResult<T>();
        result.setSuccess(true);
        result.setErrorCode(successCode);
        result.setErrorMsg(successMessage);
        result.setData(data);
        return result;
    }

    public static <T> ValidateResult<T> createSuccessInstance(T data) {
        ValidateResult result = new ValidateResult();
        result.setSuccess(true);
        result.setData(data);
        return result;
    }

    public static ValidateResult createErrorInstance(String errorCode,String errorMsg) {
        ValidateResult result = new ValidateResult();
        result.setSuccess(false);
        result.setErrorCode(errorCode);
        result.setErrorMsg(errorMsg);
        return result;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public ValidateResult addData(T data) {
        this.data = data;
        return this;
    }

    @Override
    public String toString() {
        return "ValidateResult{" +
                "success=" + success +
                ", errorCode='" + errorCode + '\'' +
                ", errorMsg='" + errorMsg + '\'' +
                ", data=" + data +
                '}';
    }

}
