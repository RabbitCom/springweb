package com.cnlive.mam.common.web;


import com.alibaba.fastjson.parser.DefaultJSONParser;
import com.alibaba.fastjson.parser.JSONLexer;
import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;

import java.io.IOException;
import java.lang.reflect.Type;

/**
 * Created by zhangxiaobin
 */
public class CustomStringSerializer implements ObjectDeserializer {

    @Override
    public String deserialze(DefaultJSONParser defaultJSONParser, Type type, Object o) {
        JSONLexer lexer = defaultJSONParser.getLexer();
        String value = lexer.stringVal();
        if(value == null || value.equals("")){
            return "";
        }else{
            value = value.replace("\"","'");
            return new StringEscapeEditor().escapeValue(value);
        }
    }

    @Override
    public int getFastMatchToken() {
        return 0;
    }
}
