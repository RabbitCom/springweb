package com.cnlive.mam.common.enums;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangxiaobin
 */
public enum ModelStatus implements EnumDB {
    New(-1),//初始化
    Edit(0),//待编辑
    EditOver(1), //已编辑
    AuditIng(2),//审核中
    AuditSuccess(3),//审核成功
    AuditFail(4),//审核失败
    OnLine(5),//上线
    OffLine(6),//下线
    ReleaseIng(7),//发布中
    ReleaseSuccess(8),//发布成功
    ReleaseFail(9),//发布失败
    Delete(10);//删除

    int dbValue;

    private ModelStatus(int i){
        this.dbValue = i;
    }
    @Override
    public int getDbValue() {
        return dbValue;
    }

    public static List<Integer> getCanUsedValues(){
        List<Integer> vals = new ArrayList<>();
        vals.add(ModelStatus.OnLine.getDbValue());
        vals.add(ModelStatus.ReleaseSuccess.getDbValue());
        vals.add(ModelStatus.ReleaseIng.getDbValue());
        vals.add(ModelStatus.ReleaseFail.getDbValue());
        return vals;
    }

    public static List<Integer> getNoCanUsedValues(){
        List<Integer> vals = new ArrayList<>();
        vals.add(ModelStatus.New.getDbValue());
        vals.add(ModelStatus.Edit.getDbValue());
        vals.add(ModelStatus.EditOver.getDbValue());
        vals.add(ModelStatus.AuditIng.getDbValue());
        vals.add(ModelStatus.AuditSuccess.getDbValue());
        vals.add(ModelStatus.AuditFail.getDbValue());
        vals.add(ModelStatus.OffLine.getDbValue());
        vals.add(ModelStatus.Delete.getDbValue());
        return vals;
    }
}
