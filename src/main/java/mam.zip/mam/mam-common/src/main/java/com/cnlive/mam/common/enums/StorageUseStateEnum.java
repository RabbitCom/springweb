package com.cnlive.mam.common.enums;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public enum StorageUseStateEnum implements EnumDB {

    NotUse(0),//未使用

    Used(1),//使用中//启用

    UsedBefore(2);//使用过//禁用

    private int State;

    StorageUseStateEnum(Integer str) {
        this.State = str;
    }

    public int getState() {
        return State;
    }

    public void setState(int state) {
        State = state;
    }

    @Override
    public int getDbValue() {
        return State;
    }
}
