package com.cnlive.mam.common.enums;

/**
 * @author zhangxiaobin
 */
public enum VideoAuditStatus  implements EnumDB {
    New(0),
    CanAudit(1),
    AuditPass(2),
    AuditNoPass(3);

    int dbValue;

    private VideoAuditStatus(int i){
        this.dbValue = i;
    }
    @Override
    public int getDbValue() {
        return dbValue;
    }
}
