package com.cnlive.mam.common.log;



import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

import java.io.IOException;

/**
 * 日志初始化
 */

public final class LogConfig {

    Resource resource;
    public LogConfig(Resource configFilePath){
        this.resource = configFilePath;
    }

    /**
     * 初始化
     *
     * @param configFilePath 配置文件路径
     * @throws JoranException 异常
     */
    public static void config(String configFilePath) throws JoranException {
        LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(lc);
        lc.reset();

        configurator.doConfigure(configFilePath);
    }
    public void reload() throws JoranException, IOException {
        LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(lc);
        lc.reset();

        configurator.doConfigure(resource.getURL());
    }
}