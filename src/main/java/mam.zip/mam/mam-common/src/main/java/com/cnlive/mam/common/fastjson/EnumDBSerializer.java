package com.cnlive.mam.common.fastjson;

import com.alibaba.fastjson.serializer.JSONSerializer;
import com.alibaba.fastjson.serializer.ObjectSerializer;
import com.alibaba.fastjson.serializer.SerializeWriter;
import com.cnlive.mam.common.enums.EnumDB;

import java.io.IOException;
import java.lang.reflect.Type;

/**
 * @author zhangxiaobin
 */

public class EnumDBSerializer implements ObjectSerializer {



    @Override
    public void write(JSONSerializer serializer, Object object, Object o1, Type type, int i) throws IOException {
        SerializeWriter out = serializer.getWriter();
        if (object == null) {
            serializer.getWriter().writeNull();
            return;
        }
        out.writeInt(((EnumDB) object).getDbValue());

    }
}
