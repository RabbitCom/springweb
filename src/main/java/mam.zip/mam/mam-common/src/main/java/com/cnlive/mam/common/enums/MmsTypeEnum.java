package com.cnlive.mam.common.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin
 */
public enum MmsTypeEnum implements EnumDB{
    COMMON(0,"普通"),TYPE_360(1,"全景"),TYPE_3D(2,"3D");

    private Integer code;
    private String showName;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    MmsTypeEnum(Integer code,String showName) {
        this.code = code;
        this.showName = showName;
    }

    MmsTypeEnum() {
    }

    @Override
    public int getDbValue() {
        return code;
    }

    public static MmsTypeEnum getMmsTypeEnumByCode(int code){
        for(MmsTypeEnum mmsTypeEnum:MmsTypeEnum.values()){
            if(mmsTypeEnum.getCode() == code){
                return mmsTypeEnum;
            }
        }
        return null;
    }

    public static List<Map<String,String>> getAllMmsTypeMap(){
        List<Map<String,String>> allTypes = new ArrayList<>();
        for (MmsTypeEnum mmsTypeEnum:MmsTypeEnum.values()){
            Map<String,String> map = new HashMap<>();
            map.put("showName",mmsTypeEnum.getShowName().toString());
            map.put("value",mmsTypeEnum.getCode().toString());
            allTypes.add(map);
        }
        return allTypes;
    }
}
