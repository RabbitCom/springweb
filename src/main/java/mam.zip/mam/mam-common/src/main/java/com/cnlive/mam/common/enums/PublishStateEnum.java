package com.cnlive.mam.common.enums;

/**
 * Created by zhangxiaobin on 16/11/2.
 */
public enum PublishStateEnum implements EnumDB
{
    TobePublish(0),//0待发布
    PublishIng(10),//10发布中
    Success(20),//20 发布成功
    Faild(30),//30发布失败
    Default(-1),//-1 取消发布后的状态 数据库默认
    ;

    Integer publishState;

    public Integer getPublishState()
    {
        return publishState;
    }

    public void setPublishState(Integer publishState)
    {
        this.publishState = publishState;
    }

    private PublishStateEnum(Integer publishState){
        this.publishState = publishState;
    }

    @Override
    public int getDbValue()
    {
        return publishState;
    }
}
