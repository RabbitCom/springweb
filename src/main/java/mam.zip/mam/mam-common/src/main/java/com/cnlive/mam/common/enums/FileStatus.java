package com.cnlive.mam.common.enums;

/**
 * @author zhangxiaobin
 * @date 15/10/30
 */
public enum FileStatus implements EnumDB {
    New(-1),//初始化
    UploadSuccess(0),//上传成功，上传完成
    TranscodingIng(1),//转码中
    TranscodingSuccess(2),//转码成功
    TranscodingFail(3),//转码失败
    Down(4);//下线

    private int value;

    private FileStatus(int i){
        this.value = i;
    }
    //Integer status;  //0初始状态，1转码完成,2分发完成,3下线
    @Override
    public int getDbValue() {
        return value;
    }
}
