package com.cnlive.mam.common.fastjson;

import com.alibaba.fastjson.parser.ParserConfig;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.cnlive.mam.common.enums.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author zhangxiaobin
 */
public class FastJsonEnumDBSupportManager {
    private static final Logger log = LoggerFactory.getLogger(FastJsonEnumDBSupportManager.class);


    public void init(){
        log.info("FastJsonEnumDBSupportManager start.");
        ParserConfig parserConfig = ParserConfig.getGlobalInstance();
        parserConfig.putDeserializer(MmsProductionStatus.class,new EnumDBDeserializer(MmsProductionStatus.class));
        parserConfig.putDeserializer(ModelStatus.class, new EnumDBDeserializer(ModelStatus.class));
        parserConfig.putDeserializer(VideoAuditStatus.class,new EnumDBDeserializer(VideoAuditStatus.class));
        parserConfig.putDeserializer(MmsTypeEnum.class,new EnumDBDeserializer(MmsTypeEnum.class));
        parserConfig.putDeserializer(PublishStateEnum.class,new EnumDBDeserializer(PublishStateEnum.class));
        parserConfig.putDeserializer(PublishTypeEnum.class,new EnumDBDeserializer(PublishTypeEnum.class));
        parserConfig.putDeserializer(FileStatus.class,new EnumDBDeserializer(FileStatus.class));
        parserConfig.putDeserializer(OptionType.class,new EnumDBDeserializer(OptionType.class));
        parserConfig.putDeserializer(VideoSources.class,new EnumDBDeserializer(VideoSources.class));
        parserConfig.putDeserializer(StorageTypeEnum.class,new EnumDBDeserializer(StorageTypeEnum.class));
        parserConfig.putDeserializer(StorageUsageEnum.class,new EnumDBDeserializer(StorageUsageEnum.class));
        parserConfig.putDeserializer(StorageUseStateEnum.class,new EnumDBDeserializer(StorageUseStateEnum.class));
        parserConfig.putDeserializer(StorageContentTypeEnum.class,new EnumDBDeserializer(StorageContentTypeEnum.class));

        SerializeConfig serializeConfig = SerializeConfig.getGlobalInstance();
        serializeConfig.put(MmsProductionStatus.class,new EnumDBSerializer());
        serializeConfig.put(ModelStatus.class,new EnumDBSerializer());
        serializeConfig.put(VideoAuditStatus.class,new EnumDBSerializer());
        serializeConfig.put(MmsTypeEnum.class,new EnumDBSerializer());
        serializeConfig.put(PublishStateEnum.class,new EnumDBSerializer());
        serializeConfig.put(PublishTypeEnum.class,new EnumDBSerializer());
        serializeConfig.put(FileStatus.class,new EnumDBSerializer());
        serializeConfig.put(OptionType.class,new EnumDBSerializer());
        serializeConfig.put(VideoSources.class,new EnumDBSerializer());
        serializeConfig.put(StorageTypeEnum.class,new EnumDBSerializer());
        serializeConfig.put(StorageUsageEnum.class,new EnumDBSerializer());
        serializeConfig.put(StorageUseStateEnum.class,new EnumDBSerializer());
        serializeConfig.put(StorageContentTypeEnum.class,new EnumDBSerializer());

        log.info("FastJsonEnumDBSupportManager end.");
    }
}
