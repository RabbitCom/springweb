package com.cnlive.mam.common.enums;

public enum TransCodeType {

	avop("avop"),
	avlogo("avlogo"),
	avsample("avsample"),
	avsnapshot("avsnapshot"),
	avinfo("avinfo");
	
	private String value;
	
	private TransCodeType(String str){
		this.value = str;
	}
	
	public String getStrValue() {
        return value;
    }

}
