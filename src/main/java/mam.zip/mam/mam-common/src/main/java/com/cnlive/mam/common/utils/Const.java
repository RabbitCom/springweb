package com.cnlive.mam.common.utils;

import java.util.HashMap;
import java.util.Map;

public class Const {
    public final static String ALL_VALUE = "-1";
    public final static String VALUE_DECOLLATOR = ",";
    public final static String KEY_DECOLLATOR = "-";
    public final static String SEPARATE_XIE = "/";
    public final static String DOT_STRING = ".";
    public static final String THUMB = "thumb";
    public static final String STAR = "\\*";
    public static final String BLANK_STRING = "";
    public static final String VALUE_POINT=".";
    public static final String WEN_HAO="?";
    public static final String XIA_HUA_XIAN="_";
    public static final String UP_IMAGE="img";
    //专辑、视频图片上传必须以此命名（图床的要求）
    public static final String SUFFIX_PIC_CDN = ".jpg";

    public final static int TranscodingFailCode_PP = -5;
    public final static int DistributionFailCode_PP = -10;
    public final static int DistributionSuccess_PP = 10;

    public final static int StartUploading = 101;
    public final static int UploadingFail = -110;
    public final static int UploadingSuccess = 110;
    public final static int TrancodingPartSuccess = 10;
    public final static int TranscodingSuccess = 20;

    // 图片素材库默认缩放图宽度
    public static final Integer THUMB_WIDTH = 160;

    // 图片比例Map
    public static final Map<String, Integer[]> albumImageType = new HashMap<String, Integer[]>();
    public static final Map<String, Integer[]> videoImageType = new HashMap<String, Integer[]>();
    public static final Map<String, String> videoImageScalCp = new HashMap<String, String>();

    public static final Integer[] videoImageTypeMax = new Integer[]{224, 126, 485, 303, 224, 398, 316, 506};
    public static int MaxVideoSizeInAlbum = 500;

    static {
        videoImageType.put("ar169", new Integer[]{224, 126, 112, 63});
        videoImageType.put("ar1610", new Integer[]{485, 303});
        videoImageType.put("ar916", new Integer[]{224, 398});
        videoImageType.put("ar1016", new Integer[]{316, 506});

        albumImageType.put("ar169", new Integer[]{224, 126, 112, 63});
        albumImageType.put("ar1610", new Integer[]{485, 303});
        albumImageType.put("ar916", new Integer[]{224, 398});
        albumImageType.put("ar1016", new Integer[]{316, 506});

        videoImageScalCp.put("ar169", "16:9");
        videoImageScalCp.put("ar1610", "16:10");
        videoImageScalCp.put("ar916", "9:16");
        videoImageScalCp.put("ar1016", "10:16");
    }

    public static final int INIT_NUM = 0;


    public static final int Video_Audit_Letv_Pass = 1;
    public static final int Video_Audit_Letv_No = 2;
    public static final int Video_Audit_Custom_Pass = 3;
    public static final int Video_Audit_Custom_No = 4;


    /**********************************
     * 频道信息 start
     ******************************************/
    // 全部频道对应的编号
    public final static Integer CHANNEL_FILM = 100001; //电影
    public final static Integer CHANNEL_TV = 100002; // 电视剧
    public final static Integer CHANNEL_VARIETY = 100003; // 综艺
    public final static Integer CHANNEL_ENTERTAIN = 100004; // 娱乐
    public final static Integer CHANNEL_MUSIC = 100005; // 音乐
    public final static Integer CHANNEL_COMIC = 100006; // 动漫
    public final static Integer CHANNEL_GAME = 100007; // 游戏
    public final static Integer CHANNEL_INFORMATION = 100008; // 资讯
    public final static Integer CHANNEL_FASHION = 100009; //风尚
    public final static Integer CHANNEL_DOCUMENTARY = 100010; // 纪录片
    public final static Integer CHANNEL_CAR = 100011; // 汽车
    public final static Integer CHANNEL_SPORTS = 100012; // 体育
    public final static Integer CHANNEL_CHILDREN = 100013; // 少儿（亲子+母婴）
    public final static Integer CHANNEL_LIVE = 100014; // 生活
    public final static Integer CHANNEL_FINANCE = 100015; // 财经
    public final static Integer CHANNEL_EDUCATE = 100016;//教育
    public final static Integer CHANNEL_HEALTHY = 100017; // 健康
    public final static Integer CHANNEL_TRAVEL = 100018; // 旅游
    public final static Integer CHANNEL_FOLKART = 100019; // 曲艺
    public final static Integer CHANNEL_PET = 100020;//宠物
    public final static Integer CHANNEL_BUSINESS = 100021;//商业
    public final static Integer CHANNEL_MILITARY = 100022;//军事
    public final static Integer CHANNEL_TECHNOLOGY = 100023;//科技
    public final static Integer CHANNEL_FUNNY = 100024;//搞笑
    public final static Integer CHANNEL_COMMONWEAL = 100025;//公益
    public final static Integer CHANNEL_OTHER = 100026;//其他
    /**********************************
     * 频道信息 end
     ******************************************/

    public static final int POSITIVE = 106001;//正片
    public static final int HERALD = 106002; // 预告
    public static final int TITBITS = 106003; // 花絮
    public static final int NEWS = 106004; // 资讯
    public static final int FEATURE = 106005; //特辑
    public static final int FRAGMENT = 106006; // 片段


    public static final int CustomCategory_Level_Step = 1;
    public static final int CustomCategory_Level_Max = 3;

    /**
     * 专辑包含视频的总数量
     */
    public static final int albumVideoCount = 500;


    public static final int K5_CBASE_TIMEOUT = 50;
    public static final int K100_CBASE_TIMEOUT = 50;

    /**
     * 剧集列表的size范围
     **/
    public static final int videos_size_min = 0;
    public static final int videos_size_max = 100;
    /**
     * 剧集列表page的最小值
     */
    public static final int videos_page_min = 0;

    /**
     * /v2/inner/videoInfo/list 相关参数
     */
    public static final int video_list_page_min = 1;
    public static final int video_list_rows_min = 10;
    public static final int video_list_rows_max = 20;

    public static final int FEE_RULE_ONE = 1;
    public static final int FEE_RULE_TWO = 2;
    public static final int FEE_RULE_THREE = 3;
    public static final String DATE_DAY = "day";
    public static final String DATE_WEEK = "week";
    public static final String FEE_FREE = "free";
    public static final String FEE_FREEEPISODES = "freeEpisodes";
    public static final String FEE_BOSS_PASSWORD = "5722cdab9b6484907175898a";
    // 负整数
    public final static String INTEGER = "^\\-*\\d*$";
    // 非负整数
    public final static String POSITIVE_INTEGER = "^[1-9]\\d*|0$";
    // 正整数
    public final static String NON_ZERO_POSITIVE_INTEGER = "^[1-9]\\d*$";
    // 正数
    public final static String NON_ZERO_POSITIVE_NUMBER = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$";

    //媒资删除
    public static final String DELETE_APP_KEY = "e261c8c5db097d4551a1a1fd65b82f70";
    public static final String DELETE_SECRET_KEY = "098f3b3e04898dd0adb7de7e99dade29";

    /**  是否主账号 0 否 */
    public static final Integer IS_PARENT_NO = 0;
    /**  是否主账号 1 是 */
    public static final Integer IS_PARENT_YES = 1;
    /**  是否为重新转码的任务  0 否 */
    public static final Integer IS_RETRANSCODE_NO = 0;
    /**  是否为重新转码的任务  1 是 */
    public static final Integer IS_RETRANSCODE_YES = 1;
    /**  转码历史记录状态 1 转码成功 */
    public static final Integer TRANSCODEHISTORY_SUCCESS = 1;
    /**  转码历史记录状态 2 转码失败 */
    public static final Integer TRANSCODEHISTORY_FAIL = 2;
    /**  转码任务进行状态 0 初始化待转码 */
    public static final Integer TRANSCODETASK_INIT = 0;
    /**  转码任务进行状态 1 转码中 */
    public static final Integer TRANSCODETASK_TRANSCODING = 1;
    /**  自动上线设置  0 否 */
    public static final Integer AUTOONLIE_NO = 0;
    /**  自动上线设置  1 是 */
    public static final Integer AUTOONLIE_YES = 1;
    /**  自动发布设置  0 否 */
    public static final Integer AUTOPUBLISH_NO = 0;
    /**  自动发布设置  1 是 */
    public static final Integer AUTOPUBLISH_YES = 1;
    /**  自动送审设置  0 否 */
    public static final Integer AUTOAUDIT_NO = 0;
    /**  自动送审设置  1 是 */
    public static final Integer AUTOAUDIT_YES = 1;
    /**  logo水印启用标识  0 禁用 */
    public static final Integer LOGOSTATUS_OFF = 0;
    /**  logo水印启用标识  1 启用 */
    public static final Integer LOGOSTATUS_ON = 1;
    /**  logo水印默认位置  0 左上角 */
    public static final Integer LOGOSITE_DEFAULT = 0;
    /**  发布任务状态 0  立即发布*/
    public static final Integer PUBLISHTASK_STATUS_PUBLISHNOW = 0;
    /**  发布任务状态 1  定时发布*/
    public static final Integer PUBLISHTASK_STATUS_PUBLISHTIME = 1;
    /** 定时发布取消状态 -1  不存在*/
    public static final String PUBLISHCANCEL_STATUS_NO = "-1";
    /** 定时发布取消状态 0  不可以取消*/
    public static final String PUBLISHCANCEL_STATUS_NOTCAN = "0";
    /** 定时发布取消状态 1  可以取消*/
    public static final String PUBLISHCANCEL_STATUS_CAN = "1";
    /** 用户是否启用栏目 0  否*/
    public static final Integer IS_START_CATEGORY_NO = 0;
    /** 用户是否启用栏目 1  是*/
    public static final Integer IS_START_CATEGORY_YES = 1;
    /**  点播云perm：dianbo */
    public static final String PERM_DIANBO = "dianbo";
    /**  获取不到客户id时，默认值 0L */
    public static final Long CUSTOMID_DEFAULT_VAL = 0L;
    /**  获取不到客户parentId时，默认值 0 */
    public static final String PARENTID_DEFAULT_VAL = "0";
    
    //码率
//    public static final String SD = "108021"; //标清
    public static final String SD = "800"; //标清
    /** 转码格式 hls */
    public static final String FMT_HLS = "hls";
    /** 转码格式 mp4 */
    public static final String FMT_MP4 = "mp4";

    /************************** redis key begin *******************************/
    /** 视频redis key */
    public static final String REDIS_KEY_VIDEO="v-";

    /** ALBUM redis key */
    public static final String REDIS_KEY_ALBUM="a-";

    /** CATEGORY redis key */
    public static final String REDIS_KEY_CATEGORY="c-";

    /** CUSTOM_CATEGORY redis key */
    public static final String REDIS_KEY_CATEGORY_CUSTOM="c-c-";

    /** CUSTOM redis key */
    public static final String REDIS_KEY_CUSTOMER="u-";

    /** SP redis key */
    public static final String REDIS_KEY_SP="sp-";

    /** file redis key */
    public static final String REDIS_KEY_FILE="f-";

    /** file by video redis key */
    public static final String REDIS_KEY_FILES_VIDEO="f-v-";

    /** ALL MENU redis key */
    public static final String REDIS_KEY_MENU_ALL="menu-all";

    /** simple MENU redis key */
    public static final String REDIS_KEY_MENU="menu-";

    public static final String REDIS_KEY_ROLE="role-";

    public static final String REDIS_KEY_ROLE_PERM="role-perm-";

    public static final String REDIS_KEY_ROLE_SP="role-sp-";

    public static final String REDIS_KEY_COUNT_7DAY_UPLOAD="count-upload-7-";

    public static final String REDIS_KEY_COUNT_7DAY_PUBLISH_SUCESS="count-publish-s-7-";

    public static final String REDIS_KEY_COUNT_7DAY_PUBLISH_FAILD="count-publish-f-7-";

    public static final String REDIS_KEY_COUNT_ALBUM="count-album-";

    public static final String REDIS_KEY_COUNT_GROUP_CATEGORY="count-group-category-";

    public static final String REDIS_KEY_COUNT_GROUP_STATUS="count-group-status-";

    public static final String REDIS_KEY_STORAGE="storage-";

    public static final String REDIS_KEY_STORAGE_ALL_SP="storage-all-sp-";

    public static final String REDIS_KEY_STORAGE_ENABLE_SP="storage-enable-sp-";

    public static final String REDIS_KEY_STORAGE_CONFIG="storage-config-";

    public static final String REDIS_KEY_STORAGE_CONFIGS="storage-configs-";

    public static final String REDIS_KEY_RELATION="relation-relation-";

    public static final String REDIS_KEY_RELATION_CATEGORY_SP="relation-category-sp-";

    public static final String REDIS_KEY_RELATION_CUSTOMCATEGORY_SP="relation-customcategory-sp-";

    public static final String REDIS_KEY_COUNT_PV="count-pv-";

    public static final String REDIS_KEY_STORAGE_DOMAIN_WEIGHT="storage-domainWeight-";

    public static final String REDIS_KEY_SP_EXP_ID="sp-exp-id-";

    public static final String REDIS_KEY_SP_EXP_SPID="sp-exp-spid-";

    /************************** redis key end *******************************/
}
