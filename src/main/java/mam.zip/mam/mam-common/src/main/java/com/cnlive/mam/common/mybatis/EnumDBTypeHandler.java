package com.cnlive.mam.common.mybatis;

import com.cnlive.mam.common.enums.*;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author zhangxiaobin
 */
@MappedTypes({
        MmsProductionStatus.class,
	    FileStatus.class,
	    VideoAuditStatus.class,
	    ModelStatus.class,
	    MmsTypeEnum.class,
	    PublishStateEnum.class,
	    PublishTypeEnum.class,
        OptionType.class,
        VideoSources.class,
        StorageTypeEnum.class,
        StorageUsageEnum.class,
        StorageUseStateEnum.class,
        StorageContentTypeEnum.class
})
public class EnumDBTypeHandler extends BaseTypeHandler<EnumDB> {


    private Class<EnumDB> type;

    public EnumDBTypeHandler(Class<EnumDB> type) {
//        ParameterizedType parameterizedType = (ParameterizedType) getClass()
//                .getGenericSuperclass();
//        type = (Class<E>) parameterizedType.getActualTypeArguments()[0];
        if (type == null) throw new IllegalArgumentException("Type argument cannot be null");
        this.type = type;
    }

    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, EnumDB e, JdbcType jdbcType) throws SQLException {
        preparedStatement.setInt(i,e.getDbValue());
    }



    @Override
    public EnumDB getNullableResult(ResultSet resultSet, String columnName) throws SQLException {
        // 根据数据库存储类型决定获取类型，本例子中数据库中存放INT类型
        int i = resultSet.getInt(columnName);

        if (resultSet.wasNull()) {
            return null;
        } else {
            // 根据数据库中的code值，定位EnumStatus子类
            return locateStatus(i);
        }
    }

    private EnumDB locateStatus(int i) {
        EnumDB[] objects =  type.getEnumConstants();
        for(EnumDB status : objects) {
            EnumDB enumDB = (EnumDB)status;
            if(enumDB.getDbValue() == i) {
                return status;
            }
        }
        return null;
    }

    @Override
    public EnumDB getNullableResult(ResultSet resultSet, int i) throws SQLException {
        return locateStatus(resultSet.getInt(i));
    }

    @Override
    public EnumDB getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        return locateStatus(callableStatement.getInt(i));
    }
}
