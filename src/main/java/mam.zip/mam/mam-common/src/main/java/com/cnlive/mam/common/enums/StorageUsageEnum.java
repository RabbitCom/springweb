package com.cnlive.mam.common.enums;

/**
 * Created by cuilongcan on 7/28/2017.
 */
public enum StorageUsageEnum implements EnumDB {

    NotSet(0),//未设置

    Production(1),//生产

    Operation(2),//运营

    ProductionAndOperation(3);//生产+运营

    private int usage;

    StorageUsageEnum(Integer str) {
        this.usage = str;
    }

    public int getUsage() {
        return usage;
    }

    public void setUsage(int usage) {
        this.usage = usage;
    }

    @Override
    public int getDbValue() {
        return usage;
    }
}
