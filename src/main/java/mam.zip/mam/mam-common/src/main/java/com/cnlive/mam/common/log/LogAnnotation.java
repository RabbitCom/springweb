package com.cnlive.mam.common.log;

import com.cnlive.mam.common.enums.OptionType;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;

/**
 * zhangxiaobin
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(value={TYPE,METHOD,PARAMETER})
public @interface LogAnnotation {
    String message() default "";
    OptionType type() default OptionType.SELECT;
}