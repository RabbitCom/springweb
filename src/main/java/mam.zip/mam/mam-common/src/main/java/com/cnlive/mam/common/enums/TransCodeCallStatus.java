package com.cnlive.mam.common.enums;

public enum TransCodeCallStatus{

	/**
	 * 初始化 0
	 */
	INIT(0),
	/**
	 * 转码中 2
	 */
	TRANSCODING(2),
	/**
	 * 成功 3
	 */
	SUCCESS(3),
	/**
	 * 失败 4
	 */
	ERROR(4);
	
	private int value;
	
	private TransCodeCallStatus(Integer str){
		this.value = str;
	}
	
	public int getValue() {
		return value;
	}

}
