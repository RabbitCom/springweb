package com.cnlive.mam.common.enums;

/**
 * Created by zhangxiaobin on 2017/5/2.
 */
public enum OptionType implements   EnumDB {

    SELECT(0),
    INSERT(1),
    UPDATE(2),
    DELETE(3),
    ;

    int value;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    OptionType (int value){
        this.value = value;
    }

    @Override
    public int getDbValue() {
        return value;
    }
}
