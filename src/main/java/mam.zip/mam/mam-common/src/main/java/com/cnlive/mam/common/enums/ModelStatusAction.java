package com.cnlive.mam.common.enums;

/**
 * Created by zhangxiaobin
 */
public enum ModelStatusAction implements EnumDB {

    NO_ACTION(0),
    ON_LINE(1),
    OFF_LINE(2);

    private int key;

    ModelStatusAction(int key) {
        this.key = key;
    }


    @Override
    public int getDbValue() {
        return key;
    }
}
