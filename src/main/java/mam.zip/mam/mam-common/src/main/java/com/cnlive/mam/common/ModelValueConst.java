package com.cnlive.mam.common;

/**
 * 值常量类
 * 命名规范：表名_字段名_值
 * Created by zhangxiaobin
 */
public class ModelValueConst {
    public final static String DIC_DICWORD_AREA = "area";
    public final static String DIC_DICWORD_SUBCATEGORY = "subCategory";
    public final static String DIC_DICWORD_LANGUAGE = "language";
    public final static String DIC_DICWORD_CONTENTRATING = "contentRating";
    public final static String DIC_DICWORD_VIDEOTYPE = "videoType";
    public final static String DIC_DICWORD_CATEGORY ="category";
    public final static String DIC_DICWORD_JPGNAME ="0000";
    public final static String DIC_DICWORD_JPG =".jpg";


}
