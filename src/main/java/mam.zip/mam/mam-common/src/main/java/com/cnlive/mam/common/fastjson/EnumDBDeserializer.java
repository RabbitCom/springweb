package com.cnlive.mam.common.fastjson;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.parser.DefaultJSONParser;
import com.alibaba.fastjson.parser.JSONLexer;
import com.alibaba.fastjson.parser.JSONToken;
import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
import com.cnlive.mam.common.enums.EnumDB;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhangxiaobin
 */

public class EnumDBDeserializer implements ObjectDeserializer {

    private final Class<?> enumClass;

    private final Map<Integer, EnumDB> indexMap = new HashMap<Integer, EnumDB>();
    public EnumDBDeserializer(Class enumClass) {

        this.enumClass = enumClass;
        EnumDB[] values = (EnumDB[])enumClass.getEnumConstants();


        for (EnumDB enumDB : values) {
            indexMap.put(enumDB.getDbValue(),enumDB);
        }

    }

    public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        try {

            Object value;
            final JSONLexer lexer = parser.getLexer();
            if (lexer.token() == JSONToken.LITERAL_INT) {
                value = lexer.intValue();
                lexer.nextToken(JSONToken.COMMA);

                T e = (T) indexMap.get(value);
                if (e == null) {
                    throw new JSONException("parse enum " + enumClass.getName() + " error, value : " + value);
                }
                return e;
            }  else {
                value = parser.parse();
            }

            throw new JSONException("parse enum Category error, value : " + value);

        } catch (JSONException e) {
            throw e;
        } catch (Throwable e) {
            throw new JSONException(e.getMessage(), e);
        }
    }

    @Override
    public int getFastMatchToken() {
        return JSONToken.LITERAL_INT;
    }

}
