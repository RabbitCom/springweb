package com.cnlive.mam.common.utils;

import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.resultMessage.CommonResultMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.regex.Pattern;

/**
 * @author ZHANGXIAOBIN
 */
public class ParamCheck {

    // 非负整数
    public final static String POSITIVE_INTEGER = "^[1-9]\\d*|0$";
    // 正整数
    public final static String NON_ZERO_POSITIVE_INTEGER = "^[1-9]\\d*$";
    // 正数
    public final static String NON_ZERO_POSITIVE_NUMBER = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$";

    public final static String IP = "^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])$";

    /**
     * 校验参数值格式
     * @param paramValue
     * @param paramName
     * @param regex
     */
    public static void matchPattern(String paramValue, String paramName, String regex) {
        if (!Pattern.matches(regex, paramValue)) {
            throw new BusinessException(CommonResultMessage.RULES_NOT_MATCH, paramName, paramValue);
        }
    }


    public static void  isIP(String paramValue,String paramName) {
        matchPattern(paramValue,paramName,IP);
    }

    public static void isPositiveInteger(String paramValue, String paramName){
        matchPattern(paramValue,paramName,POSITIVE_INTEGER);
    }

    public static void isNotNull(String paramValue,String paramName){
        if(paramValue == null){
            throw new BusinessException(CommonResultMessage.REQUIRE_VALUE, paramName, paramValue);
        }
    }

    public static void inRange(Number target, Number middle, Number range, String paramName) {
        if(Math.abs(target.doubleValue()-middle.doubleValue()) > range.doubleValue()){
            throw new BusinessException(CommonResultMessage.OUT_RANGE, paramName, target,middle,range);
        }
    }


    public static void checkInArray(Object value, Object[] array, String itemName) throws BusinessException {
        if(value != null) {

            for(int i = 0; i < array.length; ++i) {
                Object object = array[i];
                if(value.equals(object)) {
                    return;
                }
            }
            throw new BusinessException(CommonResultMessage.OUT_ARRAY,itemName);
        }
    }

    public static void checkObjectNotNull(Object value, String itemName) throws BusinessException {
        if(value == null) {
            throw  new BusinessException(CommonResultMessage.IS_NULL, itemName);
        }
    }

    public static void isHasLenth (Collection collection, String itemName) throws BusinessException{
        if (collection.size() == 0 ){
            throw  new BusinessException(CommonResultMessage.IS_NULL, itemName);
        }
    }
}
