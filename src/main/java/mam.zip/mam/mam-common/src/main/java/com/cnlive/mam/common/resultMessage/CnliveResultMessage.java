package com.cnlive.mam.common.resultMessage;

/**
 * Created by zhangxiaobin on 2017/8/23.
 */
public enum  CnliveResultMessage {

    SUCCESS(0,"success"),
    SYSTEM_ERROR(-1,"系统内部错误，请稍后重试"),

    VIDEO_NOT_EXITS(1001,"视频不存在"),
    VIDEO_NOT_USED(1002,"视频不可用"),
    PARAM_ERROR(1003,"参数非法"),

    ;

    private final int code;
    private final String message;

    CnliveResultMessage(int code,String message){
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
