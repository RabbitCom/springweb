package com.cnlive.mam.common.enums;

import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.resultMessage.CommonResultMessage;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Created by zhangxiaobin
 */
public enum DefinitionEnum {
    SMOOTH(400,"流畅"),
    SD(800,"标清"),
    HD(1500,"高清"),
    ULTRA_HD(3000,"超清");
//    _720P(720,"720p"),
//    _1080P(1080,"1080p"),
//    _4K(4000,"4k");

    private Integer definitionId;
    private String definitionName;

    public Integer getDefinitionId() {
        return definitionId;
    }

    public void setDefinitionId(Integer definitionId) {
        this.definitionId = definitionId;
    }

    public String getDefinitionName() {
		return definitionName;
	}

	public void setDefinitionName(String definitionName) {
		this.definitionName = definitionName;
	}

	DefinitionEnum(Integer definitionId, String definitionName) {
        this.definitionId = definitionId;
        this.definitionName = definitionName;
    }

    DefinitionEnum() {
    }


    public static List<Integer> getRateById(Integer definitionId){
        List<Integer> rateList = new ArrayList<>();
        for(DefinitionEnum definitionEnum:DefinitionEnum.values()){
            if(definitionEnum.definitionId.intValue() == definitionId.intValue()){
                rateList.add(definitionEnum.getDefinitionId());
                return rateList;
            }
        }
        return rateList;
    }

    public static List<Integer> getRateByIds(String definitionStr){
        String[] definitions = StringUtils.split(definitionStr, ",");
        List<Integer> rateList = new ArrayList<>();
        for(String definitionId:definitions){
            rateList.addAll(getRateById(Integer.valueOf(definitionId)));
        }
        return removeDuplicate(rateList);
    }

    public static String getShowName(Integer definitionId){
    	if(definitionId == null){
    		return "";
    	}
        for(DefinitionEnum definitionEnum:DefinitionEnum.values()){
            if(definitionEnum.definitionId.intValue() == definitionId.intValue()){
                return definitionEnum.definitionName;
            }
        }
        return "";
    }

    private static List removeDuplicate(List list){
        HashSet h = new HashSet(list);
        list.clear();
        list.addAll(h);
        return list;
    }
}
