package com.cnlive.mam.common.enums;

/**
 * @author hanfeng
 * @date 15/10/28
 */
public enum MmsProductionStatus implements EnumDB {
    //0初始状态,1上传中,2上传中断，3上传完成，4有内容已经转码完成，5所有内容都转码完成,9下线
    New(0),UploadingFail(2),uploaded(3),TranscodePDone(4),TranscodeDone(5),Offline(9);

    private int dbValue;

    private MmsProductionStatus(int i){
        this.dbValue = i;
    }

    @Override
    public int getDbValue() {
        return dbValue;
    }
}
