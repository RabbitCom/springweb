package com.cnlive.mam.excelTools;

import com.cnlive.mam.model.CustomMenuModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.CustomPermissionService;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.CustomPermissionVo;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

public class ShiroDbRealm extends AuthorizingRealm {
    @Resource(name = "customPermissionService")
    private CustomPermissionService customPermissionService;
    @Resource(name = "customService")
    private CustomService customService;

    /**
     * 认证回调函数,登录时调用.
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
        return super.getAuthenticationInfo(authcToken);
    }

    /**
     * 认证回调函数,权限验证时调用.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();

        PrincipalCollection principalCollection = SecurityUtils.getSubject().getPrincipals();
        if (principalCollection != null) {
            List principalLists = principalCollection.asList();
            if (principalLists != null && principalLists.size() > 1) {
                Map<String, String> attributes = (Map<String, String>) principalLists.get(1);
                String spIdStr = attributes.get("new_sp_id");
                if ("0".equals(spIdStr)) {
                    info.addRole("super");
                    return info;
                }
                String customIdStr = principalLists.get(0).toString();
                Long customId = Long.parseLong(customIdStr);
                CustomModel customModel = customService.getById(customId);
                Integer roleId = customModel.getRoleId();
                String institutionId = attributes.get("institution_id");
                String institutionName = attributes.get("institution_name");
                Boolean institutionFlag = (institutionId != null && !institutionId.equals(customModel.getInstitutionId()));
                if (institutionFlag) {
                    customModel.setInstitutionId(institutionId);
                    customModel.setInstitutionName(institutionName);
                }
                if (roleId != null) {
                    if (roleId == 1) {
                        info.addRole("admin");
                    } else {
                        info.addRole("user");
                    }
                    if (institutionFlag) {
                        customService.modify(customModel);
                    }
                } else {
                    String parentid = attributes.get("parent_id");
                    boolean parentFlag = StringUtils.isEmpty(parentid);
                    if (parentFlag) {
                        roleId = 1;
                        info.addRole("admin");
                    } else {
                        roleId = 2;
                        info.addRole("user");
                    }
                    customModel.setRoleId(roleId);
                    customService.modify(customModel);
                }
                CustomPermissionVo customPermissionVo = customPermissionService.getCustomRolesByRoleId(roleId);
                for (CustomMenuModel cpm : customPermissionVo.getMenus()) {
                    info.addStringPermission(cpm.getMenuId().toString());
                }
            }
        }
        return info;
    }

}
