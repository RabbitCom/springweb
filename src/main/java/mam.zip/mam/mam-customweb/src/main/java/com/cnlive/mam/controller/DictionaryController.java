package com.cnlive.mam.controller;

import com.cnlive.mam.condition.DictionaryCondition;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Function;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhangxiaobin
 */
@Controller
@RequestMapping("/dictionaryController")
public class DictionaryController extends BaseController {

    /**
     * @return List<Dictionary>
     * @throws
     * @Title: getDictionarys
     * @Description: 根据字典value、字典分类获取字典数据
     */
    @RequestMapping("/getDictionarys")
    @ResponseBody
    public List<Dictionary> getDictionarys(String dicWord, Integer Category) {
        List<Dictionary> dicList = new ArrayList<Dictionary>();
        dicList = dictionaryService.getDictionary(dicWord, Category);
        return dicList;
    }

    @RequestMapping("/manager")
    public String manager() {
        return "/dictionary/dictionary";
    }

    @RequestMapping("/getDataGrid")
    @ResponseBody
    public DataGrid getDictionarys(HttpServletRequest request, DictionaryCondition condition) {
        condition.setSort("dicId");
        Long count = dictionaryService.getByConditionCount(condition);
        List<Dictionary> list = new ArrayList<>();
        List<Map<String, Object>> dataList = new ArrayList<>();
        if (count > 0) {
            list = dictionaryService.getByCondition(condition);
        }
        List<Dictionary> categorys = dictionaryService.getDictionaryByDicWord(Dictionary.CATEGORY_DIC_WORD);
        Map<Integer, Dictionary> categoryMap = Maps.uniqueIndex(categorys, new Function<Dictionary, Integer>() {
            @Override
            public Integer apply(Dictionary input) {
                return input.getDicValue();
            }
        });
        for (int i = 0; i < list.size(); i++) {
            Map<String, Object> map = new HashMap<>();
            Dictionary dictionary = list.get(i);
            map.put("dicId", dictionary.getDicId());
            map.put("showName", dictionary.getShowName());
            map.put("dicWord", dictionary.getDicWord());
            map.put("dicValue", dictionary.getDicValue());
            map.put("categorys", dictionary.getCategorys());
            map.put("categoryNames",transformCategory(dictionary.getCategorys(),categoryMap));
            dataList.add(map);
        }
        DataGrid dg = new DataGrid();
        dg.setTotal(count);
        dg.setRows(dataList);
        return dg;
    }

    @RequestMapping("/insertDictionary")
    @ResponseBody
    public JsonResult insertDictionary(HttpServletRequest request, Dictionary dictionary) {
        JsonResult result = new JsonResult();
        if (dictionary != null) {
            Integer maxdicValue = dictionaryService.getMaxdicValue(dictionary);
            if (maxdicValue != null) {
                dictionary.setDicValue(maxdicValue + 1);
            } else {
                dictionary.setDicValue(10000);
            }
            dictionaryService.save(dictionary);
            result.setSuccess(true);
            result.setMsg("保存成功");
        }
        return result;
    }

    @RequestMapping("/modifyDictionary")
    @ResponseBody
    public JsonResult modifyDictionary(HttpServletRequest request, Dictionary dictionary) {
        JsonResult result = new JsonResult();
        dictionaryService.modify(dictionary);
        result.setSuccess(true);
        result.setMsg("保存成功");
        return result;
    }

    @RequestMapping("/delDictionary")
    @ResponseBody
    public JsonResult delDictionary(HttpServletRequest request, String dicIds) {
        JsonResult result = new JsonResult();
        if (dicIds.contains(",")) {
            String[] dicArray = dicIds.split(",");
            for (int i = 0; i < dicArray.length; i++) {
                dictionaryService.delete(Integer.parseInt(dicArray[i]));
            }
        } else {
            dictionaryService.delete(Integer.parseInt(dicIds));
        }
        result.setSuccess(true);
        result.setMsg("删除成功");
        return result;
    }

    @RequestMapping("/getDictionaryRoot")
    @ResponseBody
    public JsonResult getDictionaryRoot(HttpServletRequest request, Dictionary dictionary) {
        JsonResult result = new JsonResult();
        if (dictionary.getDicWord() != null) {
            List<Dictionary> list = dictionaryService.getDictionaryByDicWord(dictionary.getDicWord());
            if (list.size() > 0) {
                result.setObj(list);
                result.setSuccess(true);
            }
        }
        return result;
    }

    private static String transformCategory(String category, Map<Integer, Dictionary> map) {
        List<String> categoryName = new ArrayList<>();
        String[] categoryArray = new String[1];
        if (category.contains(",")) {
            categoryArray = category.split(",");
        } else {
            categoryArray[0] = category;
        }
        for (int i = 0; i < categoryArray.length; i++) {
            categoryName.add(map.get(Integer.parseInt(categoryArray[i])).getShowName());
        }
        return StringUtils.join(categoryName, ",");
    }
}
