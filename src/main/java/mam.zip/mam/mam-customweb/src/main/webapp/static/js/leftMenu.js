//切换左侧以及一级菜单显示隐藏
$("#leyun-warp-navbar").on("click", "li", function() {
    $(this).addClass("active").siblings().removeClass("active");
    var qx = $(this).attr("data-qx");
    if (qx == -1) {
        $("#modal-code-wuquanxian").modal('show');
    }
});

//切换左侧二级菜单显示隐藏
$("#leyun-warp-navbar").on("click", ".menu-info dd", function(event) {
    $(this).addClass("active").siblings().removeClass("active");
    //事件绑定重复，导致重复请求；20170330注释，如发现异常请恢复修改
//    if ($(this).find(".more-info").length == 0) {
//        //$(this).find("a").first().trigger("click");
//        var url = $(this).find("a").first().attr("data-url");
//        if (url) {
//
//            var iframe = '<iframe scrolling="0-" frameborder="0"  src="' + url + '" style="width:100%;height:99%;"></iframe>';
//            $(".leyun-warp-container").empty().append(iframe);
//            sessionStorage.setItem('iframeUrl', url);
//            event.stopPropagation();
//        }
//    }
});

//点击三级，右侧内容iframe填充
$("#leyun-warp-navbar").on("click", "dd", function(event) {
    var url = $(this).find("a").attr("data-url");
    if (url) {
        var iframe = '<iframe scrolling="0-" frameborder="0"  src="' + url + '" style="width:100%;height:99%;"></iframe>';
        $(".leyun-warp-container").empty().append(iframe);
        sessionStorage.setItem('iframeUrl', url);

        var parent = $(this).find("a").parent();
        parent.addClass("active").siblings().removeClass("active");
        $(this).find("a").parents("dd").siblings().find("*").removeClass("active");
        var li = $(this).find("a").parents("li");
        li.siblings().find("*").removeClass("active");
    }
    //event.stopPropagation();
});

//点击头部的链接，清空sessionStorage
// $("a.home").bind("click", function() {
//     sessionStorage.removeItem("iframeUrl");
// });

function jumpSys(menuKey, iframeUrl) { //根据data-menu进入某个系统，第二个参数非必需
    var a = $("#leyun-warp-navbar a[data-menu='" + menuKey + "']:eq(0)");
    var url = iframeUrl || a.attr("data-url");
    if (url) { //打开内置url
        $("#ct_iframe").attr("src", url);
        showMenuALL(a, url);
    } else { //打开外链url
        showMenuALL(a, url);
        url = a.attr("href");
        window.open(url);
    }

}

//初次进来的时候，先把iframe显示
function showIframeOnly(url) {
    $("#ct_iframe").attr("src", url);
    $(".sass-container-home").remove();
    $(".leyun-warp").removeClass("hide");
}


function showMenuInit(menuKey) {
    var a = $("#leyun-warp-navbar a[data-menu='" + menuKey + "']:eq(0)");
    var url = a.attr("data-url");
    showMenuALL(a, url);
}

function showMenuInitByUrl(url) {
    var a = $("#leyun-warp-navbar a[data-url='" + url + "']:eq(0)");
    showMenuALL(a, url);
}

function showMenuALL(a, url) {
    var dd;
    if (a.parent().is("p")) {
        var p = a.parent();
        p.addClass("active").siblings().removeClass("active");
        dd = p.parent().parent();
    } else if (a.parent().is("dd")) {
        dd = a.parent();
    }

    dd.addClass("active").siblings().removeClass("active");
    var li = dd.parent().parent();
    li.addClass("active").siblings().removeClass("active");
    li.siblings().find("*").removeClass("active");

    $(".sass-container-home").remove();
    $(".leyun-warp").removeClass("hide");
    $(".leyun-sidebar").animate({
        left: 0
    }, 200);

    sessionStorage.setItem('iframeUrl', url);

    return false;
}

//点击退出时， 清除掉sessionStorage
$(".info a:contains('退出')").on("click", function() {
    sessionStorage.removeItem("iframeUrl");
});