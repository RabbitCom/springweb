var params = {},
    index = 0;
var commit_btn;
var showName;
var dicWord;
var categorys;
var rootCategorys;
var dicId;
var lcsetting = {
    "ajax": basePath + "dictionaryController/getDataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function (i, j, d) {
            return '<input type="checkbox"  id="' + d.dicId + '" name="ck" class="checkItem">';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //字典id
            return d.dicId;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //字典名称
            return d.showName;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //字典关键字
            return d.dicWord;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //字典值
            return d.dicValue;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //所属分类
            return d.categoryNames;
        }
    }, {
        "data": "lcall",
        "className": 'commentSet-dictionary',
        "format": function (i, j, d) { //操作类型
            var editBtn = '<a href="#modal-dictionary-add" data-toggle="modal"  class="ml-10 dictionary_edit" ' +
                'dicId="' + d.dicId + '" showName="' + d.showName + '" dicValue="' + d.dicValue + '" categorys="' + d.categorys + '" dicWord="' + d.dicWord + '">' +
                LCT("编辑") + '</a>';
            var deleteBtn = '<a href="javascript:;" class="dictionary_del ml-10" dicId="' + d.dicId + '">' + LCT("删除") + '</a>';
            return '<a href="javascript:;" class="handle">' + LCT("操作") + '</a><p>' + editBtn + deleteBtn + '</p>';
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function (data) {
        checkall("#maintable"); //table全选
        $("#maintable").on("mouseover", ".commentSet-dictionary", function () {
            $(this).find("a.handle").hide();
            $(this).find("p").show();
        }).on("mouseout", ".commentSet-dictionary", function () {
            $(".commentSet-dictionary a.handle").show();
            $(".commentSet-dictionary p").hide();
        });
    }
};
var dictionaryFn = {
    init: function () {
        this.initCatogry();//初始化所属分类下拉菜单需放在第一行初始化
        this.del(); //字典删除
        this.add(); //增加字典
        this.edit(); //编辑返回
        this.search();//查询字典
        this.submit();
    },
    add: function () {
        $(".dictionary-status-result").click(function () {
            if ($(".option-items").is(":visible")) {
                $(".option-items").addClass("hide");
            } else {
                $(".option-items").removeClass("hide");
            }
        });
        $(".select-checkbox").mouseleave(function () {
            $(".option-items").addClass("hide");
        });
        $("#dictionary_status_choose").click(function () {
            var input = $("input[name='dictionary-status']");
            if ($("input[name='dictionary-status']:checked").length) {
                for (i = 0; i < input.length; i++) {
                    if (input[i].checked) {
                        input[i].checked = false;
                    }
                }
            }
        });

    },
    del: function () {
        $("#maintable").on("click", ".dictionary_del", function () {
            var dicIds = $(this).attr("dicId");
            var params_alert = {
                "title": LCT("删除"),
                "discription": LCT("是否删除该字典数据"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function () {
                    $.post(basePath + "dictionaryController/delDictionary.do?", {'dicIds': dicIds}, function (data) {
                        if (data.success) {
                            alertfn.success(data.msg);
                            $("#maintable").lctable(lcsetting, params);
                        } else {
                            alertfn.danger(data.msg);
                        }
                    }, 'json')
                }
            };
            $("body").toolsalert(params_alert);
            return;
        });
        $("#maintable").on("click", "[name='delDictionary']", function () {
            var arr = $("#maintable .checkItem:checked");
            var dicIdArray = [];
            for (var i = 0; i < arr.length; i++) {
                dicIdArray.push(arr[i]["id"]);
            }
            var dicIds = dicIdArray.join(",");
            $.post(basePath + "dictionaryController/delDictionary.do?", {'dicIds': dicIds}, function (data) {
                if (data.success) {
                    alertfn.success(data.msg);
                    $("#maintable").lctable(lcsetting, params);
                } else {
                    alertfn.danger(data.msg);
                }
            }, 'json');
        });
    },
    edit: function () {
        $("#maintable").on("click", ".dictionary_edit", function () {
            commit_btn = 'edit';
            $("input[name='dictionary-status']").attr("checked", false);
            $('#dictionary_title').html("编辑字典数据");
            dicId = $(this).attr("dicId");
            var showNameVal = $(this).attr("showName");
            var dicWordVal = $(this).attr("dicWord");
            var dicValue = $(this).attr("dicValue");
            categorys = $(this).attr("categorys");
            var showName_code_Array = [];
            var showNameArray = '';
            $("#showName").val(showNameVal);
            $("#dicWord").val(dicWordVal);
            var categorysArray = categorys.split(",");
            var input = $("input[name='dictionary-status']");
            for (var i = 0; i < input.length; i++) {
                if ($.inArray(input[i]["value"], categorysArray) != -1) {
                    // $(input[i]).attr("checked", true);
                    input[i].checked = true;
                    showName_code_Array.push($(input[i]).attr('showName'));
                }
            }
            showNameArray = showName_code_Array.join(",");
            $(".dictionary-status-result").html(showNameArray).attr("onoffStatus", "");
        });
    },
    search: function () {
        $(".btn_search").bind("click", function () {
            params = {};
            var search_showname = $.trim($(".search_showname").val());
            var search_dicword = $.trim($(".search_dicword").val());

            if (search_showname) {
                params["showName"] = search_showname;
            }
            if (search_dicword) {
                params["dicWord"] = search_dicword;
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    //初始化 字典根目录数据
    initCatogry: function () {
        $.post(basePath + "dictionaryController/getDictionaryRoot.do", {"dicWord": "category"}, function (data) {
            if (data.success) {
                rootCategorys = data.obj;
                var dictionary_choose_item = '';
                $('.dictionary-root').remove();
                if (rootCategorys) {
                    for (var i = 0; i < rootCategorys.length; i++) {
                        dictionary_choose_item += '<li class="ui-cf dictionary-root"><input class="ui-fl" type="checkbox" name="dictionary-status" ' +
                            'id="' + rootCategorys[i].dicId + '" value="' + rootCategorys[i].dicValue + '" showName="' + rootCategorys[i].showName + '"><span class="ui-fl">' + rootCategorys[i].showName + '</span></li>';
                    }
                }
                $('#categorys-item').after(dictionary_choose_item);
            }
        }, 'json');
    },
    submit: function () {
        $("#addSubmit").click(function () {
            showName = $("#showName").val();
            dicWord = $("#dicWord").val();
            if (tripSpecial(showName)) {
                return alertfn.danger('字典名称不能包含特殊字符');
            }
            if (showName == '') {
                return alertfn.danger('字典名称不能为空');
            }
            if (dicWord == '') {
                return alertfn.danger('字典关键字不能为空');
            }
            if (!tripLetter(dicWord)) {
                return alertfn.danger('字典关键字必须为英文字母');
            }
            if (categorys == '') {
                return alertfn.danger('未选择所属分类');
            }
            var url = '';
            if (commit_btn == 'edit') {
                url = "dictionaryController/modifyDictionary.do";
            } else if (commit_btn == 'add') {
                url = "dictionaryController/insertDictionary.do";
            }

            $.ajax({
                    type: "post",
                    url: basePath + url,
                    data: {
                        "showName": showName,
                        "dicWord": dicWord,
                        "categorys": categorys,
                        "dicId": dicId
                    },
                    dataType: "json",
                    success: function (data) {
                        $('#modal-dictionary-add').modal("hide");
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    }
                }
            );
        });
        $("#buildedit").click(function () {
            commit_btn = 'add';
            $('#dictionary_title').html("新增字典数据");
            $(".dictionary-status-result").html("请选择").attr("onoffStatus", "");
            $("#showName").val("");
            $("#dicWord").val("");
            $("input[name='dictionary-status']").attr("checked", false);
            showName = '';
            dicWord = '';
            categorys = '';
        });
        $('.btn_ok').click(function () {
            var dictionary_check_val = $("input[name='dictionary-status']:checked");
            var categoeryArray = [];
            var categoeryNameArray = [];
            var categoeryNames;
            if (dictionary_check_val.length) {
                for (i = 0; i < dictionary_check_val.length; i++) {
                    categoeryArray.push(dictionary_check_val[i]["value"]);
                    categoeryNameArray.push($(dictionary_check_val[i]).attr('showName'));
                    categorys = categoeryArray.join(",");
                    categoeryNames = categoeryNameArray.join(",");
                }
                if (categorys.length) {
                    $(".dictionary-status-result").html(categoeryNames).attr("onoffStatus", categorys);
                }
                $(".option-items").addClass("hide");
            } else {
                $(".dictionary-status-result").html("请选择").attr("onoffStatus", "");
            }
        });
    }
};
$(function () {
    lcsetting.thisPage = 1;
    $("#maintable").lctable(lcsetting, params);
    dictionaryFn.init();
});
function tripSpecial(param) {
    var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");
    if (pattern.test(param)) {
        return true;
    }
    return false;
}
function tripLetter(param) {
    var pattern = new RegExp("^[A-Za-z]+$");
    if (pattern.test(param)) {
        return true;
    }
    return false;
}