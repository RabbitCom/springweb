package com.cnlive.mam.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.condition.VideoPublishCondition;
import com.cnlive.mam.model.*;

import com.cnlive.mam.service.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ReleaseObj;

/**
 * 发布管理
 */
@Controller
@RequestMapping("/videoPublishController")
public class VideoPublishController extends BaseController{

    private static Logger _log = LoggerFactory.getLogger(VideoPublishController.class);

    @Resource(name = "videoService")
    private VideoService videoService;
    
    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;
    
    @Resource(name = "videoPublishService")
    private VideoPublishService videoPublishService;
    
    @Resource(name = "publishHistoryService")
    private PublishHistoryService publishHistoryService;
    
    @Resource(name = "publishTaskService")
    private PublishTaskService publishTaskService;

	@Resource(name="optionLogInfoService")
	private OptionLogInfoService optionLogInfoService;
    
    private static String[] video_publish_status={String.valueOf(ModelStatus.OnLine.getDbValue()),String.valueOf(ModelStatus.ReleaseIng.getDbValue()),
    	String.valueOf(ModelStatus.ReleaseSuccess.getDbValue()),String.valueOf(ModelStatus.ReleaseFail.getDbValue())};
    
  
    /**
     * @Description:跳转到视频发布列表页
     */
    @RequestMapping("/toVideoPublish")
    public String toPlayerSettings(HttpServletRequest request, Model model) {
    	Long customId = this.getCustomId(request);
    	CustomModel customModel = customService.getById(customId);
    	CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(this.getSpId(request));
    	model.addAttribute("customModel", customModel);
    	model.addAttribute("customSpInfoModel", customSpInfoModel);
        return "/videoPublish/videoPublish";
    }

    /**
     * @Description:条件查询视频发布列表
     */
    @RequestMapping("/videoPublishList")
    @ResponseBody
//	@LogAnnotation(message = "分页查询视频发布列表",type = OptionType.SELECT)
    public DataGrid videoPublishList(HttpServletRequest request, VideoCondition condition) {
        DataGrid dataGrid = new DataGrid();
        try {
        	condition.setPublishList(true);
            Long customId = this.getCustomId(request);
			boolean isSpAdmin = checkIsSpAdmin(request);
			if(isSpAdmin){
				condition.setSpAdmin(Const.IS_PARENT_YES);
			}else {
				condition.setSpAdmin(Const.IS_PARENT_NO);
				condition.setInstitutionId(this.getInstitutionId(request));
			}
			condition.setSucai(0);
			condition.setSpid(this.getSpId(request));
			String publishStatusParams = condition.getOnoffStatus();
         	if(StringUtils.isBlank(publishStatusParams)) {
         		condition.setOnoffStatusArray(video_publish_status);
            }else if("-1".equals(publishStatusParams)){
                condition.setOnoffStatusArray(new String [] {String.valueOf(ModelStatus.OnLine.getDbValue())});
            } else if("0".equals(publishStatusParams)){

                VideoPublishCondition publishCondition = new VideoPublishCondition();
                publishCondition.setCustomId(customId);
                publishCondition.setPublishTimeStart(condition.getPublishStartTime());
                publishCondition.setPublishTimeEnd(condition.getPublishEndTime());
                publishCondition.setPublishState(1);
                publishCondition.setPage(condition.getPage());
                publishCondition.setRows(condition.getRows());
                Long total = publishTaskService.PageCountPublishTaskInfos(publishCondition);
                if(total >0){
                    dataGrid.setTotal(total);
                    List<VideoModel> videoModels = new ArrayList<>();
                    List<PublishTaskModel> ptmodels = publishTaskService.PagePublishTaskInfos(publishCondition);
                    for(PublishTaskModel m : ptmodels){
                        VideoModel v = videoService.getById(m.getVideoId());
                        v.setCancelPrePublishFlag(Const.PUBLISHCANCEL_STATUS_CAN);
                        v.setPublishState(1);
                        v.setPrePublishedTime(m.getPrePublishedTime());
                        videoModels.add(v);
                    }
                    dataGrid.setRows(videoModels);
                }
                return dataGrid;

            }else if("1".equals(publishStatusParams)){
				condition.setOnoffStatusArray(new String [] {String.valueOf(ModelStatus.ReleaseIng.getDbValue())});
			}else if("2".equals(publishStatusParams)){
				condition.setOnoffStatusArray(new String [] {String.valueOf(ModelStatus.ReleaseSuccess.getDbValue())});
			}else if("3".equals(publishStatusParams)){
				condition.setOnoffStatusArray(new String [] {String.valueOf(ModelStatus.ReleaseFail.getDbValue())});
			}
            dataGrid = videoService.getPageByCondition(condition);

//			if(dataGrid.getTotal() > 0){
//				for (int i=0;i< dataGrid.getRows().size();i++){
//					VideoModel video = (VideoModel) dataGrid.getRows().get(i);
//                    addCancelPulishFlag(video,video.getCustomId());
//                }
//			}
        } catch (Exception e) {
            _log.error("获取发布列表失败，ex = {}",e);
        }
        return dataGrid;
    }
    
    /**
     * @Description:添加取消发布标志
     */
    private void addCancelPulishFlag(VideoModel video,Long customId){
        PublishTaskModel taskCondition = new PublishTaskModel();
        taskCondition.setVideoId(video.getVideoId());
        taskCondition.setCustomId(customId);
        taskCondition.setPublishState(1);
        List<PublishTaskModel> taskModels = publishTaskService.getTaskByCondition(taskCondition);
        if(taskModels.size() > 0){
            PublishTaskModel publishTaskModel = taskModels.get(0);
            video.setCancelPrePublishFlag(Const.PUBLISHCANCEL_STATUS_CAN);
            video.setPublishState(1);
            video.setPrePublishedTime(publishTaskModel.getPrePublishedTime());
        }else {
            video.setCancelPrePublishFlag(Const.PUBLISHCANCEL_STATUS_NOTCAN);
            video.setPublishState(0);
        }
    }
    
    /**
     * @Description:判断是否存在目录结构
     */
    @RequestMapping("/checkCategory")
    @ResponseBody
    public JsonResult checkCategory(HttpServletRequest request,ReleaseObj releaseObj) {
    	long videoIds = releaseObj.getVideoIds();
    	Long customId = getCustomId(request);
    	if(Long.valueOf(videoIds)!=null){
    		try{
				 JsonResult jsonResult = videoPublishService.checkCategory(videoIds, customId);
				 return jsonResult;
    		} catch (Exception e) {
    			_log.error("获取目录结构失败，失败信息：____________"+e.getMessage());
   			 return JsonResult.createErrorInstance("获取目录结构失败");
    		}
    	}else{
    		return JsonResult.createErrorInstance("该视频不存在");
    	}
    }

    /**
     * @Description:选择目录添加到发布任务列表
     */
    @RequestMapping("/addCategory")
    @ResponseBody
    public JsonResult addCategory(HttpServletRequest request,ReleaseObj releaseObj,String preTime,String publishStyle) {
		try{
			PublishTaskModel publishTaskModel=new PublishTaskModel();
			if("0".equals(publishStyle) && StringUtils.isEmpty(preTime)){//立即发布
				publishTaskModel.setPrePublishedTime(new Date());
				VideoModel videoModel = videoService.getById(releaseObj.getVideoIds());
    			if(videoModel!=null){
    				VideoModel update = new VideoModel();
					update.setVideoId(videoModel.getVideoId());
					update.setStatus(ModelStatus.ReleaseIng);
					update.setUpdateTime(new Date());
					update.setCustomId(videoModel.getCustomId());
					update.setUpdateUserId(videoModel.getCustomId());
    				videoService.modify(update);
    			}else {
    				return JsonResult.createErrorInstance("视频不存在");
				}
			}else{
				JsonResult jsonResult = this.checkPublishTime(preTime);
				if(!jsonResult.isSuccess()){
					return jsonResult;
				}
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date prePublishedTime = sdf.parse(preTime);
				publishTaskModel.setPrePublishedTime(prePublishedTime);
			}
			publishTaskModel.setVideoId(releaseObj.getVideoIds());
			publishTaskModel.setCustomId(getCustomId(request));
			publishTaskModel.setPublishState(Integer.valueOf(publishStyle));
			publishTaskModel.setReleaseColumnId(releaseObj.getColumnId());
			publishTaskModel.setReleaseId(releaseObj.getId());
			publishTaskModel.setReleasePid(releaseObj.getpId());
			publishTaskModel.setReleaseTitle(releaseObj.getTitle());
			publishTaskService.insert(publishTaskModel);
			return JsonResult.createSuccessInstance("success");
		} catch (Exception e) {
			 _log.error("添加目录失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("fail");
        }
    }
    
    /**
     * @Description:视频查看
     */
    @RequestMapping("/publishHistoryView")
    @ResponseBody
//	@LogAnnotation(message = "查看视频发布失败信息",type = OptionType.SELECT)
    public JsonResult publishHistoryView(HttpServletRequest request,ReleaseObj releaseObj) {
    	PublishHistory history=new PublishHistory();
    	history.setVideoId(releaseObj.getVideoIds());
    	history.setCustomId(getCustomId(request));
		try{
			String description="";
			PublishHistory publishHistory = publishHistoryService.selectByVideoIdAndCustomId(history);
			if(publishHistory!=null && StringUtils.isNotBlank(publishHistory.getDescription())){
				description=publishHistory.getDescription();
			}
			return JsonResult.createSuccessInstance("success", description);
    	} catch (Exception e) {
  			 _log.error("视频查看失败，失败信息：____________"+e.getMessage());
  			 return JsonResult.createErrorInstance("请求失败");
   		}
    }
    
    /**
     * @Description:添加到发布任务列表
     */
    @RequestMapping("/videoPublishTask")
    @ResponseBody
//	@LogAnnotation(message = "操作发布视频",type = OptionType.INSERT)
    public JsonResult videoPublishTask(HttpServletRequest request,PublishTaskModel publishTaskModel,String preTime,String publishStyle) {
    	publishTaskModel.setCustomId(getCustomId(request));
		try{
			JsonResult checkCustomResult = this.checkCustomerExist(request);
			if(!checkCustomResult.isSuccess()){
				return checkCustomResult;
			}
			CustomModel customModel =  (CustomModel)checkCustomResult.getObj();
			if("1".equals(publishStyle)){
				this.checkPublishTime(preTime);
			}
			VideoModel videoModel = videoService.getById(publishTaskModel.getVideoId());
			if(videoModel == null){
				return JsonResult.createErrorInstance(("视频不存在，操作失败"));
			}
//			if(videoModel.getCustomId().intValue() != customModel.getCustomId().intValue()){
//				_log.error("发布异常: videoCustomId={},loginCustomId={}",videoModel.getCustomId(),customModel.getCustomId());
//				return JsonResult.createErrorInstance(("用户认证失败"));
//			}
			CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
//			if(StringUtils.isBlank(customSpInfoModel.getTranscodeDomain())){
//				publishFaild(videoModel.getVideoId(),"未设置播放域名地址",customModel.getCustomId());
//				return JsonResult.createErrorInstance("请联系SP管理员设置播放域名");
//			}
			publishTaskModel.setCustomId(customModel.getCustomId());
			publishTaskModel.setVideoId(videoModel.getVideoId());
			Integer categorySettingFlag =  customSpInfoModel.getIsStartCategory();
			//未启用栏目设置
			if(categorySettingFlag == null || categorySettingFlag.intValue() == 0){
				//发布
				toCheckPublishUrl(request,publishTaskModel,preTime,publishStyle,customModel);
			}
			//启用栏目设置 分类未设置对应栏目
			if(categorySettingFlag != null && categorySettingFlag.intValue() == 1){
				Integer category = videoModel.getCategory();
				Long customCategory = videoModel.getCustomCategoryId();
                CategoryRelation relationbyselect ;
				if(customCategory == null || customCategory.intValue() == 0 ){
                    relationbyselect = customCategoryService.getRelationBySpidAndCategory(category,customModel.getSpId());
                }else {
                    relationbyselect = customCategoryService.getRelationBySpidAndCustomCategory(customCategory,customModel.getSpId());
					if(relationbyselect ==null){
						relationbyselect = customCategoryService.getRelationBySpidAndCategory(category,customModel.getSpId());
					}
				}
                if(relationbyselect == null){
                	 publishFaild(videoModel.getVideoId(),"分类未设置对应栏目",customModel.getCustomId());
                }else {
                    publishTaskModel.setMamNodeId(relationbyselect.getMAM_NodeID());
                    publishTaskModel.setMamNodeName(relationbyselect.getMAM_NodeName());
                    publishTaskModel.setCmsColumnId(relationbyselect.getCms_column_id());
                    publishTaskModel.setCmsColumnName(relationbyselect.getCms_column_name());
                    toCheckPublishUrl(request,publishTaskModel,preTime,publishStyle,customModel);
                }
			}

			OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE,customModel.getCustomId(),customModel.getContacts(),"发布视频信息",customModel.getSpId(),videoModel.getBusinessUUID(),videoModel.getVideoName());
			optionLogInfoService.create(logInfo);

            return JsonResult.createSuccessInstance(("发布操作成功"));
		} catch (Exception e) {
			 _log.error("添加视频发布任务失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("发布操作失败");
        }
    }

    /**
     * 发布失败
     * @param videoId
     * @param faildMsg
     * @param customId
     */
    private void publishFaild(Long videoId,String faildMsg,Long customId){
        VideoModel updateVideo = new VideoModel();
        updateVideo.setVideoId(videoId);
        updateVideo.setUpdateUserId(customId);
        updateVideo.setUpdateTime(new Date());
        updateVideo.setStatus(ModelStatus.ReleaseFail);
        videoService.save(updateVideo);
        videoPublishService.addPublishHistory(videoId, customId, 1, faildMsg);
    }

    /**
     * @Description:发布地址的校验
     */
    public  JsonResult toCheckPublishUrl(HttpServletRequest request,PublishTaskModel publishTaskModel,String preTime,String publishStyle,CustomModel customModel){
    	CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(this.getSpId(request));
    	if(StringUtils.isNotBlank(customSpInfoModel.getPublishUrl())){//存在发布地址时
			return this.toPublishTask(publishTaskModel,preTime,publishStyle);
		}else{
			publishFaild(publishTaskModel.getVideoId(),"未设置发布地址",publishTaskModel.getCustomId());
			return JsonResult.createSuccessInstance(null);
		}
    }
    
    /**
     * @Description:添加到发布任务列表
     */
    public JsonResult toPublishTask(PublishTaskModel publishTaskModel,String preTime,String publishStyle){
    	try{
    		if("0".equals(publishStyle) && StringUtils.isEmpty(preTime)){//立即发布
    			publishTaskModel.setPrePublishedTime(new Date());
    			VideoModel videoModel = videoService.getById(publishTaskModel.getVideoId());
    			if(videoModel!=null){
					VideoModel update = new VideoModel();
					update.setVideoId(videoModel.getVideoId());
					update.setStatus(ModelStatus.ReleaseIng);
					update.setUpdateTime(new Date());
					update.setCustomId(videoModel.getCustomId());
					update.setUpdateUserId(videoModel.getCustomId());
    				videoService.save(update);
    			}else {
					return JsonResult.createErrorInstance("视频不存在");
				}
    		}else{
    			publishTaskModel.setPrePublishedTime(CalendarUtil.parseDefaultDate(preTime));
    		}
    		publishTaskModel.setPublishState(Integer.valueOf(publishStyle));
    		publishTaskService.insert(publishTaskModel);
    		return JsonResult.createSuccessInstance(null);
    	} catch (Exception e) {
			 _log.error("添加发布任务失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("操作失败");
       }
    }
    

	/**
	 * 校验发布时间
	 * 1、不能小于当前时间；2、必须大于5分钟
	 * @param publishTime
	 * @return
	 */
	private JsonResult checkPublishTime(String publishTime){
		if(StringUtils.isEmpty(publishTime)) {
			return JsonResult.createErrorInstance("发布时间为空");
		}
		long minTimes = CalendarUtil.parseDefaultDate(publishTime).getTime() - new Date().getTime();
		if(minTimes < 0){
			return JsonResult.createErrorInstance("定时发布时间小于当前时间,请从新设置!");
		}
		if(minTimes >= 0 && minTimes <= 5 * 60 *1000){
			return JsonResult.createErrorInstance("定时发布时间设置过短，建议使用立即发布功能!");
		}
		return JsonResult.createSuccessInstance(null);
	}
	
	/**
	 * 
	 * @Description:获取所有的目录结构
	 */
	@RequestMapping("/getAllCategory")
    @ResponseBody
	public JsonResult getAllCategory(HttpServletRequest request){
		CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(this.getSpId(request));
		if(customSpInfoModel!=null && StringUtils.isNotBlank(customSpInfoModel.getCmsReqUrl())){
			try {
				String cmsReqUrl = customSpInfoModel.getCmsReqUrl();
		    	String post = HttpClientUtils.post(cmsReqUrl, "", 0);
				return JsonResult.createSuccessInstance(JSONObject.toJSON(post));
			} catch (Exception e) {
				_log.error("获取目录结构失败：_____________"+e.getMessage());
				 return JsonResult.createErrorInstance("获取目录结构失败");
			}
		}else{
			return JsonResult.createErrorInstance("获取目录结构失败");
		}
	}
	
	/**
	 * 
	 * @Description:取消定时发布
	 */
	@RequestMapping("/cancelPublish")
    @ResponseBody
//	@LogAnnotation(message = "操作取消发布",type = OptionType.UPDATE)
	public JsonResult cancelPublish(HttpServletRequest request,long videoId){
		JsonResult jsonResult=new JsonResult();
		try{
			VideoModel videoModel = videoService.getById(videoId);
			if(videoModel == null){
				return JsonResult.createErrorInstance("取消定时发布的视频不存在，发布失败");
			}

			PublishTaskModel publishTaskModel=new PublishTaskModel();
			publishTaskModel.setCustomId(getCustomId(request));
			publishTaskModel.setPublishState(Const.PUBLISHTASK_STATUS_PUBLISHTIME);
			publishTaskModel.setVideoId(videoId);
			jsonResult = publishTaskService.cancelPublish(publishTaskModel);

			OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE,videoModel.getCustomId(),videoModel.getCustomName(),"取消发布视频",videoModel.getSpid(),videoModel.getBusinessUUID(),videoModel.getVideoName());
			optionLogInfoService.create(logInfo);


		} catch (Exception e) {
			_log.error("取消定时发布失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("取消定时发布失败");
		}
		return jsonResult;
	}
}
