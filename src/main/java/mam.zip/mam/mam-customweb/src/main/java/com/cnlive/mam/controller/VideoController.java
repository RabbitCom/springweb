package com.cnlive.mam.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.*;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.exception.ValidateException;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.UuidUtil;
import com.cnlive.mam.condition.LogInfoCondition;
import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.VideoInitVo;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author zhangxiaobin
 */
@Controller
@RequestMapping("/videoController")
public class VideoController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(VideoController.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "videoAuditService")
    private VideoAuditService videoAuditService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;

    @Resource(name = "albumService")
    private AlbumService albumService;

    @Resource(name = "transcodeTaskService")
    private TranscodeTaskService transcodeTaskService;

    @Resource(name = "videoRemoveService")
    private VideoRemoveService videoRemoveService;

    @Resource(name = "remoteService")
    private RemoteService remoteService;

    @Resource(name = "optionLogInfoService")
    private OptionLogInfoService optionLogInfoService;

    @Value("#{configProperties['transOverCall_url']}")
    private String transOverCallUrl;

    @Value("#{configProperties['logopicurl_default']}")
    private String defaultLogUrl;

    @Value("#{configProperties['logopicDoamin_default']}")
    private String defaultLogDomain;

    private String[] acceptAttributes = {"subTitle", "tag", "subCategory", "synopsis", "language", "area",
            "playPlatform", "contentRating", "shieldingRule", "copyrightType", "copyrightCompany", "copyrightStart",
            "copyrightEnd", "extendProperties"};

    /**
     * @Description:跳转到视频管理页面
     */
    @RequestMapping("/manager")
    public String manager(HttpServletRequest request, String customCategoryId, Model model) {
        request.setAttribute("customCategoryId", customCategoryId);
        Long spId = this.getSpId(request);

        //存储是否配置
        if (!storageService.checkStorageComplete(spId)) {
            request.setAttribute("errorMsg","存储信息不完整，请联系管理员完善存储信息!");
        }

        //区分金山、七牛上传页面
        List<StorageModel> list = storageService.getStorageEnableBySpid(spId);
        for (StorageModel storageModel : list) {
            String bucketName = storageModel.getName();
            int type = storageModel.getType().getDbValue();
            if(StorageTypeEnum.Definition.getDbValue() != type){
                //校验bucket是否存在
                boolean bucketExtis = checkBucketExtis(bucketName,storageModel.getType());
                if(!bucketExtis){
                    request.setAttribute("errorMsg","存储信息异常，请联系管理员确认存储信息是否开通！");
                    return "/video/video_manager";
                }
            }
        }
        for (StorageModel storageModel : list) {
            //七牛，获取domain、token
            int contentType = storageModel.getContentType().getDbValue();
            if (StorageContentTypeEnum.Media.getDbValue() == contentType || StorageContentTypeEnum.MediaAndPicture.getDbValue() == contentType) {
                //存储类型如果是金山，直接返回页面
                if (StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue()) {
                	 request.setAttribute("type", "ks");
                    return "/video/video_manager";
                }
                if(StorageTypeEnum.QINIUYUN.getDbValue() == storageModel.getType().getDbValue()) {
                    Integer id = storageModel.getId();
                    String hostName =storageService.getDomainSimpleOutByStorageId(id);
                    request.setAttribute("domain", hostName);
                    request.setAttribute("type", "qn");
                    return "/video/video_manager";
                }
            }
        }
        return "/video/video_manager";
    }

    /**
     * @Description:跳转到视频审核管理页面
     */
    @RequestMapping("/toAuditManager")
    public String toAuditManager(HttpServletRequest request, Model model) {
        // 获取审核不通过的原因
        List<Dictionary> auditReasonList = new ArrayList<Dictionary>();
        auditReasonList = super.dictionaryService.getDictionary("auditReason", 100001);
        request.setAttribute("auditReasonList", auditReasonList);
        return "/videoAudit/audit_manager";
    }

    /**
     * @Description:跳转到视频审核日志管理页面
     */
    @RequestMapping("/toAuditLogManager")
    public String toAuditLogManager(HttpServletRequest request, Model model) {
        return "/videoAudit/audit_log";
    }

    /**
     * @Description:跳转到视频视频上传页面
     */
    @RequestMapping("/toVideoUploadManager")
    public String toVideoUploadManager(HttpServletRequest request, Model model) {
        Long spId = this.getSpId(request);
        CustomSpInfoModel spInfo = customSpInfoService.getBySpId(spId);
        request.setAttribute("spLogoSite", spInfo.getLogoSite());
        request.setAttribute("spLogoStatus", spInfo.getLogoStatus());

        //存储是否配置
        if (!storageService.checkStorageComplete(spId)) {
            request.setAttribute("errorMsg","存储信息不完整，请联系管理员完善存储信息!");
            return "/noStorage";
        }

        //区分金山、七牛上传页面
        List<StorageModel> list = storageService.getStorageEnableBySpid(spId);
        for (StorageModel storageModel : list) {
            String bucketName = storageModel.getName();
            int type = storageModel.getType().getDbValue();
            if(StorageTypeEnum.Definition.getDbValue() != type){
                //校验bucket是否存在
                boolean bucketExtis = checkBucketExtis(bucketName,storageModel.getType());
                if(!bucketExtis){
                    request.setAttribute("errorMsg","存储信息异常，请联系管理员确认存储信息是否开通！");
                    return "/noStorage";
                }
            }
        }
        for (StorageModel storageModel : list) {
            //七牛，获取domain、token
            int contentType = storageModel.getContentType().getDbValue();
            if (StorageContentTypeEnum.Media.getDbValue() == contentType || StorageContentTypeEnum.MediaAndPicture.getDbValue() == contentType) {
                //存储类型如果是金山，直接返回页面
                if (StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue()) {
                    return "/video/video_upload";
                }
                if(StorageTypeEnum.QINIUYUN.getDbValue() == storageModel.getType().getDbValue()) {
                    Integer id = storageModel.getId();
                    String hostName =storageService.getDomainSimpleOutByStorageId(id);
                    request.setAttribute("domain", hostName);
                    return "/video/video_qiniu_upload";
                }
            }
        }
        return "/video/video_upload";
    }

    /**
     * @Description:跳转到更换视频源页面
     */
    @RequestMapping("/toReplaceVideoUploadManager")
    public String toReplaceVideoUploadManager(HttpServletRequest request, Model model) {
        return "/video/video_replace_upload";
    }

    /**
     * @Description:跳转到视频回收站页面
     */
    @RequestMapping("/toVideoRecycle")
    public String manager(HttpServletRequest request, Model model) {
        return "/videoRecycle/videoRecycle";
    }

    /**
     * @Description: 分页查询视频数据
     */
    @RequestMapping("/dataGrid")
    @ResponseBody
    // @LogAnnotation(message = "分页查询视频列表",type = OptionType.SELECT)
    public DataGrid dataGrid(HttpServletRequest request, VideoCondition condition) throws Exception {
        DataGrid dg = new DataGrid();
        try {
            boolean isSpAdmin = checkIsSpAdmin(request);
            if (isSpAdmin) {
                condition.setSpAdmin(Const.IS_PARENT_YES);
            } else {
                condition.setSpAdmin(Const.IS_PARENT_NO);
                condition.setInstitutionId(this.getInstitutionId(request));
            }
            condition.setSpid(this.getSpId(request));
            if (StringUtils.isNotBlank(condition.getOnoffStatus())) {
                condition.setOnoffStatusArray(condition.getOnoffStatus().split(","));
                condition.setOnoffStatus(null);
            }
            if (condition.getCategory() != null) {
                if ("0".equals(condition.getCategory().toString())) {
                    condition.setCategory(null);
                }
            }

            if (StringUtils.isNotBlank(condition.getCreateCustomName())) {
                List<CustomModel> customByCustomNames = customService.getByCustomName(condition.getCreateCustomName(), condition.getSpid());
                if (customByCustomNames != null && customByCustomNames.size() > 0) {
                    List<String> customIds = new ArrayList<>();
                    for (CustomModel customModel : customByCustomNames) {
                        customIds.add(customModel.getCustomId().toString());
                    }
                    condition.setCustomIds(Joiner.on(Const.VALUE_DECOLLATOR).join(customIds).toString().split(Const.VALUE_DECOLLATOR));
                } else {
                    return dg;
                }
            }

            dg = videoService.getPageByCondition(condition);
        } catch (Exception e) {
            _log.error("分页查询视频信息列表失败，参数：{}，错误信息：{}", JSONObject.toJSONString(condition), e);
        }
        return dg;
    }

    /**
     * @Title: auditVideo
     * @Description: 视频审核(支持批量)
     */
    @RequestMapping(value = "/videoAudit", method = {RequestMethod.POST})
    @ResponseBody
    // @LogAnnotation(message = "操作送审视频",type = OptionType.UPDATE)
    public JsonResult videoAudit(HttpServletRequest request, @RequestBody VideoAuditModel videoAuditModel) {
        // TODO 参数校验
        // return JsonResult.createSuccessInstance(("audit_success"));

        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if (!checkCustomerExist.isSuccess()) {
            return checkCustomerExist;
        }
        CustomModel customModel = (CustomModel) checkCustomerExist.getObj();
        String[] videoIds = videoAuditModel.getVideoIds();
        if (videoIds == null || videoIds.length <= 0) {
            return JsonResult.createErrorInstance(("送审信息未找到"));
        }
        for (String videoId : videoIds) {
            videoService.songShen(Long.parseLong(videoId), customModel);
        }

        return JsonResult.createSuccessInstance("success");
    }

    /**
     * @Description:审核日志列表
     */
    @RequestMapping("/videoAuditDataGrid")
    @ResponseBody
    public DataGrid videoAuditDataGrid(HttpServletRequest request, VideoAuditCondition condition) {
        DataGrid dg = new DataGrid();
        try {
            condition.setSort("id");
            condition.setCustomId(this.getCustomId(request));
            dg = videoAuditService.getByCondition(condition);
        } catch (Exception e) {
            _log.error("审核日志信息列表失败，参数：{}，错误信息：{}", JSONObject.toJSONString(condition), e);
        }
        return dg;
    }

    /**
     * @Description: 跳转到视频编辑页面
     */
    @RequestMapping("/toVideoEdit")
    public String toVideoEdit(HttpServletRequest request, Long videoId, String editCategory, Model model) {

        // 扩展属性存放
        List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();
        if (videoId != null) {
            VideoModel video = videoService.getById(videoId);
            if (video == null) {
                // 判断视频是否为null 防止用户在页面上传过程中删除视频 又点击编辑造成的null
                throw new ValidateException(("视频不存在"));
            }
//			if (video.getCustomId().intValue() != customId) {
//				throw new ValidateException(("用户无权限"));
//			}
            if (video.getAlbumId() != null && video.getAlbumId().intValue() != 0) {
                AlbumModel album = albumService.getById(video.getAlbumId());
                if (album != null) {
                    Map<String, Object> stringObjectMap = CommonUtil.transBean2Map(album);

                    video = (VideoModel) reflectSetVal(video, Arrays.asList(acceptAttributes), stringObjectMap);
                }
            }
            video = super.unescapeHtmlStr(video);
            request.setAttribute("video", video);
            if (StringUtils.isNotEmpty(editCategory)) {
                video.setVideoType(null);
                video.setSubCategory(null);
                video.setLanguage(null);
                video.setArea(null);
                video.setExtendProperties(null);
            }
            Integer category = StringUtils.isEmpty(editCategory) ? video.getCategory() : Integer.parseInt(editCategory);
            super.setRequestPublicInfo(request, category);
            showPropertyList = super.getPropertyList(0, video, null, category);
            request.setAttribute("videoMmsType", video.returnMmsType().getCode());
            request.setAttribute("showPropertyList", showPropertyList);
            request.setAttribute("picFinished", videoService.returnLayerPicAllpicScale(video.getPicOriginal(),video.getPicFinishedImg(),video.getStorageImgId()));
            request.setAttribute("videoCategory", category);
            request.setAttribute("description", video.getDescription() == null ? "" : video.getDescription());
        }
        return "/video/video_edit";
    }

    /**
     * @Description: 跳转到视频查看页面
     */
    @RequestMapping("/toVideoView")
    // @LogAnnotation(message = "查看视频信息详情",type = OptionType.SELECT)
    public String toVideoView(HttpServletRequest request, Long videoId, Model model) {
        // 扩展属性存放
        List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();
        if (videoId != null) {
            VideoModel video = videoService.getById(videoId);
//			Long customId = getCustomId(request);
//			if (video.getCustomId().intValue() != customId) {
//				throw new ValidateException(("用户无权限"));
//			}
            video = super.unescapeHtmlStr(video);
            request.setAttribute("video", video);
            request.setAttribute("videoMmsType", video.returnMmsType().getCode());
            Integer Category = video.getCategory();
            super.setRequestPublicInfo(request, Category);

            // 获取扩展的属性页面展示
            showPropertyList = super.getPropertyList(0, video, null, 0);
            request.setAttribute("showPropertyList", showPropertyList);
            request.setAttribute("picFinished", videoService.returnLayerPicAllpicScale(video.getPicOriginal(),video.getPicFinishedImg(),video.getStorageImgId()));
        }
        return "/video/video_view";
    }

    /**
     * @Description: 更新视频信息
     */
    // @LogAnnotation(message = "更新视频信息",type = OptionType.UPDATE)
    @RequestMapping(value = "updateVideo", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateVideo(HttpServletRequest request, VideoModel newVideoModel) {
        try {

            JsonResult checkCustomResult = this.checkCustomerExist(request);
            if (!checkCustomResult.isSuccess()) {
                return checkCustomResult;
            }
            CustomModel customModel = (CustomModel) checkCustomResult.getObj();
            Long customId = customModel.getCustomId();
            Long spId = customModel.getSpId();
            String customName = customModel.getContacts();
            // 验证视频id
            if (newVideoModel.getVideoId() == null || newVideoModel.getVideoId().intValue() == 0)
                return JsonResult.createErrorInstance(("视频修改参数错误,请稍后重试!"));
            VideoModel oldVideoModel = videoService.getById(newVideoModel.getVideoId());
            if(oldVideoModel == null){
                return JsonResult.createErrorInstance(("视频不存在！"));
            }
            // 验证权限
//			if (customId.intValue() != oldVideoModel.getCustomId().intValue())
//				return JsonResult.createErrorInstance(("用户无权限"));
            // 验证专辑
            JsonResult albumResult = checkUpdateAlbum(oldVideoModel, newVideoModel, customId);
            if (!albumResult.isSuccess())
                return albumResult;
            newVideoModel = (VideoModel) albumResult.getObj();
            // 验证分类
            JsonResult categoryResult = checkUpdateCategory(oldVideoModel, newVideoModel);
            if (!categoryResult.isSuccess())
                return categoryResult;
            newVideoModel = (VideoModel) categoryResult.getObj();
            // 验证扩展属性
            JsonResult expResult = checkUpdateExp(request, newVideoModel, customId);
            if (!expResult.isSuccess())
                return expResult;
            newVideoModel = (VideoModel) expResult.getObj();
            newVideoModel.setAlbumId(oldVideoModel.getAlbumId());
            newVideoModel.setMmsType(null);

            newVideoModel = updateVideoStatus(oldVideoModel, newVideoModel);

            newVideoModel.fullProperty();
            newVideoModel.setCustomId(oldVideoModel.getCustomId());
            newVideoModel.setUpdateUserId(customId);
            newVideoModel.setUpdateTime(new Date());
            videoService.modify(newVideoModel);
            OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customId, customName, "编辑视频信息", spId,
                    newVideoModel.getBusinessUUID(), newVideoModel.getVideoName());
            optionLogInfoService.create(logInfo);

            return JsonResult.createSuccessInstance(("编辑视频信息成功"));
        } catch (Exception e) {
            _log.error("更新视频信息失败失败，参数：{}，错误信息：{}", JSONObject.toJSONString(newVideoModel), e);
            return JsonResult.createErrorInstance(("编辑视频信息失败,请稍后重试!"));
        }
    }

    /**
     * @Description: 修改视频详细信息
     */
    @RequestMapping(value = "updateVideoDes", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateVideoDes(HttpServletRequest request, VideoModel videoModel) {
        try {
            JsonResult checkCustomResult = this.checkCustomerExist(request);
            if (!checkCustomResult.isSuccess()) {
                return checkCustomResult;
            }
            CustomModel customModel = (CustomModel) checkCustomResult.getObj();
            if (videoModel.getVideoId() == null || videoModel.getVideoId().intValue() == 0)
                return JsonResult.createErrorInstance(("视频修改参数错误,请稍后重试!"));
            VideoModel oldVideoModel = videoService.getById(videoModel.getVideoId());
            if (oldVideoModel == null) {
                return JsonResult.createErrorInstance(("视频不存在"));
            }
            VideoModel update = new VideoModel();
            update.setUpdateTime(new Date());
            update.setUpdateUserId(customModel.getCustomId());
            update.setDescription(videoModel.getDescription());
            update.setVideoId(videoModel.getVideoId());
            videoService.modify(update);
            return JsonResult.createSuccessInstance(("编辑视频详情成功"));
        } catch (Exception e) {
            _log.error("更新视频详情失败，参数：{}，错误信息：{}", JSONObject.toJSONString(videoModel), e);
            return JsonResult.createErrorInstance(("编辑视频详情失败,请稍后重试!"));
        }
    }

    private VideoModel updateVideoStatus(VideoModel oldVideoModel, VideoModel newVideoModel) {
        ModelStatus vsNew = newVideoModel.getStatus();
        FileStatus fsNew = newVideoModel.getFileStatus();
        ModelStatus vsOld = oldVideoModel.getStatus();
        FileStatus fsOld = oldVideoModel.getFileStatus();
        if (vsOld.getDbValue() > vsNew.getDbValue()) {
            newVideoModel.setStatus(vsOld);
        }
        if (fsOld.getDbValue() > fsNew.getDbValue()) {
            newVideoModel.setFileStatus(fsOld);
        }
        return newVideoModel;
    }

    /**
     * @Description: 根据视频ID获取视频信息
     */
    // @LogAnnotation(message = "查询视频信息",type = OptionType.SELECT)
    @RequestMapping("/getVideoInfoById")
    @ResponseBody
    public JsonResult getVideoInfoById(String videoId, HttpServletRequest request) {
        if (StringUtils.isEmpty(videoId))
            return JsonResult.createErrorInstance("videoId" + ("为空"));
        try {
            Long vid = CommonUtil.parseNumber("videoId", videoId).longValue();
            VideoModel video = videoService.getById(vid);
            if (video == null)
                return JsonResult.createErrorInstance(("视频不存在"));
            Long customId = getCustomId(request);
            if (customId != video.getCustomId().intValue()) {
                return JsonResult.createErrorInstance(("用户无权限"));
            }
            return JsonResult.createSuccessInstance(video);
        } catch (Exception e) {
            _log.error("获取视频信息失败，参数：{}，错误信息：{}", videoId, e);
            return JsonResult.createErrorInstance(("获取视频信息失败"));
        }
    }

    /**
     * @throws @Title: toJoinAlbum
     * @Description: 加入专辑（支持批量）
     */
    @RequestMapping("/toJoinAlbum")
    @ResponseBody
    // @LogAnnotation(message = "操作视频加入专辑",type = OptionType.UPDATE)
    public JsonResult toJoinAlbum(HttpServletRequest request, Long albumId, String videoIds) {
        try {
            if (StringUtils.isBlank(videoIds) || albumId == null || albumId == 0L) {
                return JsonResult.createErrorInstance(("加入专辑参数错误,请稍后重试!"));
            }
            AlbumModel joinAlbum = albumService.getById(albumId);
            if (joinAlbum == null || joinAlbum.getCustomId().longValue() != this.getCustomId(request).longValue())
                return JsonResult.createErrorInstance(("专辑不存在"));
            if (joinAlbum.getStatus() == ModelStatus.Edit || joinAlbum.getStatus() == ModelStatus.New) {
                return JsonResult.createErrorInstance(("专辑状态不可用"));
            }
            JsonResult checkCustomerExist = this.checkCustomerExist(request);
            if (!checkCustomerExist.isSuccess()) {
                return checkCustomerExist;
            }
            CustomModel customModel = (CustomModel) checkCustomerExist.getObj();
            Long customId = customModel.getCustomId();
            String customName = customModel.getContacts();
//			if (customId != joinAlbum.getCustomId().intValue()) {
//				return JsonResult.createErrorInstance(("用户无权限"));
//			}
            // 验证专辑的视频数量
            if (joinAlbum.getVideoCount() >= Const.albumVideoCount) {
                return JsonResult.createErrorInstance(("专辑的视频数量已经达到上限"));
            }
            String[] ids = videoIds.split(Const.VALUE_DECOLLATOR);

            String errorMsg = "";
            List<VideoModel> joinVideos = new ArrayList<>();
            for (String videoId : ids) {
                Long vid = CommonUtil.parseNumber("videoId", videoId).longValue();
                VideoModel videoModel = videoService.getById(vid);
                if (videoModel == null) {
                    return JsonResult.createErrorInstance(("视频不存在"));
                }
                if (videoModel.getCategory().intValue() == 0 && videoModel.getCustomCategoryId().intValue() == 0) {
                    // 当前视频从未设置过数据分类和客户分类，则加入专辑的时候为它添加当前专辑的分类
                    joinVideos.add(videoModel);
                    continue;
                }
                if (videoModel.getAlbumId() != null && videoModel.getAlbumId().intValue() != 0) {
                    errorMsg = ("video_has_already_album") + ",videoId=" + videoId;
                    break;
                }

                if (videoModel.getCategory().intValue() != joinAlbum.getCategory().intValue()) {
                    errorMsg = ("video_belong_album_not_same_as_album") + ",videoId=" + videoId;
                    break;
                }
                joinVideos.add(videoModel);
            }
            if (StringUtils.isNotBlank(errorMsg)) {
                return JsonResult.createErrorInstance(errorMsg);
            }
            for (VideoModel videoModel : joinVideos) {
                VideoModel updateModel = new VideoModel();
                updateModel.setVideoId(videoModel.getVideoId());
                updateModel.setAlbumId(joinAlbum.getAlbumId());// 设置专辑id
                updateModel.setCategory(joinAlbum.getCategory());// 设置专辑数据分类
                updateModel.setCustomCategoryId(joinAlbum.getCustomCategoryId());// 设置专辑客户分类
                updateModel.setUpdateUserId(customId);
                updateModel.setUpdateTime(new Date());
                videoService.save(updateModel);
                OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customId, customName,
                        "视频加入专辑", videoModel.getSpid(), videoModel.getBusinessUUID(), videoModel.getVideoName());
                optionLogInfoService.create(logInfo);
            }
            // albumService.updateAlbumEpisodeNow(joinAlbum.getAlbumId());
            return JsonResult.createSuccessInstance(("加入专辑成功"));
        } catch (Exception e) {
            _log.error("加入专辑失败，参数：{}，错误信息：{}", "专辑id：" + albumId + "，视频ids：" + videoIds, e);
            return JsonResult.createErrorInstance(("加入专辑异常,请稍后重试!"));
        }
    }

    /**
     * @param videoId    ("video_str")ID
     * @param customImg  用户自定义的图片地址
     * @param proportion 比例 ( 'ar169'.... )("param")
     * @throws @Title: getPicByDiffScale
     * @Description: 根据不通的分辨率生成成品图并保存
     */
    @RequestMapping("/getPicByDiffScale")
    @ResponseBody
    // @LogAnnotation(message = "设置视频的自定义图片地址",type = OptionType.UPDATE)
    public JsonResult picByDiffScale(HttpServletRequest request, String videoId, String customImg, String proportion) {
        if (StringUtils.isEmpty(videoId) || StringUtils.isBlank(customImg) || StringUtils.isBlank(proportion)) {
            return JsonResult.createErrorInstance(("参数为空"));
        }
        try {
            JsonResult checkCustomResult = this.checkCustomerExist(request);
            if (!checkCustomResult.isSuccess()) {
                return checkCustomResult;
            }
            CustomModel customModel = (CustomModel) checkCustomResult.getObj();
            Long customId = customModel.getCustomId();
            Long spId = customModel.getSpId();
            String customName = customModel.getContacts();

            Long vid = CommonUtil.parseNumber("videoId", videoId).longValue();
            VideoModel video = videoService.getById(vid);
            if (video == null)
                return JsonResult.createErrorInstance(("视频不存在"));

            Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
            if (StringUtils.isNotBlank(video.getPicFinishedImg()))
                finishedImgs_map = JSON.parseObject(video.getPicFinishedImg(), Map.class);
            // 处理一下比例 通过 16:9 获取 ar169
            String scalKey = "";
            for (Map.Entry entry : Const.videoImageScalCp.entrySet()) {
                if (proportion.equals(entry.getValue())) {
                    scalKey = String.valueOf(entry.getKey());
                    break;
                }
            }
            // 处理一下 customImg
            StorageModel storageModel = storageService.getById(video.getStorageImgId());
            customImg =  replaceHost(customImg);
            Integer[] resolutions = Const.videoImageType.get(scalKey);
            Map<String, String> fbl_map = new HashMap<String, String>();
            for (int i = 0; i < resolutions.length; i = i + 2) {
                String pic_fbl = resolutions[i] + "*" + resolutions[i + 1];
                String pic_url = "";
				if(storageModel.getType()==StorageTypeEnum.QINIUYUN){
					pic_url = customImg + "?imageView2/1/w/" + resolutions[i] + "/h/" + resolutions[i + 1];
				}else{
					pic_url = customImg + "@base@tag=imgScale&w=" + resolutions[i] + "&h=" + resolutions[i + 1]
							+ "&m=2&c=1";
				}
                fbl_map.put(pic_fbl, pic_url);
            }
            finishedImgs_map.put(scalKey, fbl_map);
            VideoModel updateVideo = new VideoModel();
            updateVideo.setVideoId(video.getVideoId());
            updateVideo.setUpdateTime(new Date());
            updateVideo.setUpdateUserId(customId);
            updateVideo.setPicFinishedImg(JSON.toJSONString(finishedImgs_map));
            videoService.save(updateVideo);

            OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customId, customName,
                    "更新视频【" + proportion + "】的图片", spId, video.getBusinessUUID(), video.getVideoName());
            optionLogInfoService.create(logInfo);

            return JsonResult.createSuccessInstance("设置成功",storageModel.getType());
        } catch (Exception e) {
            if (e instanceof BusinessException) {
                return JsonResult.createErrorInstance(((BusinessException) e).getErrorMessage());
            }
            _log.error("用户自定义视频图片出错，参数：{}，错误信息：{}", "视频id：" + videoId + "，图片：" + customImg + "，比例：" + proportion, e);
            return JsonResult.createErrorInstance(("自定义图片设置异常"));
        }
    }

    /**
     * 视频上下线
     *
     * @param videoId  ("video_str") ID
     * @param action   上下线动作
     * @param request  请求
     * @param response 返回
     * @return Json结果
     */
    @RequestMapping("/toggleOnOffLine")
    @ResponseBody
    public JsonResult toggleOnOffLine(Long videoId, Integer action, HttpServletRequest request,
                                      HttpServletResponse response) {
        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);
        if (videoId == null) {
            jsonResult.setMsg(("video_str") + "ID" + ("param_lack"));
            return jsonResult;
        }

        if (action == null || action == ModelStatusAction.NO_ACTION.getDbValue()) {
            jsonResult.setMsg(("online_offline_param_lack"));
            return jsonResult;
        }

        String operation = ("offline");
        ModelStatus status = ModelStatus.OffLine;
        if (action == ModelStatusAction.ON_LINE.getDbValue()) {
            operation = ("online");
            status = ModelStatus.OnLine;
        }

        response.setHeader("Access-Control-Allow-Origin", "*");
        return handleToggleOnOffLine(videoId, status, operation, request, new ArrayList<>());
    }

    @RequestMapping("/removeVideo")
    @ResponseBody
    // @LogAnnotation(message = "视频删除操作",type = OptionType.DELETE)
    public JsonResult removeVideo(HttpServletRequest request, HttpServletResponse response, String delMeg,
                                  String videoIds) {
        if (StringUtils.isEmpty(videoIds) || StringUtils.isEmpty(delMeg)) {
            return JsonResult.createErrorInstance("请填写删除原因");
        }
        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if (!checkCustomResult.isSuccess()) {
            return checkCustomResult;
        }
        CustomModel customModel = (CustomModel) checkCustomResult.getObj();
        Long customId = customModel.getCustomId();
        Long spId = customModel.getSpId();
        String customName = customModel.getContacts();

        List<String> videoIdList = Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().splitToList(videoIds);
        for (String str : videoIdList) {
            Long videoId = CommonUtil.parseNumber("videoId", str).longValue();
            VideoModel videoModel = videoService.getById(Long.valueOf(videoId));
            if (videoModel == null) {
                continue;
            }
            // 记录视频删除前的状态
            ModelStatus oldStatus = videoModel.getStatus();
            // 设置视频状态为删除
            VideoModel updateVideo = new VideoModel();
            updateVideo.setVideoId(videoModel.getVideoId());
            updateVideo.setStatus(ModelStatus.Delete);
            updateVideo.setUpdateTime(new Date());
            updateVideo.setUpdateUserId(customId);
            videoService.save(updateVideo);
            //
            VideoRemoveModel removeModel = new VideoRemoveModel();
            removeModel.setVideoId(videoId);
            removeModel.setVideoName(videoModel.getVideoName());
            removeModel.setOldStatus(oldStatus);
            removeModel.setBusinessUUID(videoModel.getBusinessUUID());
            removeModel.setRemoveTime(new Date());
            removeModel.setRemoveUser(customName);
            removeModel.setRemoveUserId(customId);
            removeModel.setRemoveSpId(spId);
            removeModel.setRemoveMsg(delMeg);
            videoRemoveService.create(removeModel);

            OptionLogInfo logInfo = new OptionLogInfo(OptionType.DELETE, customId, customName,
                    "删除视频至回收站", spId, videoModel.getBusinessUUID(), videoModel.getVideoName());
            optionLogInfoService.create(logInfo);

        }
        response.setHeader("Access-Control-Allow-Origin", "*");
        return JsonResult.createSuccessInstance("删除成功");
    }

    /**
     * 批量上下线
     *
     * @param videoIds ("video_str")
     * @param action   动作
     * @param request  请求
     * @param response 返回
     * @return jsonResult
     * @throws Exception
     */
    @RequestMapping("/batchToggleOnOffLine")
    @ResponseBody
    // @LogAnnotation(message = "视频上下线操作",type = OptionType.UPDATE)
    public JsonResult batchToggleOnOffLine(String videoIds, Integer action, HttpServletRequest request, String delMeg,
                                           HttpServletResponse response) throws Exception {
        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);

        if (StringUtils.isEmpty(videoIds)) {
            jsonResult.setMsg(("视频") + "ID" + ("参数缺失！"));
            return jsonResult;
        }

        if (action == null || action == ModelStatusAction.NO_ACTION.getDbValue()) {
            jsonResult.setMsg(("online_offline_param_lack"));
            return jsonResult;
        }

        String operation = ("offline");
        ModelStatus status = ModelStatus.Delete;
        if (action == ModelStatusAction.ON_LINE.getDbValue()) {
            operation = ("online");
            status = ModelStatus.OnLine;
        }

        String[] videoIdArray = videoIds.split(",");
        List<Long> errorVideoList = new ArrayList<>();
        Date currentTime = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = formatter.format(currentTime);
        Date currentTime_2 = formatter.parse(dateString);

        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if (!checkCustomResult.isSuccess()) {
            return checkCustomResult;
        }
        CustomModel customModel = (CustomModel) checkCustomResult.getObj();
        Long customId = customModel.getCustomId();
        Long spId = customModel.getSpId();
        String customName = customModel.getContacts();


        for (String videoId : videoIdArray) {
            if (videoId != null) {
                VideoRemoveModel model = new VideoRemoveModel();
                VideoModel videoModel = videoService.getById(Long.valueOf(videoId));
                if (videoModel != null && videoModel.getStatus().getDbValue() != ModelStatus.Delete.getDbValue()) {
                    model.setVideoId(Long.valueOf(videoId));
                    model.setVideoName(videoModel.getVideoName());
                    model.setOldStatus(videoModel.getStatus());
                    model.setBusinessUUID(videoModel.getBusinessUUID());
                    model.setRemoveTime(currentTime_2);
                    model.setRemoveUser(customName);
                    model.setRemoveUserId(customId);
                    model.setRemoveSpId(spId);
                    if (!delMeg.equals("")) {
                        model.setRemoveMsg(delMeg);
                    } else {
                        model.setRemoveMsg("业务删除");
                    }
                    videoRemoveService.create(model);
                    VideoModel updateVideo = new VideoModel();
                    updateVideo.setVideoId(videoModel.getVideoId());
                    updateVideo.setStatus(ModelStatus.Delete);
                    updateVideo.setUpdateTime(new Date());
                    updateVideo.setUpdateUserId(customId);
                    updateVideo.setCustomId(videoModel.getCustomId());
                    videoService.modify(updateVideo);
                }
            }
        }

        response.setHeader("Access-Control-Allow-Origin", "*");
        if (errorVideoList.isEmpty()) {
            jsonResult.setSuccess(true);
            return jsonResult;
        } else {
            jsonResult.setMsg(("video_") + errorVideoList.toString() + operation + ("fail_"));
            return jsonResult;
        }
    }

    /**
     * 处理上下线逻辑
     *
     * @param videoId        ("video_str")ID
     * @param status         状态
     * @param operation      动作
     * @param request        请求
     * @param errorVideoList 失败的视频id集合
     * @return jsonResult
     */
    private JsonResult handleToggleOnOffLine(Long videoId, ModelStatus status, String operation,
                                             HttpServletRequest request, List<Long> errorVideoList) {

        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);

        try {
            Long customId = this.getCustomId(request);

            VideoModel oldVideoModel = videoService.getById(videoId);
            if (oldVideoModel == null) {
                errorVideoList.add(videoId);
                return JsonResult.createErrorInstance(("视频") + videoId + ("不存在"));
            }

//			if (oldVideoModel.getCustomId() == null
//					|| oldVideoModel.getCustomId().longValue() != customId.longValue()) {
//				errorVideoList.add(videoId);
//				return JsonResult.createErrorInstance(("没有权限对视频") + videoId + operation);
//			}

            // if (oldVideoModel.getStatus() == ModelStatus.New) {
            // errorVideoList.add(videoId);
            // return JsonResult.createErrorInstance(("video_str") + videoId +
            // ("java_messaage_6") + operation);
            // }

            if (oldVideoModel.getStatus() == status) {
                errorVideoList.add(videoId);
                return JsonResult.createErrorInstance(("视频") + videoId + ("为") + operation + ("状态，不需要操作") + operation);
            }

            VideoModel videoModel = new VideoModel();
            Long albumId = oldVideoModel.getAlbumId();
            if (status == ModelStatus.OnLine) {
                // 如果是从回收站恢复逻辑：
                // 1.将视频状态变成待编辑状态 2.还原检查客户分类和专辑是否存在，如果不存在则变成0
                status = ModelStatus.New;
                Long customCategoryId = oldVideoModel.getCustomCategoryId();
                if (customCategoryId != null && customCategoryId != 0L) {
                    CustomCategoryModel customCategoryModel = customCategoryService.getById(customCategoryId);
                    if (customCategoryModel == null) {
                        videoModel.setCustomCategoryId(0L);
                    }
                }
                if (albumId != null && albumId != 0L) {
                    AlbumModel albumModel = albumService.getById(albumId);
                    if (albumModel == null && customCategoryId != albumModel.getCustomCategoryId()) {
                        videoModel.setAlbumId(0L);
                        // albumService.updateAlbumEpisodeNow(albumId);
                    }
                }
            }
            videoModel.setVideoId(videoId);
            videoModel.setStatus(status);
            videoModel.setUpdateUserId(customId);
            videoModel.setUpdateTime(new Date());
            videoService.save(videoModel);
            _log.debug(("视频") + "{}{}成功", videoId, operation);
            return JsonResult.createSuccessInstance(("视频") + operation + ("成功！"));
        } catch (Exception e) {
            _log.error(("视频") + "{}{}出错，{}", videoId, operation, e);
            errorVideoList.add(videoId);
            return JsonResult.createErrorInstance(("视频") + videoId + operation + ("出错！"));
        }
    }

    /**
     * @Description: 验证视频名称，验证规则：同一个租户下不能重复
     */
    @RequestMapping("/checkVideoName")
    @ResponseBody
    public JsonResult checkVideoName(HttpServletRequest request, String videoName, String videoId,
                                     HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        return JsonResult.createSuccessInstance(("验证通过，可以使用"));
    }

    /**
     * @Description: 获取视频转码信息
     */
    @RequestMapping("/getTranCodeInfos")
    @ResponseBody
    public JsonResult getTranCodeInfos(String videoId, HttpServletRequest request) {
        try {

            Long vid = CommonUtil.parseNumber("videoId", videoId).longValue();
            List<FileModel> fileModels = fileService.getByVid(vid);
            if (fileModels.size() <= 0) {
                return JsonResult.createErrorInstance("暂无数据！");
            }
            String playDomain = "";
            String downLoadUrl = "";
            StorageModel storageModel = null;
            for (FileModel fileModel : fileModels) {
                if(StringUtils.isEmpty(playDomain)) {
                    playDomain = storageService.getDomainSimpleOutByStorageId(fileModel.getStorageTranscode());
                }
                if(storageModel == null){
                    storageModel = storageService.getById(fileModel.getStorageTranscode());
                }
                fileModel.setCodeRateName(DefinitionEnum.getShowName(fileModel.getCodeRate()));
                // 判断是否为从老媒资同步过来的数据
                String playStr = playDomain + Const.SEPARATE_XIE + fileModel.getStoreUri();
                fileModel.setStoreUriDomain(playStr);
                fileModel.setOriginUriDomain(playDomain+Const.SEPARATE_XIE + fileModel.getOriginUri());
                fileModel.setStorageType(storageModel.getType().getDbValue());
            }
            return JsonResult.createSuccessInstance(fileModels);

        } catch (Exception e) {
            _log.error("获取转码信息异常,参数：{}，错误信息：{}", videoId, e);
            return JsonResult.createErrorInstance("获取转码信息异常,请稍后重试!");
        }
    }

    /**
     * 修改视频的分类信息
     */
    // @LogAnnotation(message = "修改视频的分类信息",type = OptionType.UPDATE)
    @RequestMapping(value = "setVideoCustomCategory", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult setVideoCustomCategory(HttpServletRequest request, String videoId, String category,
                                             String customCategoryId) {

        JsonResult checkCustom = this.checkCustomerExist(request);
        if (!checkCustom.isSuccess()) {
            return JsonResult.createErrorInstance(("用户认证失败"));
        }
        CustomModel customModel = (CustomModel) checkCustom.getObj();

        if (StringUtils.isEmpty(videoId) || StringUtils.isEmpty(category))
            return JsonResult.createErrorInstance(("参数错误"));

        VideoModel videoModel = videoService.getById(CommonUtil.parseNumber("videoId", videoId).longValue());
        if (videoModel == null)
            return JsonResult.createErrorInstance(("视频不存在"));
//		if (videoModel.getCustomId().intValue() != customModel.getCustomId().intValue()) {
//			return JsonResult.createErrorInstance(("该视频不属于当前用户"));
//		}

        if (videoModel.getAlbumId() != null && videoModel.getAlbumId().intValue() != 0) {
            return JsonResult.createErrorInstance(("视频有所属专辑") + "," + ("不允许修改分类"));
        }
        Integer categoryLong = CommonUtil.parseNumber("category", category).intValue();
        if (videoModel.getCategory().longValue() != categoryLong.longValue()) {
            return JsonResult.createErrorInstance(("一级分类变更") + "," + ("请完善相关属性"));
        }
        Long customCategory = StringUtils.isEmpty(customCategoryId) || customCategoryId.equals("0") ? 0L
                : CommonUtil.parseNumber("customCategoryId", customCategoryId).longValue();
        VideoModel update = new VideoModel();
        update.setVideoId(videoModel.getVideoId());
        update.setCategory(categoryLong);
        update.setCustomCategoryId(customCategory);
        update.setUpdateTime(new Date());
        update.setUpdateUserId(customModel.getCustomId());
        update.setCustomId(videoModel.getCustomId());
        videoService.modify(update);

        OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(), customModel.getContacts(), "修改视频的分类信息",
                customModel.getSpId(), videoModel.getBusinessUUID(), videoModel.getVideoName());
        optionLogInfoService.create(logInfo);

        return JsonResult.createSuccessInstance(("设置成功"));
    }

    /**
     * 加入专辑校验
     *
     * @param request
     * @param albumId
     * @param videoId
     * @return
     */
    @RequestMapping("/checkAlbum")
    @ResponseBody
    public JsonResult checkAlbum(HttpServletRequest request, String albumId, String videoId) {
        JsonResult checkCustomResult = checkCustomerExist(request);
        if (!checkCustomResult.isSuccess()) {
            return checkCustomResult;
        }
        CustomModel customModel = (CustomModel) checkCustomResult.getObj();
        Long customId = customModel.getCustomId();
        if (StringUtils.isEmpty(albumId) || StringUtils.isEmpty(videoId))
            return JsonResult.createErrorInstance("albumId or video Id" + ("参数为空"));
        if (albumId.equals("0"))
            return JsonResult.createSuccessInstance(null);
        try {
            Long vid = CommonUtil.parseNumber("videoId", videoId).longValue();
            Long aid = CommonUtil.parseNumber("albumId", albumId).longValue();
            AlbumModel album = albumService.getById(aid);
            if (album == null)
                return JsonResult.createErrorInstance(("专辑不存在"));
            if (album.getStatus() == ModelStatus.Edit || album.getStatus() == ModelStatus.New)
                return JsonResult.createErrorInstance(("专辑状态不可用"));
            if (album.getVideoCount() >= Const.albumVideoCount)
                return JsonResult.createErrorInstance(("专辑的视频数量已经达到上限"));
            VideoModel video = videoService.getById(vid);
            if (video == null)
                return JsonResult.createErrorInstance(("视频不存在"));
            if (video.getCategory().intValue() != album.getCategory().intValue())
                return JsonResult.createErrorInstance(("专辑与视频的数据分类不一致"));
//			if (video.getCustomId().longValue() != customId.longValue())
//				return JsonResult.createErrorInstance(("用户无权限"));
            return JsonResult.createSuccessInstance(null);
        } catch (Exception e) {
            return JsonResult.createErrorInstance(e.getMessage());
        }
    }

    /**
     * 验证分类
     */
    private JsonResult checkUpdateCategory(VideoModel oldVideoModel, VideoModel newVideoModel) {
        // 一级分类修改
        if (oldVideoModel.getAlbumId() != null && oldVideoModel.getAlbumId().intValue() != 0) {
            if (newVideoModel.getCustomCategoryId().intValue() != oldVideoModel.getCustomCategoryId().intValue()) {
                return JsonResult.createErrorInstance(("视频有所属专辑不允许修改分类"));
            }
        } else {
            if (newVideoModel.getCustomCategoryId() != null && newVideoModel.getCustomCategoryId().intValue() != 0) {
                CustomCategoryModel ccm = customCategoryService.getById(newVideoModel.getCustomCategoryId());
                newVideoModel.setCategory(ccm.getCategory());
                newVideoModel.setCustomCategoryId(ccm.getCustomCategoryId());
            }
        }
        return JsonResult.createSuccessInstance(newVideoModel);
    }

    /**
     * 验证专辑
     */
    private JsonResult checkUpdateAlbum(VideoModel oldVideoModel, VideoModel newVideoModel, Long customId) {
        Long newAlbumId = newVideoModel.getAlbumId();
        if (newAlbumId != null && newAlbumId.longValue() != 0L) {
            AlbumModel newAlbumModel = albumService.getById(newAlbumId);
            if (newAlbumModel == null)
                return JsonResult.createErrorInstance(("专辑不存在"));
            // 验证专辑的状态是否可用
            if (!newAlbumModel.getStatus().equals(ModelStatus.EditOver)) {
                return JsonResult.createErrorInstance(("专辑状态不可用"));
            }
            // 验证专辑的 分类 id 是否跟视频的分类ID 一样
            if (newVideoModel.getCategory().longValue() != newAlbumModel.getCategory().longValue()) {
                return JsonResult.createErrorInstance(("专辑所属的分类与视频的分类不符！"));
            }
            // 验证专辑的视频数量
            if (newAlbumModel.getVideoCount().intValue() >= Const.albumVideoCount) {
                return JsonResult.createErrorInstance(("此专辑的视频数量已经达到上限！"));
            }
            // 电影专辑下面只允许有一个正片的电影,去掉校验,当时加校验是考虑boss有一个计费规则,专辑单视频,现在去掉
            // if (newAlbumModel.getCategory().intValue() ==
            // Const.CHANNEL_FILM.intValue()
            // && newVideoModel.getVideoType() != null
            // && newVideoModel.getVideoType().intValue() == Const.POSITIVE
            // && this.checkFilmVideoType(newAlbumId, oldVideoModel)) {
            // return JsonResult.createErrorInstance(("java_message_12"));
            // }
        } else {
            newVideoModel.setAlbumId(0L);
        }
        newVideoModel.setPayPlatform(null);
        return JsonResult.createSuccessInstance(newVideoModel);
    }

    /**
     * 验证扩展信息
     */
    private JsonResult checkUpdateExp(HttpServletRequest request, VideoModel newVideoModel, Long customId) {
        // 获取扩展属性的值
        String extendPropertiesValues = this.getExtPropertysValuesToJSONString(request, 0, newVideoModel, null);

        newVideoModel.setExtendProperties(extendPropertiesValues);

        // xw 处理重复tag 并且验证长度
        String tagVal = newVideoModel.getTag();
        newVideoModel.setTag(tagVal);
        newVideoModel.setUpdateTime(new Date());
        newVideoModel.setCustomId(customId);
        newVideoModel.setUpdateUserId(customId);
        return JsonResult.createSuccessInstance(newVideoModel);
    }


    /**
     * 上传初始化接口，返回媒资信息id，用于生成上传的地址
     */
    @RequestMapping(value = "/uploadFileInit", method = RequestMethod.POST)
    @ResponseBody
    // @LogAnnotation(message = "上传视频",type = OptionType.INSERT)
    public JsonResult uploadFileInit(VideoInitVo videoInitVo, HttpServletRequest request,
                                     HttpServletResponse response) {
        JsonResult checkCustomResult = checkCustomerExist(request);
        // 如果用户信息无效，返回错误信息
        if (!checkCustomResult.isSuccess()) {
            return checkCustomResult;
        }
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        try {
            JsonResult checkCustom = this.checkCustomerExist(request);
            if (!checkCustom.isSuccess()) {
                return JsonResult.createErrorInstance(("用户认证失败"));
            }
            CustomModel customModel = (CustomModel) checkCustom.getObj();
            Long customId = customModel.getCustomId();
            Long spId = customModel.getSpId();
            String customName = customModel.getContacts();

            CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
            VideoModel videoModel = new VideoModel();
            // 存储视频
            String bussinessUUID = UuidUtil.getUuid();
            videoModel.setVideoName(videoInitVo.getVideoName());
            videoModel.setMmsType(MmsTypeEnum.COMMON);
            videoModel.setCategory(videoInitVo.getCategory());
            videoModel.setCustomCategoryId(videoInitVo.getCustomCategoryId());
            videoModel.setAlbumId(videoInitVo.getAlbumId());
            videoModel.setStatus(ModelStatus.New);
            videoModel.setFileStatus(FileStatus.New);
            videoModel.setCustomId(customId);
            videoModel.setLogosite(videoInitVo.getLogosite());
            // videoModel.setCustomName(customModel.getContacts());
            videoModel.setCreateUserId(customId);
            videoModel.setBusinessUUID(bussinessUUID);
            videoModel.setSpid(spId);
            videoModel.setUploadBtime(new Date());
            videoModel.setUpdateUserId(customId);
            videoModel.setInstitutionId(this.getInstitutionId(request));
            videoModel.setCanSearch(videoInitVo.getPtpwVal() == null ? 0 : videoInitVo.getPtpwVal());//添加否片头片尾
            videoModel.setIsIcms2Mam(VideoSources.mam);

            //获取视频存储id
            StorageModel storageMediaIn = storageService.getStorageInBySpId(spId,StorageContentTypeEnum.Media);
            videoModel.setStorageId(storageMediaIn.getId());
            //获取图片存储id
            StorageModel storageImgIn = storageService.getStorageInBySpId(spId,StorageContentTypeEnum.Picture);
            videoModel.setStorageImgId(storageImgIn.getId());

            videoModel = videoService.create(videoModel);
            Long vid = videoModel.getVideoId();
            String gfmt = videoInitVo.getGfmt();
            // 文件存储路径 格式 /raw/yyyy/mmdd/spid_businessUUID + gfmt
            String originPath = getUploadVodPath(spId, bussinessUUID, gfmt);

            String defaultCodeRates = customSpInfoModel.getCodeRate();
            String codeRateArr[] = defaultCodeRates.split(Const.VALUE_DECOLLATOR);

            //获取输出存储
            StorageModel outMediaStorage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Media);
            Integer storageId = outMediaStorage.getId();
            // 存储文件相关 根据客户设置的码率，处理file数据（每种码率生成两种格式的文件数据）
            for (String codeRate : codeRateArr) {
                Integer codeRateInt = Integer.valueOf(codeRate);
                FileModel mp4File = new FileModel(Const.FMT_MP4, codeRateInt, vid, videoModel.getVideoName(),
                        originPath, gfmt, videoInitVo.getMd5(), videoInitVo.getFileSize());
                FileModel hlsFile = new FileModel(Const.FMT_HLS, codeRateInt, vid, videoModel.getVideoName(),
                        originPath, gfmt, videoInitVo.getMd5(), videoInitVo.getFileSize());
                List<FileModel> fileModels = new ArrayList<>();
                mp4File.setStorageTranscode(storageId);
                mp4File.setStorageDistribute(storageId);
                hlsFile.setStorageTranscode(storageId);
                hlsFile.setStorageDistribute(storageId);
                fileModels.add(mp4File);
                fileModels.add(hlsFile);
                fileService.saveFileList(fileModels);
            }

            return JsonResult.createSuccessInstance(ImmutableMap.of("bucket", storageMediaIn.getName(), "originPath", originPath,
                    "vid", vid, "ksak", ksConfigAK, "kssk", ksConfigSK));
        } catch (Exception ex) {
            _log.error("uploadFileInit error ,msg = {}", ex.getMessage());
            return JsonResult.createErrorInstance("系统异常，请稍后重试！");
        }
    }

    /**
     * 上传完成回调，将上传成功的文件存储至待转码定时任务表
     *
     * @param videoId 视频id
     */
    @RequestMapping(value = "/pendingTranscodeTask", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult pendingTranscodeTask(Long videoId, HttpServletRequest request) {
        try {
            // 参数校验
            if (videoId == null) {
                _log.debug("pendingTranscodeTask, videoId is empty! videoId:" + videoId);
                return JsonResult.createErrorInstance(("视频") + "videoId" + ("参数缺失"));
            }
            // 用户有效性校验
            JsonResult result = this.checkCustomerExist(request);
            if (!result.isSuccess()) {
                return JsonResult.createErrorInstance("用户认证失败！");
            }
            CustomModel customModel = (CustomModel) result.getObj();
            Long customId = customModel.getCustomId();
            if (customId.longValue() == Const.CUSTOMID_DEFAULT_VAL.longValue()) {
                _log.debug("pendingTranscodeTask, customeId is empty! videoId:" + videoId);
                return JsonResult.createErrorInstance("用户登录超时");
            }
            VideoModel videoModel = videoService.getById(videoId);
            if (videoModel != null) {
                Integer ptpwState = videoModel.getCanSearch();
                String videoName = videoModel.getVideoName();
                Integer logoSiteByUpload = videoModel.getLogosite();
                VideoModel updateVideo = new VideoModel();
                updateVideo.setVideoId(videoModel.getVideoId());
                updateVideo.setStatus(ModelStatus.Edit);
                updateVideo.setFileStatus(FileStatus.UploadSuccess);
                updateVideo.setUpdateTime(new Date());
                updateVideo.setUpdateUserId(customId);
                updateVideo.setUploadEtime(new Date());
                updateVideo.setBusinessUUID(videoModel.getBusinessUUID());
                videoService.save(updateVideo);

                CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
                Integer logoStatus = customSpInfoModel.getLogoStatus();
                Integer logoSite = logoSiteByUpload != null ? logoSiteByUpload : customSpInfoModel.getLogoSite();

                List<FileModel> files = fileService.getByVid(videoId);
                String fileOriginUri = "";
                Integer transCodeStrorageId = 0;
                if (files != null && files.size() > 0) {
                    FileModel file = files.get(0);
                    fileOriginUri = file.getOriginUri();
                    transCodeStrorageId = file.getStorageTranscode();
                }
                TranscodeTaskModel task = new TranscodeTaskModel(videoId, customId, customModel.getSpId(),
                        customSpInfoModel.getCodeRate(), fileOriginUri);
                task.setTransCodeFmt(Const.FMT_HLS + Const.VALUE_DECOLLATOR + Const.FMT_MP4);
                Integer plat = 0;
                //区分金山or七牛，不同的平台不同的域名
                StorageModel storage = storageService.getById(transCodeStrorageId);
                if(StorageTypeEnum.QINIUYUN.getDbValue() ==  storage.getType().getDbValue()){
                    plat = 1; // 七牛转码
                }
                task.setPlat(plat);

                JSONObject logoInfo = customSpInfoService.getLogoUrl(customSpInfoModel.getSpId());

                // 如果用户logo水印启用，并且存在logo图片时，处理logo图片地址格式为/{bucket}/{object_name}
                if (logoSite != null && -1 != logoSite.intValue()) {
                    if (logoStatus != null
                            && Const.LOGOSTATUS_ON.intValue() == logoStatus.intValue()
                            && logoInfo != null && logoInfo.size() > 0) {
                        if(1 == plat.intValue()) {
                            task.setLogoPicUrl(logoInfo.getString("domain") + Const.SEPARATE_XIE +logoInfo.getString("path"));
                        }else {
                            task.setLogoPicUrl(Const.SEPARATE_XIE + logoInfo.getString("bucket") +Const.SEPARATE_XIE + logoInfo.getString("path"));
                        }
                        task.setLogoSite(logoSite);
                    }
                }

                JSONObject ptpwInfo = customSpInfoService.getPtPw(customSpInfoModel.getSpId());
                //处理片头片尾
                if(ptpwState != null && ptpwState.intValue() == 1){
                    String startUrl = ptpwInfo.getString("pt");
                    String endUrl =  ptpwInfo.getString("pw");
                    String ptpwBucketName = ptpwInfo.getString("bucket");
                    task.setHeadFile(StringUtils.isNotBlank(startUrl) ? Const.SEPARATE_XIE + ptpwBucketName +Const.SEPARATE_XIE + startUrl : "");
                    task.setEndFile(StringUtils.isNotBlank(endUrl) ? Const.SEPARATE_XIE + ptpwBucketName +Const.SEPARATE_XIE + endUrl : "");
                }

                transcodeTaskService.create(task);

                OptionLogInfo logInfo = new OptionLogInfo(OptionType.INSERT, customId, customModel.getContacts(), "上传/创建视频",
                        customModel.getSpId(), videoModel.getBusinessUUID(), videoName);
                optionLogInfoService.create(logInfo);

                return JsonResult.createSuccessInstance("");
            } else {
                _log.debug("pendingTranscodeTask, videoId invalid! videoId:" + videoId + ",cur_customId:" + customId);
                return JsonResult.createErrorInstance(("视频") + "videoId" + ("参数无效"));
            }
        } catch (Exception ex) {
            _log.error("pendingTranscodeTask error ,ex={},msg = {}", ex, ex.getMessage());
            return JsonResult.createErrorInstance("上传视频回调失败");
        }
    }

    /**
     * 上传删除接口
     *
     * @param videoId
     * @param request
     * @param response
     */
    @RequestMapping(value = "/uploadRemove", method = RequestMethod.POST)
    @ResponseBody
    // @LogAnnotation(message = "上传视频过程中操作删除或者离开上传页面",type = OptionType.DELETE)
    public JsonResult uploadRemove(Long videoId, HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        try {
            if (videoId == null) {
                return JsonResult.createErrorInstance(("视频") + "videoId" + ("参数缺失"));
            }
            Long customId = this.getCustomId(request);
//			if (customId.longValue() == Const.CUSTOMID_DEFAULT_VAL.longValue()) {
//				return JsonResult.createErrorInstance("用户登录超时");
//			}
            VideoModel videoModel = videoService.getById(videoId);
            if (videoModel != null) {
//				CustomModel customModel = customService.getById(customId);
//				OptionLogInfo logInfo = new OptionLogInfo(OptionType.DELETE, customId, customModel.getContacts(),
//						"上传过程中删除视频", customModel.getSpId(), videoModel.getBusinessUUID(), videoModel.getVideoName());
//				optionLogInfoService.create(logInfo);
                // 创建删除任务
                // videoRemoveService.removeVideo(videoId,videoModel.getVideoName(),customId,customModel.getSpId(),videoModel.getCustomId(),"上传失败删除");

                // XXX:目前仅限制删除自己的视频，如果允许删除子帐号视频或逻辑修改，需修改此处。20170321 wangchaojie
//				if (videoModel.getCustomId().longValue() != customId.longValue()) {
//					_log.warn("uploadRemove! videoId:" + videoId + ",video_customId:" + videoModel.getCustomId()
//							+ ",cur_customId:" + customId);
//					return JsonResult.createErrorInstance("用户无权限删除此视频");
//				}
                videoService.deleteVideo(videoId);//包含删除file

            } else {
                return JsonResult.createErrorInstance(("视频") + "videoId" + ("参数无效"));
            }
        } catch (Exception ex) {
            _log.error("上传删除接口调用错误,videoId={} , errorinfo = {}", videoId, ex);
        }
        return JsonResult.createSuccessInstance("删除完成");
    }

    /**
     * @Description: 上线
     * @param: videoId
     */
    @RequestMapping("/onlinestatus")
    @ResponseBody
    // @LogAnnotation(message = "操作视频上线",type = OptionType.UPDATE)
    public JsonResult onlineStatus(HttpServletRequest request, String videoId) throws Exception {
        if (StringUtils.isEmpty(videoId)) {
            return JsonResult.createErrorInstance(("视频") + "ID" + ("参数缺失"));
        }

        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if (!checkCustomerExist.isSuccess()) {
            return checkCustomerExist;
        }
        CustomModel customModel = (CustomModel) checkCustomerExist.getObj();

        onOffVideo(videoId, customModel, ModelStatus.OnLine);
        return JsonResult.createSuccessInstance(null);
    }

    /**
     * @Description: 下线
     * @param: videoId
     */
    @RequestMapping("/downlinestatus")
    @ResponseBody
    // @LogAnnotation(message = "操作视频下线",type = OptionType.UPDATE)
    public JsonResult downlineStatus(HttpServletRequest request, String videoId) throws Exception {
        if (StringUtils.isEmpty(videoId)) {
            return JsonResult.createErrorInstance(("视频") + "ID" + ("参数缺失"));
        }
        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if (!checkCustomerExist.isSuccess()) {
            return checkCustomerExist;
        }
        CustomModel customModel = (CustomModel) checkCustomerExist.getObj();
        onOffVideo(videoId, customModel, ModelStatus.OffLine);
        return JsonResult.createSuccessInstance(null);
    }

    private void onOffVideo(String videoIds, CustomModel customModel, ModelStatus status) {
        List<String> videoIdArray = Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().splitToList(videoIds);
        for (String videostr : videoIdArray) {
            VideoModel video = videoService.getById(Long.valueOf(videostr));
            if (video != null) {
                String videoName = video.getVideoName();
                String cmsPlayPage = video.getVideoPlyUrl();
                OptionLogInfo logInfo = null;
                VideoModel upate = new VideoModel();
                upate.setBusinessUUID(video.getBusinessUUID());
                upate.setSpid(customModel.getSpId());
                upate.setVideoId(video.getVideoId());
                upate.setStatus(status);
                upate.setUpdateTime(new Date());
                upate.setUpdateUserId(customModel.getCustomId());
                upate.setCustomId(video.getCustomId());
                upate.setFileStatus(video.getFileStatus());
                video = videoService.modify(upate);
                if (ModelStatus.OnLine.getDbValue() == status.getDbValue()) {
                    remoteService.remoteDianBoPlay(video.getVideoId(), ModelStatus.OnLine);
                    logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(), customModel.getContacts(), "上线视频", video.getSpid(),
                            video.getBusinessUUID(), videoName);
                }
                if (ModelStatus.OffLine.getDbValue() == status.getDbValue()) {
                    if (StringUtils.isNotBlank(cmsPlayPage)) {
                        remoteService.remoteCmsOffLine(video.getBusinessUUID(), video.getSpid());
                    }
                    remoteService.remoteDianBoPlay(video.getVideoId(), ModelStatus.OffLine);
                    logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(), customModel.getContacts(), "下线视频", video.getSpid(),
                            video.getBusinessUUID(), videoName);
                }
                optionLogInfoService.create(logInfo);
            }
        }
    }

    /**
     * @Title: getAuditMessage
     * @Description: 获取审核信息
     */
    @RequestMapping("/getAuditMessage")
    @ResponseBody
    public JsonResult getAuditMessage(String videoId) {
        JsonResult result = new JsonResult();
        VideoAuditCondition condition = new VideoAuditCondition();
        condition.setVideoId(Long.parseLong(videoId));
        List<VideoAuditModel> list = videoAuditService.getVideoAuditInfoByCondition(condition);
        result.setObj(list);
        result.setSuccess(true);
        return result;
    }

    /**
     * @Description:重转码
     */
    @RequestMapping("/reTransCode")
    @ResponseBody
    // @LogAnnotation(message = "操作视频重新转码",type = OptionType.UPDATE)
    public JsonResult reTransCode(HttpServletRequest request, String videoId, String codeRate, String transCodeFmt) {

        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if (!checkCustomerExist.isSuccess()) {
            return checkCustomerExist;
        }
        CustomModel customModel = (CustomModel) checkCustomerExist.getObj();
        String codeRates = "";
        List<FileModel> fileModelList = new ArrayList<>();
        try {
            if (StringUtils.isBlank(codeRate)) {
                fileModelList = fileService.getByVid(Long.valueOf(videoId));
                for (int i = 0; i < fileModelList.size(); i++) {
                    FileModel fileModel = fileModelList.get(i);
                    if (fileModel.getStatus() != null
                            && FileStatus.TranscodingFail.getDbValue() == fileModel.getStatus().getDbValue()) {
                        if (fileModel.getCodeRate() != null) {
                            codeRates = Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(fileModel.getCodeRate(),
                                    codeRates);
                            if (StringUtils.isNotBlank(codeRates) && codeRates.startsWith(Const.VALUE_DECOLLATOR)) {
                                codeRates = codeRates.substring(1, codeRates.length());
                            }
                        }
                    }
                }
            } else {
                codeRates = codeRate;
            }

            boolean isTransCode = videoService.createTranscodeTask(Long.valueOf(videoId), codeRates, transCodeFmt,
                    customModel.getCustomId(),customModel.getSpId());
            if (isTransCode) {
                VideoModel videoModel = videoService.getById(Long.valueOf(videoId));
                FileStatus fileStatus = videoService.transcodeSuccessCheck(Long.valueOf(videoId));

                if (FileStatus.TranscodingFail.getDbValue() == fileStatus.getDbValue()) {
                    VideoModel update = new VideoModel();
                    update.setVideoId(videoModel.getVideoId());
                    update.setUpdateTime(new Date());
                    update.setFileStatus(FileStatus.TranscodingIng);// 把视频表状态改成转码中
                    update.setUpdateUserId(customModel.getCustomId());
                    update.setCustomId(videoModel.getCustomId());
                    videoService.modify(update);
                }
                if (StringUtils.isNotBlank(codeRate) && StringUtils.isNotBlank(transCodeFmt)) {
                    FileModel fileModel = fileService.getFileByVidAndCoderateAndTransCodeFmt(Long.valueOf(videoId),
                            Integer.valueOf(codeRate), transCodeFmt);
                    fileModelList.add(fileModel);
                }
                for (int i = 0; i < fileModelList.size(); i++) {
                    FileModel fileModel = fileModelList.get(i);
                    if (fileModel != null && fileModel.getStatus() != null) {
                        fileModel.setStatus(FileStatus.TranscodingIng);
                        fileService.modify(fileModel);// 把file表状态改成转码中
                    }
                }

                OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(),
                        customModel.getContacts(), "视频重新转码", videoModel.getSpid(), videoModel.getBusinessUUID(),
                        videoModel.getVideoName());
                optionLogInfoService.create(logInfo);

                return JsonResult.createSuccessInstance(null);
            }
            return JsonResult.createErrorInstance("重转码失败");
        } catch (Exception e) {
            _log.error("重转码失败,videoId={}", videoId, e);
            return JsonResult.createErrorInstance("重转码失败");
        }
    }

    /**
     * @Description:重抽帧
     */
    @RequestMapping("/reloadChouzhen")
    @ResponseBody
    // @LogAnnotation(message = "操作视频重新抽帧",type = OptionType.UPDATE)
    public JsonResult reloadChouzhen(HttpServletRequest request, String bussinessId) {

        JsonResult checkResult = checkCustomerExist(request);
        if (!checkResult.isSuccess()) {
            return JsonResult.createErrorInstance("客户认证失败，请重新登录");
        }
        CustomModel customModel = (CustomModel) checkResult.getObj();
        CustomSpInfoModel spInfo = customSpInfoService.getBySpId(customModel.getSpId());


        VideoModel videoModel = videoService.getByBusinessUUID(bussinessId);
        if(videoModel == null){
            return JsonResult.createErrorInstance("视频不存在！");
        }
        String originUri = "";
        List<FileModel> fileModels = fileService.getByVid(videoModel.getVideoId());
        if (fileModels.size() > 0) {
            originUri = fileModels.get(0).getOriginUri();
        }

        Integer plat = 0;
        String domain = "";

        Integer storageId = videoModel.getStorageId();
        StorageModel storage = storageService.getById(storageId);
        if(StorageTypeEnum.QINIUYUN.getDbValue()  == storage.getType().getDbValue()){
            plat = 1;
            domain = storageService.getDomainSimpleOutByStorageId(storageId);
        }
        VideoModel updateVideo = new VideoModel();
        String chouzhenTaskId = remoteService.remoteChouZhen(originUri, videoModel.getSpid().toString(), "POST",
                transOverCallUrl, storage.getName(),plat,domain);
        if (StringUtils.isNotBlank(chouzhenTaskId)) {
            updateVideo.setVideoId(videoModel.getVideoId());
            updateVideo.setUpdateTime(new Date());
            updateVideo.setChouzhenTaskId(chouzhenTaskId);
            updateVideo.setChouzhenBtime(new Date());
            updateVideo.setUpdateUserId(customModel.getCustomId());
            updateVideo.setCustomId(videoModel.getCustomId());
            videoService.save(updateVideo);

            OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(),
                    customModel.getContacts(), "视频重新抽帧", videoModel.getSpid(), videoModel.getBusinessUUID(),
                    videoModel.getVideoName());
            optionLogInfoService.create(logInfo);

            return JsonResult.createSuccessInstance(null);
        }
        return JsonResult.createErrorInstance("发送抽帧任务失败，请重试");
    }

    /**
     * 获取转码失败的信息
     *
     * @param request
     * @param bussinessId
     * @param videoId
     * @return
     */
    @RequestMapping("/showTranCodeFaildInfo")
    @ResponseBody
    // @LogAnnotation(message = "查看视频转码失败信息",type = OptionType.SELECT)
    public JsonResult showTranCodeFaildInfo(HttpServletRequest request, String bussinessId, Long videoId) {

        checkCustomerExist(request);
        List<FileModel> fileModels = fileService.getByVid(videoId);
        if (fileModels != null && fileModels.size() > 0) {
            for (FileModel file : fileModels) {
                file.setTransCodeFailMsg(fileService.getTranscodeErrorShowMsg(file.getFileId(), file.getTaskId()));
                file.setCodeRateName(DefinitionEnum.getShowName(file.getCodeRate()));
            }
        }
        return JsonResult.createSuccessInstance(fileModels);
    }

    /**
     * @Description:重抽帧
     */
    @RequestMapping("/refreshChouzhen")
    @ResponseBody
    // @LogAnnotation(message = "刷新视频抽帧信息",type = OptionType.SELECT)
    public JsonResult refreshChouzhen(HttpServletRequest request, String bussinessId, String picUrl) {

        VideoModel videoModel = videoService.getByBusinessUUID(bussinessId);
        if(videoModel == null){
            return JsonResult.createErrorInstance("视频不存在！");
        }
        if (picUrl.equals(videoModel.getPicOriginal())) {
            return JsonResult.createErrorInstance("抽帧未完成，请稍等！");
        } else {
            Map<String, String> resultmap = new HashMap<>();
            resultmap.put("picOriginal", videoModel.getPicOriginDomain());
            resultmap.put("storageType",String.valueOf(videoModel.getStorageType()));
            Date bt = videoModel.getChouzhenBtime(), et = videoModel.getChouzhenEtime();
            String haoshi = "";
            if (bt != null && et != null) {
                haoshi = CalendarUtil.dateBetween(bt, et);
            }
            resultmap.put("haoshi", haoshi);
            return JsonResult.createSuccessInstance("", resultmap);
        }
    }

    @RequestMapping("/saveVidUploadId")
    @ResponseBody
    public JsonResult saveVidUploadId(HttpServletRequest request, String uploadId, String vid) {
        try {
            JsonResult result = this.checkCustomerExist(request);
            CustomModel customModel = (CustomModel) result.getObj();

            Long videoId = CommonUtil.parseNumber("vid", vid).longValue();
            Long customId = customModel.getCustomId();

            VideoModel video = videoService.getById(videoId);
            if (video != null) {
                VideoModel update = new VideoModel();
                update.setVideoId(videoId);
                update.setUploadId(uploadId);
                update.setUpdateTime(new Date());
                update.setUpdateUserId(customId);
                videoService.save(update);
            } else {
                _log.error("保存uploadid 系统异常，uploadid={},vid={}", uploadId, vid);
                return JsonResult.createErrorInstance("保存失败，视频不存在");
            }
            return JsonResult.createSuccessInstance("success");
        } catch (Exception EX) {
            _log.error("保存uploadid 系统异常，uploadid={},vid={}", uploadId, vid);
            return JsonResult.createErrorInstance("保存失败");
        }
    }

    @RequestMapping("/getUploadHs")
    @ResponseBody
    // @LogAnnotation(message = "查看视频上传耗时",type = OptionType.SELECT)
    public JsonResult getUploadHaoShi(HttpServletRequest request, Long videoId) {
        try {
            if (videoId == null) {
                return JsonResult.createErrorInstance("未获取到查询的参数");
            }

            VideoModel videoModel = videoService.getById(videoId);
            if (videoModel == null) {
                _log.error("查询上传耗时未获取到视频信息，videoId  = {}", videoId);
                return JsonResult.createErrorInstance("未查询到相关视频");
            }
            Map<String, Object> result = new HashMap<>();
            result.put("vBussinessId", videoModel.getBusinessUUID());
            result.put("uploadId", videoModel.getUploadId());
            Date bt = videoModel.getUploadBtime();
            Date et = videoModel.getUploadEtime();
            if (bt != null && et != null) {
                result.put("bt", CalendarUtil.getDefaultDateString(bt));
                result.put("et", CalendarUtil.getDefaultDateString(et));
                result.put("hst", CalendarUtil.dateBetween(bt, et));
            }
            return JsonResult.createSuccessInstance("", result);
        } catch (Exception ex) {
            _log.error("获取上传耗时失败，videoId = {} ", videoId);
            return JsonResult.createErrorInstance("获取上传耗时失败，请重试！");
        }
    }

    @RequestMapping("/transcodeHaoShiView")
    @ResponseBody
    // @LogAnnotation(message = "查看视频转码耗时",type = OptionType.SELECT)
    public JsonResult transcodeHaoShiView(HttpServletRequest request, Long videoId) {
        try {
            if (videoId == null) {
                return JsonResult.createErrorInstance("未获取到查询的参数");
            }
            List<FileModel> fileModels = fileService.getByVid(videoId);
            if (fileModels != null && fileModels.size() > 0) {
                for (FileModel file : fileModels) {
                    file.setCodeRateName(DefinitionEnum.getShowName(file.getCodeRate()));
                    Date bt = file.getTranscodeBtime();
                    Date et = file.getTranscodeEtime();
                    if (bt != null && et != null) {
                        file.setTranscodeHaoshi(CalendarUtil.dateBetween(bt, et));
                    }
                }
            }
            return JsonResult.createSuccessInstance(fileModels);
        } catch (Exception ex) {
            _log.error("获取转码耗时失败，videoId = {} ", videoId);
            return JsonResult.createErrorInstance("获取转码耗时失败，请重试！");
        }
    }

    @RequestMapping("/chouzhenHaoShiView")
    @ResponseBody
    // @LogAnnotation(message = "查看视频抽帧耗时",type = OptionType.SELECT)
    public JsonResult chouzhenHaoShiView(HttpServletRequest request, Long videoId) {
        try {
            if (videoId == null) {
                return JsonResult.createErrorInstance("未获取到查询的参数");
            }

            VideoModel videoModel = videoService.getById(videoId);
            if (videoModel == null) {
                _log.error("查询抽帧耗时未获取到视频信息，videoId  = {}", videoId);
                return JsonResult.createErrorInstance("未查询到相关视频");
            }
            Map<String, Object> result = new HashMap<>();
            result.put("vBussinessId", videoModel.getBusinessUUID());
            result.put("taskId", videoModel.getChouzhenTaskId());

            Date bt = videoModel.getChouzhenBtime();
            Date et = videoModel.getChouzhenEtime();
            if (bt != null && et != null) {
                result.put("bt", CalendarUtil.getDefaultDateString(bt));
                result.put("et", CalendarUtil.getDefaultDateString(et));
                result.put("hst", CalendarUtil.dateBetween(bt, et));
            }
            return JsonResult.createSuccessInstance("", result);
        } catch (Exception ex) {
            _log.error("获取抽帧耗时失败，videoId = {} ", videoId);
            return JsonResult.createErrorInstance("获取抽帧耗时失败，请重试！");
        }
    }

    @RequestMapping("/toVideoLog")
    public String toVideoLog(HttpServletRequest request) {
        return "/log/log_manager";
    }

    /**
     * 分页操作日志
     *
     * @param request
     * @param condition
     * @return
     */
    @RequestMapping(value = "/optionLogDataGrid", method = RequestMethod.GET)
    @ResponseBody
    public DataGrid optionLogDataGrid(HttpServletRequest request, LogInfoCondition condition) {
        try {
            Long spId = this.getSpId(request);
            Long customId = this.getCustomId(request);
            if (spId == 0 || customId == 0) {
                return new DataGrid(0L, null);
            }
            condition.setSpId(spId);
            return optionLogInfoService.dataGrid(condition);
        } catch (Exception ex) {
            _log.error("查询日志出错，ex={}", ex);
            return new DataGrid(0L, null);
        }
    }

    @RequestMapping(value = "/getOptionLogByVid", method = RequestMethod.GET)
    @ResponseBody
    public JsonResult getOptionLogByVid(HttpServletRequest request, String videoBusinessId) {
        try {

            if (StringUtils.isBlank(videoBusinessId)) {
                return JsonResult.createSuccessInstance(null);
            }
            List<OptionLogInfo> byVideoBusinessId = optionLogInfoService.getByVideoBusinessId(videoBusinessId);
            return JsonResult.createSuccessInstance(byVideoBusinessId);

        } catch (Exception ex) {
            _log.error("根据视频id查询日志出错，videoBusinessId = {},ex={}", videoBusinessId, ex);
            return JsonResult.createErrorInstance("系统异常，请稍后重试");
        }
    }


    @RequestMapping(value = "/getQNToken", method = RequestMethod.GET)
    @ResponseBody
    public String getQNToken(HttpServletRequest request) {
       return getTokenForQN(bucket_qiniu_default);
    }
}
