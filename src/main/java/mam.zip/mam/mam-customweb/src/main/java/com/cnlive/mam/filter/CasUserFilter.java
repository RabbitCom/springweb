package com.cnlive.mam.filter;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.model.SpExpModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.CustomSpInfoService;
import com.cnlive.mam.service.SpExpService;
import com.cnlive.mam.service.StorageService;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 获取单点登录用户信息，添加至session并保存到客户表中
 */
public class CasUserFilter implements Filter {

    public void destroy() {
    }
      
    public void init(FilterConfig config) throws ServletException {
    }
      
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
    	HttpServletRequest req = (HttpServletRequest)request;
    	HttpServletResponse resp = (HttpServletResponse) response;  
    	HttpSession session = req.getSession();
    	Map<String,String> userMap = new HashMap<String,String>();
        
        PrincipalCollection principalCollection = SecurityUtils.getSubject().getPrincipals();
        if (principalCollection != null) {        
		      List principals = principalCollection.asList();
		      if(principals != null && principals.size() > 0) {
		    	  if(principals.size() > 0) {
		    		  userMap.put("principal", principals.get(0).toString());
		    	  }
		    	  if(principals.size() > 1) {
		    		  Map<String,String> attributes = (Map<String,String>) principals.get(1);
		    		  userMap.putAll(attributes);
		    		  
		    		  String perm = String.valueOf(userMap.get("perm"));
		    		  String perms[] = perm.split(Const.VALUE_DECOLLATOR);
		    		  //存在点播云系统进入权限时，保存用户数据并将大网id和username添加至session
		    		  if(ArrayUtils.contains(perms, Const.PERM_DIANBO)){
		    			  String usernames = (String) session.getAttribute("usernames");
		    			  //存在用户数据session时，结束过滤器
		    			  if(StringUtils.isNotEmpty(usernames)){
		    				  chain.doFilter(request, response);
		    				  return;
		    			  }
		    			  //获取用户信息，并保存至客户表中
		    			  saveCustom(session, userMap);
		    		  //无点播云权限时，跳转到无权限提示页面,具体页面后续处理
		    		  }else{
		    			  resp.sendRedirect("http://console.open.cnlive.com/open/401");
		    			  return;
		    		  }
		    	  }
		      }
	    }
        chain.doFilter(request, response);
    }

	/**
	  * 根据单点登录获取用户信息，并保存至客户表中。</br>
	  * @param session
	  * @param userMap 用户信息
	 * @throws IOException 
	  * 
	 */
	@SuppressWarnings("unchecked")
	private void saveCustom(HttpSession session, Map<String, String> userMap) throws IOException {
		ApplicationContext ac =  
                WebApplicationContextUtils.getWebApplicationContext(session.getServletContext());  
		CustomService customService = (CustomService)ac.getBean("customService");
		CustomSpInfoService customSpInfoService = (CustomSpInfoService)ac.getBean("customSpInfoService");
		StorageService storageService = (StorageService)ac.getBean("storageService");
		SpExpService spExpService = (SpExpService)ac.getBean("spExpService");
		Map<String,String> configProperties = ac.getBean("configProperties",Map.class);

		//获取并处理客户基本信息
		String parentid = userMap.get("parent_id");
		String mobile = userMap.get("mobile");
		String contacts = new String(userMap.get("contacts").getBytes(),"utf-8");
		String username = userMap.get("username");
		String newSpId = userMap.get("new_sp_id");
		String statusStr = userMap.get("status");
		String customIdStr = userMap.get("principal");
		String institutionId = userMap.get("institution_id");
		String institutionName = userMap.get("institution_name");

		boolean parentFlag = StringUtils.isEmpty(parentid);

		//添加联系人到session中key为username
		session.setAttribute("username", contacts);
		session.setAttribute("customId", customIdStr);
		session.setAttribute("spId", newSpId);
		session.setAttribute("parentId",parentFlag?Const.IS_PARENT_YES:Const.IS_PARENT_NO);
		session.setAttribute("institutionId",StringUtils.isEmpty(institutionId) ? "" :institutionId );
		session.setAttribute("institutionName",StringUtils.isEmpty(institutionName) ? "" :institutionName );
		Long customId = Long.parseLong(customIdStr);
		Integer status = Integer.parseInt(statusStr);
		CustomModel customModel = customService.getById(customId);
		Long spId = Long.parseLong(newSpId);
		//获取客户id信息，不存在时，将当前数据保存至数据库中
		if(customModel == null){
			int isParent = parentFlag?Const.IS_PARENT_YES:Const.IS_PARENT_NO;
			customModel = new CustomModel(customId,username,contacts,status,mobile);
			customModel.setSpId(spId);
			customModel.setIsParent(isParent);
			customModel.setInstitutionName(institutionName);
			customModel.setInstitutionId(institutionId);
			customService.create(customModel);
		}

		List<StorageModel> storageList = storageService.getStorageAllBySpid(spId);
		if (storageList == null || storageList.size() == 0) {
			storageService.insertDefaultStorage(spId);
		}
		CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
		//当前spId对应的配置信息不存在，将sp信息初始至sp信息表中。
		//XXX 此处为初始化sp信息，同一个sp第一次登录时只初始化一次
		if(customSpInfoModel == null){
			customSpInfoModel = new CustomSpInfoModel();
			customSpInfoModel.setSpId(spId);
			customSpInfoModel.setCodeRate(Const.SD);
			customSpInfoModel.setLogoStatus(Const.LOGOSTATUS_ON);
			customSpInfoModel.setLogoSite(Const.LOGOSITE_DEFAULT);
			customSpInfoModel.setAutoAudit(Const.AUTOAUDIT_NO);
			customSpInfoModel.setAutoPublish(Const.AUTOPUBLISH_NO);
			customSpInfoModel.setAutoOnlie(Const.AUTOONLIE_NO);
			customSpInfoModel.setIsStartCategory(Const.IS_START_CATEGORY_YES.intValue());
			customSpInfoModel.setCreateTime(new Date());
			customSpInfoModel.setCreateUserId(customId);
			customSpInfoService.create(customSpInfoModel);

			//保存默认的扩展信息
			StorageModel picStorage = storageService.getStorageInBySpId(spId, StorageContentTypeEnum.Picture);
			String logopicurlDefault = configProperties.get("logopicurl_default");
			SpExpModel spExpModel = new SpExpModel();
			spExpModel.setLogUrl(logopicurlDefault);
			spExpModel.setSpId(spId);
			spExpModel.setCreateTime(new Date());
			spExpModel.setUpdateTime(new Date());
			spExpModel.setCreateUserId(customModel.getCustomId());
			spExpModel.setUpdateUserId(customModel.getCustomId());
			spExpModel.setStorageType(picStorage.getType());
			spExpModel.setSpExpContentType(1);
			spExpModel.setStorageId(picStorage.getId());
			spExpService.create(spExpModel);

		}
	}
}