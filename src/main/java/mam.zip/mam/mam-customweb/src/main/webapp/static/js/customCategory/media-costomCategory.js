/*	alert("中间钱");
	$.fn.zTree.init();
	alert("中间hou");*/
	var treeEdit =null;//提交修改前选中节点
	var isEdit = false;
	var editRow = null;
	var editTemp = null;
	var currPage = 1;
	var leftTree = null;
	var customCategoryId = null;
	$(function() {
		// 添加 
		$("#save").click(function() {
			if (currPage != 1) {
				$("#maintable").bootstrapTable("selectPage", 1);
			}
			var nodes = leftTree.getCheckedNodes(true);
			var icmsId = nodes[0].id;
			var icmsName = nodes[0].title;
			var icmsPid = nodes[0].pid;
			var icmsColumnId = nodes[0].columnId;
			var datas = {"customCategoryId":customCategoryId,"icmsCategoryId":icmsId,"icmsCategoryName":icmsName};
			var obj = {};
			obj.customCategoryId = customCategoryId;
			obj.icmsCategoryId = icmsId;
			obj.icmsCategoryName = icmsName;
			obj.MAM_NodeID = icmsPid+"-"+icmsId;
			obj.MAM_NodeName = icmsPid+"-"+icmsId;
			obj.cms_column_id = icmsColumnId;
			obj.cms_column_name = icmsName;
			
			$.ajax({
		        type: 'post',
		        url: basePath +"customCategoryController/saveCategoryRef.do",
		        data: JSON.stringify(obj),
		        contentType: "application/json",
		        success: function (data) {
		        	$('#editorModal').modal('hide');
		        	categoryFn.getCommetList(url, 1, rows); //重新获取新数据
		           
		        },
		        error: function (msg) {
		            alert(" 数据加载失败！" + msg);
		        }
		    })
		});
		//关闭事件
		$("#editorModal").on("hide.bs.modal", function() {
			isEdit = false;
		});
		

	});
	function queryParamsFunctionMain(params) {
		return {
			pageSize : params.limit,
			pageNo : params.offset / params.limit + 1,
			spcolumn : params.search,
			spId:"82"
		};
	}

	function responseHandler(res) {
		return {
			"rows" : res.result,
			"total" : res.totalCount
		};
	}
	
	function isId(res){
        if(leftTree == null){
            $('#editorModal').modal('hide');
            alertfn.danger("未设置栏目获取地址");
        }else {
            $('#editorModal').modal('show');
            customCategoryId = res;
        }
	}


$(function(){
	InitTree();
});	
 function onClick(e, treeId, treeNode) {
    }
 function InitTree() {
    var setting = {
        async:{
    		autoParam: ["title","columnId"],
    		dataType: "json",
    		  enable: true
    	},
    	check:{
    		enable:true,
    		chkStyle: "radio",
    		radioType:"all"
    	},
        data: {
            key: {
                name:"title"
            },
            simpleData: {
                enable: true,
                idKey: "id",
                pIdKey: "pid",
                rootPId: 0,
                checked: true
            }
        },
        callback: {
            onClick: onClick
        }
    };
     $.post(basePath + "customCategoryController/getCustomColumnTree.do",
         function(data){
             var res = $.parseJSON(data);
             if(res.success){
                 leftTree = $.fn.zTree.init($("#lTree"), setting, JSON.parse(res.obj));
             }
     });
  }




/**
 * Created by zhaojing on 2015/11/06.
 */
//获取字符串的长度
var rel = /^[\w\u4e00-\u9fa5 +]{1,20}$/;
var url = basePath + "customCategoryController/dataGridNew.do";
var page = 1;
var rows = 10;
var categoryFn = {
    init: function() {
        this.addFenlei(); //添加分类
        this.addFenlei_son(); //添加子分类
        this.fenleiName(); //分类名称修改
        this.delFenlei(); //删除
        this.getCommetList(url, page, rows); //渲染数据
        this.arrowcheckbox(); //全选箭头
    },
    addFenlei: function() {
        //获取大分类category
        $.getJSON(
            basePath + "customCategoryController/getCategorys.do",
            function(data) {
                var system_channel = '';
                for (var i = 0; i < data.length; i++) {
                    var showName = data[i].showName;
                    var dicValue = data[i].dicValue;
                    system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
                }
                $("#modal-fenlei-add .fenlei-channel").attr("data-id", data[0].dicValue).html(system_channel);
                $(".systemCatagory").attr("data-id", '0').append(system_channel);
            }
        );
        //添加分类初始化
        $(".fenlei-channel").on("change", function() {
            var data_option_id = $(this).children('option:selected').attr("data-id");
            $(".fenlei-channel").attr("data-id", data_option_id);
        });
        //系统分类筛选
        $(".systemCatagory").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory").attr("data-id", categoryId);
            categoryFn.getCommetList(url, 1, rows);
        });
        //触发弹窗
        $(".btn-fenlei-add").click(function() {
            $("#fenlei").attr("data-dismiss", "");
            $("#error_show_msg").html("");
            $("#modal-fenlei-add .fenlei-name").val("");
        });
        //确定
        $("#fenlei").click(function() {
            var fenlei_name = $.trim($("#modal-fenlei-add .fenlei-name").val());
            var fenlei_channel = $("#modal-fenlei-add .fenlei-channel").attr("data-id");
            var fenlei_channel_val = $("#modal-fenlei-add .fenlei-channel").val();
            var obj = {};
            obj.customCategoryName = fenlei_name;
            obj.category = fenlei_channel;
            if (fenlei_name != "") {
                if (rel.test(fenlei_name) && categoryFn.chkstrlen(fenlei_name) <= 20) {
                    $(this).attr("data-dismiss", "modal");
                    $("#error_show_msg").html("");
                    $.ajax({
                        type: "post",
                        url: basePath + "customCategoryController/save.do",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                categoryFn.getCommetList(url, 1, rows); //重新获取新数据
                                alertfn.success(LCT("添加成功"));
                            } else {
                                var params = {
                                    "discription": data.msg,
                                    "iconType": "triangle",
                                    "confirmBtn": true
                                };
                                $("body").toolsalert(params);
                                return;
                            }
                        },
                        error: function() {
                            //console.log("fail");
                        }
                    });
                } else {
                    $("#error_show_msg").html(LCT("请输入由") + " 1-20 " + LCT("个字节，由中文，字母，数字，下划线组成的名称"));
                }
            } else {
                $("#error_show_msg").html(LCT("分类名称不能为空"));
            }
        });
    },
    addFenlei_son: function() {
        //添加子分类
        $(".media-upload-box").on("click", ".add-fenlei", function() {
            $(".add-fenlei").attr("id", "");
            $(this).attr("id", "cur-son-fenlei");
            if ($(this).hasClass("add-son-fenlei")) {
                $("#modal-fenlei-son-add").attr("flag", 1);
            } else if ($(this).hasClass("add-grandson-fenlei")) {
                $("#modal-fenlei-son-add").attr("flag", 1);
            }
            $("#fenlei_son").attr("data-dismiss", "");
            $("#error_show_msg_son").html("");
            $("#modal-fenlei-son-add .fenlei-name").val("");
        });
        $("#fenlei_son").click(function() {
            var $this = $("#cur-son-fenlei");
            var flag = $("#modal-fenlei-son-add").attr("flag");
            var cur_tr = $this.closest("tr");
            var pid = cur_tr.attr("data-id");
            var checked_falg = cur_tr.find("input").is(":checked") ? true : false;
            var cur_channel = cur_tr.find("td").eq(2).html();
            var son_fenlei_name = $.trim($("#modal-fenlei-son-add input:text").val());
            if (son_fenlei_name != "") {
                if (rel.test(son_fenlei_name) && categoryFn.chkstrlen(son_fenlei_name) <= 20) {
                    $(this).attr("data-dismiss", "modal");
                    $("#error_show_msg_son").html("");
                    var obj = {};
                    obj.customCategoryName = son_fenlei_name;
                    obj.parentCustomCategoryId = pid;
                    $.ajax({
                        type: "post",
                        url: basePath + "customCategoryController/save.do",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                var data_id = data.obj.customCategoryId;
                                if (flag == 1) {
                                    var cur_tbody = $this.closest(".le-text-xs");
                                    var sub_html = "";
                                    sub_html += '<tr><td class="second" colspan="7">';
                                    sub_html += '<table class="table table-default table-center break-allg">';
                                    sub_html += '<tbody>';
                                    sub_html += '<tr pid=' + pid + ' data-id=' + data_id + '>';
                                    if (checked_falg) {
                                        sub_html += '<td width="5%"><input del-flag="1" class="checkItem0" type="checkbox" checked></td>';
                                    } else {
                                        sub_html += '<td width="5%"><input del-flag="1" class="checkItem0" type="checkbox"></td>';
                                    }
                                    sub_html += '<td width="25%"><div class="col-xs-11 col-xs-offset-1 from-group-icon">';
                                    sub_html += '<input type="text"  old-value="' + son_fenlei_name + '" class="disable form-control" name="" value="' + son_fenlei_name + '" placeholder="">';
                                    sub_html += '<a href="javascript:void(0)" class="icon-link"><i class="icon-fenlei-child"></i></a>';
                                    sub_html += '</div></td>';
                                    sub_html += '<td width="15%">' + cur_channel + '</td>';
                                    sub_html += '<td width="10%">0</td>';
                                    sub_html += '<td width="10%">0</td>';
                                    sub_html += '<td width="10%">暂无</td>';
                                    sub_html += '<td width="25%">';
                                    sub_html += '<a class="btn btn-primary121"  onclick="isId('+data_id+')">设置对应栏目</a><a href="javascript:void(0)" class="delItem">' + LCT("删除") + '</a>';
                                    sub_html += '</td></tr>';
                                    sub_html += '</tbody></table>';
                                    sub_html += '</td></tr>';
                                    cur_tbody.append(sub_html);
                                    cur_tr.addClass("cur");
                                    cur_tr.closest(".le-text-xs").find("tr").show();
                                } 
                                alertfn.success(LCT("添加成功"));
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function() {
                            //console.log("fail");
                        }
                    });
                } else {
                    $("#error_show_msg_son").html(LCT("请输入由") + " 1-20 " + LCT("个字节，由中文，字母，数字，下划线组成的名称"));
                }
            } else {
                $("#error_show_msg_son").html(LCT("分类名称不能为空"));
            }
        });
    },
    fenleiName: function() {
        //文本框获得焦点，失去焦点的状态
        $("#maintable").on("focus", "input:text", function() {
            $(this).removeClass("disable");
        });
        $("#maintable").on("blur", "input:text", function() {
            $(this).addClass("disable");
        });
        //修改名称
        $("#maintable").on("change", "input:text", function() {
            if ($("#mask_layer").length == 0) {
                var $this = $(this);
                var old_value = $this.attr("old-value");
                var customCategoryId = $this.closest("tr").attr("data-id");
                var customCategoryName = $.trim($this.val());
                if (customCategoryName == "") {
                    var params = {
                        "discription": LCT("分类信息名称不能为空"),
                        "iconType": "triangle",
                        "confirmBtn": true,
                        "cancelBtn": false,
                        "confirmEvent": function() {
                            $this.val(old_value);
                        }
                    };
                    $("body").toolsalert(params);
                } else {
                    if (rel.test(customCategoryName) && categoryFn.chkstrlen(customCategoryName) <= 20) {
                        var obj = {};
                        $this.attr("old-value", $this.val());
                        obj.customCategoryId = customCategoryId;
                        obj.customCategoryName = customCategoryName;
                        $.ajax({
                            type: "post",
                            url: basePath + "customCategoryController/updateCustomCategoryName.do",
                            data: JSON.stringify(obj),
                            contentType: "application/json; charset=utf-8",
                            async: false,
                            dataType: "json",
                            success: function(data) {
                                if (data.success) {
                                    var params = {
                                        "discription": LCT("分类名称修改成功"),
                                        "iconType": "success",
                                        "confirmBtn": true
                                    };
                                    $("body").toolsalert(params);
                                } else {
                                    var params = {
                                        "discription": LCT("分类名称修改失败"),
                                        "iconType": "triangle",
                                        "confirmBtn": true
                                    };
                                    $("body").toolsalert(params);
                                }
                            },
                            error: function() {
                                //console.log("fail");
                            }
                        });
                    } else {
                        var params = {
                            //"discription": LCT("请输入由")+" 1-20 "+LCT("个字节，由中文，字母，数字，下划线组成的名称"),
                            "discription": LCT("请输入由1-20个字节，由中文，字母，数字，下划线组成的名称"),
                            "iconType": "triangle",
                            "confirmBtn": true,
                            "cancelBtn": false,
                            "confirmEvent": function() {
                                $this.val(old_value);
                            }
                        };
                        $("body").toolsalert(params);
                    }

                }
            }
        });
    },
    delFenlei: function() {
        //分类管理--单个删除
        $("#maintable").on("click", ".delItem", function() {
            var delids = "";
            ids = $(this).closest("tr").find("td:eq(1)").find("input").val();
            delids = $(this).closest("tr").attr("data-id");
            var params = {
                "title": LCT("删除"),
                "discription": LCT("确认删除如下分类") + '"' + ids + '"',
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function() {
                    $.ajax({
                        type: "get",
                        url: basePath + "customCategoryController/delCustomCategory.do?customCategoryIds=" + delids,
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                categoryFn.getCommetList(url, 1, rows);
                                alertfn.success(LCT("已成功删除分类") + ":" + ids);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function() {
                            //console.log("fail");
                        }
                    });
                }
            };
            $("body").toolsalert(params);
        });
        //分类管理--多个删除
        $("#delMulti").bind("click", function() {
            ids = "";
            var delids = "";
            var del_flag = [];
            var arr = $("#maintable .checkItem0:checked");
            if (arr.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("请先选中一条记录"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            }
            $(arr).each(function(i) {
                delids += $(arr).eq(i).closest("tr").attr("data-id") + ",";
                ids += $(arr).eq(i).closest("tr").find("td:eq(1)").find("input").val() + ",";
                del_flag.push($(arr).eq(i).attr("del-flag"));

            });
            if (unique(del_flag).length == 1 && unique(del_flag) == "1") {
                var params = {
                    "title": LCT("删除"),
                    "discription": LCT("是否批量删除选中分类"), //提示内容
                    "iconType": "triangle",
                    "confirmBtn": true,
                    "cancelBtn": true,
                    "confirmEvent": function() {
                        var arr = $("#maintable .checkItem0:checked");
                        $.ajax({
                            type: "get",
                            url: basePath + "customCategoryController/delCustomCategory.do?customCategoryIds=" + delids,
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function(data) {
                                if (data.success) {
                                    categoryFn.getCommetList(url, 1, rows);
                                    alertfn.success(LCT("已成功批量删除选中分类"));
                                } else {
                                    alertfn.danger(data.msg);
                                }
                            },
                            error: function() {
                                //console.log("fail");
                            }
                        });
                    }
                };
            } else {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("所选分类包含专辑或视频"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
            }
            $("body").toolsalert(params);
        });
    },
    pager: function(pageNum, pageTotal, url) {
        var dom = $(".ui-page");
        var html = "";
        dom.empty();
        if (pageTotal == 0 || pageTotal == 1) {
            html += '<p class="ui-fl txt">' + LCT("共") + '<span class="all"></span>' + LCT("条，每页") + LCT("显示") + '<span class="rows">' + rows + '</span>' + LCT("条") + '</p>';
        } else {
            html += '<p class="ui-fl txt">' + LCT("共") + '<span class="all"></span>' + LCT("条，每页显") + LCT("示") + '<span class="rows">' + rows + '</span>' + LCT("条") + '</p>';
        }

        if (pageNum > pageTotal) {
            return;
        }
        if (pageNum != 1) {
            html += "<a class='prev' href='#'><i class='ui-page-prev'></i></a>";
        }
        if (pageTotal < 7) {
            for (var i = 0; i < pageTotal; i++) {
                var j = i + 1;
                html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
            }
        } else if (pageTotal < 11) {
            if (pageNum < 6) {
                for (var i = 0; i < pageNum; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                var k = pageNum + 4 < pageTotal ? pageNum + 4 : pageTotal;
                for (var i = pageNum; i < k; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                html += "<span>......</span><a href='#' data-page='" + pageTotal + "'>" + pageTotal + "</a>";
            } else {
                html += "<a href='#' data-page='1'>1</a><span>......</span>";
                for (var i = pageNum - 5; i < pageTotal; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
            }
        } else {
            if (pageNum < 6) {
                for (var i = 0; i < pageNum; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                var k = pageNum + 4 < pageTotal ? pageNum + 4 : pageTotal;
                for (var i = pageNum; i < k; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                html += "<span>......</span><a href='#' data-page='" + pageTotal + "'>" + pageTotal + "</a>";
            } else if (pageNum + 4 < pageTotal) {
                html += "<a href='#' data-page='1'>1</a><span>......</span>";
                for (var i = pageNum - 5; i < pageNum; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                for (var i = pageNum; i < pageNum + 4; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                html += "<span>......</span><a href='#' data-page='" + pageTotal + "'>" + pageTotal + "</a>";
            } else {
                html += "<a href='#' data-page='1'>1</a><span>......</span>";
                for (var i = pageNum - 5; i < pageNum; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
                for (var i = pageNum; i < pageTotal; i++) {
                    var j = i + 1;
                    html += "<a href='#' data-page='" + j + "'>" + j + "</a>";
                }
            }
        }
        if (pageNum != pageTotal) {
            html += "<a class='next' href='#'><i class='ui-page-next'></i></a>";
        }
        dom.append(html);
        $("a[data-page='" + pageNum + "']").addClass("active");
    },
    chkstrlen: function(str) {
        var strlen = 0;
        for (var i = 0; i < str.length; i++) {
            if (str.charCodeAt(i) > 255)
                strlen += 2;
            else
                strlen++;
        }
        return strlen;
    },
    getCommetList: function(url, page, rows) {
        var category = $(".systemCatagory").attr("data-id");
        $.getJSON(
            url + "?page=" + page + "&rows=" + rows + "&category=" + category,
            function(data) {
                $("#maintable tbody").remove();
                var tbody_html = '';
                if (data.rows.length) {
                    for (var i = 0; i < data.rows.length; i++) {
                        var feilei_pid = data.rows[i].pid;
                        var feilei_id = data.rows[i].id;
                        var feilei_name = data.rows[i].text;
                        var feilei_categoryName = data.rows[i].categoryName;
                        var feilei_videoCount = data.rows[i].videoCount; //视频个数
                        var feilei_albumCount = data.rows[i].albumCount; //专辑个数
                        var feilei_categoryRelation = data.rows[i].categoryRelation;//对应cms栏目
                        tbody_html += '<tbody class="le-text-xs">';
                        tbody_html += '<tr data-id=' + feilei_id + ' pid=' + feilei_pid + '>';
                        if (feilei_videoCount == 0 && feilei_albumCount == 0) {
                            tbody_html += '<td><input del-flag="1" class="checkall_category checkItem0" type="checkbox"/></td>';
                        } else {
                            tbody_html += '<td><input del-flag="0" class="checkall_category checkItem0" type="checkbox"/></td>';
                        }
                        tbody_html += '<td><div class="col-xs-12 from-group-icon">';
                        tbody_html += '<input type="text" old-value="' + feilei_name + '" class="form-control disable" name="" value="' + feilei_name + '" placeholder="">';
                        tbody_html += '<a href="javascript:void(0)" class="icon-link"><i class="caret"></i></a>';
                        tbody_html += '</div></td>';
                        tbody_html += '<td>' + feilei_categoryName + '</td>';
                        tbody_html += '<td>' + feilei_videoCount + '</td>';
                        tbody_html += '<td>' + feilei_albumCount + '</td>';
                        tbody_html += '<td>' + feilei_categoryRelation + '</td>';
                        if (data.rows[i].children.length == 0 && (feilei_videoCount != 0 || feilei_albumCount != 0)) {
                            tbody_html += '<td><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].id+')">设置对应栏目</a></td>';
                        } else if (feilei_videoCount == 0 && feilei_albumCount == 0) {
                            tbody_html += '<td><a href="javascript:void(0)" data-toggle="modal" data-target="#modal-fenlei-son-add" class="add-fenlei add-son-fenlei mr-20">' + LCT("添加子分类") + '</a><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].id+')">设置对应栏目</a>' + '<a href="javascript:void(0)" class="delItem">' + LCT("删除") + '</a></td>';
                        } else {
                            tbody_html += '<td><a href="javascript:void(0)" data-toggle="modal" data-target="#modal-fenlei-son-add" class="add-fenlei add-son-fenlei mr-20">' + LCT("添加子分类") + '</a><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].id+')">设置对应栏目</a></td>';
                        }
                        tbody_html += '</tr>';
                        for (var j = 0; j < data.rows[i].children.length; j++) {
                            var sub_feilei_id = data.rows[i].children[j].id;
                            var sub_feilei_pid = data.rows[i].children[j].pid;
                            var sub_feilei_name = data.rows[i].children[j].text;
                            var sub_feilei_categoryName = data.rows[i].children[j].categoryName;
                            var sub_feilei_videoCount = data.rows[i].children[j].videoCount;
                            var sub_feilei_albumCount = data.rows[i].children[j].albumCount;
                            var sub_feilei_categoryRelation = data.rows[i].children[j].categoryRelation;
                            tbody_html += '<tr><td class="second" colspan="7"><table class="table table-default table-center break-allg">';
                            tbody_html += '<tr data-id=' + sub_feilei_id + ' pid=' + sub_feilei_pid + '>';
                            if (sub_feilei_videoCount == 0 && sub_feilei_albumCount == 0) {
                                tbody_html += '<td width="5%"><input del-flag="1" class="checkItem0" type="checkbox"/></td>';
                            } else {
                                tbody_html += '<td width="5%"><input del-flag="0" class="checkItem0" type="checkbox"/></td>';
                            }
                            tbody_html += '<td width="25%"><div class="col-xs-11 col-xs-offset-1 from-group-icon">';
                            tbody_html += '<input type="text" old-value="' + sub_feilei_name + '" class="form-control disable" name="" value="' + sub_feilei_name + '" placeholder="">';
                            tbody_html += '<a href="javascript:void(0)" class="icon-link"><i class="icon-fenlei-child"></i></a>';
                            tbody_html += '</div></td>';
                            tbody_html += '<td width="15%">' + sub_feilei_categoryName + '</td>';
                            tbody_html += '<td width="10%">' + sub_feilei_videoCount + '</td>';
                            tbody_html += '<td width="10%">' + sub_feilei_albumCount + '</td>';
                            if(sub_feilei_categoryRelation != null || sub_feilei_categoryRelation != ""){
                            	tbody_html += '<td width="10%">' + sub_feilei_categoryRelation + '</td>';
                            }else{
                            	tbody_html += '<td width="10%">暂无</td>';
                            }
                            
                            if (data.rows[i].children[j].children.length == 0 && (sub_feilei_videoCount != 0 || sub_feilei_albumCount != 0)) {
                                tbody_html += '<td width="25%"><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].children[j].id+')">设置对应栏目</a></td>';
                            } else if (sub_feilei_videoCount == 0 && sub_feilei_albumCount == 0) {
                                tbody_html += '<td width="25%"><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].children[j].id+')">设置对应栏目</a><a href="javascript:void(0)" class="delItem">' + LCT("删除") + '</a></td>';
                            } else {
                                tbody_html += '<td width="25%"><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].children[j].id+')">设置对应栏目</a></td>';
                            }
                            tbody_html += ' </tr>';
                            if (data.rows[i].children[j].children.length) {
                                tbody_html += '<tr><td class="second" colspan="7">';
                                tbody_html += '<table class="table table-default table-center break-allg">';
                                for (k = 0; k < data.rows[i].children[j].children.length; k++) {
                                    var third_feilei_id = data.rows[i].children[j].children[k].id;
                                    var third_feilei_pid = data.rows[i].children[j].children[k].pid;
                                    var third_feilei_name = data.rows[i].children[j].children[k].text;
                                    var third_feilei_categoryName = data.rows[i].children[j].children[k].categoryName;
                                    var third_feilei_videoCount = data.rows[i].children[j].children[k].videoCount;
                                    var third_feilei_albumCount = data.rows[i].children[j].children[k].albumCount;
                                    tbody_html += '<tr data-id=' + third_feilei_id + ' pid=' + third_feilei_pid + '>';
                                    if (third_feilei_videoCount == 0 && third_feilei_albumCount == 0) {
                                        tbody_html += '<td width="5%"><input del-flag="1" class="checkItem0" type="checkbox"/></td>';
                                    } else {
                                        tbody_html += '<td width="5%"><input del-flag="0" class="checkItem0" type="checkbox"/></td>';
                                    }
                                    tbody_html += '<td width="30%"><div class="col-xs-10 col-xs-offset-2 from-group-icon">';
                                    tbody_html += '<input type="text" old-value="' + third_feilei_name + '" class="form-control disable" name="" value="' + third_feilei_name + '" placeholder="">';
                                    tbody_html += '<a href="javascript:void(0)" class="icon-link"><i class="icon-fenlei-child"></i></a>';
                                    tbody_html += '</div></td>';
                                    tbody_html += '<td width="20%">' + third_feilei_categoryName + '</td>';
                                    tbody_html += '<td width="10%">' + third_feilei_videoCount + '</td>';
                                    tbody_html += '<td width="10%">' + third_feilei_albumCount + '</td>';
                                    if (third_feilei_videoCount == 0 && third_feilei_albumCount == 0) {
                                        tbody_html += '<td width="35%"><a href="javascript:void(0)" class="btn btn-primary121" onclick="isId('+data.rows[i].children[j].children[k].id+')">设置对应栏目</a><a href="javascript:void(0)" class="delItem">' + LCT("删除") + '</a></td>';
                                    } else {
                                        tbody_html += '<td width="35%"></td>';
                                    }
                                    tbody_html += '</tr>';
                                }
                                tbody_html += '</table>';
                                tbody_html += '</td></tr>';
                            }
                            tbody_html += '</table>';
                            tbody_html += '</td></tr>';
                        }
                        tbody_html += '</tbody>';
                    }
                } else {
                    tbody_html += '<tbody>';
                    tbody_html += '<tr>';
                    tbody_html += '<td colspan="7"><i class="caret hide"></i>' + LCT("该数据分类下暂无自定义分类") + '</td>';
                    tbody_html += '</tr>';
                    tbody_html += '</tbody>';
                }
                $("#maintable").append(tbody_html);
                categoryFn.pager(page, Math.ceil(data.total / rows));
                $(".all").text(data.total);
                $(".rows").text(rows);
                $(".media-upload-box tbody tr").has("i.caret").show();
            }
        );
    },
    arrowcheckbox: function() {
        //按组全选
        $("#maintable").on("click", ".checkItem0", function() {
            var $this = $(this);
            var cur_tr = $this.closest("tr");
            var cur_tbody = $this.closest("tbody");
            var length1 = cur_tr.find(".col-xs-offset-1").length;
            var length2 = cur_tr.find(".col-xs-offset-2").length;
            if (length2 == 0 && length1 == 0) {
                if ($(this).is(":checked")) {
                    cur_tbody.find(".checkItem0").prop("checked", "checked");
                } else {
                    cur_tbody.find(".checkItem0").prop("checked", false);
                }
            } else if (length2 == 0 && length1) {
                if ($this.is(":checked")) {
                    cur_tbody.find(".checkItem0").prop("checked", "checked");
                } else {
                    cur_tbody.find(".checkItem0").prop("checked", false);
                    $this.closest(".le-text-xs").find(".checkall_category").prop("checked", false);
                }
            } else if (length2 && length1 == 0) {
                $this.closest("table").closest("tr").prev().find(".checkItem0").prop("checked", false);
                $this.closest(".le-text-xs").find(".checkall_category").prop("checked", false);
            }
        });
        //点击箭头
        $(".media-upload-box tbody tr").has("i.caret").show();
        $(".media-upload-box").on("click", "tr .icon-link", function() {
            var $this = $(this);
            var cur_tr = $(this).closest("tr");
            if (cur_tr.hasClass("cur")) {
                cur_tr.removeClass("cur");
                $this.closest("tbody").find("tr").hide().eq(0).show();
            } else {
                cur_tr.addClass("cur");
                $this.closest("tbody").find("tr").show();
            }
        });
    }
};
$(function() {
    categoryFn.init();
    $(".ui-page").on("click", "a", function() {
        var num = 0;
        var numPre = $(this).parent().find(".active").attr("data-page") * 1;
        if ($(this).hasClass("prev")) {
            num = numPre - 1;
        } else if ($(this).hasClass("next")) {
            num = numPre + 1;
        } else {
            num = $(this).attr("data-page");
        }
        categoryFn.getCommetList(url, num * 1, rows);
        return false;
    });
})