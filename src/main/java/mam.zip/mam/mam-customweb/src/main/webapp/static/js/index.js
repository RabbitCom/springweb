$(function () {
    $.ajax({
        type: "get",
        url: basePath + "customPermissionController/getPermissionMenus.do",
        dataType: "json",
        success: function (data) {
            for (var i = 0; i < data.obj.length; i++) {
                $("#permission_" + data.obj[i].menuId).attr("data-url", basePath + data.obj[i].url);
                $("#permission_" + data.obj[i].menuId).text(data.obj[i].menuName);
            }
        }
    });
});