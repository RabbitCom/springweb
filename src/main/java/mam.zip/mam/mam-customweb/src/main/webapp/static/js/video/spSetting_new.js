
var custom_obj = null;
var customSet = {
		init: function(){
            this.baseHandle(); //页面基础操作
			this.getCustomInfo();//获取用户信息
            this.malv(); //初始化码率设置
		},
		baseHandle: function() {
			//tab切换
			$(".le-all-tpl-tabs li").click(function(e) {
				for (var i = 0; i < $(".le-all-tpl-tabs li").length; i++) {
					if ($(".le-all-tpl-tabs li").eq(i).hasClass("active")) {
						$(".le-all-tpl-tabs li").eq(i).removeClass("active");
						$(".le-tpl-tab-con").removeClass("active");
					}
				}
				$(e.target).addClass("active");
				$(".le-tpl-tab-con").eq($(e.target).index()).addClass("active");
			});
			//save按钮事件绑定
            $("#buttion_transCode").click(function() {
                //码率信息
            	var malv_arr = $("#malvContent").find(".checkItem:checked");
                var rates = "";
                for (var i = 0; i < malv_arr.length; i++) {
                    rates += ","+$(malv_arr[i]).val();
                }
                if(rates != ""){
                    rates = rates.substring(1);
                }

                var cur_src = $("#vedio-img-box02 li img").attr("src");
                var siteArr = $("#logoSite .logoST:checked");
                var lgStatusArr = $("#logoSite .logoStatus:checked");
                var lgStatus = $(lgStatusArr[0]).val()
                var site = $(siteArr[0]).val();
                setTimeout(function() {
                    $.post(basePath + '/spSetting/updateTransCodeSetting.do', {
                        customImg: cur_src,
                        target: site,
                        logoStatus: lgStatus,
                        rate:rates,
                        spId : $("#spId_hidden").val()
                    }, function(result) {
                        if (result.success) {
                            alertfn.success(LCT("保存成功"));
                        } else {
                            alertfn.danger(result.msg);
                        }
                    }, 'JSON');
                    return;
                }, 300);

            });
            $("#buttion_process").click(function() {
                var autoAudit = $('input:radio[name="audit"]:checked').val();
                var autoOnlie = $('input:radio[name="autoOnlie"]:checked').val();
                var autoPublish = $('input:radio[name="publish"]:checked').val();
                setTimeout(function() {
                    $.post(basePath + '/spSetting/updateProcessSetting.do', {
                        autoAudit: autoAudit,
                        autoOnlie: autoOnlie,
                        autoPublish: autoPublish,
                        spId : $("#spId_hidden").val()
                    }, function(result) {
                        if (result.success) {
                            alertfn.success(LCT("保存成功"));
                        } else {
                            alertfn.danger(result.msg);
                        }
                    }, 'JSON');
                    return;
                }, 300);

            });
            $("#button_cmsSettings").click(function() {
                var isStartCategory = $('input:radio[name="startCategory"]:checked').val();
                var cmsReqUrl = $('#customTreeUrl').val().trim();
                var publishUrl = $('#publishUrl').val().trim();
                var offLineUrl = $('#offLineUrl').val().trim();
                if("1"==isStartCategory){//启用栏目
                    if(cmsReqUrl==null || cmsReqUrl==''){
                        alertfn.danger("自定义栏目接口地址为空！");
                        return false;
                    }
                    else if( !(cmsReqUrl.startsWith("http") || cmsReqUrl.startsWith("https"))){
                        alertfn.danger("自定义栏目接口地址不正确");
                        return false;
                    }
                }

                if(publishUrl==null || publishUrl==''){
                    alertfn.danger("自定义发布内容地址为空！");
                    return false;
                }
                else if( !(publishUrl.startsWith("http") || publishUrl.startsWith("https"))){
                    alertfn.danger("自定义发布内容地址不正确");
                    return false;
                }

                if(offLineUrl==null || offLineUrl==''){
                    alertfn.danger("自定义内容下线地址为空！");
                    return false;
                }
                else if( !(offLineUrl.startsWith("http") || offLineUrl.startsWith("https"))){
                    alertfn.danger("自定义内容下线地址不正确");
                    return false;
                }

                setTimeout(function() {
                    $.post(basePath + '/spSetting/updateCMSSetting.do', {
                        cmsReqUrl:cmsReqUrl,
                        publishUrl:publishUrl,
                        offLineUrl:offLineUrl,
                        isStartCategory:isStartCategory,
                        spId : $("#spId_hidden").val()
                    }, function(result) {
                        if (result.success) {
                            alertfn.success(LCT("保存成功"));
                        } else {
                            alertfn.danger(result.msg);
                        }
                    }, 'JSON');
                    return;
                }, 300);

            });
            $("#button_ptpw").click(function () {
                var startUrl = $('#startUrl_ptpw').val();
                var endUrl = $('#endUrl_ptpw').val();
                // if(startUrl==null || startUrl == "" || startUrl == undefined){
                //     alertfn.danger("片头地址为空！");
                //     return false;
                // }
                // if(endUrl==null || endUrl == "" || endUrl == undefined){
                //     alertfn.danger("片尾地址为空！");
                //     return false;
                // }
                setTimeout(function() {
                    $.post(basePath + '/spSetting/updatePtPw.do', {
                        startUrl: startUrl,
                        endUrl: endUrl,
                        spId : $("#spId_hidden").val()
                    }, function(result) {
                        if (result.success) {
                            alertfn.success(LCT("保存成功"));
                        } else {
                            alertfn.danger(result.msg);
                        }
                    }, 'JSON');
                    return;
                }, 300);
            })
		},
    	getCustomInfo: function(){
			$.ajax({
				type: "GET",
				url: basePath + "/spSetting/getSpSettingInfo.do",
				success: function(data) {
					data = typeof(data) == "string" ? JSON.parse(data) : data;

					var customId = data.obj.customId;
					var spInfo = data.obj.spInfo;
					var spId = spInfo.spId;

					$("#spId_hidden").val(spId);

					if(spInfo.autoAudit == "0"){
						$("input[name='audit'][value='0']").prop("checked","checked");
					}else{
						$("input[name='audit'][value='1']").prop("checked","checked");
					}

					if(spInfo.autoOnlie == "0"){
						$("input[name='autoOnlie'][value='0']").prop("checked","checked");
					}else{
						$("input[name='autoOnlie'][value='1']").prop("checked","checked");
					}

					if(spInfo.autoPublish == "0"){
						$("input[name='publish'][value='0']").prop("checked","checked");
					}else{
						$("input[name='publish'][value='1']").prop("checked","checked");
					}

					if(spInfo.isStartCategory == "0"){
						$("input[name='startCategory'][value='0']").prop("checked","checked");
					}else{
						$("input[name='startCategory'][value='1']").prop("checked","checked");
					}

					if(spInfo.logoStatus == "0"){
						$("input[name='logoStatus'][value='0']").prop("checked","checked");
					}else{
						$("input[name='logoStatus'][value='1']").prop("checked","checked");
					}

					if(spInfo.cmsReqUrl != null && spInfo.cmsReqUrl != ""){
						$("#columnTreeUrl").attr("value",spInfo.cmsReqUrl);
						$("#customTreeUrl").attr("value",spInfo.cmsReqUrl);
					}

					if(spInfo.publishUrl != null && spInfo.publishUrl != ""){
						$("#publishUrl").attr("value",spInfo.publishUrl);
					}

					if(spInfo.offLineUrl != null && spInfo.offLineUrl != ""){
						$("#offLineUrl").attr("value",spInfo.offLineUrl);
					}

                    if(spInfo.logoSite == "0"){
                        $("input[name='logoST'][value='0']").prop("checked","checked");
                    }else if(spInfo.logoSite == "1"){
                        $("input[name='logoST'][value='1']").prop("checked","checked");
                    }else if(spInfo.logoSite == "2"){
                        $("input[name='logoST'][value='2']").prop("checked","checked");
                    }else if(spInfo.logoSite == "3"){
                        $("input[name='logoST'][value='3']").prop("checked","checked");
                    }

                    if(spInfo.ptDomainUrl != null && spInfo.ptDomainUrl != ""){
                        $('#startUrl_ptpw').attr("value",spInfo.ptDomainUrl);
                    }

                    if(spInfo.pwDomainUrl != null && spInfo.pwDomainUrl != ""){
                        $('#endUrl_ptpw').attr("value",spInfo.pwDomainUrl);
                    }

                    if(spInfo.logoDomainUrl != null && spInfo.logoDomainUrl != ""){
                        $("#vedio-img-box02 li img").attr("src",spInfo.logoDomainUrl);
                    }
				},
				error: function() {}
			});
		},
    	malv: function(){
            $.getJSON(
                basePath + "spSetting/getSpDefinition.do",
                function(data) {
                    var malv_html = "";
                    var checked_length = 0;
                    //malv_html += '<div class="col-md-10"><span class="ui-fl mt-5">' + LCT("默认清晰度：") + '</span><label class="checkbox-inline ui-fl">' + LCT("标清") + '</label></div>';
                    malv_html += '<label class="col-md-1 col-md-offset-2" style="padding-left: 0;">&nbsp;&nbsp;&nbsp;<i class="star"  style="display: none;">*</i>' + LCT("选择清晰度：") + '</label><div class="col-md-8"><label class="m-l-r-5"><input class="checkall" id="malvAllSelect" type="checkbox" value="">' + LCT("全部")+'</label>&nbsp;&nbsp;&nbsp;&nbsp;';
                    for (var i = 0; i < data.length; i++) {
                        var dicValue = data[i].dicValue;
                        var showValue = data[i].showValue;
                        var selected = data[i].selected;
                        if (data[i].dicValue != "800") {
                            malv_html += '<label class="m-l-r-5" >';
                            if (selected) {
                                checked_length++;
                                malv_html += '<input type= "checkbox" checked class="checkItem" value= "' + dicValue + '" />';
                            } else {
                                malv_html += '<input type= "checkbox" class="checkItem" value= "' + dicValue + '" />';
                            }
                            malv_html += showValue + '</label>';
                        }
                    }
                    malv_html +="</div>";
                    $("#malvContent").html(malv_html);
                    if (checked_length == data.length - 1) {
                        $("#malvAllSelect").prop("checked", true);
                    } else {
                        $("#malvAllSelect").prop("checked", false);
                    }
                    checkall("#malv-set");
                }
            );
		}
}

$(function() { // 信息初始化
    customSet.init();
})