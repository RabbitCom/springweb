var category_obj = {};
var videoEditFn = {
    init: function() {
        this.baseHandle(); //页面基础操作
        this.initEpisode(); //初始化集数
        this.dilverCode(); //转码情况
        this.radioCheckbox(); //页面单选，多选
        this.switchDateEn(); //日期中英文切换
        setTimeout(videoEditFn.editImg, 1000);//图片信息
    },
    baseHandle: function() {
        //tab初始化
        $(".vedio-edit-img-con .le-img-tabs li").first().addClass("active");
        $(".vedio-edit-img-con .vedio-img-box").first().addClass("active");
        //返回
        $(".back").click(function() {
            closeIframeFromInner('refresh');
        });
        //tab切换
        $(".le-all-tpl-tabs li").click(function(e) {
            for (var i = 0; i < $(".le-all-tpl-tabs li").length; i++) {
                if ($(".le-all-tpl-tabs li").eq(i).hasClass("active")) {
                    $(".le-all-tpl-tabs li").eq(i).removeClass("active");
                    $(".le-tpl-tab-con").removeClass("active");
                }
            }
            $(e.target).addClass("active");
            $(".le-tpl-tab-con").eq($(e.target).index()).addClass("active");
        });
        $("#save_video").on('click', function() {
            videoEditFn.albumCheck();
            var subCategory = PublicPullSubmitSelected("subCategory"); //影视分类多选
            var videoType = PublicPullSubmitSelected("videoType"); //视频类型
            var area = PublicPullSubmitSelected("area"); //地区多选
            var language = PublicPullSubmitSelected("language"); //语言
            var requireCon = $(".requireCon");
            for (var i = 0; i < requireCon.length; i++) {
                var block_length = $(requireCon[i]).find("li").length;
                if (block_length == 0) {
                    var flag = $(requireCon[i]).attr("flag");
                    $("#" + flag).css("border", "1px #fb5259 solid");
                }
            }
            if ($("#albumId").hasClass("error")) {
                var validate_result = false;
            } else {
                var validate_result = $("#information").valid();
            }
            if (subCategory && videoType && area && language && validate_result) {
                $.post(basePath + 'videoController/updateVideo.do', $.serializeObject($('#information')), function(result) {
                    if (result.success) {
                        var params = {
                            "discription": result.msg,
                            "iconType": "success",
                            "confirmBtn": true,
                            "confirmEvent": function() {
                                $("html,body").animate({
                                    scrollTop: 0
                                }, 400);
                            }
                        };
                    } else {
                        var params = {
                            "title": LCT("错误"),
                            "discription": result.msg,
                            "iconType": "warningCircle",
                            "confirmBtn": true
                        };
                    }
                    $("body").toolsalert(params);
                    return;
                }, 'JSON');
            } else {
                if (!subCategory) {
                    PublicSuccessError("tab-subCategory", false);
                } else {
                    PublicSuccessError("tab-subCategory", true);
                }
                if (!videoType) {
                    PublicSuccessError("tab-videoType", false);
                } else {
                    PublicSuccessError("tab-videoType", true);
                }
                if (!area) {
                    PublicSuccessError("tab-area", false);
                } else {
                    PublicSuccessError("tab-area", true);
                }
                if (!language) {
                    PublicSuccessError("tab-language", false);
                } else {
                    PublicSuccessError("tab-language", true);
                }
                error_scroll();
                return false;
            }
        });
    },
    initEpisode: function() {
        var episode_value = $("input[name='episode']").val();
        if (episode_value.indexOf(".")) {
            if (episode_value[episode_value.length - 1] == 0) {
                $("input[name='episode']").val(Math.round(episode_value));
            }
        }
    },
    dilverCode: function() {
        var videoId = $("#videoId_hidden").val();
        var tbody_html = '';
        $.ajax({
            url: basePath + "super/getTranCodeInfos.do?videoId=" + videoId,
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                	if(data.obj.length == 0){
                		$("#downLoad").css("display","none");
                		return;
                	}
                	var firstFileId = data.obj[0].fileId;
                    var firstVideoId = data.obj[0].videoId;
                    for (var i = 0; i < data.obj.length; i++) {
                        var codeRate = data.obj[i].codeRate;
                        var codeRateName = data.obj[i].codeRateName;
                        var transCodeFmt = data.obj[i].transCodeFmt;
                        var duration = data.obj[i].duration || 0;
                        var status = data.obj[i].status;
                        var fileId = data.obj[i].fileId;
                        var videoName = data.obj[i].videoName;
                        var storeUrl = data.obj[i].storeUriDomain;
                        var showStatus;
                        if(status == 0){
                            showStatus = "上传成功";
                        }
                        else if(status == 1){
                            showStatus = "转码中";
                        }
                        else if(status == 2){
                            showStatus = "转码成功";
                        }
                        else if(status == 3){
                            showStatus = "转码失败";
                        }
                        else if(status == 4){
                            showStatus = "下线";
                        }else{
                            showStatus = "初始化";
                        }
                        tbody_html += '<tr>';
                        tbody_html += '<td>' + codeRateName + '</td>';
                        tbody_html += '<td id="status_'+codeRate+'_'+transCodeFmt+'">' + showStatus + '</td>';
                        tbody_html += '<td>' + transCodeFmt + '</td>';
                        tbody_html += '<td>' + vrsFn.formatSeconds(duration) + '</td>';
                        
                        if (status == 2) {
                            tbody_html += '<td><a href="#modal-video-view" data-toggle="modal" class="videoView" data-id="'+ fileId +'" data-name="'+ videoName +'" codeRate="' + codeRate + '" storeUrl="' + storeUrl + '">' + LCT("预览")
                                + '</a></td>';
                        } else {
                            tbody_html += '<td><a>' + LCT("无") + '</a></td>';
                        }
                        tbody_html += '</tr>';
                    }
                    //下载
                    $("#downLoad").on("click", function(){
                        var downUrl = basePath + "playInfo/getDownloadVideo.do?fileId="+firstFileId+"&vId="+firstVideoId;
                        window.open(downUrl, "_blank");
                        // location.href = basePath + "playInfo/getDownloadVideo.do?fileId="+firstFileId;
                    });
                } else {
                	$("#downLoad").css("display","none");
                    tbody_html += '<tr>';
                    tbody_html += '<td colspan="5">' + data.msg + '</td>';
                    tbody_html += '</tr>';
                }
                $("table.media-manage-table tbody").html(tbody_html);
               
            },
            error: function() {
                //console.log("fail");
            }
        });
        //预览
        $("#editTable").on("click", ".videoView", function() {
            var data_name = $(this).attr("data-name");
            var storeUrl = $(this).attr("storeUrl");
            var fileCodeRate = $(this).attr("codeRate");
            var playerParams = "type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1";
            if(fileCodeRate == 400){
                playerParams += ("&currRate=1&videoUrl_1=" + storeUrl );
            }
            if(fileCodeRate == 800){
                playerParams += ("&currRate=2&videoUrl_2=" + storeUrl );
            }
            if(fileCodeRate == 1500){
                playerParams += ("&currRate=3&videoUrl_3=" + storeUrl );
            }
            if(fileCodeRate == 3000){
                playerParams += ("&currRate=4&videoUrl_4=" + storeUrl );
            }
            //获取播放地址
            // $("#cnlivePlayer").attr("flashVars","hasBorder=false&model=2&videoURL="+storeUrl);
            $("#cnlivePlayer").attr("flashVars",playerParams);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $("#modal-video-view .close").click(function() {
//            $("#player").html("");
        });
       
    },
    editImg: function() {
        $(".upload-mask").show();
        $("#vedio-img-box02 .upload-btn-group a").removeClass("active");
        $(".upload-mask").click(function() {
            alertfn.danger(LCT("请先选择要上传的比例"));
        });
        //上传比例按钮选择及提示
        $("#vedio-img-box02").on("click", ".upload-btn-group a", function() {
            var max_wh = $(this).attr("data-size");
            $(".upload-mask").hide();
            $(this).addClass("active").siblings().removeClass("active");
            $("#vedio-img-box02 p b").html(max_wh);
        });
        //渲染初始八张图，及各端默认图
        if ($("#vedio-img-box01").length) {
            var li_html = "";
            li_html += '<ul class="clearfix">';
            for (var i = 1; i < 9; i++) {
                if (picOriginal_fromJSP) {
                    if(storageType == 1){
                        li_html += '<li><i></i><img src=' + picOriginal_fromJSP +'0000'+ i +'.jpg@base@tag=imgScale&w=230&h=130&m=2&c=1'+'></li>';
                    }
                    if(storageType == 2){
                        li_html += '<li><i></i><img src=' + picOriginal_fromJSP +'00000'+ i + '.jpg?imageView2/1/w/230/h/130'+'></li>';
                    }
                } else {
                    li_html += '<li><i></i><img src="http://yweb1.cnliveimg.com/image/mz/default_160x90.png"></li>';
                }

            }
            li_html += '</ul>';
            $("#vedio-img-box01").prepend(li_html);
        }
        var data = picFinished_fromJSP;
        //右边成品图
        var divWidth = $(".vedio-img-box2").width();
        var divHeight;
        var bili_html = '';
        var btn_html = '';
        for (var i = 0; i < data.length; i++) {
            var data_info = data[i];
            var bl = data_info.bl;
            var url = data_info.info[0].url;
            var max_wh = data_info.info[0].fbl;
            divHeight = Math.floor(divWidth * parseInt(bl.split(":")[1]) / parseInt(bl.split(":")[0]));
            bili_html += '<div style="height:' + divHeight + 'px" img-wh="' + max_wh.replace(/\*/, "_") + '"><img height=' + divHeight + ' src=' + url + '></div>';
            bili_html += '<p>' + bl + '(&nbsp;';
            for (var j = 0; j < data_info.info.length; j++) {
                var wh = data_info.info[j].fbl;
                bili_html += wh + '&nbsp;';
            }
            bili_html += ')</p>';
            btn_html += '<a href="javascript:void(0)" data-index=' + i + ' class="btn-danger btn-l ml-10" data-size=' + max_wh + '>' + bl + '</a>';
        }
        $(".vedio-img-box2").html(bili_html);
        if ($("#vedio-img-box01").length) {
            $("#vedio-img-box01 .btn-img-group").prepend(btn_html);
        }
        $("#vedio-img-box02 .upload-btn-group").html(LCT("图片比例") + "：<br/><br/>" + btn_html);


        if (picOriginal_fromJSP) {
            $(".vedio-edit-img-con").on("click", "#vedio-img-box01 li", function() {
                $(this).addClass("active").siblings().removeClass("active");
            });
            //各端图片保存提交（图片信息）
            $("#vedio-img-box01").on("click", ".btn-img-group a", function() {
                var a_bili = $(this).html();
                var index = $(this).index();
                var cur_src = $("#vedio-img-box01").find("li.active img").attr("src");
                if (cur_src == null) {
                    alertfn.danger("请先选择图片!");
                } else {
                	cur_src = cur_src.split("@base@tag=imgScale")[0];
                	cur_src = cur_src.split("?")[0];
                    var params = {
                        "discription": LCT("是否替换右侧") + a_bili + LCT("的显示图片"),
                        "iconType": "triangle",
                        "confirmBtn": true,
                        "cancelBtn": true,
                        "confirmEvent": function() {
                            $.post(basePath + 'videoController/getPicByDiffScale.do',
                                {
                                videoId: $("#videoId_hidden").val(),
                                customImg: cur_src,
                                proportion: a_bili
                            }, function(result) {
                                if (result.success) {
                                	var src1=$(".vedio-img-box2 div").eq(index).attr("img-wh");
                                	var split = src1.split("_");
                                	
                                	if(result.obj==2){
                                		cur_src = cur_src+"?imageView2/1/w/"+split[0]+"/h/"+split[1];
                                	}else{
                                		cur_src = cur_src+"@base@tag=imgScale&w="+split[0]+"&h="+split[1]+"&m=2&c=1";
                                	}
                                    $(".vedio-img-box2 div").eq(index).find("img").attr("src", cur_src);
                                    alertfn.success(LCT("替换成功"));
                                } else {
                                    alertfn.danger(result.msg);
                                }
                            }, 'JSON');
                        }
                    };
                    $("body").toolsalert(params);
                    return;
                }
            });
        }
        //各端图片保存提交（自定义图片）
        $("#vedio-img-box02").on("click", ".btn-img-group a", function() {
            var cur_src = $("#vedio-img-box02 li img").attr("src");
            var a_active = $("#vedio-img-box02 .upload-btn-group a.active");
            if (a_active.length) {
                var index = a_active.attr("data-index");
                var a_bili = a_active.html();
                var data_size = a_active.attr("data-size").split("*");
                if (cur_src) {
                    var img = $("#vedio-img-box02 li img");
                    $("<img/>").attr("src", $(img).attr("src")).load(function() {
                        $(img).attr({
                            "real-width": this.width,
                            "real-height": this.height
                        });
                    });
                    setTimeout(function() {
                        var realWidth = parseInt($(img).attr("real-width"));
                        var realHeight = parseInt($(img).attr("real-height"));
                        if (parseInt(data_size[0]) <= realWidth && parseInt(data_size[1]) <= realHeight) {
                            var params = {
                                "discription": LCT("是否替换右侧") + a_bili + LCT("的显示图片"),
                                "iconType": "triangle",
                                "confirmBtn": true,
                                "cancelBtn": true,
                                "confirmEvent": function() {
                                    $.post(basePath + '/videoController/getPicByDiffScale.do', {
                                        videoId: $("#videoId_hidden").val(),
                                        customImg: cur_src,
                                        proportion: a_bili
                                    }, function(result) {
                                        if (result.success) {
                                        	var src1=$(".vedio-img-box2 div").eq(index).attr("img-wh");
                                        	var split = src1.split("_");
                                        	if(result.obj==2){
                                        		cur_src = cur_src+"?imageView2/1/w/"+split[0]+"/h/"+split[1];
                                        	}else{
                                        		cur_src = cur_src+"@base@tag=imgScale&w="+split[0]+"&h="+split[1]+"&m=2&c=1";
                                        	}
                                            $(".vedio-img-box2 div").eq(index).find("img").attr("src", cur_src);
                                            alertfn.success(LCT("替换成功"));
                                        } else {
                                            alertfn.danger(result.msg);
                                        }
                                    }, 'JSON');

                                }
                            };
                            $("body").toolsalert(params);
                            return;
                        } else {
                            alertfn.danger(LCT("宽度不能小于") + data_size[0] + "！" + LCT("高度不能小于") + data_size[1] + "！");
                        }
                    }, 300);
                } else {
                    alertfn.danger(LCT("请先上传图片"));
                }
            } else {
                alertfn.danger(LCT("请先选择要替换的比例"));
            }
        });
    },
    albumCheck: function() { //专辑id校验
        var albumId = $("#albumId").val();
        var videoId = $("#videoId_hidden").val();
        var albumId_error = $("#albumId-error");
        var albumCheckErrorMsg = "";
        $("#albumId").val(albumId).removeClass("error");
        $("#albumId-error").hide();
        if (vrsFn.checkNum(albumId) && albumId) {
            $.ajax({
                url: basePath + "videoController/checkAlbum.do",
                data: "videoId=" + videoId + "&albumId=" + albumId,
                type: "get",
                async: false,
                dataType: "json",
                success: function(data) {
                    if (!data.success) {
                        boo = true;
                        albumCheckErrorMsg = data.msg;
                        $("#albumId").addClass("error");
                        if (albumId_error.length) {
                            albumId_error.html(albumCheckErrorMsg).show();
                        } else {
                            $("#albumId").after('<label id="albumId-error" class="error" for="albumId" style="display: inline-block;">' + albumCheckErrorMsg + '</label>');
                        }
                    }
                }
            });
        }
    },
    radioCheckbox: function() {
        var initRadio_arr = [
            [".mmsType", ".videoType", ".contentRating", ".shieldingRule", ".copyrightType",".autoOnline",".autoPublish"],
            [mmsType_value, videoType_value, contentRating_values, shieldingRule_values, copyrightType_values,autoOnline_values,autoPublish_values]
        ];
        var initCheckbox_arr = [
            [".subCategory", ".language", ".area", ".payPlatform", ".playPlatform", ".downloadPlatform"],
            [subCategory_values, language_values, area_values, payPlatform_values, playPlatform_values, downloadPlatform_values]
        ];
        for (var i = 0; i < initRadio_arr[0].length; i++) {
            initRadio(initRadio_arr[0][i], initRadio_arr[1][i]);
        }
        for (var j = 0; j < initCheckbox_arr[0].length; j++) {
            initCheckbox(initCheckbox_arr[0][j], initCheckbox_arr[1][j]);
        }
        // 常用属性开始
        $(".videoType").click(function() { // 视频类型
            multiRadio.radio(this, ".videoType");
            var ifpass = multiRadio.radioValue("videoType", ".videoType");
            PublicSuccessError("tab-videoType", ifpass);
        });

        $(".subCategory input").click(function(e) { // 影视分类多选
            var that = $(this).parent();
            multiRadio.multi(that); // 选择并改变状态
            var ifpass = multiRadio.multiValue("subCategory", ".subCategory");
            PublicSuccessError("tab-subCategory", ifpass);
        });

        $(".language input").click(function(e) { // 语言单选
            var that = $(this).parent();
            multiRadio.multi(that, ".language");
            var ifpass = multiRadio.multiValue("language", ".language");
            PublicSuccessError("tab-language", ifpass);
        });

        $(".area input").click(function() { // 地区多选
            var that = $(this).parent();
            var boo = multiRadio.select(that);
            if (!boo) {
                multiRadio.multi(that);
            } else {
                multiRadio.areaSelect = !multiRadio.areaSelect;
            }
            var ifpass = multiRadio.multiValue("area", ".area");
            PublicSuccessError("tab-area", ifpass);
        });
        $(".autoOnline").click(function() { // 年龄分级单选
            multiRadio.radio(this, ".autoOnline");
            multiRadio.radioValue("autoOnline", ".autoOnline");
        });
        $(".autoPublish").click(function() { // 年龄分级单选
            multiRadio.radio(this, ".autoPublish");
            multiRadio.radioValue("autoPublish", ".autoPublish");
        });
        //购买/非购买版权修改
        // var originVideoId = $("#originVideoId_hidden").val();
        // if (originVideoId == 0 || originVideoId == null) {
        //     $(".playPlatform input").click(function() { // 播放平台多选
        //         var that = $(this).parent();
        //         multiRadio.multi(that);
        //         var ifpass = multiRadio.multiValue("playPlatform", ".playPlatform");
        //         //PublicSuccessError("tab-playPlatform", ifpass);//去掉必选
        //     });
        //
        //     $(".downloadPlatform input").click(function() { // 下载平台多选
        //         var that = $(this).parent();
        //         multiRadio.multi(that);
        //         var ifpass = multiRadio.multiValue("downloadPlatform", ".downloadPlatform");
        //         PublicSuccessError("tab-downloadPlatform", ifpass);
        //     });
        //     $(".copyrightType").click(function() { // 版权类型单选
        //         multiRadio.radio(this, ".copyrightType");
        //         var ifpass = multiRadio.radioValue("copyrightType", ".copyrightType");
        //         PublicSuccessError("tab-copyrightType", ifpass);
        //     });
        // } else {
        //     $("input[name='copyrightCompany']").attr("disabled", true);
        //     $("input[name='copyrightStart']").attr("disabled", true);
        //     $("input[name='copyrightEnd']").attr("disabled", true);
        // }
        //
        // $(".contentRating").click(function() { // 年龄分级单选
        //     multiRadio.radio(this, ".contentRating");
        //     multiRadio.radioValue("contentRating", ".contentRating");
        // });
        //
        // $(".shieldingRule").click(function() { // 海外屏蔽单选;
        //     multiRadio.radio(this, ".shieldingRule");
        //     var ifpass = multiRadio.radioValue("shieldingRule", ".shieldingRule");
        //     PublicSuccessError("tab-shieldingRule", ifpass);
        // });
    },
    switchDateEn: function() {
        var createTime = $("#video_edit_createtime").val();
        var updatetime = $("#video_edit_updatetime").val();
        var copyrightStart = $("#d4311").val();
        var copyrightEnd = $("#d4312").val();
        var releaseDate = $("#releaseDate").val();
        if (lctu.getLanguage() == "en") {
            $("#video_edit_createtime").val(formatDateEn(createTime.replace(/-/ig, "/")));
            $("#video_edit_updatetime").val(formatDateEn(updatetime.replace(/-/ig, "/")));
            $("#d4311-result").val(vrsFn.formatDateEn_short(copyrightStart.replace(/-/ig, "/")));
            $("#d4312-result").val(vrsFn.formatDateEn_short(copyrightEnd.replace(/-/ig, "/")));
            $("#releaseDate-result").val(vrsFn.formatDateEn_short(releaseDate.replace(/-/ig, "/")));
        } else {
            $("#d4311-result").val(copyrightStart);
            $("#d4312-result").val(copyrightEnd);
            $("#releaseDate-result").val(releaseDate);
        }
    }
};
var buildEdit = {
    init: function(id) {
        this.connect(id);
    },
    editNameDom: $("input[name=editName]").parent(),
    editClassDom: $("#editClass"),
    start: false,
    connect: function(id) {
        $.ajax({
            url: basePath + "customCategoryController/dataGrid.do",
            data: category_obj, //分类信息加参数
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                window.classfiyObject_obj = data;
                buildEdit.createDom(data, id);
                if (id == "editClass") {
                    buildEdit.start = true
                }

            }
        })
    },
    createDom: function(data, id) {
        var s1 = new createClass(id, data);
        s1.init(2, id);
    },
    setInformation: function() { //设置分类信息事件;
        var arr = $("#setClass option:selected");
        var classId = "";
        var categoryId = "";
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                classId = $(arr).eq(i).attr("data-id");
                categoryId = $(arr).eq(i).attr("category-id");
                break;
            }
        }
        $(".systemCatagory option[data-id='" + categoryId + "']").prop("selected", true);
        if (classId == "") {
            delete params["customCategoryId"];
        } else {
            params["customCategoryId"] = classId;
        }
        lcsetting.thisPage = 1;
        $("#maintable").lctable(lcsetting, params);
    }
};
createClass.prototype = {
    init: function(num, id) {
        var This = this;
        for (var i = 0; i < 2; i++) {
            var oSel = document.createElement("select");
            oSel.index = i;
            oSel.className = "form-control";
            this.oParent.appendChild(oSel);
            oSel.onchange = function() {
                This.change(this.index);
            }
        }
        if (id == "setClass") {
            var ahref = document.createElement("a")
            $(this.oParent).append('<a data-menu="vrsCategory" class="icon-set link-gray3" href="' + basePath + 'customCategoryController/toCustomCategoryManager.do">' + LCT("设置分类信息") + '</a>');
        }
        this.first();
    },
    change: function(iNow) {
        switch (iNow) {
            case 0: //改变1级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.zero(now);
                break;
            case 1: //改变2级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.one(now);
                break;
//            case 2: //改变3级时候处理
//                var now = this.aSel[iNow].selectedIndex;
//                this.two(now);
//                break;
        }
        if (this.oParent == document.getElementById("setClass")) {
            buildEdit.setInformation();
        }
    },
    noting: function() {
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i + 1].appendChild(opt);
        }
    },
    zero: function(n) { //改变一级处理函数

        for (var i = 0; i < 2; i++) { //清空源信息;
            if (i == 0) {
                continue
            }
            this.aSel[i].innerHTML = "";
        }
        if (n == 0) {
            this.noting();
            return
        }
        var arr = this.data[n - 1];
        if (arr.children.length) {
            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);
                this.aSel[1].appendChild(opt);
            }
        } else {
            this.noting();
            return;
        }

//        if (arr.children[0].children.length) {
//            for (var i = 0; i < arr.children[0].children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[0].children[i].text;
//                opt.setAttribute("data-id", arr.children[0].children[i].id);
//                opt.setAttribute("category-id", arr.children[0].children[i].category);
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }
    },
    one: function(n) { //改变二级处理函数
//        var a1 = this.aSel[0].selectedIndex - 1;
//        var arr = this.data[a1].children[n];
//        this.aSel[2].innerHTML = "";
//        if (arr.children.length != 0) {
//
//            for (var i = 0; i < arr.children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[i].text;
//                opt.setAttribute("data-id", arr.children[i].id);
//                opt.setAttribute("category-id", arr.children[i].category);
//
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }

    },
    two: function(n) {

    },
    first: function() { //上来初始化
        var arr = this.data;
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i].appendChild(opt);
        }
        for (var i = 0; i < arr.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = arr[i].text;
            $(opt).attr("data-id", arr[i].id);
            $(opt).attr("category-id", arr[i].category);
            this.aSel[0].appendChild(opt);
        }
    }
}

function createClass(id, data) {
    this.oParent = document.getElementById(id);
    this.data = data;
    this.aSel = this.oParent.getElementsByTagName("select");
}

function reTransCode(videoId,codeRate,transCodeFmt){
	$("a[id^='reTransCode_"+codeRate+"']").each(function(){
		$(this).text(LCT("无"));
		$(this).attr('onclick','');
	});
	$.ajax({
		url: basePath + "videoController/reTransCode.do",
		data: {
			videoId:videoId,
			codeRate:codeRate
			},
        type: "post",
        dataType: "json",
        success: function(data) {
            if (data.success) {
            	$("td[id^='status_"+codeRate+"']").each(function(){
            		$(this).html(LCT(data.msg));
            	})
            }else{
            	$("td[id^='status_"+codeRate+"']").each(function(){
            		$(this).html("重转码失败");
            		$("a[id^='reTransCode_"+codeRate+"']").each(function(){
            			$(this).text(LCT("重转码"));
            			$(this).attr('onclick','reTransCode("'+videoId+'","'+String(codeRate)+'","'+String(transCodeFmt)+'")');
            		});
            	})
            }
        }
	})
}
$(function() { // 校验 编辑基本信息初始化
    videoEditFn.init();
    vrsFn.categoryInit(); //页面初始渲染数据分类
    vrsFn.infomationValidate(); //表单验证规则
})