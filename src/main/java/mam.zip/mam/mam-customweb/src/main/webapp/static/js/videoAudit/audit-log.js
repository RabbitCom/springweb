//默认显示当前一周时间
var params = {},videoName_arr=[],auditMessage_arr=[];
var lcsetting = {
    "ajax": basePath + "videoController/videoAuditDataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            return d.videoId;
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<p class="videoLogName"></p>';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            if (d.auditType == 1) {
                return d.auditUser;
            } else if (d.auditType == 2) {
                return LCT("乐视审核");
            }
        }
    }, {
        "data": "lcall",
        "className": "timeCols",
        "format": function(i, j, d) {
            if (lctu.getLanguage() == "en") {
                return vrsFn.formatDateEn_short(d.auditTime.replace(/-/ig, "/")); //审核时间
            } else {
                return formatDate(d.auditTime); //审核时间
            }
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            if (d.action == 1 || d.action == 3) {
                return LCT("审核通过");
            }
            if (d.action == 2) {
                return LCT("乐视审核未通过");
            }
            if (d.action == 4) {
                return LCT("审核未通过");
            }
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            if (d.auditReason == null || d.auditReason == undefined) {
                return " ";
            }
            if (d.auditReason == 110001) {
                return LCT("视频内容不清晰");
            }
            if (d.auditReason == 110002) {
                return LCT("视频内容不合法");
            }
            if (d.auditReason == 110003) {
                return LCT("视频名称等不合法");
            }
            if (d.auditReason == 110004) {
                return LCT("版权问题");
            }
            if (d.auditReason == 110999) {
                return LCT("其他");
            }
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var auditMessage = d.auditMessage;
            auditMessage_arr.push(auditMessage);
            if (d.auditMessage == null || d.auditMessage == undefined) {
                return " ";
            }
            return '<p class="remark"></p>';
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var videoLogName = videoName_arr[i];
            var remark_html = auditMessage_arr[i];
            console.log(remark_html);
            $(tr[i]).find("p.videoLogName").attr("title", videoLogName).text(videoLogName);
            $(tr[i]).find("p.remark").attr("title", remark_html).text(remark_html);
        }
        videoName_arr=[];
        auditMessage_arr=[];
    }
};
var auditLogFn = {
    init: function() {
        this.handleTable(); //表格数据筛选
        this.derivedExcel(); //Excel导出
        //this.switchDateEn_init(); //日期插件初始化
    },
    handleTable: function() {
        $("#maintable").lctable(lcsetting);
        //点击审核状态
        $(".search_select").change(function() {
            $(".btn_search").click();
        });
        //点击搜索按钮
        $(".btn_search").bind("click", function() {
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var search_select = $.trim($(".search_select").val());
            var fromtime = $.trim($(".fromtime").val());
            var totime = $.trim($(".totime").val());
            var action = $(".search_select option:selected").val();
            if (action) {
                params["action"] = action;
            } else {
                delete params["action"];
            }
            if (fromtime) {
                params.auditTimeStart = fromtime;
            } else {
                delete params["auditTimeStart"];
            }
            if (totime) {
                params.auditTimeEnd = totime;
            } else {
                delete params["auditTimeEnd"];
            }
            if (value_name) {
                params["videoName"] = value_name;
            } else {
                delete params["videoName"];
            }
            if (value_id) {
                params["videoId"] = value_id;
            } else {
                delete params["videoId"];
            }
            if (search_select) {
                params["action"] = search_select;
            } else {
                delete params["action"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    derivedExcel: function() {
        checkall("#modal-rizhi-excel");
        $("#btn-excel").attr("href", "");
        $("#btn-excel").click(function() {
            var length = $("#maintable tbody td[colspan='7']").length;
            if (length) {
                alertfn.danger(LCT("没有要导出的审核日志"));
            } else {
                $("#btn-excel").attr("href", "#modal-rizhi-excel");
            }
        });
        $("#modal-rizhi-excel").on('hide.bs.modal', function() {
            $("#btn-excel").attr("href", "");
        });
        $("#modal-rizhi-excel").on("click", ".btn-ok", function() {
            var arr_hearders = [];
            var arr_fields = [];
            var arr_customCategoryId = [];
            var arr_videos = [];
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var value_status = $.trim($(".search_select").val());
            var fromtime = $.trim($(".fromtime").val());
            var totime = $.trim($(".totime").val());
            var checkbox = $("#modal-rizhi-excel input:checkbox");
            var checkbox_table = $("#maintable tbody input:checkbox");
            var setClass_option = $("#setClass option:selected");
            for (i = 0; i < setClass_option.length; i++) {
                var data_id = $(setClass_option[i]).attr("data-id");
                if (data_id != undefined) {
                    arr_customCategoryId.push(data_id);
                }
            }
            var customCategoryId = arr_customCategoryId[arr_customCategoryId.length - 1];
            for (var i = 1; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    arr_hearders.push($(checkbox[i]).closest("label").text());
                    arr_fields.push($(checkbox[i]).val());
                }
            }
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    arr_videos.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            if (arr_hearders.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("未选择任何excel导出项"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            } else {
                var url = basePath + "exportExcelAuditLog.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                if (fromtime) {
                    url += "&auditTimeStart=" + fromtime;
                }
                if (totime) {
                    url += "&auditTimeEnd=" + totime;
                }
                if (value_name) {
                    url += "&videoName=" + value_name;
                }
                if (value_id) {
                    url += "&videoId=" + value_id;
                }
                if (value_status) {
                    url += "&action=" + value_status;
                }
                if (customCategoryId) {
                    url += "&customCategoryId=" + customCategoryId;
                }
                if (arr_videos.length) {
                    url += "&videoIds=" + arr_videos;
                }
                window.open(url, "_blank");
            }
        });
    },
    switchDateEn_init: function() {
        $(".fromtime").val(vrsFn.GetDateStr(-7, 0));
        $(".totime").val(vrsFn.GetDateStr(0, 0));
        var startTime = $("#d4311").val();
        var endTime = $("#d4312").val();
        if (lctu.getLanguage() == "en") {
            $("#d4311-result").val(vrsFn.formatDateEn_short(startTime));
            $("#d4312-result").val(vrsFn.formatDateEn_short(endTime));
        } else {
            $("#d4311-result").val(startTime);
            $("#d4312-result").val(endTime);
        }
    }
};
$(function() {
    auditLogFn.init();
})