package com.cnlive.mam.task;

import com.alibaba.fastjson.JSON;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.StorageService;
import com.ksyun.ks3.exception.Ks3ClientException;
import com.ksyun.ks3.exception.serviceside.NoSuchKeyException;
import com.ksyun.ks3.http.HttpClientConfig;
import com.ksyun.ks3.service.Ks3;
import com.ksyun.ks3.service.Ks3Client;
import com.ksyun.ks3.service.Ks3ClientConfig;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.BucketManager;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.model.BatchStatus;
import com.qiniu.util.Auth;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by zhangxiaobin on 2017/5/9.
 */
@Component
public class DeleteResourcePublic {

    private static Logger _log = LoggerFactory.getLogger(DeleteResourcePublic.class);

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "storageService")
    private StorageService storageService;

    @Value("#{configProperties['upload.Ks3.config.AK']}")
    private String accessKeyID;

    @Value("#{configProperties['upload.Ks3.config.SK']}")
    private String accessKeySecret;

    @Value("#{configProperties['qiniu.AK']}")
    String qiniu_ksConfigAK;
    @Value("#{configProperties['qiniu.Sk']}")
    String qiniu_ksConfigSK;

    @Value("#{configProperties['devMode']}")
    private String devMode;

    public boolean deleteVideo(VideoModel video){
        if (!Boolean.parseBoolean(devMode)) {
            Map<String,String> map = new HashMap<String,String>();
            Map<String,String> mapDir = new HashMap<String,String>();
            List<String> fileList = new ArrayList<>();

            String picOriginal = video.getPicOriginal();

            Integer storageId = video.getStorageId();

            StorageModel storageVideo = storageService.getById(storageId);
            boolean isKsYun = true;
            boolean isQnYun = false;
            String bucketName = "";
            bucketName = storageVideo.getName();
            if(StorageTypeEnum.KSYUN.getDbValue() == storageVideo.getType().getDbValue()){
                isKsYun = true;
            }
            if(StorageTypeEnum.QINIUYUN.getDbValue() == storageVideo.getType().getDbValue()){
                isQnYun = true;
            }

            //抽帧失败的视频，找不到抽帧图片，不进行查找删除
            if(StringUtils.isNotBlank(picOriginal)) {
                picOriginal = picOriginal.substring(picOriginal.indexOf(Const.SEPARATE_XIE + video.getSpid() + Const.SEPARATE_XIE) + 1);
                //抽帧的图片为8张，默认文件名为00001.jpg至00008.jpg
                for (int i = 1; i <= 8; i++) {
                    if(isKsYun) {
                        map.put(picOriginal + "0000" + i + ".jpg", bucketName);
                    }
                    if(isQnYun){
                        fileList.add(picOriginal + "00000" + i + ".jpg");
                    }
                }

            }

            List<FileModel> files = fileService.getByVid(video.getVideoId());
            for(FileModel file : files){
                if(StringUtils.isNotBlank(file.getStoreUri())){
                    if(isKsYun) {
                        mapDir.put(file.getStoreUri(),bucketName);
                    }
                    if(isQnYun){
                        fileList.add(file.getStoreUri());
                    }
                }
                if(StringUtils.isNotBlank(file.getOriginUri())){
                    if(isKsYun) {
                        map.put(file.getOriginUri(), bucketName);
                    }
                    if(isQnYun){
                        fileList.add(file.getOriginUri());
                    }
                }
            }
            if(isKsYun) {
                Boolean deleteFile = ks3DeleteFile(map, bucketName, false);
                Boolean deleteDir = ks3DeleteFile(mapDir, bucketName, true);
                return deleteFile && deleteDir;
            }
            if(isQnYun && fileList != null && fileList.size() > 0){
                qnDeleteFile(bucketName, fileList.toArray(new String[fileList.size()]));
                return true;
            }

        }
        return true;
    }


    /**
     *
     * 从金山服务器中删除文件
     * @param map 参数key:fileUrl,value:bucket
     *
     */
    private Boolean ks3DeleteFile(Map<String,String> map,String bucketName, boolean dirDel){
        boolean result = false;
        try{
            Ks3ClientConfig config = new Ks3ClientConfig();
            config.setProtocol(Ks3ClientConfig.PROTOCOL.http);
            //true表示以   region/{bucket}/{key}的方式访问；false表示以  {bucket}.region/{key}的方式访问
            config.setPathStyleAccess(false);
            HttpClientConfig hconfig = new HttpClientConfig();
            //在HttpClientConfig中可以设置httpclient的相关属性，比如代理，超时，重试等。
            config.setHttpClientConfig(hconfig);
            Ks3 client = new Ks3Client(accessKeyID,accessKeySecret,config);
            for(String fileUrl : map.keySet()){
                if(fileUrl == null){
                    continue;
                }

                try{
                    if(dirDel){
                        String dir = fileUrl.substring(0,fileUrl.lastIndexOf("/")+1);
                        client.removeDir(bucketName,dir);
                    }else{
                        client.deleteObject(map.get(fileUrl),fileUrl);
                    }
                }catch(NoSuchKeyException e){
                    _log.info("fileUrl："+fileUrl+" 已删除");
                }catch(Ks3ClientException e){
                    _log.error(e.getMessage());
                }catch(Exception e){
                    _log.error(e.getMessage());
                    return false;
                }
                _log.info("ks3DeleteFile! bucket:"+map.get(fileUrl)+" | fileUrl:"+fileUrl);
            }
            result = true;
        }catch (Exception ex){
            _log.error("删除金山文件失败,删除参数：{}  ， 错误信息：{}", JSON.toJSONString(map),ex);
        }
        return result;
    }

    private void qnDeleteFile(String bucketName,String... keyList){
        Configuration configuration = new Configuration(Zone.autoZone());
        Auth auth = Auth.create(qiniu_ksConfigAK, qiniu_ksConfigSK);
        BucketManager bucketManager = new BucketManager(auth,configuration);
        try {
            BucketManager.BatchOperations batchOperations = new BucketManager.BatchOperations();
            batchOperations.addDeleteOp(bucketName, keyList);
            Response response = bucketManager.batch(batchOperations);
            BatchStatus[] batchStatusList = response.jsonToObject(BatchStatus[].class);
            for (int i = 0; i < keyList.length; i++) {
                BatchStatus status = batchStatusList[i];
                if (status.code != 200) {
                    _log.error("qn delete file error ={}",status.data.error);
                }
            }
        } catch (QiniuException ex) {
            _log.error("qn delete file error ={}",ex.response.toString());
        }

    }


}
