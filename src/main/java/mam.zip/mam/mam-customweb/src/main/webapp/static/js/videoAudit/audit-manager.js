var params = {},videoName_arr=[],
    ids = "";
var lcsetting = {
    "ajax": basePath + "videoController/dataGrid.do?onoffStatus=1,4&sucai=0",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
                return '<input type="checkbox" flag="true" data-id="' + d.videoId + '" value="" name="ck" class="checkItem">';
        }
        }, {
            "data": "lcall",
            "format": function(i, j, d) { //基本信息
                var videoName = d.videoName;
                videoName_arr.push(videoName);
                return '<dl class="clearfix">' +
                    '<dt class="ui-fl img">' +
                    '<a class="video-view"  videoPlyUrl =' + d.playUrl + ' videoPlyImgUrl = '+ d.listPicUrl +' href="#modal-video-view" data-toggle="modal" ><img src=' + getListPicUrl(d.listPicUrl) + '></a>' +
                    '</dt>' +
                    '<dd class="ui-fl album-info">' +
                    '<p>' + LCT("ID") + '：' + d.businessUUID + '</p>' +
                    '<p class="videoName"></p>' +
                    '<p>' + LCT("时长") + '：<span class="video-duration">' + vrsFn.formatSeconds(d.duration) + '</span></p>' +
                    '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                    '</dd>' +
                    '</dl>';
            }
        },
        {
            "data": "lcall",
            "format": function(i, j, d) { //上传时间
                return d.createTime;
            }
        },
       {
           "data": "lcall",
           "format": function(i, j, d) {
               function parese(s) {
                   if (s == 1) {
                       return '<span class="link-blue-txt">' + LCT("待送审") + '</span>';
                   }
                   if (s == 4) {
                       return '<span class="link-blue-txt">' + LCT("审核拒绝") + '</span>';
                   }
               }
               return parese(d.status); //视频审核状态
           }
       },{
            "data": "lcall",
            "format": function(i, j, d) {
                var content = '<a href="javascript:void(0)" lc_inner_href="' + basePath + 'videoController/toVideoView.do?videoId=' + d.videoId + '" class="video-audit ml-10" data-id="' + d.videoId + '">' + LCT("查看") + '</a>';
                if(d.status == 4){
                    content = content + '<a href="javascript:void(0)"  class="video-auditMes ml-10" data-id="' + d.videoId + '">' + LCT("拒绝原因") + '</a>';
                }
                content = content + '<a href="javascript:void(0)"  class="video-sent ml-10" data-id="' + d.videoId + '">' + LCT("送审") + '</a>';
                return content;
            }
        }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
//    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); //table
        //视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(LCT("名称") + '：'+remark_html);
            $(tr[i]).find("a.video-view").attr("data-name", remark_html);
            $(tr[i]).find("a.playbackSettings").attr("data-name", remark_html);
        }
        videoName_arr=[];
    }
};
var auditFn = {
    init: function() {
        this.freeCheckNew(); //免审设置(新)
        this.check(); //审核
        this.editPreview(); //编辑预览
        this.derivedExcel(); //Excel导出
        this.handleTable(); //表格数据筛选
        this.edit(); //表格数据筛选
        this.switchDateEn_init(); //日期插件初始化
        this.videoSent(); //送审
        this.getAuditMessage();//查看失败信息
    },
    getAuditMessage: function(){
    	$("#maintable").on("click", ".video-auditMes", function() {
        	var videoId = $(this).attr("data-id");
        	$.ajax({
                type: "GET",
                url: basePath + 'videoController/getAuditMessage.do?videoId='+videoId,
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function(data) {
                    var showMsg = {};
                    showMsg.discription = LCT("拒绝原因:"+data.obj[0].auditMessage);
//                    showMsg.iconType = "success";
                    showMsg.confirmBtn = true;
                    $("body").toolsalert(showMsg);
                    return;
                }
            });
    	})
    },
    videoSent: function(){
    	$("#maintable").on("click", ".video-sent", function() {
        	var obj = {};
            var data_id = [];
        	data_id.push($(this).attr("data-id"));
        	obj.videoIds = data_id;
        	$.ajax({
                type: "post",
                url: basePath + 'videoController/videoAudit.do',
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function(data) {
                    var showMsg = {};
                    if (data.success) {
                        $(".btn_search").click();
                        showMsg.discription = LCT("送审成功");
                        showMsg.iconType = "success";
                        showMsg.confirmBtn = true;
                    } else {
                        showMsg.title = LCT("错误"),
                        showMsg.discription = LCT("送审失败，请重试");
                        showMsg.iconType = "triangle";
                        showMsg.confirmBtn = true;
                    }
                    $("body").toolsalert(showMsg);
                    return;
                }
            });
    	})
    },
    editPreview: function() {
        $("#maintable").on("click", ".video-edit", function() {
            var customCategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumId");

            if (categoryId && categoryId != "" && categoryId != "0") {
                var lc_inner_href = basePath + "videoController/toVideoEdit.do?videoId=" + videoId;
                showInIFrame(lc_inner_href);
            } else {
                if (albumId != null && albumId != 0) {
                    var params = {
//                        "discription": LCT("请先对专辑") + albumId + LCT("进行分类设置"),
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    }
                } else {
                    var params = {
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                }
                $("body").toolsalert(params);
                return;
            }
        });
        $("#maintable").on("click", ".video-view", function() {
            var videoPlyUrl = $(this).attr("videoPlyUrl");
            var data_name = $(this).attr("data-name");
            var imgUrl = $(this).attr("videoPlyImgUrl");
            if(imgUrl == "" || imgUrl == null || imgUrl == undefined || imgUrl == "null" || imgUrl == "undefined"){
                imgUrl = "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
            }else {
                imgUrl = imgUrl ;
            }
            $("#cnlivePlayer").attr("flashVars","type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1&currRate=2&cover="+imgUrl+"&videoUrl_2="+videoPlyUrl);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $('#modal-video-view').on('hide.bs.modal', function() {
            // $("#player").html("");
        });
    },
    checkallAudit: function(parent, checkItem, checkall) {
        $(parent).on("click", checkItem, function() {
            var b = $(parent).find(checkItem).length == $(checkItem + ":checked").length ? true : false;
            $(parent).find(checkall).prop("checked", b);
        });
        $(parent).on("click", checkall, function() {
            if ($(checkall).is(":checked")) {
                $(parent).find(checkItem).prop("checked", "checked");
            } else {
                $(parent).find(checkItem).prop("checked", false);
            }
        });
    },
    freeCheckNew: function() {
        var category_dl = [];
        checkall("#catagoryCon"); //数据分类免审全选
        //渲染免审弹框
        //数据分类免审
        $("#openAuditSettings").attr("href", "");
        $("#openAuditSettings").on('click', function() {
            $("#customCatagoryCon dl").addClass("hide");
            $.getJSON(
                basePath + "customCategoryController/freeAuditDisplay.do",
                function(data) {
                    if (data.success) {
                        $("#modal-mianshenhe-set").modal('show');
                        var system_channel = '';
                        var customCatagory = '';
                        customCatagory += '<option data-id="0" selected="">' + LCT("请选择") + '</option>';
                        for (var i = 0; i < data.obj.length; i++) {
                            var categoryName = data.obj[i].categoryName;
                            var categoryValue = data.obj[i].categoryValue;
                            var auditSetting = data.obj[i].auditSetting;
                            if (auditSetting == '1') {
                                system_channel += '<label class="checkbox-inline" title="' + categoryName + '"><input class="checkItem" type="checkbox" checked value="' + categoryValue + '">' + categoryName + '</label>';
                            } else {
                                system_channel += '<label class="checkbox-inline" title="' + categoryName + '"><input class="checkItem" type="checkbox" value="' + categoryValue + '">' + categoryName + '</label>';
                                customCatagory += '<option data-id="' + categoryValue + '">' + categoryName + '</option>';
                            }
                            auditFn.checkallAudit("#dlCon", ".checkItem_" + categoryValue, ".checkall_" + categoryValue);
                        }
                        $("#catagoryCon dd").html(system_channel);
                        $(".systemCatagory").html(customCatagory);
                        $("#catagoryCon").find(".checkall").prop("checked", false);
                    } else {
                        alertfn.danger(data.msg)
                    }
                }
            );
        });
        //数据分类--全部
        $("#catagoryCon").on("click", ".checkall", function() {
            if ($(this).is(":checked")) {
                $("#customCatagoryCon").hide();
            } else {
                var checkItem = $("#catagoryCon .checkItem");
                var html = '';
                html += ' <option data-id="0">' + LCT("请选择") + '</option>';
                for (var i = 0; i < checkItem.length; i++) {
                    var categoryId = $(checkItem[i]).val();
                    var categoryName = $(checkItem[i]).parent().text();
                    if (!$(checkItem[i]).is(":checked")) {
                        html += '<option data-id="' + categoryId + '">' + categoryName + '</option>';
                    }
                }
                $(".systemCatagory").html(html).attr("data-id", 0).removeAttr("data-oldid");
                $("#customCatagoryCon").show();
            }
        });
        //数据分类--checkItem,关联自定义分类
        $("#catagoryCon").on("click", ".checkItem", function() {
            var categoryId = $(".systemCatagory").attr("data-id");
            if ($(".checkall_" + categoryId).is(":checked")) {
                $("input[value='" + categoryId + "']").prop("checked", true);
                $(".systemCatagory option[data-id='" + categoryId + "']").remove();
                $(".checkall_" + categoryId).prop("checked", false);
                $(".checkItem_" + categoryId).prop("checked", false);
            }
            var b = $("#catagoryCon").find(".checkItem").length == $("#catagoryCon").find("input.checkItem:checked").length ? true : false;
            var checkItem = $("#catagoryCon .checkItem");

            if (b) {
                $("#customCatagoryCon").hide();
            } else {
                var html = '';
                html += ' <option data-id="0">' + LCT("请选择") + '</option>';
                for (var i = 0; i < checkItem.length; i++) {
                    var categoryId = $(checkItem[i]).val();
                    var categoryName = $(checkItem[i]).parent().text();
                    if (!$(checkItem[i]).is(":checked")) {
                        html += '<option data-id="' + categoryId + '">' + categoryName + '</option>';
                    }
                }
                $(".systemCatagory").html(html).attr("data-id", 0).removeAttr("data-oldid");
                $("#customCatagoryCon").show();
                $("#customCatagoryCon dl").addClass("hide");
            }
        });
        //自定义分类免审,上一次操作
        $(".systemCatagory").click(function() {
            var categoryId = $(".systemCatagory").attr("data-id");
            var checkall = $("#customCatagoryCon .checkall_" + categoryId);
            if (checkall.is(":checked")) {
                $(".systemCatagory").attr("flag-checkall", 1);
            } else {
                $(".systemCatagory").attr("flag-checkall", 0);
            }
            $(".systemCatagory").attr("data-oldId", categoryId);
        });
        //自定义分类免审,本次操作
        $(".systemCatagory").on("change", function() {
            var categoryOldId = $(".systemCatagory").attr("data-oldId");
            var flag_checkall = $(".systemCatagory").attr("flag-checkall");
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory").attr("data-id", categoryId);
            if (flag_checkall == '1') { //自定义全选
                $("input[value='" + categoryOldId + "']").prop("checked", true);
                $(".systemCatagory option[data-id='" + categoryOldId + "']").remove();
                $(".checkall_" + categoryOldId).prop("checked", false);
                $(".checkItem_" + categoryOldId).prop("checked", false);
            }
            if (categoryId == '0') {
                $("#customCatagoryCon dl").addClass("hide");
            } else {
                category_dl.push(categoryId);
                if (unique(category_dl).length == category_dl.length) { //是否重新请求接口
                    $.getJSON(
                        basePath + "customCategoryController/dataGrid.do?category=" + categoryId,
                        function(data) {
                            var html = '';
                            html += '<dl class="dl_category clearfix dl_' + categoryId + '">';
                            if (data.length) {
                                html += '<dt><label class="checkbox-inline"><input class="checkall_' + categoryId + '" type="checkbox" value="">' + LCT("全部") + '</label></dt>';
                                html += '<dd>';
                                for (var i = 0; i < data.length; i++) {
                                    var customCategory_id = data[i].id;
                                    var customCategory_name = data[i].text;
                                    var auditSetting = data[i].auditSetting;
                                    html += '<label  title="' + customCategory_name + '" class="checkbox-inline">';
                                    if (auditSetting == '1') {
                                        html += '<input class="checkItem_' + categoryId + '" type="checkbox" checked value="' + customCategory_id + '">';
                                    } else {
                                        html += '<input class="checkItem_' + categoryId + '" type="checkbox" value="' + customCategory_id + '">';
                                    }

                                    html += customCategory_name + '</label>';
                                }
                                html += '</dd>';
                            } else {
                                html += '<dd><p class="text-center" style="padding:15px 0 10px;">' + LCT("该数据下暂无自定义分类") + '</p></dd>';
                            }


                            html += '</dl>';
                            $(".dl_category").addClass("hide");
                            $("#dlCon").append(html);
                        }
                    );
                } else {
                    category_dl = unique(category_dl);
                    $(".dl_" + categoryId).removeClass("hide").siblings().addClass("hide");
                }
                $("#customCatagoryCon").find(".checkall").prop("checked", false);
            }
        });
        //提交免审
        $("#modal-mianshenhe-set").on("click", ".btn-ok", function() {
            var category_arr = [];
            var customCategory_arr = [];
            var checkbox = $("#catagoryCon").find("input.checkItem");
            var checkItem = $("#customCatagoryCon").find("input");
            var categoryId = $(".systemCatagory").attr("data-id");
            if ($(".checkall_" + categoryId).is(":checked")) {
                $("input[value='" + categoryId + "']").prop("checked", true);
                $(".systemCatagory option[data-id='" + categoryId + "']").remove();
                $(".checkall_" + categoryId).prop("checked", false);
                $(".checkItem_" + categoryId).prop("checked", false);
            }
            //数据分类
            for (var i = 0; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    category_arr.push($(checkbox[i]).val());
                }
            }
            //自定义分类
            for (var i = 0; i < checkItem.length; i++) {
                if (checkItem[i].checked) {
                    customCategory_arr.push($(checkItem[i]).val());
                }
            }
            $.post(basePath + "customCategoryController/freeAudit.do", {
                categoryIds: category_arr.join(',') || '-1',
                customCategoryIds: customCategory_arr.join(',') || '-1'
            }, function(data) {
                if (data.success) {
                    var params = {
                        "discription": LCT("设置成功"),
                        "iconType": "success",
                        "confirmBtn": true
                    };
                } else {
                    var params = {
                        "title": LCT("错误"),
                        "discription": data.msg,
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                }
                $("body").toolsalert(params);
                return;
            }, 'JSON');
        });
        $("#modal-mianshenhe-set").on('hide.bs.modal', function() {
            category_dl = [];
            $("#dlCon").html("");
        });
    },
    check: function() {
        //单个审核渲弹框
        $("#maintable").on("click", ".check-single", function() {
            var data_id = $(this).attr("data-id");
            $("#modal-videoverify").addClass("modal-videoverify-single");
            $("#modal-videoverify").attr("data-id", data_id);
            $("#modal-videoverify").find(".btn-check").attr("flag", 1);
            $.post(basePath + 'videoController/getVideoInfoById.do', {
                videoId: data_id
            }, function(result) {
                if (result.success) {
                    var v = result.obj;
                    var single_html = '';
                    single_html += '<div id="player" style="height:315px;margin: 11px 10px 10px 6px; width: 570px;"></div>';
                    single_html += '<p><span>' + LCT("视频") + 'ID：</span><span>' + v.videoId + '</span></p>';
                    single_html += '<p><span>' + LCT("视频名称") + '：</span><span class="video-name"></span>';
                    single_html += '<span class="ml-50">' + LCT("副标题") + '：</span>';
                    if (v.subTitle && v.subTitle != null && v.subTitle != "") {
                        single_html += '<span>' + v.subTitle + '</span>';
                    }
                    single_html += '</p>';
                    single_html += '<p class="over-text"><span>' + LCT("视频简介") + '：</span>';
                    if (v.synopsis && v.synopsis != null && v.synopsis != "") {
                        single_html += '<span class="text-overflow">' + v.synopsis + '</span>';
                    }
                    single_html += '</p>';
                    $("#modal-videoverify").find(".verify-left").addClass("veriry-single").html(single_html);
                    $("#modal-videoverify").find("span.video-name").text(v.videoName);

                    var player = new CloudVodPlayer();
                    var language = window.lctu.getLanguage();
                    var player_obj = {
                        uu: v.customId,
                        vu: v.videoId,
                        p: 21,
                        pu: 6,
                    };
                    if (language == "en") {
                        player_obj.lang = "en_US";
                    } else {
                        delete(player_obj.lang);
                    }
                    player.init(player_obj, "player");
                } else {
                    alert(result.msg);
                }
            }, 'JSON');
        });

        //批量审核渲弹框
        $("#maintable").on("click", ".check-all", function() {
            $(this).attr("href", "");
            var check_all_data_id = [];
            var check_all_custom_id = [];
            var check_all_data_img = [];
            var check_all_data_name = [];
            var maintable_checkItem_arr = $("#maintable .checkItem:checked");
            $(maintable_checkItem_arr).each(function(i) {
                check_all_data_id.push($(maintable_checkItem_arr).eq(i).attr("data-id"));
                check_all_custom_id.push($(maintable_checkItem_arr).eq(i).attr("custom-id"));
                check_all_data_img.push($(maintable_checkItem_arr).eq(i).closest("tr").find("dt img").attr("src"));
                check_all_data_name.push($(maintable_checkItem_arr).eq(i).closest("tr").find("dd p:first").html());
            });
//            for (var i = 0; i < maintable_checkItem_arr.length; i++) {
//                if ($(maintable_checkItem_arr[i]).attr("flag")) {
//                    $(maintable_checkItem_arr[i]).closest("tr").addClass("warning");
//                }
//            }
//            for (var i = 0; i < maintable_checkItem_arr.length; i++) {
//                if ($(maintable_checkItem_arr[i]).attr("flag")) {
//                    var params = {
//                        "title": LCT("错误"),
//                        "discription": LCT("所选视频中包含待编辑、未转码完成或已审核的视频"),
//                        "iconType": "triangle",
//                        "confirmBtn": true
//                    };
//                    $("body").toolsalert(params);
//                    return;
//                }
//            }
            if (maintable_checkItem_arr.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("请先选中一条记录"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            } else {
                $(this).attr("href", "#modal-videoverify");
                $("#modal-videoverify").find(".verify-left").removeClass("veriry-single");
                $("#modal-videoverify").find(".btn-check").attr("flag", 0);
                var all_html = '';
                all_html += '<ul>';
                for (var i = 0; i < maintable_checkItem_arr.length; i++) {
                    all_html += '<li custom-id=' + check_all_custom_id[i] + ' data-id=' + check_all_data_id[i] + '>';
                    all_html += '<p><img src=' + check_all_data_img[i] + ' alt=""><i class="icon-video"></i></p>';
                    all_html += '<label class="checkbox-inline"><input class="icheckSquareGreen" type="checkbox" checked data-id=' + check_all_data_id[2 * i] + ' value="">' + check_all_data_name[i] + '</label>';
                    all_html += '</li>';
                }
                all_html += '</ul>';

                $("#modal-videoverify").find(".verify-left").html(all_html);
                $('.icheckSquareGreen').iCheck({
                    cursor: true,
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                    increaseArea: '20%'
                });
            }
        });
        $("#maintable").on("click", ".checkItem", function() {
            $(this).closest("tr").removeClass("warning");
        });
        //批量审核--预览
        $("#modal-videoverify").on("click", ".modal-videoverify li", function() {
            var $this = $(this);
            var uu = $this.attr("custom-id");
            var vu = $this.attr("data-id");
            $this.siblings().find("#player").remove().end().find("p").show();
            $this.find("p").hide();
            if ($this.find("#player").length == 0) {
                $this.prepend('<div id="player" style="width:180px;height:100px;"></div>');
                var player = new CloudVodPlayer();
                var language = window.lctu.getLanguage();
                var player_obj = {
                    uu: uu,
                    vu: vu,
                    p: 21,
                    pu: 6,
                    skinnable: 0
                };
                if (language == "en") {
                    player_obj.lang = "en_US";
                } else {
                    delete(player_obj.lang);
                }
                player.init(player_obj, "player");
            }
        });
        //审核结果
        $(".icheckFlatRed").on("ifChecked", function() {
            var $this = $(this);
            var index = $this.closest(".form-group").index();
            if (index == 1) {
                $this.closest(".verify-right").find(".check-reason").show();
            } else {
                $this.closest(".verify-right").find(".check-reason").hide();
            }
        });
        $('#modal-videoverify').on('hide.bs.modal', function() {
            $("#player").html("");
        });
        //提交审核结果
        $(".btn-check").click(function() {
        	var maintable_checkItem_arr = $("#maintable .checkItem:checked");
        	var obj = {};
            var data_id = [];
        	for (var i = 0; i < maintable_checkItem_arr.length; i++) {
        		data_id.push(maintable_checkItem_arr[i].attributes[2].nodeValue);
            }
        	obj.videoIds = data_id;
        	
        	
        	
        	
//            var cur_modal = $(this).closest(".modal");
//            var obj = {};
//            var data_id = [];
//            if ($(this).attr("flag") == "1") {
//                data_id.push(cur_modal.attr("data-id"));
//            } else {
//                var icon_checkbox = cur_modal.find(".verify-left .icheckbox_square-green");
//                if (icon_checkbox.length == 0) {
//                    return;
//                }
//                for (var i = 0; i < icon_checkbox.length; i++) {
//                    if ($(icon_checkbox[i]).hasClass("checked")) {
//                        data_id.push($(icon_checkbox[i]).closest("li").attr("data-id"));
//                    }
//                }
//            }
//            var value1 = cur_modal.find(".iradio_flat-red.checked").find("input").val();
//            var value2 = cur_modal.find(".check-reason").find("select").val();
//            var value3 = cur_modal.find("textarea").val();
//            obj.videoIds = data_id;
//            obj.action = value1;
//            if (value1 == "4") {
//                obj.auditReason = value2;
//            } else {
//                obj.auditReason = "";
//            }
//            obj.auditMessage = value3;
            if (obj.videoIds.length) {
                $.ajax({
                    type: "post",
                    url: basePath + 'videoController/videoAudit.do',
                    data: JSON.stringify(obj),
                    contentType: "application/json; charset=utf-8",
                    dataType: 'json',
                    success: function(data) {
                        var showMsg = {};
                        if (data.success) {
                            $(".btn_search").click();
                            showMsg.discription = LCT("送审成功");
                            showMsg.iconType = "success";
                            showMsg.confirmBtn = true;
                        } else {
                            showMsg.title = LCT("错误"),
                            showMsg.discription = LCT("送审失败");
                            showMsg.iconType = "triangle";
                            showMsg.confirmBtn = true;
                        }
                        $("body").toolsalert(showMsg);
                        return;
                    }
                });
            } else {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("请先选中一条记录"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            }
//            cur_modal.find(".icheckFlatRed").iCheck('uncheck').first().iCheck('check');
//            cur_modal.find(".check-reason").val("").hide();
//            cur_modal.find("textarea").val("");
        });
    },
    derivedExcel: function() {
        checkall("#modal-excel"); //excel全选
        $("#btn-excel").attr("href", "");
        $("#btn-excel").click(function() {
            var length = $("#maintable tbody td[colspan='6']").length;
            if (length) {
                alertfn.danger(LCT("没有要导出的视频"));
            } else {
                $("#btn-excel").attr("href", "#modal-excel");
            }
        });
        $("#modal-excel").on('hide.bs.modal', function() {
            $("#btn-excel").attr("href", "");
        });
        $("#modal-excel").on("click", ".btn-ok", function() {
            var arr_hearders = [];
            var arr_fields = [];
            var arr_customCategoryId = [];
            var arr_videos = [];
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var value_status = $.trim($(".search_select").val());
            var fromtime = $.trim($(".fromtime").val());
            var totime = $.trim($(".totime").val());
            var checkbox = $("#modal-excel input:checkbox");
            var checkbox_table = $("#maintable tbody input:checkbox");
            var setClass_option = $("#setClass option:selected");
            for (i = 0; i < setClass_option.length; i++) {
                var data_id = $(setClass_option[i]).attr("data-id");
                if (data_id != undefined) {
                    arr_customCategoryId.push(data_id);
                }
            }
            var customCategoryId = arr_customCategoryId[arr_customCategoryId.length - 1];
            for (var i = 1; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    arr_hearders.push($(checkbox[i]).closest("label").text());
                    arr_fields.push($(checkbox[i]).val());
                }
            }
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    arr_videos.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            if (arr_hearders.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("未选择任何excel导出项"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            } else {
                var url = basePath + "exportExcelAuditVideo.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                if (fromtime) {
                    url += "&startTime=" + fromtime;
                }
                if (totime) {
                    url += "&endTime=" + totime;
                }
                if (value_name) {
                    url += "&videoName=" + value_name;
                }
                if (value_id) {
                    url += "&videoId=" + value_id;
                }
                if (value_status) {
                    url += "&auditStatus=" + value_status;
                }
                if (customCategoryId) {
                    url += "&customCategoryId=" + customCategoryId;
                }
                if (arr_videos.length) {
                    url += "&videoIds=" + arr_videos;
                }
                window.open(url, "_blank");
            }
        });
    },
    handleTable: function() {
        //初始化表格
        params["auditStatus"] = 5;
        params["fileStatus"] = 2;
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".btn_search").bind("click", function() {
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var value_status = $.trim($(".search_select").val());
            var fromtime = $.trim($(".fromtime").val());
            var totime = $.trim($(".totime").val());
            if (fromtime) {
                params.startTime = fromtime;
            } else {
                delete params["startTime"];
            }
            if (totime) {
                params.endTime = totime;
            } else {
                delete params["endTime"];
            }
            if (value_name) {
                params["videoName"] = value_name;
            } else {
                delete params["videoName"];
            }
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
//            if (value_status) {
//                params["auditStatus"] = value_status;
//            } else {
//                delete params["auditStatus"];
//            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
        //点击审核状态
        $(".search_select").change(function() {
            $(".btn_search").click();
        });
    },
    edit: function() {
        $("#maintable").on("click", ".video-audit", function() {
            showInIFrame($(this).attr("lc_inner_href"));
        });
    },
    switchDateEn_init: function() {
        // $(".fromtime").val(vrsFn.GetDateStr(-7, 0));
        // $(".totime").val(vrsFn.GetDateStr(0, 0));
        // var startTime = $("#d4311").val();
        // var endTime = $("#d4312").val();
        // $("#d4311-result").val(startTime);
        // $("#d4312-result").val(endTime);
    }
};
$(function() {
        auditFn.init();
    })
    //编辑-返回

function closeIframeFromOuter(type) {
    videoName_arr=[];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}