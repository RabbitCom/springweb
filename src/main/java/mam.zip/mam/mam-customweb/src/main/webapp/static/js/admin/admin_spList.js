/**
 * Created by zhangxiaobin on 2017/6/6.
 */
var params = {}
var lcsetting = {
    "ajax": basePath + "admin/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [ {
        "data": "spId",
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            return d.bucketName || '' ;
        }
    },
    {
        "data": "lcall",
        "format": function(i, j, d) {
            return d.transcodeDomain || '';
        }
    },
    {
        "data": "lcall",
        "format": function(i, j, d) {
            return d.imgDomain || '';
        }
    },
    {
        "data": "lcall",
        "format": function(i, j, d) {
            // return '<a href="javascript:void(0)" class="spSettings" data="' + d + '" >' + LCT("设置") + '</a>' ;
            return '<a data-toggle="modal" href="#modal-admin-settings"  class="ml-10 admin-settings" ' +
                ' data-spid="'+d.spId+'"' +' data-bn="'+d.bucketName+'"' +
                ' data-pdomain="'+d.transcodeDomain+'"' + ' data-imgdomain="'+d.imgDomain+'"' +
                '>' + LCT("设置") + '</a>';
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "..."
};
var recoverFn = {
    init: function() {
        this.handleTable(); //表格数据筛选
        this.upateSpSetting();
    },
    handleTable: function() {
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".search_select").change(function() {
            $(".btn_search").click();
        });
        $(".btn_search").bind("click", function() {
            var sp_id = $.trim($(".search_id").val());
            if (sp_id) {
                params["spId"] = sp_id;
            } else {
                delete params["spId"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    upateSpSetting: function() {
        $("#maintable").on("click", ".admin-settings", function() {
            var spId = $(this).attr("data-spid");
            var bucketName = $(this).attr("data-bn") || '';
            var playDomain = $(this).attr("data-pdomain") || '';
            var imgDomain = $(this).attr("data-imgdomain") || '';
            $("#admin_spId").val(spId);
            $("#admin_bucketName").val(bucketName=="undefined" ? '' : bucketName);
            $("#admin_transcodeDomain").val(playDomain=="undefined" ? '' : playDomain);
            $("#admin_imgDomain").val(imgDomain=="undefined" ? '' : imgDomain);
        });

        $("#set-admin-settings-ok").on('click', function() {
            // $('#modal-admin-settings').modal('hide');
            // $(".btn_search").click();
            var admin_bucketName = $("#admin_bucketName").val();
            var admin_transcodeDomain = $("#admin_transcodeDomain").val();
            var admin_imgDomain = $("#admin_imgDomain").val();
            var admin_spId = $("#admin_spId").val();
            var boo = true;
            $("#admin_imgDomain_div label").remove();
            $("#admin_transcodeDomain_div label").remove();
            $("#admin_bucketName_div label").remove();
            if(vrsFn.getStringLen(admin_bucketName) < 2 ){
                var html = '<label class="error">' + LCT("请输入bucketName") + '</label>';
                $("#admin_bucketName_div").append(html);
                boo = false;
            }
            if(vrsFn.getStringLen(admin_transcodeDomain) < 2 ){
                var html = '<label class="error">' + LCT("请输入内容播放域名") + '</label>';
                $("#admin_transcodeDomain_div").append(html);
                boo = false;
            }
            if(vrsFn.getStringLen(admin_imgDomain) < 2 ){
                var html = '<label class="error">' + LCT("请输入图片展示域名") + '</label>';
                $("#admin_imgDomain_div").append(html);
                boo = false;
            }

            if(boo){
                $.ajax({
                    url: basePath + "admin/updateSpBucketInfo.do",
                    data: {
                        spId : admin_spId,
                        bucketName: admin_bucketName,
                        transcodeDomain: admin_transcodeDomain,
                        imgDomain:admin_imgDomain
                    },
                    type: "post",
                    dataType: "json",
                    success: function(data) {
                        if (data.success) {
                            $('#modal-admin-settings').modal('hide');
                            alertfn.success(LCT("设置成功"));
                        } else {
                            alertfn.danger(data.msg);
                        }
                        $(".btn_search").click();
                    }
                });
            }

            return false;
        });
        $('#modal-admin-settings').on('hide.bs.modal', function() {
            $("#admin_spId").val("");
            $("#admin_bucketName").val("");
            $("#admin_transcodeDomain").val("");
            $("#admin_imgDomain").val("");
            $("#admin_imgDomain_div label").remove();
            $("#admin_transcodeDomain_div label").remove();
            $("#admin_bucketName_div label").remove();
        });
    }
};
//modal-admin-settings
$(function() {
    recoverFn.init();
});