package com.cnlive.mam.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.SolrRetrieveService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.SolrRetrieveVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by cuilongcan on 7/17/2017.
 */
@Controller
@RequestMapping("solrRetrieve")
public class SolrRetrieveController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(VideoController.class);

    @Resource(name = "videoService")
    private VideoService videoService;
    @Resource(name = "solrRetrieveService")
    private SolrRetrieveService solrRetrieveService;

    @RequestMapping(value = "/dataGrid")
    @ResponseBody
    public DataGrid dataGrid(HttpServletRequest request, VideoCondition condition, String videoName_solr) throws Exception {
        DataGrid dg = new DataGrid();
        if (StringUtils.isEmpty(videoName_solr)) {
            return dg;
        }
        try {
            String keywords = videoName_solr;
            Integer page = condition.getPage();
            Integer rows = condition.getRows();
            Long spId = this.getSpId(request);
            String institutionId = this.getInstitutionId(request);
            String resultJson = solrRetrieveService.getByKeyWord(keywords, page, rows, spId, institutionId);
            if(StringUtils.isEmpty(resultJson)){
                return dg;
            }
            JSONObject resultObj = JSONObject.parseObject(resultJson);
            JSONObject data = resultObj.getJSONObject("data");
            List<SolrRetrieveVo> mamList = data.getJSONArray("mamList").toJavaList(SolrRetrieveVo.class);
            Long total = data.getLong("totalNum");
            List<VideoModel> videoModelList = new ArrayList<>();
            for (SolrRetrieveVo vo : mamList) {
                VideoModel videoModel = videoService.getByBusinessUUID(vo.getId());
//                vo.solrToVideo(videoModel);
                videoModelList.add(videoModel);
            }
            dg = new DataGrid(total, videoModelList);
        } catch (Exception e) {
            _log.error("solor查询视频信息列表失败，参数：{}，错误信息：{}", videoName_solr, e);
        }
        return dg;
    }
}
