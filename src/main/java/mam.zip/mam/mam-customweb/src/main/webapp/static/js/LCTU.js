

window.lctu = {
	getLanguage: function() {
		// return "en";
		var langArr = ["zh_cn", "en", "zh_tw"];
		
		return "zh_cn";

		function getQueryString(key) {
			var url = window.location.href;
			var value = url.match(new RegExp("[?&#]" + key + "=([^&#]*)(&?)", "i"));
			return value ? decodeURIComponent(value[1]) : "";
		}

		function getCookieByKey(key) {
			var cookieArr = document.cookie.split(";");
			for (var i = 0; i < cookieArr.length; i++) {
				var obj = cookieArr[i].split("=");
				if (obj[0] == key) {
					return obj[1];
				}
			}
			return "";
		}

		function getLanguageByPath() {
			var language = "zh_cn";

			var pathArr = window.location.pathname.split("/");
			for (var i = 0; i < langArr.length; i++) {
				if (pathArr.indexOf(langArr[i]) > -1) {
					language = langArr[i];
				}
			}
			return language;
		}
	},
	loadCssSync: function(url) {
		var cssLink = document.createElement("link");
		cssLink.rel = "stylesheet";
		cssLink.rev = "stylesheet";
		cssLink.type = "text/css";
		cssLink.media = "screen";
		cssLink.href = url;
		document.getElementsByTagName("head")[0].appendChild(cssLink);
	},
	loadJsSync: function(js, callback) {
		var script = document.createElement("script");
		script.type = "text/javascript";
		if (script.readyState) { //IE
			script.onreadystatechange = function() {
				if (script.readyState == "loaded" ||
					script.readyState == "complete") {
					script.onreadystatechange = null;
					if (typeof callback != "undefined") {
						callback();
					}
				}
			};
		} else { //Others: Firefox, Safari, Chrome, and Opera
			script.onload = function() {
				if (typeof callback != "undefined") {
					callback();
				}
			};
		}
		script.src = js;
		document.body.appendChild(script);
	},
	formatDateEn: function(d, type) {
		/**
		 * 支持格式：年月日格式：march 8,2016
		 * 			年月日 时分格式：march 8,2016 PM 02:48
		 * 			年月日 时分秒格式：march 8,2016 PM 02:48:12
		 * 	type: 不传时，返回年月日
		 * 		  传m时，返回年月日，时分
		 * 		  传s时，返回年月日，时分秒
		 */
		var s = "";
		var lang = {
			aWeekStr: ["wk", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
			aMonStr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
		};
		var now = d ? new Date(d) : new Date();
		var year = now.getFullYear();
		var month = now.getMonth();
		var date = now.getDate();
		var hour = now.getHours();
		var minute = now.getMinutes();
		var second = now.getSeconds();
		date = date < 10 ? "0" + date : date;
		hour = hour < 10 ? "0" + hour : hour;
		minute = minute < 10 ? "0" + minute : minute;
		second = second < 10 ? "0" + second : second;
		s = hour > 12 ? "PM" : "AM";

		if (!type) {
			return lang.aMonStr[month] + " " + date + ", " + year;
		} else if (type == "m") {
			return lang.aMonStr[month] + " " + date + ", " + year  + " " + hour + ":" + minute+ " " + s;
		} else if (type == "s") {
			return lang.aMonStr[month] + " " + date + ", " + year + "<br>" + hour + ":" + minute + ":" + second + " " + s;
		}
	},
	formatDate: function(d) {
		if (d != null) {
			if (d.trim().indexOf(" ") > -1) {
				return d.split(" ")[0];
			} else {
				var now = new Date(d);
				var year = now.getFullYear();
				var month = now.getMonth() + 1 < 10 ? '0' + (now.getMonth() + 1) : now.getMonth() + 1;
				var date = now.getDate() < 10 ? '0' + now.getDate() : now.getDate();
				return year + "-" + month + "-" + date;
			}
		} else {
			return ' ';
		}
	},
	formatDateL: function(d) {
		var now = new Date(d);
	    var year = now.getFullYear();
	    var month = now.getMonth() + 1;
	    var date = now.getDate();
	    var hour = now.getHours();
	    var minute = now.getMinutes();
	    var second = now.getSeconds();
	    month = month < 10 ? "0" + month : month;
	    date = date < 10 ? "0" + date : date;
	    hour = hour < 10 ? "0" + hour : hour;
	    minute = minute < 10 ? "0" + minute : minute;
	    second = second < 10 ? "0" + second : second;
	    return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
	},
	getTimeZone: function() {
		var timeZoneArr = ['utc-12 夸贾林岛','utc-11 萨摩亚','utc-10 夏威夷','utc-9 阿拉斯加','utc-8 太平洋时间(美国和加拿大)','utc-7 山地时间(美国和加拿大)','utc-6 中部时间(美国和加拿大)','utc-5 东部时间(美国和加拿大)','utc-4：30 加拉加斯','utc-4 大西洋时间（加拿大）','utc-3：30 纽芬兰','utc-3 萨尔瓦多','utc-2 中大西洋','utc-1 亚速尔群岛','utc 英国','utc+1 柏林、法国、丹麦','utc+2 罗马、巴勒斯坦、希腊','utc+3 科威特','utc+4 毛里求斯','utc+5 印度','utc+6 缅甸、尼泊尔','utc+6：30 仰光','utc+7 曼谷','utc+8 北京','utc+9 首尔','utc+9：30 达尔文','utc+10 澳大利亚','utc+11 所罗门群岛','utc+12 新西兰','utc+13 努库阿洛法','utc+14 圣诞岛'];
		var timeZoneArrEn = ['utc-12 夸贾林岛','utc-11 萨摩亚','utc-10 夏威夷','utc-9 阿拉斯加','utc-8 太平洋时间(美国和加拿大)','utc-7 山地时间(美国和加拿大)','utc-6 中部时间(美国和加拿大)','utc-5 东部时间(美国和加拿大)','utc-4：30 加拉加斯','utc-4 大西洋时间（加拿大）','utc-3：30 纽芬兰','utc-3 萨尔瓦多','utc-2 中大西洋','utc-1 亚速尔群岛','utc 英国','utc+1 柏林、法国、丹麦','utc+2 罗马、巴勒斯坦、希腊','utc+3 科威特','utc+4 毛里求斯','utc+5 印度','utc+6 缅甸、尼泊尔','utc+6：30 仰光','utc+7 曼谷','utc+8 Beijing','utc+9 首尔','utc+9：30 达尔文','utc+10 澳大利亚','utc+11 所罗门群岛','utc+12 新西兰','utc+13 努库阿洛法','utc+14 圣诞岛'];
		var zeroZone = "utc 英国";
		var zeroZoneEn = "utc britain";
		if(lctu.getLanguage() == "en"){
			timeZoneArr = timeZoneArrEn;
			zeroZone = zeroZoneEn;
		}
		//获取当前时区
		var d = new Date();
		var str = "";
		var p = d.getTimezoneOffset();
		// var p = 360;
		if(p == 0){
			return zeroZone;
		}
		var dd = p / 60;
		dd = 0-dd;
		dd = dd >0?"+"+dd:dd;
		var i = 0,j=-1;
		for(;i<timeZoneArr.length;i++){
			if(timeZoneArr[i].indexOf(dd+" ")>-1){
				j=i;break;
			}
		}
		return timeZoneArr[j];
	},
	monStr:["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
	isBeimei:function(){
		if (window.location.hostname.indexOf("us") >= 0) {
			return true;
		}else{
			return false;
		}
	}
};


Array.prototype.indexOf = function(val) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == val) return i;
    }
    return -1;
};

Array.prototype.remove = function(val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};

