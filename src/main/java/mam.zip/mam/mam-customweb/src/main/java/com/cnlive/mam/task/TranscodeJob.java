package com.cnlive.mam.task;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.model.*;
import com.cnlive.mam.service.*;
import com.google.common.base.Splitter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.common.utils.Const;

@Component
public class TranscodeJob {
    private static Logger _log = LoggerFactory.getLogger(TranscodeJob.class);
    
    @Resource(name = "transcodeTaskService")
    private TranscodeTaskService transcodeTaskService;

	@Resource(name = "transcodeHistoryService")
	private TranscodeHistoryService transcodeHistoryService;
    
    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;
    
    @Resource(name = "remoteService")
    private RemoteService remoteService;

    @Resource(name = "storageService")
    private StorageService storageService;
    
    @Value("#{configProperties['transOverCall_url']}")
    private String transOverCallUrl;

	@Value("#{configProperties['devMode']}")
	private String devMode;

    public void transcodeRequest(){
		if (!Boolean.parseBoolean(devMode)) {
			//获取所有待转码任务表中信息
			List<TranscodeTaskModel> tasks = transcodeTaskService.getAll();
			if (tasks != null && tasks.size() > 0) {
				for (TranscodeTaskModel task : tasks) {
					//FIXME 如果转码间隔时间较长，可以忽略该重新查验功能
					task = transcodeTaskService.findById(task.getId());
					if (task.getStatus() != null && Const.TRANSCODETASK_INIT == task.getStatus().intValue()) {
						task.setStatus(Const.TRANSCODETASK_TRANSCODING);
						transcodeTaskService.modify(task);
						transcoding(task);
					}
				}
			}
		}
    }
    
    /**
     * 
      * 转码请求
      * @author  wangchaojie　2017年3月21日
      *
     */
    private void transcoding(TranscodeTaskModel task){
    	Long videoId = task.getVideoId();
    	Long spId = task.getSpId();
    	Long customId = task.getCustomId();
    	String originUri = task.getFileOriginUri();
        try{
        	VideoModel videoModel =videoService.getById(videoId);
            if(videoModel == null){
            	_log.error("转码任务表中信息错误：videoId="+videoId+" 无效！任务表中对应数据已删除！");
            	transcodeTaskService.delete(task);
            	return;
            }else{
				boolean updateFlag = updateFlag(task.getIsReTranscode().intValue(), task.getCodeRate());
				if(updateFlag){
					VideoModel upateVideo = new VideoModel();
					upateVideo.setVideoId(videoModel.getVideoId());
					upateVideo.setFileStatus(FileStatus.TranscodingIng);
					upateVideo.setUpdateTime(new Date());
					videoService.save(upateVideo);
				}
            }

            //获取视音频的输出bucket
			String domain = "";
			StorageModel mediaStorage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Media);
            if(task.getPlat().intValue() == 1){
				domain = storageService.getDomainSimpleInByStorageId(mediaStorage.getId());
			}

			//开始转码请求
            String transCodeTaskId = remoteService.remoteTransCode("POST",transOverCallUrl, task,mediaStorage.getName(),domain);
            //请求转码失败 （转码服务未启动或无法连接）
            if(StringUtils.isEmpty(transCodeTaskId)){
				transcodeFaild(videoId,task);
            }else {
				//更新本次转码任务中的文件信息及任务表中的fileTaskId
				this.updateFileInfo(task, transCodeTaskId);
				task.setFileTaskId(transCodeTaskId);
				transcodeTaskService.modify(task);
			}
			//首次转码请求，进行抽帧；重新转码的请求不再进行抽帧处理
			if(task.getIsReTranscode().intValue() == Const.IS_RETRANSCODE_NO.intValue()){
				//获取视音频的输出bucket
				StorageModel imgStorage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Picture);
				this.chouzhenReq(spId, customId, originUri, videoId, imgStorage.getName(),task.getPlat(),domain);
			}
        }catch(Exception ex){
        	_log.error("转码任务失败 ,{}",ex);
			transcodeFaild(videoId,task);
        }
    }

    private void transcodeFaild(Long videoId,TranscodeTaskModel task){
    	_log.info("转码失败，videoId={},转码codeRage={}",videoId,task.getCodeRate());
		boolean updateFlag = updateFlag(task.getIsReTranscode().intValue(), task.getCodeRate());
		if(updateFlag){
			VideoModel upateVideo = new VideoModel();
			upateVideo.setVideoId(videoId);
			upateVideo.setFileStatus(FileStatus.TranscodingFail);
			videoService.save(upateVideo);
		}
		this.createTranscodeHistroy(task);
	}
    
	/**
	  * 抽帧请求
	  * @param spId 用户spId
	  * @param customId 客户id
	  * @param originUri 视频源地址
	  * @author  wangchaojie　2017年3月27日
	  * 
	 */
	private void chouzhenReq(Long spId, Long customId, String originUri, Long videoId,String bucketName,Integer plat,String domain) {
		//请求抽帧接口
		String chouzhenTaskId = remoteService.remoteChouZhen(originUri,spId.toString(),"POST",transOverCallUrl,bucketName,plat,domain);
		if(StringUtils.isNotBlank(chouzhenTaskId)){
			VideoModel update = new VideoModel();
			update.setVideoId(videoId);
			update.setUpdateTime(new Date());
			update.setChouzhenBtime(new Date());
			update.setChouzhenTaskId(chouzhenTaskId);
			videoService.save(update);
		}
	}
    
	/**
	  * 转码服务连接超时，记录转码失败错误信息
	  * @param task 任务
	  * @author  wangchaojie　2017年4月5日
	  * 
	 */
	private void createTranscodeHistroy(TranscodeTaskModel task){
		List<FileModel> files = fileService.getByVid(task.getVideoId());
		String[] transCodeFmts = this.getTaskTransCodeFmt(task);
		String codeRates[] = task.getCodeRate().split(Const.VALUE_DECOLLATOR);
		//查找出本次转码任务中的文件信息,添加到任务历史记录表中
		for(FileModel file : files){
			//判断文件的码率和格式是否与此次转码的任务匹配
			if(ArrayUtils.contains(codeRates, String.valueOf(file.getCodeRate())) &&
					ArrayUtils.contains(transCodeFmts, file.getTransCodeFmt())){

				FileModel updateFile = new FileModel();
				updateFile.setFileId(file.getFileId());
				updateFile.setStatus(FileStatus.TranscodingFail);
				fileService.modify(updateFile);

				TranscodeHistoryModel history = new TranscodeHistoryModel(task.getVideoId(),task.getCustomId(),
						Const.TRANSCODEHISTORY_FAIL,file.getFileId(),task.getFileTaskId());
				//XXX 转码服务器连接超时 暂用提示
				history.setErrorCode("0000");
				history.setErrorMsg("未获取到转码任务ID或转码系统未正确返回任务ID");
				transcodeHistoryService.create(history);


			}
		}
		transcodeTaskService.delete(task);
	}

	/**
	  * 根据任务信息获取本次任务重的转码格式
	  * @param task 任务
	  * @return 任务中的转码格式
	  * 
	 */
	private String[] getTaskTransCodeFmt(TranscodeTaskModel task) {
		String defaultFmts = Const.FMT_HLS + Const.VALUE_DECOLLATOR + Const.FMT_MP4;
		String transCodeFmt = StringUtils.isEmpty(task.getTransCodeFmt()) ? defaultFmts : task.getTransCodeFmt();
		String transCodeFmts[] = transCodeFmt.split(Const.VALUE_DECOLLATOR);
		return transCodeFmts;
	}

	/**
	  * 更新本次转码任务中的文件信息
	  * @param task 任务
	  * @param transCodeTaskId
	  * @author  wangchaojie　2017年4月5日
	  * 
	 */
	private void updateFileInfo(TranscodeTaskModel task,String transCodeTaskId) {
		List<FileModel> files = fileService.getByVid(task.getVideoId());
		String[] transCodeFmts = this.getTaskTransCodeFmt(task);
		String codeRates[] = task.getCodeRate().split(Const.VALUE_DECOLLATOR);
		for(FileModel updateFile : files){
		    _log.info("更新文件信息......{}",updateFile.getFileId());
		    //如果已经转码成功 ，不再转码
		    if(FileStatus.TranscodingSuccess.getDbValue() == updateFile.getStatus().getDbValue()){
		    	continue;
		    }
		    //只更改本次转码任务的文件状态为转码中
		    if(ArrayUtils.contains(codeRates, String.valueOf(updateFile.getCodeRate())) &&
		    		ArrayUtils.contains(transCodeFmts, updateFile.getTransCodeFmt())){
				FileModel updateFileModel = new FileModel();
				updateFileModel.setFileId(updateFile.getFileId());
				updateFileModel.setTaskId(transCodeTaskId);
				updateFileModel.setStatus(FileStatus.TranscodingIng);
				updateFileModel.setTranscodeBtime(new Date());
				updateFileModel.setUpdateTime(new Date());
				fileService.modify(updateFileModel);
		    }
		}
	}

	private boolean updateFlag(int reTranscodeFlag,String transCodeCodeRates){
		if(Const.IS_RETRANSCODE_YES.intValue() == reTranscodeFlag){
			boolean updateFlag = false;
			List<String> transCodeCodeRateList = Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().splitToList(transCodeCodeRates);
			if(transCodeCodeRateList.contains(String.valueOf(DefinitionEnum.SD.getDefinitionId()))){
				updateFlag = true;
			}
			return updateFlag;
		}
		return true;
	}
}
