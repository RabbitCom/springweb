/**
 * variables
 * @type {Object}
 */

//var js:"http://js.saas.letvcloud.com/"
var variables = {
    timeout: 1500,
    timeout_lg: 2500,
    msg_submit_ok: '恭喜，添加成功',
    msg_null: '抱歉，暂无数据',
    msg_network_err: '网络错误，请重新刷新页面'
};
/**
 * 消息提示
 * @type {Object}
 */
var alertfn = {
    safariClass:"flipInX",
    common: function(obj, msg) {
        obj.find(">p").html(msg);
        // obj.removeClass('hide').addClass('animated flipInX');
        obj.removeClass('hide').addClass('animated '+this.safariClass);
        setTimeout(function() {
            obj.removeClass("animated flipInX").addClass('hide');
        }, variables.timeout_lg);
    },
    success: function(msg) {
        var alert_success = $("#alert-success");
        this.common(alert_success, msg);
    },
    warning: function(msg) {
        var alert_warning = $("#alert-warning");
        this.common(alert_warning, msg);
    },
    danger: function(msg) {
        var alert_danger = $("#alert-danger");
        this.common(alert_danger, msg);
    }
};
/**
 * 弹窗事件
 * @type {Object}
 */
var modalfn = {
    alert: function(msg) {
        var modal_alert = $("#modal-alert");
        modal_alert.find(".modal-body .msg").html(msg);
        modal_alert.modal({
            backdrop: true
        }, 'show');
    },
    confirm: function(msg) {
        var modal_confirm = $("#modal-confirm");
        modal_confirm.find(".modal-body .msg").html(msg);
        modal_confirm.modal({
            backdrop: true
        }, 'show');
    }
};
/**
 * 通用事件
 * @type {Object}
 */
var basefn = {
    init: function() {
        (function(){
            var ua = navigator.userAgent.toLowerCase();
            if(ua.indexOf('chrome')<0 && ua.indexOf('safari')>-1){//判断是Safari浏览器的话，去掉动画效果
                alertfn.safariClass = "";
            }else if ( !! window.ActiveXObject || "ActiveXObject" in window ){
                alertfn.safariClass = "";//判断是IE浏览器的话，去掉动画效果
            }
        })();
        this.topbar_fn(); //顶部通用
        this.left_nav_fn(); //左侧菜单
        this.tplset(); //模板设置
    },
    btn: {
        //按钮交互
        loading: function(obj) {
            obj.button('loading');
        },
        reset: function(obj) {
            obj.button('reset');
        }
    },
    loading: {
        //loading 显示隐藏事件
        show: function(obj) {
            obj.removeClass("hide");
        },
        hide: function(obj) {
            obj.addClass("hide");
        }
    },
    tplset: function() {
        //模版针对 是否签约 造型
        template.config("escape", false);
        template.helper('signedFormat', function(val) {
            var str;
            if (val) {
                str = 'checked'
            }
            return '<input type="checkbox" name="signed" data-size="mini" data-on-color="success" class="boot-switch" ' + str + '>';
        });
    },
    topbar_fn: function() {
        //后台管理顶部header事件
        var header_control = $("#topbar-nav-control");
        if (header_control.length) {
            //点击操作显示更多
            header_control.unbind().bind("click", function() {
                $(this).toggleClass("active");
                $(this).next("dl").toggleClass("active");
            });
            //鼠标点击网页空白处 关闭顶部已展开的headerbar
            $(document).mouseup(function(e) {
                if (!header_control.is(e.target) && header_control.has(e.target).length === 0 && header_control.hasClass("active")) {
                    header_control.removeClass("active");
                    header_control.next("dl").removeClass("active");
                }
            });
        }
    },
    left_nav_fn: function() {
        //左侧导航 点击显示其下更多
        var nav_control = $("#leyun-warp-navbar"),
            nav_control_links = nav_control.find(".item-link");
        if (nav_control_links.length) {
            nav_control_links.unbind().bind("click", function() {
                $(this).parent().toggleClass("active");
                $(this).find("dl").toggleClass("active");
            });
        }
    },
    login: function() {
        //login 该项无实际使用意义，不过可以作为ajax写法的参考
        var loginform = $("#login-form"),
            loginform_submit = $("#login-btn-submit");
        if (loginform.length) {
            loginform.validate({
                submitHandler: function(form) {
                    basefn.btn.loading(loginform_submit);
                    //ajax提交方式
                    var param = loginform.serialize();
                    $.ajax({
                        url: 'login.json',
                        type: 'get',
                        dataType: 'json'
                    }).done(function(data) {
                        if (data.code == 1) {
                            window.location.reload();
                        } else {
                            basefn.btn.reset(loginform_submit);
                            alertfn.warning(data.msg);
                        }
                    }).fail(function() {
                        alertfn.danger(variables.msg_network_err);
                    });
                }
            });
        }
    }
};
/**
 * 页面dom加载执行
 */
$(function() {
    //init
    basefn.init();
    //$("[data-toggle='tooltip']:not(.active)").tooltip();

    //添加QQ反馈的点击事件，中文下-被嵌套的界面才加
    var l = "zh_cn";
    try{
        l = lctu.getLanguage();
    }catch(e){}
    if(!l || l == "zh_cn"){
        if (self != top) {
            var html = '<ul class="le-quick-right-nav clearfix">' +
                '<li class="clearfix"><a href="#" class="tencent">qq</a></li>' +
                '</ul>';
            if($(".action-bar .back").length==0){
                $("body").append(html);
            }
            $("body").on("click", ".tencent", function() {
                var a = $("<a href='http://wpa.qq.com/msgrd?v=3&uin=800054392&site=qq&menu=yes' target='_blank'>Apple</a>").get(0);
                var e = document.createEvent('MouseEvents');

                e.initEvent('click', true, true);
                a.dispatchEvent(e);
            });
        }
    }

    //点击关闭父级窗口的控制台菜单
    if (self != top) {
        $(document).on("click",function(){
            $("#le-control-menus",parent.document).parent().removeClass("open");
        });
    }

    //判断控制浏览器跳转，http code为400时，判断errcode值
    $(document).ajaxError(function(event, request, settings, thrownError) {
        try {
            if (request.status == 400) {
                var responseJSON = JSON.parse(request.responseText);
                if (responseJSON.errCode == 90000) {
                    top.window.location.href = responseJSON.errMsg;
                }
            }
        } catch (e) {}
    });

    //ajax统一格式化返回值，将明绩库里的值转义回来
    $.ajaxSetup({
        dataFilter: function(response) {
            if (response && response.indexOf("public_footer") < 0 && response.indexOf("UEditor_duyang") < 0) {
                var s = praseHtmlCodeToString(response);
                response = s;
                // console.log(s);
                //一定要返回一个字符串不能不返回或者不给返回值，否则会进入success方法  
                return response;
            } else {
                //如果没有超时直接返回  
                return response;
            }
        }
    });
});

function praseHtmlCodeToString(str) {
    str = str.replace(/\&quot\;/g, "\\\"");
    // str = str.replace(/\&quot\;/g,"'");
    // str = str.replace(new RegExp('(["\"])', 'g'), "\\\"");
    var c = document.createElement('div');
    c.innerHTML = str;
    str = c.innerText || c.textContent;
    c = null;
    return str;
}

//弹框，全选，确定

function checkall(parent) {
    $(parent).on("click", ".checkItem", function() {
        var b = $(parent).find(".checkItem").length == $(parent).find("input.checkItem:checked").length ? true : false;
        $(parent).find(".checkall").prop("checked", b);
    });
    $(parent).on("click", ".checkall", function() {
        if ($(this).is(":checked")) {
            $(parent).find(".checkItem").prop("checked", "checked");
        } else {
            $(parent).find(".checkItem").prop("checked", false);
        }
    });
}
//格式化时间 year-month-date

function formatDate(d) {
    if (d != null) {
        if (d.trim().indexOf(" ") > -1) {
            return d.split(" ")[0];
        } else {
            var now = new Date(d);
            var year = now.getFullYear();
            var month = now.getMonth() + 1 < 10 ? '0' + (now.getMonth() + 1) : now.getMonth() + 1;
            var date = now.getDate() < 10 ? '0' + now.getDate() : now.getDate();
            return year + "-" + month + "-" + date;
        }
    } else {
        return ' ';
    }
}


//格式化时间
function formatDateEn(d) {
    var now = new Date(d);
    var monName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var noon = "";
    var year=now.getFullYear();
    var month=now.getMonth();
    var date=now.getDate();
    var hour=now.getHours();
    var minute=now.getMinutes();
    var second=now.getSeconds();
    minute = minute < 10 ? "0"+minute : minute;
    second = second < 10 ? "0"+second : second;
    if(lctu.getLanguage() == "en"){
        if(hour > 12){
            noon = "PM";
            hour = (hour - 12);
        }else{
            hour = hour;
            noon = "AM";
        }
        return monName[month]+" "+date+", "+year+" "+hour+":"+minute+":"+second +" " +noon;
    }else{
        date = date < 10 ? "0"+date : date;
        month = (month+1) < 10 ? "0"+ (month+1) : (month+1);
        hour = hour < 10 ? "0"+hour : hour;
        return year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second;
    }
}

//格式化时间 yyyy-MM-dd hh:mm:ss

function formatDateL(d) {
    var now = new Date(d);
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    var date = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    month = month < 10 ? "0" + month : month;
    date = date < 10 ? "0" + date : date;
    hour = hour < 10 ? "0" + hour : hour;
    minute = minute < 10 ? "0" + minute : minute;
    second = second < 10 ? "0" + second : second;
    return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
}
//时长转换-ms--00:00:00

function formatSeconds(d) {
    if (d != null) {
        var hour = Math.floor(d / 1000 / 3600) < 10 ? '0' + Math.floor(d / 1000 / 3600) : Math.floor(d / 1000 / 3600);
        var minite = Math.floor((d / 1000 % 3600) / 60) < 10 ? '0' + Math.floor((d / 1000 % 3600) / 60) : Math.floor((d / 1000 % 3600) / 60);
        var second = Math.floor(d / 1000 % 60) < 10 ? '0' + Math.floor(d / 1000 % 60) : Math.floor(d / 1000 % 60);
        return hour + ":" + minite + ":" + second;
    } else {
        return 0;
    }
}
//视频大小转换

function formatMb(b) {
    if (b) {
        if (b === 0) return '0 B';
        var k = 1000,
            sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'],
            i = Math.floor(Math.log(b) / Math.log(k));
        return (b / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
    } else {
        return '0 B';
    }
}

function getQueryByUrl(url, key) {
    var value = url.match(new RegExp("[?&#]" + key + "=([^&#]*)(&?)", "i"));
    return value ? decodeURIComponent(value[1]) : "";
}

if(typeof lctu == "undefined"){
    window.lctu = {};
}

lctu.isBeimei = function(){
    if (window.location.hostname.indexOf("us") >= 0) {
        return true;
    }else{
        return false;
    }
};