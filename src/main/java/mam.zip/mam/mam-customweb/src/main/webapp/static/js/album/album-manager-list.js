
var _INFO_ = {
    toggleOnOffLineUrl: "/albumController/toggleOnOffLine.do?",
    toggleOnOffLineTxt: LCT("专辑")
};
var params = {},
    index = 0,
    category_obj = {},
    albumName_arr = [];
var lcsetting = {
    "ajax": basePath + "albumController/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            if (d.status == 1) {
                var isdelete = 2;
            } else if (d.status == 2) {
                var isdelete = 1;
            } else {
                var isdelete = 0;
            }
            return '<input type="checkbox" isdelete=' + isdelete + ' data-id="' + d.albumId + '" value="" name="ck" class="checkItem" videoCount="' + d.videoCount + '">';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var albumName = d.albumName;
            albumName_arr.push(albumName);
            return '<dl class="clearfix">' +
                '<dt class="ui-fl img">' +
                '<img src=' + getListPicUrlForAlbum(d.listPicUrl) + '>' +
                '</dt>' +
                '<dd class="ui-fl album-info">' +
                '<p>' + LCT("ID") + '：' + d.albumId + '</p>' +
                '<p class="albumName"></p>' +
                '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                '</dd>' +
                '</dl>';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            return d.videoCount; //视频数量
        }
    }, {
        "data": "status",
        "format": function(i, j, d) {
            function parese(s) {
                if (s == 0) {
                    return '<span class="link-blue-txt">' + LCT("待编辑") + '</span>';
                }
                if (s == 1) {
                    return '<span class="link-blue-txt">' + LCT("已编辑") + '</span>';
                }
            }

            return parese(d); //专辑状态
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //创建时间
            if (lctu.getLanguage() == "en") {
                return formatDateEn(d.createTime.replace(/-/ig, "/"));
            } else {
                return d.createTime;
            }
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //更新时间
            if (lctu.getLanguage() == "en") {
                return formatDateEn(d.updateTime.replace(/-/ig, "/"));
            } else {
                return d.updateTime;
            }
        }
    }, {
        "data": "lcall",
        "className": 'commentSet-album',
        "format": function(i, j, d) {
            var editBtn = '';
            var toggleLine = '';
            var manageBtn = '';
            var deleteBtn = '';
            var categoryBtn = '';
            editBtn += '<a href="javascript:void(0)" lc_inner_href="' + basePath + 'albumController/toAlbumEdit.do?albumId=' + d.albumId + '" class="album-edit ml-10" data-id="' + d.albumId + '">' + LCT("编辑") + '</a>';
            categoryBtn += '<a data-toggle="modal" href="#modal-set-feilei" category-id=' + d.category + ' customCategory-id=' + d.customCategoryId + ' customCategory-id=' + d.customCategoryId + ' data-id="' + d.albumId + '"  video-count="' + d.videoCount + '" class="ml-10 fenlei-set" isFee="' + d.isFee + '">' + LCT("分类修改") + '</a>';
            /*if (d.status == 1) {
                toggleLine = '<a href="javascript:void(0)" isDelete="2" data-id=' + d.albumId + ' class="ml-10 toggleLine">' + LCT("下线") + '</a>'
            } else if (d.status == 2) {
                toggleLine = '<a href="javascript:void(0)" isDelete="1" data-id=' + d.albumId + ' class="ml-10 toggleLine">' + LCT("上线") + '</a>'
            }*/
            if (d.videoCount > 0) {
                manageBtn = '<a href="' + basePath + 'albumController/toAlbumVideo.do?albumId=' + d.albumId + '" class="ml-10" >' + LCT("管理") + '</a>';
            }
            /*if ((d.status == 0 || d.status == 2) && d.videoCount == 0) {
                if (lctu.getLanguage() == "en") {
                    deleteBtn = "";
                } else {
                    deleteBtn = '<a href="#modal-detele" data-toggle="modal" data-id="' + d.albumId + '" class="ml-10 detele">' + LCT("删除") + '</a>';
                }
            }*/
            return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' +
                editBtn + manageBtn + toggleLine + '<br/>' + categoryBtn + deleteBtn + '</p>';
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); //table全选
        //操作
        $("#maintable").on("mouseover", ".commentSet-album", function() {
            $(this).find("a.handle").hide();
            $(this).find("p").show();
        }).on("mouseout", ".commentSet-album", function() {
            $(".commentSet-album a.handle").show();
            $(".commentSet-album p").hide();
        });
        //专辑名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = albumName_arr[i];
            $(tr[i]).find("p.albumName").attr("title", remark_html).text(LCT('名称') + '：' + remark_html);

        }
        albumName_arr = [];
    }
}
var albumFn = {
    init: function() {
        this.handleTable(); //表格数据筛选
       // this.albumStatus(); //获取初始上下线状态
        this.toggleOnOffLine(); //专辑上下线
        this.derivedExcel(); //Excel导出
        this.systemCatagory(); //大数据分类
        this.fenlei(); //分类修改
        this.newAlbum(); //新建专辑
       // this.deteleAlbum(); //专辑移除
        this.edit(); //编辑返回
    },
    handleTable: function() {
        if (albumFn.albumStatus().length) {
            params["albumStatus"] = albumFn.albumStatus();
        } else {
            delete params["albumStatus"];
        }
        $("#maintable").lctable(lcsetting, params);

        //点击搜索按钮
        $(".btn_search").bind("click", function() {
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            albumFn.albumStatus();
            if (albumFn.albumStatus().length) {
                params["albumStatus"] = albumFn.albumStatus();
            } else {
                delete params["albumStatus"];
            }
            if (value_name) {
                params["albumName"] = value_name;
            } else {
                delete params["albumName"];
            }
            if (value_id) {
                params["albumId"] = value_id;
            } else {
                delete params["albumId"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    albumStatus: function() {
        var albumStatus_arr = [];
        var icon_checkbox = $(".search-info label");
        for (var i = 0; i < icon_checkbox.length; i++) {
            if ($(icon_checkbox[i]).find("input:checked").length) {
                albumStatus_arr.push($(icon_checkbox[i]).find("input").attr("albumstatus"));
            }
        }
        return albumStatus_arr;
    },
    checkAlbumdName: function(editName, result) {
        $.ajax({
            url: basePath + "albumController/checkAlbumdName.do",
            data: "albumName=" + editName,
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                if (data.success) {
                    result = false;
                } else {
                    result = true;
                }
            }
        });
        return result;
    },
    toggleOnOffLine: function() {
//        toggleOnOffLine("albumId", _INFO_.toggleOnOffLineUrl, _INFO_.toggleOnOffLineTxt); //单个上下线
//        $("#mul-online").click(function() {
//            mulToggleOnOffLine(1, 1); //批量上线
//        });
//        $("#mul-offline").click(function() {
//            mulToggleOnOffLine(1, 6); //批量下线
//        });
    },
    derivedExcel: function() {
        checkall("#modal-album-excel"); //excel全选
        $("#btn-excel").attr("href", "");
        $("#btn-excel").click(function() {
            var length = $("#maintable tbody td[colspan='7']").length;
            if (length) {
                alertfn.danger(LCT("没有要导出的专辑"));
            } else {
                $("#btn-excel").attr("href", "#modal-album-excel");
            }
        });
        $("#modal-album-excel").on('hide.bs.modal', function() {
            $("#btn-excel").attr("href", "");
        });
        $("#modal-album-excel").on("click", ".btn-ok", function() {
            var arr_hearders = [];
            var arr_fields = [];
            var arr_customCategoryId = [];
            var arr_videos = [];
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var checkbox = $("#modal-album-excel input:checkbox");
            var checkbox_table = $("#maintable tbody input:checkbox");
            var setClass_option = $("#setClass option:selected");
            var categoryId = $(".systemCatagory").attr("data-id");
            for (i = 0; i < setClass_option.length; i++) {
                var data_id = $(setClass_option[i]).attr("data-id");
                if (data_id != undefined) {
                    arr_customCategoryId.push(data_id);
                }
            }
            var customCategoryId = arr_customCategoryId[arr_customCategoryId.length - 1];
            for (var i = 1; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    arr_hearders.push($(checkbox[i]).closest("label").text());
                    arr_fields.push($(checkbox[i]).val());
                }
            }
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    arr_videos.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            if (arr_hearders.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("未选择任何excel导出项"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            } else {
                albumFn.albumStatus();
                var url = basePath + "exportExcelAlbum.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                if (value_name) {
                    url += "&albumName=" + value_name;
                }
                if (value_id) {
                    url += "&albumId=" + value_id;
                }
                if (albumFn.albumStatus().length) {
                    url += "&albumStatus=" + albumFn.albumStatus();
                }
                if (customCategoryId) {
                    url += "&customCategoryId=" + customCategoryId;
                }
                if (categoryId != '0') {
                    url += "&category=" + categoryId;
                }
                if (arr_videos.length) {
                    url += "&albumIds=" + arr_videos;
                }
                window.open(url, "_blank");
            }
        });
    },
    systemCatagory: function() {
        //获取大分类category
        $.getJSON(
            basePath + "customCategoryController/getCategorys.do",
            function(data) {
                var system_channel = '';
                for (var i = 0; i < data.length; i++) {
                    var showName = data[i].showName;
                    var dicValue = data[i].dicValue;
                    system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
                }
                $(".systemCatagory").attr("data-id", '0').append(system_channel);
                $(".systemCatagory-modal").attr("data-id", '0').append(system_channel);
                $(".systemCatagory-album").attr("data-id", '0').append(system_channel);
                //buildEdit.init("setClass");
            }
        );
        //数据分类筛选
        $(".systemCatagory").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory").attr("data-id", categoryId);
            category_obj = {};
            category_obj.category = categoryId;
            if (categoryId == "0") {
                $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>' + vrsFn.customCategoryInitDom);
            } else {
                $("#setClass").html("<label>" + LCT('自定义分类') + "：</label>");
                buildEdit.start = false;
                buildEdit.init("setClass");
            }
            delete params["customCategoryId"];
            params["category"] = categoryId;
            $(".btn_search").click();
        });
        //分类设置-数据分类
        $(".systemCatagory-modal").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory-modal").attr("data-id", categoryId);
            category_obj.category = categoryId;
            $("#editClass_album").html("");
            buildEdit.init("editClass_album");
        });
        //新建专辑-数据分类
        $(".systemCatagory-album").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory-album").attr("data-id", categoryId);
            category_obj.category = categoryId;
            if (categoryId == "0") {
                $("#editClass").html(vrsFn.customCategoryInitDom);
            } else {
                $("#editClass").html("");
                buildEdit.init("editClass");
            }
        });
    },
    fenlei: function() {
        $("#maintable").on("click", ".fenlei-set", function() {
            var albumId = $(this).attr("data-id");
            var customcategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoCount = $(this).attr("video-count");
            var isFee = $(this).attr("isFee");
            $(".systemCatagory-modal option[data-id='" + categoryId + "']").prop("selected", true);
            $(".systemCatagory-modal").attr("data-id", categoryId);
            category_obj.category = categoryId;
            if (videoCount > 0 || isFee == 0 || isFee == 1) {
                $(".systemCatagory-modal").prop("disabled", "disabled");
            } else {
                $(".systemCatagory-modal").prop("disabled", false);
                category_obj.categorys = categoryId; //全部，带推荐
            }
            $("#modal-set-feilei").attr({
                "album-id": albumId,
                "customcategory-id": customcategoryId,
                "category-id": categoryId
            });
            if (buildEdit.start) {
                return
            }
            buildEdit.init("editClass_album");
            if (customcategoryId != 0) {
                var obj = classfiyObject.getPidAndId(customcategoryId, window.classfiyObject_obj, 1);
                if (obj._level == 1) {
                    $("#editClass_album").find("select").eq(0).find("option[data-id=" + customcategoryId + "]").prop("selected", true);
                } else if (obj._level == 2) {
                    $("#editClass_album").find("select").eq(0).find("option[data-id=" + obj._pid + "]").prop("selected", true);
                    $("#editClass_album").find("select").eq(0).change();
                    $("#editClass_album").find("select").eq(1).find("option[data-id=" + obj._id + "]").prop("selected", true);
                } 
//                else if (obj._level == 3) {
//                    var obj3 = classfiyObject.getPidAndId(obj._pid, window.classfiyObject_obj, 1);
//                    $("#editClass_album").find("select").eq(0).find("option[data-id=" + obj3._pid + "]").prop("selected", true);
//                    $("#editClass_album").find("select").eq(0).change();
//                    $("#editClass_album").find("select").eq(1).find("option[data-id=" + obj._pid + "]").prop("selected", true);
//                    $("#editClass_album").find("select").eq(1).change();
//                    $("#editClass_album").find("select").eq(2).find("option[data-id=" + obj._id + "]").prop("selected", true);
//                }
            }
        });
        $("#set-feilei-ok").click(function() {
            var arr = $("#editClass_album option:selected");
            var albumId = $("#modal-set-feilei").attr("album-id");
            var customcategoryId = $("#modal-set-feilei").attr("customcategory-id");
            var categoryId = $("#modal-set-feilei").attr("category-id");
            var ids, category_selected;
            category_selected = $(".systemCatagory-modal").attr("data-id");
            for (var i = arr.length - 1; i >= 0; i--) {
                if ($(arr).eq(i).attr("data-id")) {
                    ids = $(arr).eq(i).attr("data-id");
                    break;
                }
            }
            /*if (typeof(ids) == "undefined") {
                if (buildEdit.editClassDom_album.has("label").length != 0) {
                    return false;
                }
                var html = '<label class="error">' + '自定义分类不能为空' + '</label>';
                buildEdit.editClassDom_album.append(html);
                return false;
            } else {
                buildEdit.editClassDom_album.find("label").remove();
            }*/
            if (typeof(ids) == "undefined") {
                ids = 0;
            }
            if (category_selected != categoryId) {
                var lc_inner_href = basePath + 'albumController/toAlbumEdit.do?albumId=' + albumId + '&editCategory=' + category_selected + '&editCustomCategory=' + ids;
                $('#modal-set-feilei').modal('hide');
                showInIFrame(lc_inner_href);
            } else {
                if (customcategoryId == ids) {
                    $('#modal-set-feilei').modal('hide');
                } else {
                    $.ajax({
                        url: basePath + "albumController/setAlbumCustomCategory.do",
                        data: "category=" + category_selected + "&customCategoryId=" + ids + "&albumId=" + albumId,
                        type: "post",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                var cur_tr = $("#maintable").find("input[data-id=" + albumId + "]").closest("tr");
                                $('#modal-set-feilei').modal('hide');
                                cur_tr.find("a.fenlei-set").attr("customcategory-id", ids);
                                alertfn.success(data.msg);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        }
                    });
                }
            }
            return false;
        });
        $('#modal-set-feilei').on('hide.bs.modal', function() {
            $("#editClass_album").html("");
            buildEdit.start = false;
            if (buildEdit.editNameDom.has("label").length) {
                buildEdit.editNameDom.find("label").remove();
            }
        });
        $("#maintable").on("click", ".icon-set", function() {
            jumpOutUrl("vrsCategory");
        });
    },
    newAlbum: function() {
        $("#buildedit").click(function() { //新建专辑
            category_obj = {};
            if (buildEdit.start) {
                return
            }
            //buildEdit.init("editClass");
            $("#editClass").html(vrsFn.customCategoryInitDom);
        });
        $("#editClass").change(function() {
            var categoryId = $(this).find('option:selected').attr("category-id");
            $(".systemCatagory-album option[data-id='" + categoryId + "']").prop("selected", true);
            $(".systemCatagory-album").attr("data-id", categoryId);
        });
        $("#editSubmit").on('click', function() {
            var arr = $("#editClass option:selected");
            var categoryId = $(".systemCatagory-album").attr("data-id");
            var editName = $("input[name=editName]").val().trim();
            //var reg = /^[\u4e00-\u9fa5 a-zA-Z0-9\•\！\【\】\？\“\”\‘\’\《\》\（\）\，\。\—\*\：\!\[\]\?\"\'\<\>\(\)\,\.\-\_\*\:]{1,50}$/;
            var boo = true;
            if (vrsFn.getStringLen(editName) < 2 || vrsFn.getStringLen(editName) > 50) {
                boo = false;
            }
            if (!boo) {
                var html = '<label class="error">' + LCT("专辑名称由1-25个字符组成") + '</label>';
                if (buildEdit.editNameDom.has("label").length != 0) {
                    buildEdit.editNameDom.find("label").html(html);
                    return false;
                }
                buildEdit.editNameDom.append(html);
                return false;
            } else if (albumFn.checkAlbumdName(editName)) {
                var html = '<label class="error">' + LCT("该专辑名称已经存在") + '</label>';
                if (buildEdit.editNameDom.has("label").length != 0) {
                    buildEdit.editNameDom.find("label").html(html);
                    return false;
                }
                buildEdit.editNameDom.append(html);
                return false;
            } else {
                buildEdit.editNameDom.find("label").remove();
            }
            var ids;
            for (var i = arr.length - 1; i >= 0; i--) {
                if ($(arr).eq(i).attr("data-id")) {
                    ids = $(arr).eq(i).attr("data-id");
                    break;
                }
            }
            if (categoryId == '0') {
                if ($("#newAlbumCategory").has("label").length != 0) {
                    return false;
                }
                var html = '<label class="error ml-5">' + LCT('数据分类不能为空') + '</label>';
                $("#newAlbumCategory").append(html);
                return false;
            } else {
                $("#newAlbumCategory label").remove();
            }
            $.ajax({
                url: basePath + "albumController/saveAlbum.do",
                data: {
                    customCategoryId: ids,
                    albumName: editName,
                    category: categoryId,
                    k: Math.random() * 100
                },
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        $('#modal-zhuanji-add').modal('hide');
                        alertfn.success(LCT("添加成功"));
                    } else {
                        alertfn.danger(data.msg);
                    }
                    $(".btn_search").click();
                }
            });
            return false;
        });
        $('#modal-zhuanji-add').on('hide.bs.modal', function() {
            $("input[name=editName]").val("");
            $("#editClass").html("");
            $(".systemCatagory-album").attr("data-id", 0);
            $("#newAlbumCategory option[data-id='0']").prop("selected", true);
            buildEdit.start = false;
            if ($("#newAlbumCategory").has("label").length) {
                $("#newAlbumCategory").find("label").remove();
            }
            buildEdit.editNameDom.find("label").remove();
        });
    },
   /* deteleAlbum: function() {
        $("#maintable").on("click", ".detele", function() {
            var albumId = $(this).attr("data-id");
            $("#modal-detele").attr("album-id", albumId);
        });
        $("#mul-detele").click(function() {
            var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var mulToggleOnOffLine = [];
            var videoCountArr = [];
            var videoIds = [];
            for (var i = 0; i < arr.length; i++) {
                mulToggleOnOffLine.push($(arr[i]).attr("isdelete"));
                if ($(arr[i]).attr("videoCount") != '0') {
                    videoCountArr.push($(arr[i]).attr("videoCount"));
                }
            }
            $(arr).each(function(i) {
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if (arr.length > 0) {
                if (mulToggleOnOffLine.indexOf("2") < 0 && videoCountArr.length == 0) {
                    $(this).attr("href", "#modal-detele");
                    $("#modal-detele").attr("album-id", ids);
                } else if (videoCountArr.length) {
                    var params = {
                        "title": LCT("错误"),
                        "discription": LCT("不能删除有视频的专辑"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                    $("body").toolsalert(params);
                    return;
                } else {
                    var params = {
                        "title": LCT("错误"),
                        "discription": LCT("不能删除上线状态的专辑"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                    $("body").toolsalert(params);
                    return;
                }

            } else {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("请先选中一条记录"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            }
        });
        $("#detele-ok").click(function() {
            var videoId = $("#modal-detele").attr("album-id");
            $.ajax({
                url: basePath + "albumController/removeAlbum.do",
                data: {
                    albumIds: videoId,
                    removeMsg: $("#del-reason").val()
                },
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT("删除成功"));
                        $("#modal-detele").modal("hide");
                        //$("table[data-lctable='data-lctable']").lctable(lcsetting, params);
                        $(".btn_search").click();
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
            })
        });
        $('#modal-detele').on('hide.bs.modal', function() {
            $("#del-reason").val("");
            $("#modal-detele").removeAttr("album-id");
            $("#mul-detele").attr("href", "");
        });
    },*/
    edit: function() {
        $("#maintable").on("click", ".album-edit", function() {
            showInIFrame($(this).attr("lc_inner_href"));
        });
    }
};
$(function() {
    albumFn.init();
});
var buildEdit = {
    init: function(id) {
        this.connect(id);
    },
    editNameDom: $("input[name=editName]").parent(),
    editClassDom: $("#editClass"),
    editClassDom_album: $("#editClass_album"),
    start: false,
    connect: function(id) { //请求ajax
        $.ajax({
            url: basePath + "customCategoryController/dataGrid.do",
            //data: "",
            data: category_obj,
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                window.classfiyObject_obj = data;
                buildEdit.createDom(data, id);
                if (id == "editClass" || id == "editClass_album") {
                    buildEdit.start = true
                }
            }
        })
    },
    createDom: function(data, id) {
        var s1 = new createClass(id, data);
        s1.init(2, id);
    },
    setInformation: function() { //设置分类信息事件;

        var arr = $("#setClass option:selected");
        var classId = "";
        var categoryId = "";
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                classId = $(arr).eq(i).attr("data-id");
                categoryId = $(arr).eq(i).attr("category-id");
                $(".systemCatagory").attr("data-id", categoryId);
                break;
            }
        }
        $(".systemCatagory option[data-id='" + categoryId + "']").prop("selected", true);
        var systemCatagoryId = $(".systemCatagory").attr("data-id");
        if (systemCatagoryId == "0") {
            delete params["category"];
        } else {
            params["category"] = systemCatagoryId;
        }
        $(".systemCatagory").change(function() {
            classId = "";
        });
        if (classId == "") {
            delete params["customCategoryId"];
        } else {
            params["customCategoryId"] = classId;
        }
        lcsetting.thisPage = 1;
        $("#maintable").lctable(lcsetting, params);
    }
}
createClass.prototype = {
    init: function(num, id) {
        var This = this;
        for (var i = 0; i < 2; i++) {
            var oSel = document.createElement("select");
            oSel.index = i;
            oSel.className = "form-control";
            this.oParent.appendChild(oSel);
            oSel.onchange = function() {
                This.change(this.index);
            }
        }
//        if (id != "editClass" && id != "editClass_album") {
//            var ahref = document.createElement("a")
//            $(this.oParent).append('<a data-menu="vrsCategory" class="icon-set link-gray3" href="' + basePath + 'customCategoryController/toCustomCategoryManager.do">' + LCT("设置分类信息") + '</a>');
//        }
        this.first();
    },
    change: function(iNow) {
        switch (iNow) {
            case 0: //改变1级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.zero(now);
                break;
            case 1: //改变2级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.one(now);
                break;
//            case 2: //改变3级时候处理
//                var now = this.aSel[iNow].selectedIndex;
//                this.two(now);
//                break;
        }
        if (this.oParent == document.getElementById("setClass")) {
            buildEdit.setInformation();
        }

    },
    noting: function() {
        for (var i = 0; i < 1; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i + 1].appendChild(opt);
        }
    },
    zero: function(n) { //改变一级处理函数
        for (var i = 0; i < 2; i++) { //清空源信息;
            if (i == 0) {
                continue
            }
            this.aSel[i].innerHTML = "";
        }
        if (n == 0) {
            this.noting();
            return
        }
        var arr = this.data[n - 1];
        if (arr.children.length) {
            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);
                this.aSel[1].appendChild(opt);
            }
        } else {
            this.noting();
            return;
        }

//        if (arr.children[0].children.length) {
//            for (var i = 0; i < arr.children[0].children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[0].children[i].text;
//                opt.setAttribute("data-id", arr.children[0].children[i].id);
//                opt.setAttribute("category-id", arr.children[0].children[i].category);
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }
    },
    one: function(n) { //改变二级处理函数
//        var a1 = this.aSel[0].selectedIndex - 1;
//        var arr = this.data[a1].children[n];
//        this.aSel[2].innerHTML = "";
//        if (arr.children.length != 0) {
//
//            for (var i = 0; i < arr.children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[i].text;
//                opt.setAttribute("data-id", arr.children[i].id);
//                opt.setAttribute("category-id", arr.children[i].category);
//
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }

    },
    two: function(n) {

    },
    first: function() { //上来初始化
        var arr = this.data;
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i].appendChild(opt);
        }
        for (var i = 0; i < arr.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = arr[i].text;
            $(opt).attr("data-id", arr[i].id);
            $(opt).attr("category-id", arr[i].category);
            this.aSel[0].appendChild(opt);
        }
    }
}

function createClass(id, data) {
    this.oParent = document.getElementById(id);
    this.data = data;
    this.aSel = this.oParent.getElementsByTagName("select");
}
//编辑-返回

function closeIframeFromOuter(type) {
    albumName_arr = [];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}