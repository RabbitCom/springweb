var albumEditFn = {
    init: function() {
        this.baseHandle(); //页面基础操作
        this.radioCheckbox(); //页面单选，多选
        this.switchDateEn();
        setTimeout(albumEditFn.editImg,1000);//图片信息
    },
    baseHandle: function() {
        //tab初始化
        $(".vedio-edit-img-con .le-img-tabs li").first().addClass("active");
        $(".vedio-edit-img-con .vedio-img-box").first().addClass("active");
        $(".vedio-edit-img-con").on("click", "#vedio-img-box01 li", function() {
            $(this).addClass("active").siblings().removeClass("active");
        });
        //返回
        $(".back").click(function() {
            closeIframeFromInner('refresh');
        });
        $(".le-all-tpl-tabs li").click(function(e) {
            for (var i = 0; i < $(".le-all-tpl-tabs li").length; i++) {
                if ($(".le-all-tpl-tabs li").eq(i).hasClass("active")) {
                    $(".le-all-tpl-tabs li").eq(i).removeClass("active");
                    $(".le-tpl-tab-con").removeClass("active");
                }
            }
            $(e.target).addClass("active");
            $(".le-tpl-tab-con").eq($(e.target).index()).addClass("active");
        });
        $("#save_album").on('click', function() {
            // var subCategory = PublicPullSubmitSelected("subCategory"); //影视分类多选
            // var area = PublicPullSubmitSelected("area"); //地区多选
            // var language = PublicPullSubmitSelected("language"); //语言
            var validate_result = $("#information").valid();
            // var requireCon = $(".requireCon");
            // for (var i = 0; i < requireCon.length; i++) {
            //     var block_length = $(requireCon[i]).find("li").length;
            //     if (block_length == 0) {
            //         var flag= $(requireCon[i]).attr("flag");
            //         $("#"+flag).css("border", "1px #fb5259 solid");
            //     }
            // }
            if (validate_result) {
                albumEditFn.album_form_submit();
            } else {
                // if (!subCategory) {
                //     PublicSuccessError("tab-subCategory", false);
                // } else {
                //     PublicSuccessError("tab-subCategory", true);
                // }
                // if (!area) {
                //     PublicSuccessError("tab-area", false);
                // } else {
                //     PublicSuccessError("tab-area", true);
                // }
                // if (!language) {
                //     PublicSuccessError("tab-language", false);
                // } else {
                //     PublicSuccessError("tab-language", true);
                // }
                error_scroll();
                return false;
            }
        });
    },
    editImg: function() {
        $(".upload-mask").show();
        $("#vedio-img-box02 .upload-btn-group a").removeClass("active");
        $(".upload-mask").click(function() {
            alertfn.danger(LCT("请先选择要上传的比例"));
        });
        //上传比例按钮选择及提示
        $("#vedio-img-box02").on("click", ".upload-btn-group a", function() {
            var max_wh = $(this).attr("data-size");
            $(".upload-mask").hide();
            $(this).addClass("active").siblings().removeClass("active");
            $("#vedio-img-box02 p b").html(max_wh);
        });
        var data = picFinished_fromJSP;
        //右边成品图
        var divWidth = $(".vedio-img-box2").width();
        var divHeight;
        var bili_html = '';
        var btn_html = '';
        for (var i = 0; i < data.length; i++) {
            var data_info = data[i];
            var bl = data_info.bl;
            var url = data_info.info[0].url;
            var max_wh = data_info.info[0].fbl;
            divHeight = Math.floor(divWidth * parseInt(bl.split(":")[1]) / parseInt(bl.split(":")[0]));
            bili_html += '<div style="height:' + divHeight + 'px" img-wh="' + max_wh.replace(/\*/, "_") + '"><img height=' + divHeight + ' src=' + url + '></div>';
            bili_html += '<p>' + bl + '(&nbsp;';
            for (var j = 0; j < data_info.info.length; j++) {
                var wh = data_info.info[j].fbl;
                bili_html += wh + '&nbsp;';
            }
            bili_html += ')</p>';
            btn_html += '<a href="javascript:void(0)" data-index=' + i + ' class="btn-danger btn-l ml-10" data-size=' + max_wh + '>' + bl + '</a>';
        }
        $(".vedio-img-box2").html(bili_html);
        if ($("#vedio-img-box01").length) {
            $("#vedio-img-box01 .btn-img-group").prepend(btn_html);
        }
        $("#vedio-img-box02 .upload-btn-group").html(LCT("图片比例") + "：<br/><br/>" + btn_html);

        //各端图片保存提交（自定义图片）
        $("#vedio-img-box02").on("click", ".btn-img-group a", function() {
            var cur_src = $("#vedio-img-box02 li img").attr("src");
            var a_active = $("#vedio-img-box02 .upload-btn-group a.active");
            if (a_active.length) {
                var index = a_active.attr("data-index");
                var a_bili = a_active.html();
                var data_size = a_active.attr("data-size").split("*");
                if (cur_src) {
                    var img = $("#vedio-img-box02 li img");
                    $("<img/>").attr("src", $(img).attr("src")).load(function() {
                        $(img).attr({
                            "real-width": this.width,
                            "real-height": this.height
                        });
                    });
                    setTimeout(function() {
                        var realWidth = parseInt($(img).attr("real-width"));
                        var realHeight = parseInt($(img).attr("real-height"));
                        if (parseInt(data_size[0]) <= realWidth && parseInt(data_size[1]) <= realHeight) {
                            var params = {
                                "discription": LCT("是否替换右侧") + a_bili + LCT("的显示图片"),
                                "iconType": "triangle",
                                "confirmBtn": true,
                                "cancelBtn": true,
                                "confirmEvent": function() {
                                    $.post(basePath + 'albumController/getPicByDiffScale.do', {
                                        albumId: $("#albumId").val(),
                                        customImg: cur_src,
                                        proportion: a_bili
                                    }, function(result) {
                                        if (result.success) {
                                        	var src1=$(".vedio-img-box2 div").eq(index).attr("img-wh");
                                        	var split = src1.split("_");
                                        	if(result.obj==2){
                                        		cur_src = cur_src+"?imageView2/1/w/"+split[0]+"/h/"+split[1];
                                        	}else{
                                        		cur_src = cur_src+"@base@tag=imgScale&w="+split[0]+"&h="+split[1]+"&m=2&c=1";
                                        	}
                                        	 $(".vedio-img-box2 div").eq(index).find("img").attr("src", cur_src);
                                        	 alertfn.success(LCT("替换成功"));
                                        } else {
                                            alertfn.danger(result.msg);
                                        }
                                    },'JSON');

                                }
                            };
                            $("body").toolsalert(params);
                            return;
                        } else {
                            alertfn.danger(LCT("宽度不能小于") + data_size[0] + ' ' + LCT("高度不能小于") + data_size[1] + "！");
                        }
                    }, 300);
                } else {
                    alertfn.danger(LCT("请先上传图片"));
                }
            } else {
                alertfn.danger(LCT("请先选择要替换的比例"));
            }
        });
    },
    radioCheckbox: function() {
        initCheckbox(".subCategory", subCategory_values);
        initCheckbox(".language", language_values);
        initCheckbox(".area", area_values);
        //计费标识
        if (isFee_value == '0') {
            initRadio(".isFee", 0);
        } else if (isFee_value == '1') {
            initRadio(".isFee", 1);
        }
        initCheckbox(".payPlatform", payPlatform_values); //计费平台
        initCheckbox(".playPlatform", playPlatform_values);
        initRadio(".contentRating", contentRating_values);
        initRadio(".shieldingRule", shieldingRule_values);
        initRadio(".copyrightType", copyrightType_values);
        $(".subCategory input").click(function(e) { // 影视分类多选
            var that = $(this).parent();
            multiRadio.multi(that); // 选择并改变状态
            var ifpass = multiRadio.multiValue("subCategory", ".subCategory");
            PublicSuccessError("tab-subCategory", ifpass);
        });

        $(".language input").click(function(e) { // 语言多选
            var that = $(this).parent();
            multiRadio.multi(that, ".language");
            var ifpass = multiRadio.multiValue("language", ".language");
            PublicSuccessError("tab-language", ifpass);
        });

        $(".area input").click(function() { // 地区多选
            var that = $(this).parent();
            var boo = multiRadio.select(that);
            if (!boo) {
                multiRadio.multi(that);
            }
            var ifpass = multiRadio.multiValue("area", ".area");
            PublicSuccessError("tab-area", ifpass);
        });
        // 计费标识
        var categoryId = $("input[name='category']").val();
        if (isFee_value != 1 && (categoryId == 100001 || categoryId == 100002)) {
            $(".isFee").click(function() {
                multiRadio.radio(this, ".isFee");
                var ifpass = multiRadio.radioValue("isFee", ".isFee");
                PublicSuccessError("tab-isFee", ifpass);
            });
            //双击取消是的选择
            $(".isFee").dblclick(function() {
                $(this).find("i").removeClass("active");
            });
        }
        //计费平台
        $(".payPlatform input").click(function() { 
            var that = $(this).parent();
            var boo = multiRadio.select(that);
            if (!boo) {
                multiRadio.multi(that);
            }
            var ifpass = multiRadio.multiValue("payPlatform", ".payPlatform");
            PublicSuccessError("tab-payPlatform", ifpass);
        });
        
        
        
        //购买/非购买版权修改
        var originAlbumId = $("#originAlbumId_hidden").val();
        if (originAlbumId == 0 || originAlbumId == null) {
            $(".playPlatform input").click(function() { // 播放平台多选
                var that = $(this).parent();
                multiRadio.multi(that);
                var ifpass = multiRadio.multiValue("playPlatform", ".playPlatform");
                //PublicSuccessError("tab-playPlatform", ifpass);
            });
            $(".copyrightType").click(function() { // 版权类型单选
                multiRadio.radio(this, ".copyrightType");
                var ifpass = multiRadio.radioValue("copyrightType", ".copyrightType");
                PublicSuccessError("tab-copyrightType", ifpass);
            });
        } else {
            $("input[name='copyrightCompany']").attr("disabled", true);
            $("input[name='copyrightStart']").attr("disabled", true);
            $("input[name='copyrightEnd']").attr("disabled", true);
        }
        $(".contentRating").click(function() { // 年龄分级单选
            multiRadio.radio(this, ".contentRating");
            var ifpass = multiRadio.radioValue("contentRating", ".contentRating");
            PublicSuccessError("tab-contentRating", ifpass);
        });

        $(".shieldingRule").click(function() { // 海外屏蔽单选;
            multiRadio.radio(this, ".shieldingRule");
            var ifpass = multiRadio.radioValue("shieldingRule", ".shieldingRule");
            PublicSuccessError("tab-shieldingRule", ifpass);
        });
    },
    album_form_submit: function() {
        var obj = $.serializeObject($('#information'));
        console.log(obj);
        $.post(basePath + 'albumController/updateAlbum.do', obj, function(result) {
            if (result.success) {
                var params = {
                    "discription": result.msg,
                    "iconType": "success",
                    "confirmBtn": true,
                    "confirmEvent": function() {
                        $("html,body").animate({
                            scrollTop: 0
                        }, 400)
                    }
                };
                $("body").toolsalert(params);
                return;
            } else {
                var params = {
                    "title": LCT("错误"),
                    "discription": result.msg,
                    "iconType": "warningCircle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            }
        }, 'JSON');
        return false; // 阻止表单自动提交事件
    },
    switchDateEn: function() {
        var createTime = $("#album_edit_createtime").val();
        var updatetime = $("#album_edit_updatetime").val();
        var copyrightStart = $("#d4311").val();
        var copyrightEnd = $("#d4312").val();
        if (lctu.getLanguage() == "en") {
            $("#album_edit_createtime").val(formatDateEn(createTime.replace(/-/ig, "/")));
            $("#album_edit_updatetime").val(formatDateEn(updatetime.replace(/-/ig, "/")));
            $("#d4311-result").val(vrsFn.formatDateEn_short(copyrightStart.replace(/-/ig, "/")));
            $("#d4312-result").val(vrsFn.formatDateEn_short(copyrightEnd.replace(/-/ig, "/")));
        } else {
            $("#d4311-result").val(copyrightStart);
            $("#d4312-result").val(copyrightEnd);
        }
    }
};
$(function() {
    albumEditFn.init();
    vrsFn.categoryInit(); //页面初始渲染数据分类
    vrsFn.infomationValidate(); //表单验证规则
})