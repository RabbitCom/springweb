var params = {},
    storageId = $('#storageId').val();
var storageConfigs = {},
    index = 0;
var lcsetting = {
    "ajax": basePath + "storageConfigsController/dataGrid.do?storageId=" + storageId,
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function (i, j, d) { //访问方式
            if (d.ioType == 0) {
                return '未设置';
            }
            if (d.ioType == 1) {
                return '输入';
            }
            if (d.ioType == 2) {
                return '输出';
            }
            if (d.ioType == 3) {
                return '输入+输出';
            }
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //协议
            if (d.protocol == 0) {
                return '未设置';
            }
            if (d.protocol == 1) {
                return 'http';
            }
            if (d.protocol == 2) {
                return 'ftp';
            }
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //用户名
            return d.userName || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //密码
            return d.passWord || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //域名
            return d.hostName;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //端口号
            return d.port || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //权重
            return d.weight;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //操作类型
            var editBtn = '<a href="#modal-storageConfig-edit" data-toggle="modal"  class="ml-10 storageConfig_edit" ' +
                'configId="' + d.id + '" ioType="' + d.ioType + '" protocol="' + d.protocol + '" userName="' + d.userName +
                '" passWord="' + d.passWord + '" hostName="' + d.hostName + '" port="' + d.port + '" path="' + d.path + '" weight="' + d.weight + '">' + LCT("编辑") + '</a>';
            var deleteBtn = '<a href="javascript:;" class="storageConfig_del ml-10" configId="' + d.id + '">' + LCT("删除") + '</a>';
            return '<a href="javascript:;" class="handle"> </a><p>' + editBtn + deleteBtn + '</p>';
        }
    }
    ],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "..."
};
var storageConfigFn = {
    init: function () {
        this.add();
        this.del();
        this.edit();
        this.back();

    },
    add: function () {
        $("#buildAdd").click(function () {
            $('input:radio[name="protocol_add"]').removeAttr("checked");
            $('input:radio[name="ioType_add"]').removeAttr("checked");
            $('input:text[name="userName_add"]').val("");
            $('input:text[name="passWord_add"]').val("");
            $('input:text[name="hostName_add"]').val("");
            $('input:text[name="port_add"]').val("");
            $('input:text[name="path_add"]').val("");
            $('input:text[name="weight_add"]').val("");
        });
        $("#addSubmit").click(function () {
            var protocol = $('input:radio[name="protocol_add"]:checked').val();
            var ioType = $('input:radio[name="ioType_add"]:checked').val();
            var userName = $('input:text[name="userName_add"]').val();
            var passWord = $('input:text[name="passWord_add"]').val();
            var hostName = $('input:text[name="hostName_add"]').val();
            var port = $('input:text[name="port_add"]').val();
            var path = $('input:text[name="path_add"]').val();
            var weight = $('input:text[name="weight_add"]').val();

            if ($.trim(protocol) == "") {
                alertfn.danger("请选择协议");
                return;
            }
            if ($.trim(ioType) == "") {
                alertfn.danger("请选择访问方式");
                return;
            }
            if ($.trim(hostName) == "") {
                alertfn.danger("请输入hostName");
                return;
            }
            if (weight != "" && weight != undefined) {
                if (!checkNum(weight)) {
                    alertfn.danger("权重为正整数");
                    return;
                }
            }

            $.post(
                basePath + "storageConfigsController/add.do",
                {
                    protocol: protocol,
                    storageId: storageId,
                    userName: userName,
                    passWord: passWord,
                    hostName: hostName,
                    port: port,
                    path: path,
                    weight: weight,
                    ioType: parseInt(ioType)
                },
                function (data) {
                    if (data.success) {
                        $('#modal-storageConfig-add').modal("hide");
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    } else {
                        alertfn.danger(data.msg);
                    }

                }
                , 'JSON');
        });
    },
    edit: function () {
        var configId;
        $("#maintable").on("click", ".storageConfig_edit", function () {
            $('input:radio[class="protocol_edit"]').prop("checked", false);
            $('input:radio[name="ioType_edit"]').prop("checked", false);
            var $this = $(this);
            configId = $this.attr("configId");
            var protocol = $this.attr("protocol");
            var userName = $this.attr("userName");
            var passWord = $this.attr("passWord");
            var hostName = $this.attr("hostName");
            var port = $this.attr("port");
            var path = $this.attr("path");
            var ioType = $this.attr("ioType");
            var weight = $this.attr("weight");
            $('.userName_edit').val(userName);
            $('.passWord_edit').val(passWord);
            $('.hostName_edit').val(hostName);
            $('.weight_edit').val(weight);
            if (port != "undefined") {
                $('.port_edit').val(port);
            } else {
                $('.port_edit').val("");
            }
            $('.path_edit').val(path);
            if (protocol != 0 && protocol != undefined) {
                $('#protocol_' + protocol).prop("checked", "true");
            }
            if (ioType != 0 && ioType != undefined) {
                $('#ioType_' + ioType).prop("checked", "true");
            }
        });

        $("#editSubmit").click(function () {
            var protocol = $('input:radio[name="protocol_edit"]:checked').val();
            var ioType = $('input:radio[name="ioType_edit"]:checked').val();
            var userName = $('.userName_edit').val();
            var passWord = $('.passWord_edit').val();
            var hostName = $('.hostName_edit').val();
            var port = $('.port_edit').val();
            var path = $('.path_edit').val();
            var weight = $('.weight_edit').val();

            if ($.trim(protocol) == "") {
                alertfn.danger("请选择协议");
                return;
            }
            if ($.trim(ioType) == "") {
                alertfn.danger("请选择访问方式");
                return;
            }
            if ($.trim(hostName) == "") {
                alertfn.danger("请输入hostName");
                return;
            }
            if (!checkNum(weight)) {
                alertfn.danger("权重为正整数");
                return;
            }
            $.post(
                basePath + "storageConfigsController/edit.do",
                {
                    id: configId,
                    protocol: protocol,
                    userName: userName,
                    passWord: passWord,
                    hostName: hostName,
                    port: port,
                    path: path,
                    weight: weight,
                    ioType: parseInt(ioType)
                },
                function (data) {
                    if (data.success) {
                        $('#modal-storageConfig-edit').modal("hide");
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    } else {
                        alertfn.danger(data.msg);
                    }

                }
                , 'JSON');
        });
    },
    del: function () {
        $("#maintable").on("click", ".storageConfig_del", function () {
            var $this = $(this);
            var configId = $this.attr("configId");
            var params_alert = {
                "title": LCT("删除"),
                "discription": LCT("是否删除该配置"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function () {
                    $.ajax({
                        type: "post",
                        url: basePath + "storageConfigsController/del.do",
                        dataType: "json",
                        data: {
                            id: configId
                        },
                        success: function (data) {
                            if (data.success) {
                                $("#maintable").lctable(lcsetting, params);
                                alertfn.success(data.msg);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        }
                    });
                }
            };
            $("body").toolsalert(params_alert);

        })
    },
    back: function () {
        $(".back").click(function () {
            closeIframeFromInner('refresh');
        });
    }
};
$(function () {
    $("#maintable").lctable(lcsetting, params);
    storageConfigFn.init();
});
function checkNum(param) {
    var pattern = new RegExp("^[1-9]\d*|0$");
    if (pattern.test(param)) {
        return true;
    }
    return false;
}
