package com.cnlive.mam.controller;

import com.cnlive.mam.condition.CustomCondition;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomRoleModel;
import com.cnlive.mam.service.CustomRoleService;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/customRoleController")
public class CustomRoleController extends BaseController {

    @Resource
    private CustomRoleService customRoleService;

    /**
     * 用户列表页
     * @return
     */
    @RequestMapping("/toUserList")
    public String toUserList(HttpServletRequest request, ModelMap modelMap) {
        Object sp_id = SecurityUtils.getSubject().getPrincipals().oneByType(Map.class).get("new_sp_id");
        Integer adminSpId = null;
        List<CustomRoleModel> list = customRoleService.selectBySpId(Integer.valueOf(sp_id.toString()));
        List<CustomRoleModel> adminList = customRoleService.selectBySpId(adminSpId);
        list.addAll(0, adminList);
        modelMap.addAttribute("roleList", list);
        return "/customRole/userList";
    }

    /**
     * 用户列表页数据获取 AJAX
     * @param request
     * @param page
     * @param rows
     * @param name
     * @param contacts
     * @return
     */
    @RequestMapping("/userList")
    @ResponseBody
    public DataGrid userList(
            HttpServletRequest request,
            @RequestParam(defaultValue = "1", required = false) Integer page,
            @RequestParam(defaultValue = "10", required = false) Integer rows,
            String name,
            String contacts) {
        Object sp_id = SecurityUtils.getSubject().getPrincipals().oneByType(Map.class).get("new_sp_id");
        CustomCondition customCondition = new CustomCondition();
        customCondition.setPage(page);
        customCondition.setRows(rows);
        customCondition.setContacts(contacts);
        customCondition.setName(name);
        customCondition.setSpId(Integer.valueOf(sp_id.toString()));
        customCondition.setIsParent(0);
        return customService.getCustomInfoList(customCondition);
    }

    @RequestMapping("/userBind")
    @ResponseBody
    public JsonResult userBind(HttpServletRequest request, Long uid, Integer roleId) {
        Long spId = this.getSpId(request);
        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if(!checkCustomerExist.isSuccess()){
            return JsonResult.createErrorInstance("用户认证失败");
        }
        CustomModel customModel = (CustomModel) checkCustomerExist.getObj();
//        if(uid == null ||  customModel.getCustomId().intValue() != uid.intValue()){
//            return JsonResult.createErrorInstance("用户认证失败");
//        }
        if(spId.intValue() != customModel.getSpId().intValue()){
            return JsonResult.createErrorInstance("sp不同不允许修改");
        }
        CustomModel updateCustom = new CustomModel();
        updateCustom.setCustomId(uid);
        updateCustom.setRoleId(roleId);
        customService.modify(updateCustom);
        return JsonResult.createSuccessInstance("操作成功");
    }

}
