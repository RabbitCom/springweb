//七牛再次封裝JS 
function UploadBean(config){
	this.opt = {
        domain:"",
        key:"",
        type:"",
        // file:null,
        UploadProgress:function(up,rs){
                
        },
        FileUploaded:function(up,rs){
               
        },
        BeforeUpload:function(up,rs){

        },
        FilesAdded:function(up,rs){

        }
     };
	 this.init = function(config){
		 UploadBean.opt=$.extend(this.opt,config);
		 if(UploadBean.opt.type == 'qn'){
          UploadBean.opt.uploader =  Qiniu.uploader({
       
           disable_statistics_report: false,
           runtimes: 'html5,flash,html4',
           browse_button: 'addFiles',
           container: 'container',
           uptoken_url : basePath + "videoController/getQNToken.do",
           domain:  UploadBean.opt.domain, 
           auto_start: false,
           init:{
               Key:function(uploader,file){
              	var key = UploadBean.opt.key.replace('\$\{filename\}',file.name);
	        		return key;
               },
//               
               FilesAdded:function(up, files){
                      UploadBean.opt.FilesAdded(up,files);
               },
               UploadProgress:function(up,rs){
                      UploadBean.opt.UploadProgress(up,rs);
                    },
               FileUploaded:function(up,rs){
                    UploadBean.opt.FileUploaded(up,rs); 
               },
               BeforeUpload:function(up,rs){
                  UploadBean.opt.BeforeUpload(up,rs); 
               }
           },
         });
          
      }
      if(UploadBean.opt.type == 'ks'){
      	console.log("come in ks");
      	var dataUrl = basePath + "optionsInfoController/ksConfig.do";
           $.post(dataUrl,function(rs){

           Ks3.config.AK =rs.obj.ksak;
           Ks3.config.SK = rs.obj.kssk;
           Ks3.config.region = rs.obj.region;
           Ks3.config.bucket = rs.obj.bucket;
           var policy = {
                  "expiration": new Date(getExpires(3600)*1000).toISOString(), //一小时后
                  "conditions": [
                      ["eq","$bucket", Ks3.config.bucket],
                      ["starts-with", "$key", ""],
                      ["starts-with", "$acl", "public-read"],
                      ["starts-with", "$name", ""],   //表单中传了name字段，也需要加到policy中
                      ["starts-with", "$x-kss-meta-custom-param1",""],  //必须只包含小写字符
                      ["starts-with", "$Cache-Control",""],
                      ["starts-with", "$Expires", ""],
                      ["starts-with", "$uploadDomain", ""],
                      ["starts-with", "$Content-Disposition", ""]
                  ]
              };
          
          var stringToSign = Ks3.Base64.encode(JSON.stringify(policy));
          var signatureFromPolicy = Ks3.b64_hmac_sha1(Ks3.config.SK, stringToSign);
          console.log('signatureFromPolicy:' + signatureFromPolicy);
          ks3UploadUrl =  Ks3.config.protocol + '://' + Ks3.ENDPOINT[Ks3.config.region] + '/';
          
          var ks3Options = {
              KSSAccessKeyId: Ks3.config.AK,
              policy: stringToSign,
              signature: signatureFromPolicy,
              bucket_name: Ks3.config.bucket,
              key: UploadBean.opt.key,
              acl: "public-read",
              uploadDomain: ks3UploadUrl +  Ks3.config.bucket,
              autoStart: false,
              'x-kss-meta-custom-param1': 'Hello',
              'Cache-Control': 'max-age=600',                //设置缓存多少秒后过期
              'Expires': new Date(getExpires(600) * 1000),   //设置缓存过期时间
              'Content-Disposition' :'attachment;filename=', // 触发浏览器下载文件
              onFilesAddedCallBack: function(uploader, obj){//文件上传之前时调用的回调函数
                  UploadBean.opt.FilesAdded(uploader, obj);
              },
              onBeforeUploadCallBack: function(uploader, obj){//文件上传之前时调用的回调函数
                  UploadBean.opt.BeforeUpload(uploader, obj);
              },
              onFileUploadedCallBack: function(uploader, obj){//文件上传完成时调用的回调函数
                  UploadBean.opt.FileUploaded(uploader, obj);
              },
              onUploadProgressCallBack: function(uploader, obj){//文件上传完成时调用的回调函数
                  UploadBean.opt.UploadProgress(uploader, obj);
              },
          };
          var pluploadOptions = {
              browse_button: "addFiles", //触发对话框的DOM元素自身或者其ID
              drop_element: document.body,
              filters: {
                  mime_types : [
                      { title : "UPLOAD FILES", extensions : uploadOption.extensions}
                  ],
                  max_file_size : uploadOption.max_file_size, //最大上传大小
                  prevent_duplicates : true //不允许选取重复文件
              }
          };
          UploadBean.opt.uploader = new ks3FileUploader(ks3Options, pluploadOptions).uploader;

        });
      }

  };
  this.start=function(){
      UploadBean.opt.uploader.start();
  };
  this.stop=function(){
      UploadBean.opt.uploader.stop();
  }
};
var uploader = new UploadBean();
uploader.init({
	  domain:"test.qnvod.cnlive.com",
//	  domain:$("#domain").val(),
//	  key:$("#type").val(),
	  type:'qn',
//	  type:$("#type").val(),
	  'FilesAdded': function (up, files) {
		  var tbody_html = '';
	      var tbody_origin_html = '';
		  for(var i = 0 ; i < files.length; i++){
			  var file = files[i];
			  tbody_html += '<tr id="'+file.id+'">';
              tbody_html += '<td>' + file.name + '</td>';
              tbody_html += '<td>' + file.size + '</td>';
              tbody_html += '<td><span id="' + file.id + '_progress"><progress id="' + file.id + '_progressBar" value="0" max="100" style="width: 100%"></progress></span>';
              tbody_html += '<p id="' + file.id + '_baifenbi" style="display: none;"> </p></td>';
              tbody_html += '<td><a href="javascript:void(0)" onclick=deleteUpload("'+file.id+'") >' + LCT("刪除") + '</a></td>';
              tbody_html += '</tr>';
		  }
		  $("#uploadShowInfo").append(tbody_html);
    },

    'UploadProgress': function (up, file) {
        // 每个文件上传时，处理相关的事情
    	console.log(file.precent);
        var trMd5 = file.id;
        $("#" + trMd5 + "_progress").html('<progress id="' + trMd5 + '_progressBar" value="' + file.percent + '" max="100" style="width: 100%"></progress>');
        $("#" + trMd5 + "_baifenbi").html(file.percent + "%");
        $("#" + trMd5 + "_baifenbi").css("display", "block");
    },
    'FileUploaded': function (uploader, file, responseObject) {
        $("tr[id='" + file.id + "']").remove();
    },

    'BeforeUpload': function (up, file) {
    	var lastIndex = file.name.lastIndexOf(".");
        var nameLength = file.name.length;
    	var fileSuffix = file.name.substring(lastIndex + 1, nameLength);
    	var url = basePath + "optionsInfoController/optionsUpload.do";
    	var type = file.type;
        type = type.substring(0, type.lastIndexOf("/"));
        var relationId = $("#videoId_hidden").val();
        if (type == "video") {
            type = 0;
        } else if (type == "image") {
            type = 1;
        } else {
            type = 2;
        }
    	var data = {
    			md5:file.id,
    			name:file.name,
    			type:type,
    			suffix:fileSuffix,
    			size:file.size,
    			relationId:relationId
    	};
    	$.post(url,data,function(result){
    			console.log(result);
    		}
    	 );
    }
     
});

function pageInfo (){
	var url = basePath + "optionsInfoController/dataGrid.do";
	$.get(url,function(data){
		console.log(data);
//		  var tbody_html = '';
//		  for(var i = 0 ; i < data.length; i++){
//			  var file = data[i];
//			  tbody_html += '<tr id="options_'+file.id+'">';
//             tbody_html += '<td>' + file.name + '</td>';
//             tbody_html += '<td>' + file.size + '</td>';
//             tbody_html += '<td>'+ file.path +'</td>';
//             tbody_html += '<td><a href="javascript:void(0)" onclick=deleteUpload("'+file.id+'") >' + LCT("刪除") + '</a></td>';
//             tbody_html += '</tr>';
//		  }
//		  $("#optionsShowInfo").append(tbody_html);
	});
}
		
function deleteUpload(id){
	var url = basePath + "optionsInfoController/dataGrid.do?id="+id;
	$.get(url,function(data){
		console.log(data);
	})
}

$("#uploadFiles").on('click',function(){
	uploader.start();
})


 

