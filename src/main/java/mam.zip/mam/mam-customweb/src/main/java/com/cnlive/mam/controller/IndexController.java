package com.cnlive.mam.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cnlive.mam.model.CustomCategoryModel;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.vo.MenuTree;

@Controller
@RequestMapping("/indexController")
public class IndexController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(IndexController.class);

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;


    /**
     * 前端心跳轮询,防止上传时间过长session丢失
     */
    @RequestMapping("/polling")
    public void polling(HttpServletResponse response) {
        try {
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "GET,POST");
            response.getWriter().print("");
        } catch (IOException e) {
            _log.error(e.getMessage());
        }
    }

    /**
     * @Title: getMenuTreeByCustom
     * @Description:组装客户分类菜单
     * @param @param customId
     * @return List<MenuTree>
     * @throws
     */
    @RequestMapping("/getMenuTreeByCustom")
    @ResponseBody
    public List<MenuTree> getMenuTreeByCustom(HttpServletRequest request,Long id) {
        // 获取customId
        Long customId = this.getCustomId(request);
        List<MenuTree> tl = new ArrayList<MenuTree>();
        try {
            if (id != null) {
                // ("video_list")
                Map<String, Object> video_attr = new HashMap<String, Object>();
                video_attr.put("url", "/videoController/manager.do?customCategoryId=" + id);
                MenuTree tree_video = new MenuTree("v_001", String.valueOf(id), ("video_list"), "open", null, video_attr);
                // ("album_list")
                Map<String, Object> album_attr = new HashMap<String, Object>();
                album_attr.put("url", "/albumController/manager.do?customCategoryId=" + id);
                MenuTree tree_album = new MenuTree("a_001", String.valueOf(id), ("album_list"), "open", null, album_attr);

                tl.add(tree_album);
                tl.add(tree_video);
            } else {
                List<CustomCategoryModel> customCategoryList = customCategoryService.getCustomCategoryByCustomId(customId);
                if (customCategoryList != null && customCategoryList.size() > 0) {
                    for (CustomCategoryModel customCategoryModel : customCategoryList) {
                        MenuTree tree = new MenuTree();
                        tree.setId(String.valueOf(customCategoryModel.getCustomCategoryId()));
                        tree.setPid(String.valueOf(customCategoryModel.getParentCustomCategoryId()));
                        tree.setText(customCategoryModel.getCustomCategoryName());
                        tl.add(tree);
                    }
                }
            }
        } catch (Exception e) {
            _log.error(e.getMessage());
        }
        return tl;
    }

    @RequestMapping("/logout")
    public String logout(){
    	SecurityUtils.getSubject().logout();
		return "redirect:https://testuser.cnlive.com/OpenSSO2/logout?service=http://test.mam.cnlive.com/loginsc";
    }
    
}
