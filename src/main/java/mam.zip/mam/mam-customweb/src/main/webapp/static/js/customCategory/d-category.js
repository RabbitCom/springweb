/* Created by zhaojing on 2015/11/06.
 */

/*	alert("中间钱");
	$.fn.zTree.init();
	alert("中间hou");*/
	var treeEdit =null;//提交修改前选中节点
	var isEdit = false;
	var editRow = null;
	var editTemp = null;
	var currPage = 1;
	var leftTree = null;
	var dicValues = null;
	$(function() {
	    //添加
		$("#save").click(function() {
			if (currPage != 1) {
				$("#maintable").bootstrapTable("selectPage", 1);
			}
			var nodes = leftTree.getCheckedNodes(true);
			var icmsId = nodes[0].id;
			var icmsName = nodes[0].title;
			var icmsPid = nodes[0].pid;
			var icmsColumnId = nodes[0].columnId;
			var obj = {};
			obj.categoryDicValue = dicValues;
			obj.icmsCategoryId = icmsId;
			obj.icmsCategoryName = icmsName;
			obj.MAM_NodeID = icmsPid+"-"+icmsId;
			obj.MAM_NodeName = icmsPid+"-"+icmsId;
			obj.cms_column_id = icmsColumnId;
			obj.cms_column_name = icmsName;
			
			$.ajax({
		        type: 'post',
		        url: basePath +"customCategoryController/saveCategoryRef.do",
		        data: JSON.stringify(obj),
		        contentType: "application/json",
		        success: function (data) {
		        	$('#editorModal').modal('hide');
		        	categoryFn.addCategory();
		           
		        }
		    })
		});
		//关闭事件
		$("#editorModal").on("hide.bs.modal", function() {
			isEdit = false;
		});
		

	});
	function queryParamsFunctionMain(params) {
		return {
			pageSize : params.limit,
			pageNo : params.offset / params.limit + 1,
			spcolumn : params.search,
			spId:"82"
		};
	}

	function responseHandler(res) {
		return {
			"rows" : res.result,
			"total" : res.totalCount
		};
	}
	
	function isDicValues(res){
		if(leftTree == null){
            $('#editorModal').modal('hide');
            alertfn.danger("未设置栏目获取地址");
		}else {
            $('#editorModal').modal('show');
            dicValues = res;
        }
	}


$(function(){
	InitTree();
});	
 function onClick(e, treeId, treeNode) {
    }
 function InitTree() {
    var setting = {
        async:{
    		autoParam: ["title","columnId"],
    		dataType: "json",
    		  enable: true
    	},
    	check:{
    		enable:true,
    		chkStyle: "radio",
    		radioType:"all"
    	},
        data: {
            key: {
                name:"title"
            },
            simpleData: {
                enable: true,
                idKey: "id",
                pIdKey: "pid",
                rootPId: 0,
                checked: true
            }
        },
        callback: {
            onClick: onClick
        }
    };
     $.post(basePath + "customCategoryController/getCustomColumnTree.do",
         function(data){
             var res = $.parseJSON(data);
             if(res.success){
                 leftTree = $.fn.zTree.init($("#lTree"), setting, JSON.parse(res.obj));
             }
     });
  }


/**
 * Created by zhaojing on 2015/11/06.
 */
//获取字符串的长度
var rel = /^[\w\u4e00-\u9fa5 +]{1,20}$/;
var url = basePath + "customCategoryController/dataGridNew.do";
var page = 1;
var rows = 10;
var categoryFn = {
    init: function() {
        this.addCategory(); //获取参数
        this.delRelation(); //删除
    },
    addCategory: function() {
        $("#maintable tbody").remove();
    	//获取分类对应的icms栏目
    	$.ajax({
            type: "post",
            url: basePath + "customCategoryController/getCategoryRelationBy.do",
//            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
//            async: false,
            success: function(res) {
            	var tbody_html = '';
                for (var i = 0; i < res.obj.length; i++) {
                	var showName = res.obj[i].categorys.showName;
                	var dicValue = res.obj[i].categorys.dicValue;
                	tbody_html += '<tbody class="le-text-xs">';
                	tbody_html += '<tr style="display: table-row;" data-id='+ res.obj[i].CategoryRelation.categoryRelationId +'>';
                	// tbody_html += '<td width="10%">' + dicValue + '</td>';
                	tbody_html += '<td width="20%">' + showName + '</td>';
                	if(res.obj[i].flag == true){
                		tbody_html += '<td width="20%">' + res.obj[i].CategoryRelation.icmsCategoryName + '</td>';
                		// tbody_html += '<td width="10%"><a class="btn btn-primary121" onclick="isDicValues('+res.obj[i].categorys.dicValue+')">设置对应栏目</a><a href="javascript:void(0)" class="delItem">' + LCT("删除对应栏目") + '</a></td>';
                		tbody_html += '<td width="10%"><a class="btn btn-primary121" onclick="isDicValues('+res.obj[i].categorys.dicValue+')">设置对应栏目</a></td>';
                	}else{
                		tbody_html += '<td width="20%"></td>';
                		tbody_html += '<td width="10%"><a class="btn btn-primary121" onclick="isDicValues('+res.obj[i].categorys.dicValue+')">设置对应栏目</a></td>';
                	}
                	
                	tbody_html += '</tr>';
                	tbody_html += '</tbody>';
                }
                $("#maintable").append(tbody_html);
                $(".media-upload-box tbody tr").has("i.caret").show();
            	
            },
            error: function() {
                //console.log("fail");
            }
        });
    },
    delRelation: function() {
        //分类管理--单个删除
        $("#maintable").on("click", ".delItem", function() {
            var delids = "";
            ids = $(this).closest("tr").find("td:eq(1)").find("input").val();
            delids = $(this).closest("tr").attr("data-id");
            var params = {
                "title": LCT("删除"),
                "discription": LCT("确认删除对应栏目"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function() {
                    $.ajax({
                        type: "get",
                        url: basePath + "customCategoryController/deleteCategoryRelation.do?categoryRelationId=" + delids,
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                            	categoryFn.addCategory();
                                alertfn.success(LCT("已成功删除栏目关系"));
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function() {
                            //console.log("fail");
                        }
                    });
                }
            };
            $("body").toolsalert(params);
        });
    }
};
$(function() {
    categoryFn.init();
})