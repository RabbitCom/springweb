package com.cnlive.mam.task;

import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.VideoDeleteTaskService;
import com.cnlive.mam.service.VideoService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin on 2017/5/9.
 */
@Component
public class deleteVideoInitFailJob extends DeleteResourcePublic{

    private static Logger _log = LoggerFactory.getLogger(deleteVideoInitFailJob.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "videoDeleteTaskService")
    private VideoDeleteTaskService videoDeleteTaskService;

    @Value("#{configProperties['devMode']}")
    private String devMode;

    public void deleteVideoInitFaild(){
        if (!Boolean.parseBoolean(devMode)) {
            List<VideoModel> uploadFaildVideos = videoService.getUploadFaildVideos();
            if (uploadFaildVideos != null && uploadFaildVideos.size() > 0) {
                for (VideoModel videoModel : uploadFaildVideos) {
                    try{
                        deleteVideo(videoModel);
                        videoDeleteTaskService.delVideoAndFile(videoModel.getVideoId());
                    }catch (Exception ex){
                        _log.error("删除上传失败的视频信息出错，error={},msg={}",ex,ex.getMessage());
                    }

                }
            }
        }
    }
}
