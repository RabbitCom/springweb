(function(window) {
window.LCT = function(key) {
    return key;
};
})(window);