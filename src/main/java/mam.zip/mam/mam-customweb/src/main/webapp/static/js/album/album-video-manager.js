
var params = {},
    ids = "",
    videoName_arr = [],
    index = 0;
var lcsetting = {
    "ajax": basePath + "videoController/dataGrid.do?albumId=" + $("#albumId_hidden").val(),
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text", //到时候去掉此参数
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            return '<input type="checkbox" class="checkItem" value="" data-id="' + d.videoId + '">';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<dl class="clearfix">' +
                '<dt class="ui-fl img">' +
                '<a class="video-view"  videoPlyUrl =' + d.playUrl + ' videoPlyImgUrl = '+ d.listPicUrl +' href="#modal-video-view" data-toggle="modal" ><img src=' + getListPicUrl(d.listPicUrl) + '></a>' +
                '</dt>' +
                '<dd class="ui-fl album-info">' +
                '<p>' + LCT("ID") + '：' + d.businessUUID + '</p>' +
                '<p class="videoName"></p>' +
                '<p>' + LCT("时长") + '：<span class="video-duration">' + vrsFn.formatSeconds(d.duration) + '</span></p>' +
                '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                '</dd>' +
                '</dl>';
        }
    }, {
        "data": "status",
        "format": function(i, j, d) {
            function parese(s) {
                if (s == -1) {
                    return '<span class="link-blue-txt">' + LCT("初始化") + '</span>';
                }
                if (s == 0) {
                    return '<span class="link-blue-txt">' + LCT("待编辑") + '</span>';
                }
                if (s == 1) {
                    return '<span class="link-blue-txt">' + LCT("已编辑") + '</span>';
                }
                if (s == 2) {
                    return '<span class="link-blue-txt">' + LCT("审核中") + '</span>';
                }
                if (s == 3) {
                    return '<span class="link-blue-txt">' + LCT("审核通过") + '</span>';
                }
                if (s == 4) {
                    return '<span class="link-blue-txt">' + LCT("审核拒绝") + '</span>';
                }
                if (s == 5) {
                    return '<span class="link-blue-txt">' + LCT("上线") + '</span> ';
                }
                if (s == 6) {
                    return '<span class="link-blue-txt">' + LCT("下线") + '</span>';
                }
                if (s == 7) {
                    return '<span class="link-blue-txt">' + LCT("发布中") + '</span>';
                }
                if (s == 8) {
                    return '<span class="link-blue-txt">' + LCT("发布成功") + '</span>';
                }
                if (s == 9) {
                    return '<span class="link-blue-txt">' + LCT("发布失败") + '</span>';
                }
            }
            return parese(d); //视频状态
        }
    }, {
        "data": "lcall",
        "className": 'fileStatus',
        "format": function(i, j, d) {
            function parese(z) {
                if (z == -1) {
                    return '<span class="link-blue-txt">' + LCT("上传中") + '</span>';
                }
                if (z == 0) {
                    return '<span class="link-blue-txt">' + LCT("上传完成") + '</span>';
                }
                if (z == 1) {
                    return '<span class="link-blue-txt">' + LCT("转码中") + '</span>';
                }
                if (z == 2) {
                    return '<span class="link-blue-txt">' + LCT("转码成功") + '</span>';
                }
                if (z == 3) {
                    return '<span class="link-blue-txt">' + LCT("转码失败") + '</span><p>'
                        +'<a class="transcodingDetails" style="color: red;" data-toggle="modal" href="#modal-transcoding-details" data-id="' + d.videoId + '">' + "查看原因" + '</a >';
                }
            }
            return parese(d.fileStatus); //媒资状态
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //上传时间
            return d.createTime;
        }
    },{
        "data": "lcall",
        "className": 'commentSet',
        "format": function(i, j, d) {
            var editPage = '<a href="javascript:void(0)" class="video-edit ml-10" category-id="' + d.category + '" customcategory-id="' + d.customCategoryId + '" data-albumId="' + d.albumId + '" data-id="' + d.videoId + '">' + LCT("编辑") + '</a>';
            var deleteBtn = '<br/><a href="#modal-detele" data-toggle="modal" data-id="' + d.videoId + '" class="ml-10 detele">' + LCT("删除") + '</a>';
            var videoDel = '<br/><a href="javascript:void(0)"  class="video-del ml-10"  data-id="' + d.videoId + '">' + LCT("移出专辑") + '</a>' ;
            var onlineBtn = '<br/><a href="javascript:void(0)" data-id="' + d.videoId  +'" class="ml-10 online">' + LCT("上线") + '</a>';
            var downlineBtn = '<br/><a href="javascript:void(0)" data-id="' + d.videoId  +'" class="ml-10 downline">' + LCT("下线") + '</a>';
            var _content = '<br/><a href="javascript:void(0)"  class="video-audit ml-10" data-id="' + d.videoId + '">' + LCT("视频信息") + '</a>';
            var showcmsurl = '<br/><a href="javascript:window.open(\'' + d.videoPlyUrl + '\')">播放页面</a>';

            var sucai = d.isIcms2Mam;
            if(sucai == 1){
                return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  +editPage + _content +'</p>';
            }

            var reTransCodeBtn = '';
            if(d.fileStatus == 3){
                var reTransCodeBtn = '<br/><a href="javascript:void(0)"  data-id="' + d.videoId  +'" class="ml-10 reTransCode">' + LCT("重转码") + '</a>';
            }

            var playerCode = "";
            if(d.status >=5 && d.fileStatus == 2 && d.status != 6){
                playerCode = '<br/><a data-toggle="modal" href="#modal-playCode-details" data-id="' + d.spid +'_'+ d.businessUUID  +'" data-picUrl="'+d.listPicUrl+'" class="playerCodeShow">' + LCT("外嵌播放代码") + '</a>';
            }
            function parese(m,n) {
            	//编辑、移除、删除
            	if(m == 0){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + videoDel + deleteBtn  + reTransCodeBtn + playerCode+'</p>';
            	}
            	//编辑、查看、删除、移除
            	if((m == 1 || m == 4) && n == 2){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + deleteBtn + videoDel + _content  + reTransCodeBtn + playerCode+'</p>';
            	}
            	//预览、查看、移除
            	if(m == 2 && n == 2){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + _content + videoDel +playerCode+'</p>';
            	}
            	//编辑、上线（下线）、查看、删除、移除
            	if(m == 3 && n == 2){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage  + onlineBtn + _content + videoDel + deleteBtn  +playerCode+'</p>';
            	}
            	//编辑、下线、查看、移除
            	if((m == 5 )&& n == 2){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + downlineBtn + videoDel + _content +playerCode+'</p>';
            	}
            	//编辑、上线、查看、删除、移除
            	if((m == 6 ) && n == 2){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + onlineBtn + deleteBtn + videoDel + _content +playerCode+'</p>';
            	}
            	//编辑、查看、移除
            	if(m == 7 && n == 2){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + editPage + videoDel + _content +playerCode+'</p>';
            	}
                if(m == 8 && n==2){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + downlineBtn + _content +showcmsurl +playerCode+'</p>';
                }
                if(m == 9 && n ==2){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + downlineBtn + _content +showcmsurl +playerCode+'</p>';
                }
            }
            return parese(d.status,d.fileStatus);
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); //table
        //操作
        $("#maintable").on("mouseover", ".commentSet", function() {
            $(this).find("a.handle").hide();
            $(this).find("p").show();
        }).on("mouseout", ".commentSet", function() {
            $(".commentSet a.handle").show();
            $(".commentSet p").hide();
        });
        //视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(LCT("名称") + '：'+remark_html);
            $(tr[i]).find("a.video-view").attr("data-name", remark_html);
        }
        videoName_arr = [];
    }
}
var albumVideoFn = {
    init: function() {
    	this.mltiSelect();//多条件查询
        this.handleTable(); //表格数据筛选
        this.albumStatus(); //获取初始上下线状态
        this.derivedExcel(); //Excel导出
        this.editPreview(); //编辑预览
        this.del(); //视频移除
        this.edit(); //编辑返回
        this.deteleVideo(); //视频删除
        this.onoffline();//上下线
        this.videoAudit(); //查看
        this.reTransCode();//重新转码
        this.showPlayerCode(); //播放器嵌入代码
    },
    
    mltiSelect: function() {
    	var input = $("input[name='video-status']");
    	var video_status;
        var video_status_valArr = [];
        var video_status_textArr = [];
        if (!$("input[name='video-status']:checked").length) {
            $(".video-status-result").html("请选择").attr("onoffStatus", "");;
        } else {
            for (i = 0; i < input.length; i++) {
                if (input[i].checked) {
                    var video_status_val = $(input[i]).val();
                    var video_status_text = $(input[i]).closest("li").text();
                    video_status_valArr.push(video_status_val);
                    video_status_textArr.push(video_status_text);
                    video_status = video_status_valArr.join(",")
                    if (video_status_valArr.length) {
                        $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                    }
                }
            }
        }
        $(".video-status-result").click(function() {
            if ($(".option-items").is(":visible")) {
                $(".option-items").addClass("hide");
            } else {
                $(".option-items").removeClass("hide");
            }
        });
        $(".select-checkbox").mouseleave(function() {
            $(".option-items").addClass("hide");
        })
        $("#video_status_choose").click(function(){
        	var input = $("input[name='video-status']");
        	if($("input[name='video-status']:checked").length){
        		for(i = 0; i < input.length; i++){
        			 if (input[i].checked) {
        				 input[i].checked = false;
        			 }
        		}
        	} 
        })
        $(".select-checkbox .btn_ok").click(function() {
        	var input = $("input[name='video-status']");
        	var video_status;
            var video_status_valArr = [];
            var video_status_textArr = [];
            if (!$("input[name='video-status']:checked").length) {
                $(".video-status-result").html("请选择").attr("onoffStatus", "");;
            } else {
                for (i = 0; i < input.length; i++) {
                    if (input[i].checked) {
                        var video_status_val = $(input[i]).val();
                        var video_status_text = $(input[i]).closest("li").text();
                        video_status_valArr.push(video_status_val);
                        video_status_textArr.push(video_status_text);
                        video_status = video_status_valArr.join(",")
                        if (video_status_valArr.length) {
                            $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                        }
                    }
                }
            }
            $(".option-items").addClass("hide");
            var onoff  = $(".video-status-result").attr("onoffstatus");
        	if (onoff) {
            	params["onoffStatus"] = onoff;
            } else {
            	params["onoffStatus"] = "0,1,2,3,4,5,6,7,8,9";
            }
            var fileStatus = $.trim($(".search_select option:selected").val());
            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    videoAudit: function(){
		$("#maintable").on("click", ".video-audit", function() {
			var videoId = $(this).attr("data-id");
			var lc_inner_href = basePath + "videoController/toVideoView.do?videoId=" + videoId;
            showInIFrame(lc_inner_href);
		});
    },
    reTransCode:function(){
        $("#maintable").on("click", ".reTransCode", function() {
            var videoId = $(this).attr("data-id");
            if(videoId!=null){
                $(this).text( LCT("转码中"));
                $(this).removeAttr("data-id");
                $.ajax({
                    url: basePath + "videoController/reTransCode.do",
                    data: {videoId:videoId},
                    type: "post",
                    dataType: "json",
                    success: function(data) {
                        if(data.success) {
                            $(".btn_search").click();
                        }
                    }
                })
            }
        });
    },
    showPlayerCode :function () {
        $("#maintable").on("click", ".playerCodeShow", function() {
            var jiemu_id = $(this).attr("data-id");
            // var poster = "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
            var poster = $(this).attr("data-picUrl");
            var width = 800;
            var height = 450;
            $("#jiemu_id_hidden").val(jiemu_id);
            $("#poster_url").val(poster);
            $("#width_v").val(width);
            $("#height_v").val(height);
            var playCode = '<iframe src="http://z.cnlive.com/videoplay.html?'
                + 'vid='+jiemu_id+'&poster='+poster+'"'
                + ' style="border: 0;width: '+width+'px;height: '+height+'px;"></iframe>';

            var showHtml = '<textarea id="playerCode_text" disabled style="width: 100%;height: 100px;">'+playCode+'</textarea>'

            $("#showCode_div").html(showHtml);
        });
        $("#modal-playCode-details").on("hide.bs.modal", function() {
            $("#showCode_div").html("");
        });


        $("#copy-playCode").zclip({
            path: basePath + 'static/js/video/ZeroClipboard.swf', //记得把ZeroClipboard.swf引入到项目中
            copy: function(){
                var jiemu_id_get = $("#jiemu_id_hidden").val();
                var poster_get = $("#poster_url").val();
                var width_get = $("#width_v").val();
                var height_get = $("#height_v").val();
                var playCode_get = '<iframe src="http://z.cnlive.com/videoplay.html?'
                    + 'vid='+jiemu_id_get+'&poster='+poster_get+'"'
                    + ' style="border: 0;width: '+width_get+'px;height: '+height_get+'px;"></iframe>';
                $("#playerCode_text").text(playCode_get);
                return $("#playerCode_text").val();
            },
            afterCopy:function(){/* 复制成功后的操作 */
                var $copysuc = $("<div class='copy-tips' style='z-index:9999'><div class='copy-tips-wrap'>☺ 复制成功</div></div>");
                $("body").find(".copy-tips").remove().end().append($copysuc);
                $(".copy-tips").fadeOut(3000);
            }
        });
    },
    albumStatus: function() {
        var albumStatus_arr = [];
        var icon_checkbox = $(".search-info label");
        for (var i = 0; i < icon_checkbox.length; i++) {
            if ($(icon_checkbox[i]).find("input:checked").length) {
                albumStatus_arr.push($(icon_checkbox[i]).find("input").attr("albumstatus"));
            }
        }
        return albumStatus_arr;
    },
    handleTable: function() {
        //初始化表格
        if (albumVideoFn.albumStatus().length) {
            params["onoffStatus"] = albumVideoFn.albumStatus();
        } else {
            delete params["onoffStatus"];
        }
    	var onoff  = $(".video-status-result").attr("onoffstatus");
    	if (onoff) {
        	params["onoffStatus"] = onoff;
        } else {
            delete params["onoffstatus"];
        }
        $("#maintable").lctable(lcsetting, params);

        //点击搜索按钮
        $(".btn_search").bind("click", function() {
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var value_status = $.trim($(".search_status").val());
            var fileStatus = $.trim($(".search_select option:selected").val());
            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }
            albumVideoFn.albumStatus();
            if (albumVideoFn.albumStatus().length) {
                params["onoffStatus"] = albumVideoFn.albumStatus();
            } else {
                delete params["onoffStatus"];
            }
            if (value_name) {
                params["videoName"] = value_name;
            } else {
                delete params["videoName"];
            }
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
            if (value_status) {
                params["status"] = value_status;
            } else {
                delete params["status"];
            }
            var custom_name = $.trim($(".search_customName").val());
            if(custom_name){
                params["createCustomName"] = custom_name;
            }else {
                delete params["createCustomName"];
            }
            var uploadStartTime = $.trim($("#d4311").val());
            var uploadEndTime = $.trim($("#d4312").val());
            if(uploadStartTime){
                params["startTime"] = uploadStartTime;
            }else{
                delete params["startTime"];
            }
            if(uploadEndTime){
                params["endTime"] = uploadEndTime;
            }else{
                delete params["endTime"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    derivedExcel: function() {
        checkall("#modal-excel");
        $("#btn-excel").attr("href", "");
        $("#btn-excel").click(function() {
            var length = $("#maintable tbody td[colspan='6']").length;
            if (length) {
                alertfn.danger(LCT("没有要导出的视频"));
            } else {
                $("#btn-excel").attr("href", "#modal-excel");
            }
        });
        $("#modal-excel").on('hide.bs.modal', function() {
            $("#btn-excel").attr("href", "");
        });
        $("#modal-excel").on("click", ".btn-ok", function() {
            var arr_hearders = [];
            var arr_fields = [];
            var arr_videos = [];
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var checkbox_table = $("#maintable tbody input:checkbox");
            var checkbox = $("#modal-excel input:checkbox");
            for (var i = 1; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    arr_hearders.push($(checkbox[i]).closest("label").text());
                    arr_fields.push($(checkbox[i]).val());
                }
            }
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    arr_videos.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            if (arr_hearders.length == 0) {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("未选择任何excel导出项"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
                $("body").toolsalert(params);
                return;
            } else {
                albumVideoFn.albumStatus();
                var url = basePath + "exportExcelVideo.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                if (value_name) {
                    url += "&videoName=" + value_name;
                }
                if (value_id) {
                    url += "&videoId=" + value_id;
                }
                if (albumVideoFn.albumStatus().length) {
                    url += "&value_status=" + albumVideoFn.albumStatus();
                }
                if (arr_videos.length) {
                    url += "&videoIds=" + arr_videos;
                }
                window.open(url, "_blank");
            }
        });
    },
    editPreview: function() {
        $("#maintable").on("click", ".video-edit", function() {
            var customCategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumId");

            if (categoryId && categoryId != "" && categoryId != "0") {
                var lc_inner_href = basePath + "videoController/toVideoEdit.do?videoId=" + videoId;
                showInIFrame(lc_inner_href);
            } else {
                if (albumId != null && albumId != 0) {
                    var params = {
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    }
                } else {
                    var params = {
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                }
                $("body").toolsalert(params);
                return;
            }
        });
        $("#maintable").on("click", ".video-view", function() {
            var videoPlyUrl = $(this).attr("videoPlyUrl");
            var data_name = $(this).attr("data-name");
            var imgUrl = $(this).attr("videoPlyImgUrl");
            if(imgUrl == "" || imgUrl == null || imgUrl == undefined || imgUrl == "null" || imgUrl == "undefined"){
                imgUrl = "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
            }else {
                imgUrl = imgUrl ;
            }
            $("#cnlivePlayer").attr("flashVars","type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1&currRate=2&cover="+imgUrl+"&videoUrl_2="+videoPlyUrl);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $('#modal-video-view').on('hide.bs.modal', function() {
            // $("#player").html("");
        });
    },
    del: function() {
        //单个移除
        $("#maintable").on("click", ".video-del", function() {
            var $this = $(this);
            var data_id = $this.attr("data-id");
            var albumId = $("#albumId_hidden").val();
            var params_alert = {
                "title": LCT("移除"),
                "discription": LCT("是否移除该视频"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function() {
                    $.ajax({
                        type: "post",
                        url: basePath + "/albumController/remoteVideoInAlbum.do?videoIds=" + data_id + "&albumId=" + albumId,
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                alertfn.success(data.msg);
                                //$("table[data-lctable='data-lctable']").lctable(lcsetting, params);
                                $(".btn_search").click();
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function() {
                            //console.log("fail");
                        }
                    });
                }
            };
            $("body").toolsalert(params_alert);
            return;
        });
        //批量移除
        $("#mul-del").click(function() {
            var videoIds = [];
            var albumId = $("#albumId_hidden").val();
            var arr = $("#maintable .checkItem:checked");
            for (var i = 0; i < arr.length; i++) {
                videoIds.push($(arr[i]).attr("data-id"));
            }
            if (arr.length > 0) {
                var params_alert = {
                    "title": LCT("移除"),
                    "discription": LCT("是否批量移除选中视频"),
                    "iconType": "triangle",
                    "confirmBtn": true,
                    "cancelBtn": true,
                    "confirmEvent": function() {
                        $.ajax({
                            type: "post",
                            url: basePath + "/albumController/remoteVideoInAlbum.do?videoIds=" + videoIds + "&albumId=" + albumId,
                            dataType: "json",
                            success: function(data) {
                                data = typeof(data) == "string" ? JSON.parse(data) : data;
                                if (data.success) {
                                    alertfn.success(data.msg);
                                    //$("table[data-lctable='data-lctable']").lctable(lcsetting, params);
                                    $(".btn_search").click();
                                } else {
                                    alertfn.danger(data.msg);
                                }
                            },
                            error: function() {
                                //console.log("fail");
                            }
                        });
                    }
                };
            } else {
                var params_alert = {
                    "title": LCT("错误"),
                    "discription": LCT("请先选中一条视频"),
                    "iconType": "triangle",
                    "confirmBtn": true
                };
            }
            $("body").toolsalert(params_alert);
            return;
        });
    },

    edit: function() {
        $("#maintable").on("click", ".video-edit", function() {
//            showInIFrame($(this).attr("lc_inner_href"));
        	var customCategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumId");
            if (categoryId && categoryId != "" && categoryId != "0") {
                var lc_inner_href = basePath + "videoController/toVideoEdit.do?videoId=" + videoId;
                showInIFrame(lc_inner_href);
                }else {
                    if (albumId != null && albumId != 0) {
                        var params = {
//                            "discription": LCT("请先对专辑") + albumId + LCT("进行分类设置"),
                            "discription": LCT("请先进行分类设置"),
                            "iconType": "triangle",
                            "confirmBtn": true
                        }
                    } else {
                        var params = {
                            "discription": LCT("请先进行分类设置"),
                            "iconType": "triangle",
                            "confirmBtn": true
                        };
                    }
                    $("body").toolsalert(params);
                    return;
                }
        });
        //返回
        $(".back").click(function() {
            closeIframeFromInner('refresh');
        });
    },
    onoffline: function(){
    	$("#maintable").on("click", ".online", function() {
    		var videoId = $(this).attr("data-id");
    		$.ajax({
    			url: basePath + "videoController/onlinestatus.do",
    			data: "videoId=" + videoId,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT( "成功"));
                        $(".btn_search").click();
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
    		})
    	});
    	//批量上线
    	$("#mul-online").click(function() {
   		 var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var flag = true;
            $(arr).each(function(i,e) {
            	var onlineArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(onlineArr).find("a.online");
         		if(!aArr[0]){
         			flag = false;
         			alertfn.danger("包含未达到上线条件的视频，请重新选择");
             		return false;
         		}
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return false;
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if(flag){
           	 if (arr.length > 0) {
	            	 $.ajax({
	          			url: basePath + "videoController/onlinestatus.do",
	          			data: "videoId=" + ids,
	                     type: "post",
	                     dataType: "json",
	                      success: function(data) {
	                          if (data.success) {
	                              alertfn.success(LCT( "成功"));
	                              $(".btn_search").click();
	                          } else {
	                              alertfn.danger(data.msg);
	                          }
	                      }
	          		})
	             }else{
	            	 alertfn.danger(LCT("请先选中一条视频"));
	             }
            }
    	});
    	 
    	$("#maintable").on("click", ".downline", function() {
    		var videoId = $(this).attr("data-id");
    		$.ajax({
    			url: basePath + "videoController/downlinestatus.do?videoId="+videoId,
    			data: "videoId=" + videoId,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT( "成功"));
                        $(".btn_search").click();
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
    		})
    	});
    	//批量下线
    	$("#mul-offline").click(function() {
    		var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var flag = true;
            $(arr).each(function(i,e) {
            	var downlineArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(downlineArr).find("a.downline");
        		if(!aArr[0]){
        			flag = false;
            		alertfn.danger("包含未达到下线条件的视频，请重新选择");
            		return;
        		}
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if(flag){
            	 if (arr.length > 0) {
            		 $.ajax({
              			url: basePath + "videoController/downlinestatus.do",
              			data: "videoId=" + ids,
                          type: "post",
                          dataType: "json",
                          success: function(data) {
                              if (data.success) {
                                  alertfn.success(LCT( "成功"));
                                  $(".btn_search").click();
                              } else {
                                  alertfn.danger(data.msg);
                              }
                          }
              		})
            	 }else{
            		 alertfn.danger(LCT("请先选中一条视频"));
            	 }
            }
    	});
    },
    
    deteleVideo: function() {
        $("#maintable").on("click", ".detele", function() {
            var videoId = $(this).attr("data-id");
            $("#modal-detele").attr("video-id", videoId);
            //vrsFn.deteleRecoverVideo(videoId, 2);
        });
        $("#mul-detele").click(function() {
            var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var flag = true;
            var videoIds = [];
            $(arr).each(function(i,e) {
            	var deleteArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(deleteArr).find("a.detele");
        		if(!aArr[0]){
        			flag = false;
            		$("#modal-detele").modal("hide");
            		alertfn.danger(LCT("包含未达到删除条件的视频，请重新选择"));
            		return false;
        		}
            	if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return false;
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if(flag){
            	if (arr.length > 0) {
               	 $(this).attr("href", "#modal-detele");
                    $("#modal-detele").attr("video-id", ids);
                   //vrsFn.deteleRecoverVideo(ids, 2);
               } else {
                   alertfn.danger(LCT("请先选中一条视频"));
               }
            }
        });
        $("#detele-ok").click(function() {
            var videoId = $("#modal-detele").attr("video-id");
            var delMeg = $("#del-reason").val();
            $.ajax({
                url: basePath + "videoController/removeVideo.do",
                data: "videoIds=" + videoId + "&delMeg=" + delMeg,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                    	$("#modal-detele").modal("hide");
                        alertfn.success(LCT("删除成功"));
                        $(".btn_search").click();
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
            });
        });
    },
};
$(function() {
    albumVideoFn.init();
});
//编辑-返回

function closeIframeFromOuter(type) {
    videoName_arr = [];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}