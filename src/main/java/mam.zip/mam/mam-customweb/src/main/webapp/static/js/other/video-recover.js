var params = {},
    index = 0,
    videoName_arr = [],
    category_obj = {};
var lcsetting = {
    "ajax": basePath + "videoRecycleController/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            return '<input type="checkbox" class="checkItem" data-id="' + d.id + '">';
        }
    }, {
        "data": "businessUUID",
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<p class="videoName videoName-release"></p>';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
        	return (d.removeUser || '') + '<br>' + (d.removeTime || '');
        }
    },
    {
    	"data": "lcall",
        "format": function(i, j, d) {
            return d.removeMsg;
        }
    }, 
    {
        "data": "lcall",
        "format": function(i, j, d) {
            return '<a href="javascript:void(0)" class="recover" data-id="' + d.id + '">' + LCT("恢复") + '</a><a data-toggle="modal" href="#modal-remove" class="remove ml-10" data-id="' + d.id + '">' + LCT("彻底删除") + '</a>';
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); //table全选
        //视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(remark_html);
        }
        videoName_arr = [];
    }
};
var recoverFn = {
    init: function() {
        this.handleTable(); //表格数据筛选
        this.systemCatagory(); //大数据分类
        this.videoIdName(); //搜索ID，名称
        this.recoverVideo(); //恢复   
        this.removeVideo(); //彻底删除
    },
    handleTable: function() {
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".search_select").change(function() {
            $(".btn_search").click();
        });
        $(".btn_search").bind("click", function() {
            var value_id = $.trim($(".search_id").val());
            var value_name = $.trim($(".search_name").val());
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
            if (value_name) {
                params["videoName"] = encodeURIComponent(value_name);
            } else {
                delete params["videoName"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    systemCatagory: function() {
        //获取大分类category
        $.getJSON(
            basePath + "customCategoryController/getCategorys.do",
            function(data) {
                var system_channel = '';
                system_channel += '<option data-id="0" value=' + LCT("请选择") + '>' + LCT("请选择") + '</option>';
                for (var i = 0; i < data.length; i++) {
                    var showName = data[i].showName;
                    var dicValue = data[i].dicValue;
                    system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
                }
                $(".systemCatagory").attr("data-id", '0').html(system_channel);
            }
        );
        //数据分类筛选
        $(".systemCatagory").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory").attr("data-id", categoryId);
            category_obj = {};
            category_obj.category = categoryId;
            if (categoryId == "0") {
                $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>' + vrsFn.customCategoryInitDom);
            } else {
                $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>');
                buildEdit.start = false;
                buildEdit.init("setClass");
            }
            delete params["customCategoryId"];
            params["category"] = categoryId;
            $(".btn_search").click();
        });
    },
    videoIdName: function() {
        $("#video-id-name select").change(function() {
            var index = $(this).find("option:selected").index();
            $("#video-id-name input:text").val("").hide().eq(index).show();
        });
    },
    recoverVideo: function() {
        $("#maintable").on("click", ".recover", function() {
            var id = $(this).attr("data-id");
            //vrsFn.deteleRecoverVideo(videoId,1);
            $.ajax({
                url: basePath + "videoRecycleController/reinState.do",
                data: "videoIds=" + id,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT("成功"));
                        $(".btn_search").click();
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
            });
        });
        $("#mul-recover").click(function() {
            var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var videoIds = [];
            $(arr).each(function(i) {
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if (arr.length > 0) {
            	$.ajax({
                    url: basePath + "videoRecycleController/reinState.do",
                    data: "videoIds=" + ids,
                    type: "post",
                    dataType: "json",
                    success: function(data) {
                        if (data.success) {
                            alertfn.success(LCT( "成功"));
                            $(".btn_search").click();
                        } else {
                            alertfn.danger(data.msg);
                        }
                    }
                });
            } else {
                alertfn.danger(LCT("请先选中一条记录"));
            }
        });
    },
    removeVideo: function() {
        $("#maintable").on("click", ".remove", function() {
            var id = $(this).attr("data-id");
            $("#modal-remove").attr("video-id", id);
        });
        $("#mul-remove").click(function() {
            var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var videoIds = [];
            $(arr).each(function(i) {
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if (arr.length > 0) {
                $(this).attr("href", "#modal-remove");
                $("#modal-remove").attr("video-id", ids);
            } else {
                alertfn.danger(LCT("请先选中一条记录"));
            }
        });
        $("#remove-ok").click(function() {
            var videoId = $("#modal-remove").attr("video-id");
            if($("#remove-ok").attr("data-deleting")){
            	return;
            }
            $.ajax({
                url: basePath + "videoRecycleController/removeVideo.do",
                data: "videoIds=" + videoId,
                type: "post",
                dataType: "json",
                beforeSend: function(XMLHttpRequest){
      			  	$("#remove-ok").attr("data-deleting","true");
      		  	},
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT("删除成功"));
                    } else {
                        alertfn.danger(data.msg);
                    }
                    $("#modal-remove").modal("hide");
                    $(".btn_search").click();
                },
                complete: function(XMLHttpRequest, textStatus){
      			  	$("#remove-ok").removeAttr("data-deleting");
      		  	}
            });
        });
    },
};
$(function() {
    recoverFn.init();
});
var buildEdit = {
    init: function(id) {
        this.connect(id);
    },
    editNameDom: $("input[name=editName]").parent(),
    editClassDom: $("#editClass"),
    start: false,
    connect: function(id) {
        $.ajax({
            url: basePath + "customCategoryController/dataGrid.do",
            data: category_obj,
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                window.classfiyObject_obj = data;
                buildEdit.createDom(data, id);
                if (id == "editClass") {
                    buildEdit.start = true
                }
            }
        });
    },
    createDom: function(data, id) {
        var s1 = new createClass(id, data);
        s1.init(3, id);
    },
    setInformation: function() { //设置分类信息事件;
        var arr = $("#setClass option:selected");
        var classId = "";
        var categoryId = "";
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                classId = $(arr).eq(i).attr("data-id");
                break;
            }
        }
        $(".systemCatagory").change(function() {
            classId = "";
        });
        if (classId == "") {
            delete params["customCategoryId"];
        } else {
            params["customCategoryId"] = classId;
        }
        lcsetting.thisPage = 1;
        $("#maintable").lctable(lcsetting, params);
    }
};
createClass.prototype = {
    init: function(num, id) {
        var This = this;
        for (var i = 0; i < 3; i++) {
            var oSel = document.createElement("select");
            oSel.index = i;
            oSel.className = "form-control";
            this.oParent.appendChild(oSel);
            oSel.onchange = function() {
                This.change(this.index);
            }
        }
        this.first();
    },
    change: function(iNow) {
        switch (iNow) {
            case 0: //改变1级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.zero(now);
                break;
            case 1: //改变2级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.one(now);
                break;
            case 2: //改变3级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.two(now);
                break;
        }
        if (this.oParent == document.getElementById("setClass")) {
            buildEdit.setInformation();
        }
    },
    noting: function() {
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i + 1].appendChild(opt);
        }
    },
    zero: function(n) { //改变一级处理函数

        for (var i = 0; i < 3; i++) { //清空源信息;
            if (i == 0) {
                continue
            }
            this.aSel[i].innerHTML = "";
        }
        if (n == 0) {
            this.noting();
            return
        }
        var arr = this.data[n - 1];
        if (arr.children.length) {
            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);
                this.aSel[1].appendChild(opt);
            }
        } else {
            this.noting();
            return;
        }

        if (arr.children[0].children.length) {
            for (var i = 0; i < arr.children[0].children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[0].children[i].text;
                opt.setAttribute("data-id", arr.children[0].children[i].id);
                opt.setAttribute("category-id", arr.children[0].children[i].category);
                this.aSel[2].appendChild(opt);
            }
        } else {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[2].appendChild(opt);
        }
    },
    one: function(n) { //改变二级处理函数
        var a1 = this.aSel[0].selectedIndex - 1;
        var arr = this.data[a1].children[n];
        this.aSel[2].innerHTML = "";
        if (arr.children.length != 0) {

            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);

                this.aSel[2].appendChild(opt);
            }
        } else {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[2].appendChild(opt);
        }

    },
    two: function(n) {

    },
    first: function() { //上来初始化
        var arr = this.data;
        for (var i = 0; i < 3; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i].appendChild(opt);
        }
        for (var i = 0; i < arr.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = arr[i].text;
            $(opt).attr("data-id", arr[i].id);
            $(opt).attr("category-id", arr[i].category);
            this.aSel[0].appendChild(opt);
        }
    }
}

function createClass(id, data) {
    this.oParent = document.getElementById(id);
    this.data = data;
    this.aSel = this.oParent.getElementsByTagName("select");
}