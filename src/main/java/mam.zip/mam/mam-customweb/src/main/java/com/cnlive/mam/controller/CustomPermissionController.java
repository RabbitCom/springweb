package com.cnlive.mam.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.cnlive.mam.model.CustomMenuModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomPermissionModel;
import com.cnlive.mam.model.CustomRoleModel;
import com.cnlive.mam.service.CustomMenuService;
import com.cnlive.mam.service.CustomPermissionService;
import com.cnlive.mam.service.CustomRoleService;
import com.cnlive.mam.vo.CustomPermissionVo;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created by cuilongcan on 2017/5/10.
 * 用户权限管理接口
 */
@Controller
@RequestMapping("/customPermissionController")
public class CustomPermissionController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(CustomPermissionController.class);
    @Resource(name = "customPermissionService")
    private CustomPermissionService customPermissionService;
    @Resource(name = "customMenuService")
    private CustomMenuService customMenuService;
    @Resource(name = "customRoleService")
    private CustomRoleService customRoleService;

    @RequestMapping("/toCustomPermission")
    public String toCustomPermission(HttpServletRequest request) {
        return "/permission/permission";
    }

    //获取角色列表
    @RequestMapping(value = "/getCustomMenus", method = RequestMethod.GET)
    @ResponseBody
    public DataGrid getCustomMenus(HttpServletRequest request) {
        DataGrid dataGrid = new DataGrid();
        HttpSession session = request.getSession();
        Integer spId = Integer.valueOf((String) session.getAttribute("spId"));
        List<CustomPermissionVo> cpvList = new ArrayList<>();
        List<CustomRoleModel> roles = customRoleService.selectBySpId(spId);//获取全部角色
        List<CustomMenuModel> customMenuModels = customMenuService.selectAll();//获取菜单
        Map<Integer, CustomMenuModel> menuMap = new HashMap<>();
        for (CustomMenuModel customMenuModel : customMenuModels) {
            menuMap.put(customMenuModel.getMenuId(), customMenuModel);
        }
        for (CustomRoleModel customRoleModel : roles) {
            Integer roleId = customRoleModel.getRoleId();
            List<CustomPermissionModel> permissions = customPermissionService.getPermissionByRoleId(roleId);
            List<CustomMenuModel> menus = new ArrayList<>();
            for (CustomPermissionModel customPermissionModel : permissions) {//组装所需菜单
                if (customPermissionModel.getMenuId() != null) {
                    menus.add(menuMap.get(customPermissionModel.getMenuId()));
                }
            }
            CustomPermissionVo vo = new CustomPermissionVo();//组装vo
            vo.setRoleId(roleId);
            vo.setRoleName(customRoleModel.getRoleName());
            vo.setMenus(menus);
            vo.setDescription(customRoleModel.getDescription());
            cpvList.add(vo);
        }
        dataGrid.setRows((List) JSONObject.parse(JSONObject.toJSONString(cpvList, SerializerFeature.DisableCircularReferenceDetect)));
        return dataGrid;
    }

    //新增时，获取菜单
    @RequestMapping(value = "/getPermissionMenus", method = RequestMethod.GET)
    @ResponseBody
    public JsonResult getPermissionMenus(HttpServletRequest request) {
        JsonResult result = new JsonResult();
        List<CustomMenuModel> menus = customMenuService.selectAll();
        result.setObj(menus);
        result.setSuccess(true);
        return result;
    }

    //插入新的角色
    @RequestMapping(value = "/inserCustomPermission", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult inserCustomPermission(HttpServletRequest request, String roleName, String menus, String description) {
        HttpSession session = request.getSession();
        Integer spId = Integer.valueOf((String) session.getAttribute("spId"));
        JsonResult result = new JsonResult();
        List<String> list = new ArrayList<>();
        if (menus != null && menus.contains(",")) {
            menus = menus.replaceAll("/", "");
            list = Arrays.asList(menus.split(","));
        } else {
            list.add(menus);
        }
        CustomRoleModel customRoleModel = new CustomRoleModel();
        customRoleModel.setRoleName(roleName);
        customRoleModel.setSpId(spId);
        customRoleModel.setDescription(description);
        List customRoleModels = customRoleService.selectByRoleNameAndSpid(customRoleModel);
        if (customRoleModels.size() > 0) {
            result.setSuccess(true);
            result.setMsg("角色名已存在");
            return result;
        }
        customPermissionService.insertCustomPermission(customRoleModel, list);
        result.setSuccess(true);
        result.setMsg("创建成功");
        return result;
    }

    //删除角色信息
    @RequestMapping(value = "/delCustomPermission", method = RequestMethod.GET)
    @ResponseBody
    public JsonResult delCustomPermission(HttpServletRequest request, Integer roleId) {
        JsonResult result = new JsonResult();
        result.setSuccess(false);
        CustomModel customModel = new CustomModel();
        customModel.setRoleId(roleId);
        Long count = customService.countByCustom(customModel);
        if (count > 0) {
            result.setMsg("无法删除，已有用户分配该角色");
        } else {
            customPermissionService.delCustomPermission(roleId);
            result.setMsg("删除成功");
            result.setSuccess(true);
        }
        return result;
    }

    //更新角色信息
    @RequestMapping(value = "/updateCustomPermission", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateCustomPermission(HttpServletRequest request, Integer roleId, String roleName, String menus, String description) {
        JsonResult result = new JsonResult();
        List<String> list = new ArrayList<>();
        if (menus != null && menus.contains(",")) {
            menus = menus.replaceAll("/", "");
            list = Arrays.asList(menus.split(","));
        } else {
            list.add(menus);
        }
        customPermissionService.updateCustomPermission(roleId, roleName, description, list);
        result.setSuccess(true);
        result.setMsg("编辑成功");
        return result;
    }
}
