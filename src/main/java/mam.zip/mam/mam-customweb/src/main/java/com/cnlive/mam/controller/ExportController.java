package com.cnlive.mam.controller;


import com.cnlive.mam.common.ModelValueConst;
import com.cnlive.mam.common.exception.ValidateException;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.excelTools.ExcelUtils;
import com.cnlive.mam.excelTools.JsGridReportBase;
import com.cnlive.mam.excelTools.TableData;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.AlbumService;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.service.VideoAuditService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.ExcelVo;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Controller
@RequestMapping("/")
public class ExportController extends BaseController {
    private static Logger _log = LoggerFactory.getLogger(ExportController.class);

    @Resource(name = "albumService")
    private AlbumService albumService;

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "videoAuditService")
    private VideoAuditService videoAuditService;

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;

    /**
     * ("video")excel("export")
     *
     * @param hearders  excel的列头
     * @param fields    数据对应的属性字段
     * @param condition 数据的查询条件
     * @throws Exception
     */
    @RequestMapping("exportExcelVideo")
    public void exportExcelVideo(HttpServletRequest request, HttpServletResponse response, String hearders, String fields, VideoCondition condition) {
        if (StringUtils.isBlank(hearders) || StringUtils.isBlank(fields)) {
            _log.error("导出excel参数错误！");
            throw new ValidateException(("export") + "excel" + ("param_error"));
        }

        condition = this.updateCondition(condition);
        condition.setCustomId(this.getCustomId(request));
        if (StringUtils.isNotBlank(condition.getOnoffStatus())) {
            condition.setOnoffStatusArray(condition.getOnoffStatus().split(","));
            condition.setOnoffStatus(null);
        }
        String videoIds = condition.getVideoIds();
        if (StringUtils.isNotEmpty(videoIds)) {
            condition = new VideoCondition();
            condition.setVideoIdArray(videoIds.split(Const.VALUE_DECOLLATOR));
        }

        //获取视频数据
        List<VideoModel> videoList_old = videoService.getVideoInfoByCondition(condition);

        String title = "点播云视频信息-"+CalendarUtil.getDateString(new Date(),CalendarUtil.SHORT_DATE_FORMAT_NO_DASH);
        try {
            this.exportToExcel(request, response, title, hearders, fields, videoList_old, 1);
        } catch (Exception e) {
            _log.error("视频导出excel错误,msg={},ex={}",e, e.getMessage());
            throw new ValidateException(("video_export") + "excel" + ("error_"));
        }
    }

    /**
     * ("album")excel("export")
     *
     * @param hearders  excel的列头
     * @param fields    数据对应的属性字段
     * @param condition 数据的查询条件
     * @throws Exception
     */
    @RequestMapping("exportExcelAlbum")
    public void exportExcelAlbum(HttpServletRequest request, HttpServletResponse response, String hearders, String fields, AlbumCondition condition) {
        if (StringUtils.isBlank(hearders) || StringUtils.isBlank(fields)) {
            _log.error(("export") + "excel参数错误！");
            throw new ValidateException(("export") + "excel" + ("param_error"));
        }
        if (StringUtils.isNotBlank(condition.getAlbumStatus())) {
            condition.setAlbumStatusArray(condition.getAlbumStatus().split(","));
            condition.setAlbumStatus(null);
        }
        condition.setCustomId(this.getCustomId(request));
        condition.setSort("albumId");

        String albumIds = condition.getAlbumIds();
        if (StringUtils.isNotEmpty(albumIds)) {
            condition = new AlbumCondition();
            condition.setAlbumIdArray(albumIds.split(Const.VALUE_DECOLLATOR));
        }

        //获取专辑数据
        List<AlbumModel> albumList = albumService.getAlbumInfoByCondition(condition);

        String title = "SAAS" + ("media_asset_album_info");
        try {
            this.exportToExcel(request, response, title, hearders, fields, albumList, 2);
        } catch (Exception e) {
            _log.error("专辑导出excel错误,ex={}", e.getMessage());
            throw new ValidateException(("album_export") + "excel" + ("error_"));
        }
    }

    /**
     * 审核视频excel("export")
     *
     * @param hearders  excel的列头
     * @param fields    数据对应的属性字段
     * @param condition 数据的查询条件
     * @throws Exception
     */
    @RequestMapping("exportExcelAuditVideo")
    public void exportExcelAuditVideo(HttpServletRequest request, HttpServletResponse response, String hearders, String fields, VideoCondition condition) {
        if (StringUtils.isBlank(hearders) || StringUtils.isBlank(fields)) {
            _log.error(("export") + "excel参数错误！");
            throw new ValidateException(("export") + "excel" + ("param_error"));
        }
        condition = this.updateCondition(condition);
        condition.setCustomId(this.getCustomId(request));
        condition.setOnoffStatusArray(new String[]{"1"});

        String videoIds = condition.getVideoIds();
        if (StringUtils.isNotEmpty(videoIds)) {
            condition = new VideoCondition();
            condition.setVideoIdArray(videoIds.split(Const.VALUE_DECOLLATOR));
        }
        //获取视频数据
        List<VideoModel> videoList_old = videoService.getVideoInfoByCondition(condition);

        String title = "SAAS" + ("media_asset_audit_info");
        try {
            this.exportToExcel(request, response, title, hearders, fields, videoList_old, 1);
        } catch (Exception e) {
            _log.error("视频审核信息导出excel失败,ex={}", e.getMessage());
            throw new ValidateException(("audit_info_export") + "excel" + ("error_"));
        }
    }

    /**
     * 审核日志excel("export")
     *
     * @param hearders  excel的列头
     * @param fields    数据对应的属性字段
     * @param condition 数据的查询条件
     * @throws Exception
     */
    @RequestMapping("exportExcelAuditLog")
    public void exportExcelAuditLog(HttpServletRequest request, HttpServletResponse response, String hearders, String fields, VideoAuditCondition condition) {
        if (StringUtils.isBlank(hearders) || StringUtils.isBlank(fields)) {
            _log.error("导出excel参数错误！");
            throw new ValidateException(("export") + "excel" + ("param_error"));
        }
        condition.setCustomId(this.getCustomId(request));
        condition.setSort("id");
        //获取审核日志数据
        List<VideoAuditModel> auditList = videoAuditService.getVideoAuditInfoByCondition(condition);

        String title = "SAAS" + ("media_asset_audit_log");
        try {
            this.exportToExcel(request, response, title, hearders, fields, auditList, 3);
        } catch (Exception e) {
            _log.error("视频审核列表导出excel出错,ex={}", e.getMessage());
            throw new ValidateException(("video_audit_log_export") + "excel" + ("error_"));
        }
    }

    /**
     * 导出excelzip下载包
     *
     * @param request
     * @param response
     * @param hearders
     * @param fields
     * @param condition
     */
    @RequestMapping("zipDownload")
    public void exportToZip(HttpServletRequest request, HttpServletResponse response, String hearders, String fields, VideoCondition condition) throws IOException {
        if (StringUtils.isBlank(hearders) || StringUtils.isBlank(fields)) {
            _log.error("导出excel参数错误！");
            throw new ValidateException(("export") + "excel" + ("param_error"));
        }

        condition = this.updateCondition(condition);
        condition.setCustomId(this.getCustomId(request));
        if (StringUtils.isNotBlank(condition.getOnoffStatus())) {
            condition.setOnoffStatusArray(condition.getOnoffStatus().split(","));
            condition.setOnoffStatus(null);
        }
        String videoIds = condition.getVideoIds();
        if (StringUtils.isNotEmpty(videoIds)) {
            condition = new VideoCondition();
            condition.setVideoIdArray(videoIds.split(Const.VALUE_DECOLLATOR));
        }
        //获取视频数据
        List<VideoModel> videoList_old = videoService.getVideoInfoByCondition(condition);
        String title = "SAAS" + ("media_asset_video_info");
        String[] heardersArray = hearders.split(Const.VALUE_DECOLLATOR);
        String[] fieldsArray = fields.split(Const.VALUE_DECOLLATOR);
        //转换字典数据
        List<ExcelVo> List_new = convertVideoData(videoList_old, fieldsArray);
        TableData td = ExcelUtils.createTableData(List_new, ExcelUtils.createTableHeader(heardersArray), fieldsArray);
        ZipOutputStream zipOutputStream = null;
        try {
            JsGridReportBase report = new JsGridReportBase(request, response);
            HSSFWorkbook wb = report.generateExcel(title, null, td);
            zipOutputStream = ExcelUtils.createZipStream(response, "mamVideo");
            zipOutputStream.putNextEntry(new ZipEntry(title + ".xls"));
            List<String> picUrls = new ArrayList<>();
            for (int i = 0; i < videoList_old.size(); i++) {
                Map<String,String> map = videoList_old.get(0).getAllPicScale();
                picUrls.add(map.get("316*506"));
            }
            String[] files = picUrls.toArray(new String[picUrls.size()]);
            for (int i = 0; i < files.length; i++) {
                URL url = new URL(files[i]);
                zipOutputStream.putNextEntry(new ZipEntry(i + ".jpg"));
                InputStream fis = url.openConnection().getInputStream();
                byte[] buffer = new byte[1024];
                int r;
                while ((r = fis.read(buffer)) != -1) {
                    zipOutputStream.write(buffer, 0, r);
                }
                fis.close();
            }
            wb.write(zipOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            zipOutputStream.flush();
            zipOutputStream.close();
        }
    }

    /**
     * 导出动作
     * 按照选择的视频、专辑导出到excel
     *
     * @param request
     * @param response
     * @param title
     * @param hearders
     * @param fields
     * @param dataList
     * @throws Exception
     */
    private void exportToExcel(HttpServletRequest request, HttpServletResponse response, String title, String hearders, String fields, List dataList, Integer type) throws Exception {
        response.setContentType("application/msexcel;charset=UTF-8");
        String[] heardersArray = hearders.split(Const.VALUE_DECOLLATOR);
        String[] fieldsArray = fields.split(Const.VALUE_DECOLLATOR);

        //转换字典数据
        List<ExcelVo> List_new = new ArrayList<>();
        if (type.intValue() == 1) {
            List_new = convertVideoData(dataList, fieldsArray);
        }
        if (type.intValue() == 2) {
            List_new = convertAlbumData(dataList, fieldsArray);
        }
        if (type.intValue() == 3) {
            List_new = convertAuditLogData(dataList, fieldsArray);
        }

        TableData td = ExcelUtils.createTableData(List_new, ExcelUtils.createTableHeader(heardersArray), fieldsArray);
        JsGridReportBase report = new JsGridReportBase(request, response);
        report.exportToExcel(title, null, td);
    }

    private OutputStream getDownloadPic(HttpServletRequest request, HttpServletResponse response, String picUrl, String picName) {
        OutputStream out = null;
        try {
            URL url = new URL(picUrl);
            URLConnection conn = url.openConnection();
            InputStream inStream = conn.getInputStream();
            BufferedInputStream bins = new BufferedInputStream(inStream);// 放到缓冲流里面
            // 清空response
            response.reset();
            // 设置response的Header
            response.setHeader("Content-Disposition", "attachment;fileName=" + picName);
            response.setContentType("application/x-download");
            out = response.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out;
    }

    //转换视频数据
    private List<ExcelVo> convertVideoData(List<VideoModel> list, String[] fieldsArray) {
        List<ExcelVo> volist = new ArrayList<ExcelVo>();

        List fieldList = Arrays.asList(fieldsArray);

        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                VideoModel v = list.get(i);
                ExcelVo vo = new ExcelVo();
                vo.setCustomId(v.getCustomId());
                //vo.setCustomName(v.getCustomName());
//                vo.setVideoId(v.getVideoId());
                vo.setVideoName(v.getVideoName());
                vo.setTag(v.getTag());
                vo.setSynopsis(v.getSynopsis());
                //处理时长
                if (fieldList.contains("duration")) {
                        if (v.getDuration() != null && v.getDuration() != 0) {
                        Long d = Long.parseLong(v.getDuration().toString());
                        vo.setDuration(this.formatTime(d));
                    } else {
                        vo.setDuration("00:00:00");
                    }
                }
                //处理客户分类名称
                if (fieldList.contains("categoryName")) {
                    Integer category = v.getCategory();
                    if(category == null || "0".equals(category)){
                        vo.setCategoryName("");
                    }else {
                        Dictionary dictionary = dictionaryService.getDictionaryByDicValue(ModelValueConst.DIC_DICWORD_CATEGORY, v.getCategory());
                        if (dictionary != null) {
                            vo.setCategoryName(dictionary.getShowName());
                        } else {
                            vo.setCategoryName("");
                        }
                    }

                }

                //处理专辑名称
                if (fieldList.contains("albumName")) {
                    //vo.setAlbumName(v.getAlbumName());
                    if (v.getAlbumId() != null && v.getAlbumId().intValue() != 0) {
                        AlbumModel albumModel = albumService.getById(v.getAlbumId());
                        if (albumModel != null) {
                            vo.setAlbumName(albumModel.getAlbumName());
                        }

                    }
                }

                vo.setVideoImageType(v.getAllPicScale());

                volist.add(vo);
            }
        }
        return volist;
    }

    //转换专辑数据
    private List<ExcelVo> convertAlbumData(List<AlbumModel> list, String[] fieldsArray) {
        List<ExcelVo> volist = new ArrayList<ExcelVo>();
        List fieldList = Arrays.asList(fieldsArray);
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                AlbumModel v = list.get(i);
                ExcelVo vo = new ExcelVo();
                vo.setAlbumName(v.getAlbumName());
                vo.setAlbumId(v.getAlbumId());
                vo.setTag(v.getTag());
                vo.setSynopsis(v.getSynopsis());
                vo.setEpisodeCount(v.getEpisodeCount());

                //处理客户分类名称
                if (fieldList.contains("customCategoryName")) {
                    //vo.setCustomCategoryName(v.getCustomCategoryName());
                    if (v.getCustomCategoryId() != null && v.getCustomCategoryId().intValue() != 0) {
                        CustomCategoryModel ccm = customCategoryService.getById(v.getCustomCategoryId());
                        if (ccm != null) {
                            vo.setCustomCategoryName(ccm.getCustomCategoryName());
                        }
                    }
                }

                vo.setCopyrightCompany(v.getCopyrightCompany());
                //处理版权类型字典值
                if (fieldList.contains("copyrightType")) {
                    if (v.getCopyrightType() != null) {
                        int copyright = v.getCopyrightType();
                        List<Dictionary> copyrightTypeList = dictionaryService.getDictionary("copyrightType", v.getCategory());
                        for (Dictionary d : copyrightTypeList) {
                            if (d.getDicValue() == copyright) {
                                vo.setCopyrightType(d.getShowName());
                                break;
                            }
                        }
                    }
                }
                //处理播放平台字典值
                if (fieldList.contains("playPlatform")) {
                    if (StringUtils.isNotBlank(v.getPlayPlatform())) {
                        String[] pfs = v.getPlayPlatform().split(",");
                        StringBuffer pfsbf = new StringBuffer();
                        // 播放平台
                        List<Dictionary> playPlatformList = dictionaryService.getDictionary("platform", v.getCategory());
                        for (int j = 0; j < pfs.length; j++) {
                            for (Dictionary d : playPlatformList) {
                                if (String.valueOf(d.getDicValue()).equals(pfs[j].toString())) {
                                    pfsbf.append(d.getShowName()).append(",");
                                    break;
                                }
                            }
                        }
                        vo.setPlayPlatform(pfsbf.toString());
                    }
                }

                //处理开始日期
                vo.setCopyrightStart(CalendarUtil.getDateString(v.getCopyrightStart(), CalendarUtil.SHORT_DATE_FORMAT));
                //处理结束日期
                vo.setCopyrightEnd(CalendarUtil.getDateString(v.getCopyrightEnd(), CalendarUtil.SHORT_DATE_FORMAT));
                //内容分级字典值
                if (fieldList.contains("contentRating")) {
                    if (StringUtils.isNotBlank(v.getContentRating())) {
                        int contentRating = Integer.parseInt(v.getContentRating());
                        List<Dictionary> contentRatingList = dictionaryService.getDictionary("contentRating", v.getCategory());
                        for (Dictionary d : contentRatingList) {
                            if (d.getDicValue() == contentRating) {
                                vo.setContentRating(d.getShowName());
                                break;
                            }
                        }
                    }
                }
                //屏蔽规则字典值
                if (fieldList.contains("shieldingRule")) {
                    if (v.getShieldingRule() != null) {
                        if (v.getShieldingRule() == 0) {
                            vo.setShieldingRule(("shield_expect_china"));
                        }
                        if (v.getShieldingRule() == 1) {
                            vo.setShieldingRule(("all_allow"));
                        }
                    }
                }
                volist.add(vo);
            }
        }
        return volist;
    }

    //转换审核日志数据
    private List<ExcelVo> convertAuditLogData(List<VideoAuditModel> list, String[] fieldsArray) {
        List<ExcelVo> volist = new ArrayList<ExcelVo>();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                VideoAuditModel v = list.get(i);
                ExcelVo vo = new ExcelVo();
                vo.setVideoId(v.getVideoId());
                vo.setVideoName(v.getVideoName());
                vo.setAuditUser(v.getAuditUser());
                vo.setAuditTime(CalendarUtil.getDateString(v.getAuditTime(), CalendarUtil.SHORT_DATE_FORMAT));
                //处理审核结果
                if (v.getAction() != null && v.getAction().intValue() != 0) {
                    if (v.getAction() == 1) {
                        vo.setAction(("leeco_audit_pass"));
                    }
                    if (v.getAction() == 2) {
                        vo.setAction(("leeco_audit_not_pass"));
                    }
                    if (v.getAction() == 3) {
                        vo.setAction(("custom_audit_pass"));
                    }
                    if (v.getAction() == 4) {
                        vo.setAction(("custom_audit_not_pass"));
                    }
                }
                //处理失败原因
                if (v.getAuditReason() != null && v.getAuditReason().intValue() != 0) {
                    List<Dictionary> auditReasonList = dictionaryService.getDictionary("auditReason", Const.CHANNEL_FILM);
                    for (Dictionary d : auditReasonList) {
                        if (d.getDicValue().intValue() == v.getAuditReason().intValue()) {
                            vo.setAuditReason(d.getShowName());
                            break;
                        }
                    }
                }
                vo.setAuditMessage(v.getAuditMessage());
                volist.add(vo);
            }
        }
        return volist;
    }

    /*
    * 毫秒转化
    */
    private String formatTime(long ms) {

        int ss = 1000;
        int mi = ss * 60;
        int hh = mi * 60;
        int dd = hh * 24;

        long day = ms / dd;
        long hour = (ms - day * dd) / hh;
        long minute = (ms - day * dd - hour * hh) / mi;
        long second = (ms - day * dd - hour * hh - minute * mi) / ss;
        long milliSecond = ms - day * dd - hour * hh - minute * mi - second * ss;

        String strDay = day < 10 ? "0" + day : "" + day; //天
        String strHour = hour < 10 ? "0" + hour : "" + hour;//小时
        String strMinute = minute < 10 ? "0" + minute : "" + minute;//分钟
        String strSecond = second < 10 ? "0" + second : "" + second;//秒
        String strMilliSecond = milliSecond < 10 ? "0" + milliSecond : "" + milliSecond;//毫秒
        strMilliSecond = milliSecond < 100 ? "0" + strMilliSecond : "" + strMilliSecond;

        return strHour + ":" + strMinute + ":" + strSecond;
    }
}

