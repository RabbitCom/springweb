package com.cnlive.mam.controller;


import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.enums.StorageUseStateEnum;
import com.cnlive.mam.condition.StorageCondition;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.StorageConfigsService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by zhangxiaobin on 2017/7/18.
 */
@Controller
@RequestMapping("/storageController")
public class StorageController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(StorageController.class);

    @Autowired
    private StorageConfigsService storageConfigsService;
    @Autowired
    private StorageService storageService;

    @RequestMapping("/manager")
    public String toManager(HttpServletRequest request) {
        return "/storage/storage_manager";
    }

    @RequestMapping("/dataGrid")
    @ResponseBody
    public DataGrid dataGrid(HttpServletRequest request, StorageCondition condition) {
        Long spId = super.getSpId(request);
        condition.setSpid(spId);
        return storageService.getPageByCondition(condition);
    }

    @RequestMapping("/add")
    @ResponseBody
    public JsonResult addStorage(HttpServletRequest request, StorageModel storageModel) {

        if(StringUtils.isEmpty(storageModel.getName().trim()) || storageModel.getType() == null ||
                storageModel.getContentType() == null || storageModel.getYongtu() == null){
            return JsonResult.createErrorInstance("参数异常，请稍后重试！");
        }
        Long spId = super.getSpId(request);
        boolean nameExtis = storageService.checkNameExtis(storageModel.getName().trim(), storageModel.getType(),
                storageModel.getContentType(), spId, storageModel.getYongtu());
        if(nameExtis){
            return JsonResult.createErrorInstance("存储名称已经存在！");
        }

        //校验当前存储是否存在
        if(StorageTypeEnum.QINIUYUN.getDbValue() == storageModel.getType().getDbValue() ||
                StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue()){
            boolean checkBucket = checkBucketExtis(storageModel.getName().trim(), storageModel.getType());
            if(!checkBucket){
                return JsonResult.createErrorInstance("存储信息异常，请联系管理员确认存储信息是否开通！");
            }
        }

        storageModel.setSpid(spId);
        storageModel.setUseState(StorageUseStateEnum.NotUse);
        storageService.save(storageModel);
        return JsonResult.createSuccessInstance("添加成功");
    }

    @RequestMapping("/del")
    @ResponseBody
    public JsonResult delStorage(HttpServletRequest request, Integer id) {
        StorageModel storage = storageService.getById(id);
        if(storage == null){
            return JsonResult.createSuccessInstance("操作失败，数据不存在！");
        }
        int useStateVal= storage.getUseState().getDbValue();
        if(StorageUseStateEnum.Used.getDbValue() == useStateVal ||
                StorageUseStateEnum.UsedBefore.getDbValue() == useStateVal){
            return JsonResult.createSuccessInstance("操作失败，使用过的存储不允许删除！");
        }
        storageService.delete(storage.getId());
        return JsonResult.createSuccessInstance("删除成功");
    }

    @RequestMapping("/edit")
    @ResponseBody
    public JsonResult editStorage(HttpServletRequest request, StorageModel storageModel) {
        Long spId = super.getSpId(request);
        storageModel.setSpid(spId);

        //校验当前存储是否存在
        if(StorageTypeEnum.QINIUYUN.getDbValue() == storageModel.getType().getDbValue() ||
                StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue()){
            boolean checkBucket = checkBucketExtis(storageModel.getName().trim(), storageModel.getType());
            if(!checkBucket){
                return JsonResult.createErrorInstance("存储信息异常，请联系管理员确认存储信息是否开通！");
            }
        }

        storageService.modify(storageModel);
        return JsonResult.createSuccessInstance("修改成功");
    }

    @RequestMapping("/enabled")
    @ResponseBody
    public JsonResult enabledStorage(HttpServletRequest request, Integer storageId, Integer contentType, Integer type) {

        if(contentType == null || storageId == null){
            return JsonResult.createErrorInstance("参数异常，稍后重试");
        }
        try{
            //校验当前存储是否存在
            StorageModel enableStorage = storageService.getById(storageId);
            if(StorageTypeEnum.QINIUYUN.getDbValue() == enableStorage.getType().getDbValue() ||
                    StorageTypeEnum.KSYUN.getDbValue() == enableStorage.getType().getDbValue()){
                boolean checkBucket = checkBucketExtis(enableStorage.getName(), enableStorage.getType());
                if(!checkBucket){
                    return JsonResult.createErrorInstance("存储信息异常，请联系管理员确认存储信息是否开通！");
                }
            }

            Long spId = super.getSpId(request);
            List<StorageModel> storagesEnable = storageService.getStorageEnableBySpid(spId);
            for (StorageModel sm : storagesEnable){
                int contentTypeVal = sm.getContentType().getDbValue();
                sm.setSpid(spId);
                if(StorageContentTypeEnum.MediaAndPicture.getDbValue() == contentType.intValue()){
                    sm.setUseState(StorageUseStateEnum.UsedBefore);
                    storageService.modify(sm);
                }
                if(StorageContentTypeEnum.Picture.getDbValue() == contentType.intValue() &&
                        StorageContentTypeEnum.Picture.getDbValue() ==contentTypeVal){
                    sm.setUseState(StorageUseStateEnum.UsedBefore);
                    storageService.modify(sm);
                }
                if(StorageContentTypeEnum.Media.getDbValue() == contentType.intValue() &&
                        StorageContentTypeEnum.Media.getDbValue() ==contentTypeVal){
                    sm.setUseState(StorageUseStateEnum.UsedBefore);
                    storageService.modify(sm);
                }
            }
            StorageModel storageModel = new StorageModel();
            storageModel.setId(storageId);
            storageModel.setUseState(StorageUseStateEnum.Used);
            storageModel.setSpid(spId);
            storageService.modify(storageModel);
            return JsonResult.createSuccessInstance("操作成功");
        }catch (Exception ex){
            _log.error("enabled storage error,error={}",ex);
            return JsonResult.createErrorInstance("操作异常，请稍后重试");
        }
    }
}
