/**
 * 视频列表页面与专辑列表页面公用js
 */
var params = {},
    params_modal = {},
    albumName_modal_arr = [];

var vrsFn = {
    "customCategoryInitDom": '<select class="form-control"><option>' + LCT("请选择") + '</option></select><select class="form-control"><option>' + LCT("请选择") + '</option></select>',
    "rules_30": /^[0-9 ·\a-zA-Z\u4E00-\u9FA5\s-]{1,30}$/,
    "rules_40": /^[0-9 ·\a-zA-Z\u4E00-\u9FA5\s-]{1,40}$/,
    "rules_50": /^[0-9 ·\a-zA-Z\u4E00-\u9FA5\s-]{1,50}$/,
    init: function() {
        this.tagAction("tag", vrsFn.rules_40, 40, 15);
        this.tagAction("director", vrsFn.rules_30, 30, 3);
        this.tagAction("actor", vrsFn.rules_30, 30, 10);
        this.tagAction("screenwriter", vrsFn.rules_30, 30, 3);
        this.tagAction("filmProduce", vrsFn.rules_30, 30, 3);
        this.tagAction("guest", vrsFn.rules_30, 30, 10);
        this.tagAction("host", vrsFn.rules_30, 30, 10);
        this.tagAction("lyrics", vrsFn.rules_30, 30, 3);
        this.tagAction("composer", vrsFn.rules_30, 30, 3);
        this.tagAction("singer", vrsFn.rules_30, 30, 10);
        this.tagAction("master", vrsFn.rules_30, 30, 10);
        this.tagAction("original", vrsFn.rules_30, 30, 10);
        this.tagAction("creative", vrsFn.rules_30, 30, 10);
        this.tagAction("gamePlayer", vrsFn.rules_30, 30, 10);
        this.tagAction("lecturer", vrsFn.rules_30, 30, 10);
    },
    /*
     * 获取字符串的长度，英文=1，中文=2
     * @param
     *      Str为字符串
     * @return
     *      每出现一次中文，字符长度+1
     *
     */
    getStringLen: function(Str) {
        var i, len, code;
        if (Str == null || Str == "") return 0;
        len = Str.length;
        for (i = 0; i < Str.length; i++) {
            code = Str.charCodeAt(i);
            if (code > 255) {
                len++;
            }
        }
        return len;
    },
    /*
     * 时长转换
     * @param
     *      ms为单位的时长
     * @return
     *      hour:minite:second
     *
     */
    formatSeconds: function(d) {
        if (d != null) {
            var hour = Math.floor(d / 1000 / 3600) < 10 ? '0' + Math.floor(d / 1000 / 3600) : Math.floor(d / 1000 / 3600);
            var minite = Math.floor((d / 1000 % 3600) / 60) < 10 ? '0' + Math.floor((d / 1000 % 3600) / 60) : Math.floor((d / 1000 % 3600) / 60);
            var second = Math.ceil(d / 1000 % 60) < 10 ? '0' + Math.ceil(d / 1000 % 60) : Math.ceil(d / 1000 % 60);
            return hour + ":" + minite + ":" + second;
        } else {
            return '-';
        }
    },
    /*
     * 验证数字
     * @param
     *      验证字段
     * @return
     *      是否为数字
     *
     */
    checkNum: function(value) {
        var patrn = /^[0-9]*$/;
        if (patrn.test(value)) {
            return true;
        } else {
            return false;
        }
    },
    /*
     * 时间格式化,带年月日 时分秒
     * @param
     *      formatDateEn_short(1471348474)
     * @return
     *      英文返回"Jan 18, 1970"
     *      中文返回 "1970-01-18"    
     *
     */
    formatDateEn_short: function(d) {
        if (d && d != "") {
            var now = new Date(d);
            var monName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            var noon = "";
            var year = now.getFullYear();
            var month = now.getMonth();
            var date = now.getDate();
            if (lctu.getLanguage() == "en") {
                return monName[month] + " " + date + ", " + year;
            } else {
                date = date < 10 ? "0" + date : date;
                month = (month + 1) < 10 ? "0" + (month + 1) : (month + 1);
                return year + "-" + month + "-" + date;
            }
        }

    },
    /*
     * 英文日期显示，配合my97
     * @param
     *      2015-11-26
     * @return
     *      Nov 26,2015
     *
     */
    formatDateEnMy97: function(dom) {
        var dom_arr = $(dom).val().split("-");
        var monName = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var monthIndex = vrsFn.zeroFirst(dom_arr[1]);
        var newDateEn = "";
        newDateEn += monName[monthIndex - 1] + " "; //月
        newDateEn += vrsFn.zeroFirst(dom_arr[2]) + ", "; //日
        newDateEn += dom_arr[0]; //年
        return newDateEn;
    },
    /*
     * 去掉补全0
     * @param
     *      08,06,11
     * @return
     *      8,6,11
     *
     */
    zeroFirst: function(target) {
        var endTarget = "";
        if (target[0] == "0") {
            endTarget = target[1];
        } else {
            endTarget = target;
        }
        return endTarget;
    },
    /*
     * my 97日期插件
     * @param
     *      目標元素
     * @return
     *      中英文日期顯示
     */
    swithDateEn: function(date) {
        var result_dom = $("#" + date.attr("id") + "-result");
        result_dom.val(date.val());
    },
    onclearedMy97: function(dom) {
        var result_dom = $("#" + dom.attr("id") + "-result");
        result_dom.val("");
    },
    /**
     * 上传图片的操作
     * Scale : 分辨率
     * proportion : 比例
     */
    setImagePreview: function(obj) { //图片上传
        var array = new Array('gif', 'jpeg', 'png', 'jpg', 'bmp'); //可以上传的文件类型
        if (obj.value == '') {
            alertfn.danger(LCT("请选择上传的图片") + "！");
        } else {
            var fileContentType = obj.value.match(/^(.*)(\.)(.{1,8})$/)[3]; //这个文件类型正则很有用
            var isExists = false;
            //循环判断图片的格式是否正确
            for (var i = 0; i < array.length; i++) {
                if (fileContentType.toLowerCase() == array[i].toLowerCase()) {
                    //图片格式正确之后，上传到本地服务器
                    isExists = true;
                }
            }
            if (isExists == false) {
                alertfn.danger(LCT("上传图片类型不正确") + "!");
            }
            if (isExists) {
                //设置比例、分辨率的参数
                var a_active = $("#vedio-img-box02 .upload-btn-group a.active");
                $("#hidden_img_proportion").val(a_active.html());
                $("#hidden_img_scale").val(a_active.attr("data-size"));
                $("#vedio-img-box02 li").append('<p style="width: 300px;position: absolute;top:0;left:0;height: 300px;background-color: rgba(0,0,0,0.5);line-height: 300px;text-align: center;font-size: 18px;color: #fff;">' + LCT("正在上传，请稍后") + '...</p>');
                $("#upload").hide();
                //上传图片
                $('#video_picUpload_form').ajaxSubmit({
                    url: basePath + "uploadController/uploadPicSource.do",
                    type: 'post',
                    success: function(data) {
                        var rs = $.parseJSON(data);
                        if (rs.success) {
                            var img = rs.obj.pic_fineshed;
                            $("#vedio-img-box02 li img").attr({
                                "src": img
                            });
                            $("#vedio-img-box02 li p").remove();
                            $("#upload").show();
                            return false;
                        } else {
                            $("#vedio-img-box02 li p").remove();
                            $("#upload").show();
                            alertfn.danger(rs.msg);
                            $('#upload').replaceWith('<input id="upload" style="position:absolute;top:230px;opacity:0;height:36px;cursor:pointer;" name="myfile" onChange="javascript:vrsFn.setImagePreview(this);" type="file"/>');
                            return false;
                        }
                    }
                });
            }

        }
    },
    /**
     * 上传logo操作
//     * Scale : 分辨率
//     * proportion : 比例
     */
    setLogoImage: function(obj) { //图片上传
        var array = new Array('gif', 'jpeg', 'png', 'jpg', 'bmp'); //可以上传的文件类型
        if (obj.value == '') {
            alertfn.danger(LCT("请选择上传的图片") + "！");
        } else {
            var fileContentType = obj.value.match(/^(.*)(\.)(.{1,8})$/)[3]; //这个文件类型正则很有用
            var isExists = false;
            //循环判断图片的格式是否正确
            for (var i = 0; i < array.length; i++) {
                if (fileContentType.toLowerCase() == array[i].toLowerCase()) {
                    //图片格式正确之后，上传到本地服务器
                    isExists = true;
                }
            }
            if (isExists == false) {
                alertfn.danger(LCT("上传图片类型不正确") + "!");
            }
            if (isExists) {
//                //设置比例、分辨率的参数
//                var a_active = $("#vedio-img-box02 .upload-btn-group a.active");
//                $("#hidden_img_proportion").val(a_active.html());
//                $("#hidden_img_scale").val(a_active.attr("data-size"));
//                $("#vedio-img-box02 li").append('<p style="width: 300px;position: absolute;top:0;left:0;height: 300px;background-color: rgba(0,0,0,0.5);line-height: 300px;text-align: center;font-size: 18px;color: #fff;">' + LCT("正在上传，请稍后") + '...</p>');
//                $("#upload").hide();
//                上传图片
                $('#video_picUpload_form').ajaxSubmit({
                    url: basePath + "uploadController/uploadPicSource.do?uploadType=logo",
                    type: 'post',
                    success: function(data) {
                        var rs = $.parseJSON(data);
                        if (rs.success) {
                            var img = rs.obj.pic_fineshed;
                            $("#vedio-img-box02 li img").attr({
                                "src": img
                            });
                            $("#vedio-img-box02 li p").remove();
                            $("#upload").show();
                            return false;
                        } else {
                            $("#vedio-img-box02 li p").remove();
                            $("#upload").show();
                            alertfn.danger(rs.msg);
                            $('#upload').replaceWith('<input id="upload" style="position:absolute;top:230px;opacity:0;height:36px;cursor:pointer;" name="myfile" onChange="javascript:vrsFn.setImagePreview(this);" type="file"/>');
                            return false;
                        }
                    }
                });
            }

        }
    },
    /*
     * 取地址栏多个参数的value
     * @param
     *      key
     * @return
     *      value
     *
     */
    locationValue: function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    },
    categoryInit: function() { //页面初始渲染数据分类
        var categoryId = $("input[name='category']").val();
        var cur_url = window.location.href.split("&");
        var categoryId_cookie, customCategoryId_cookie;
        if (cur_url.length > 1) {
            categoryId = vrsFn.locationValue("editCategory");
            customCategoryId_cookie = vrsFn.locationValue("editCustomCategory");
            $("#categoryId_hidden").val(categoryId);
            $("#customCategoryId_hidden").val(customCategoryId_cookie);
        }
        //数据分类
        PullAjax(basePath + "customCategoryController/getCategorys.do", "", function success(data) {
            for (var i = 0; i < data.length; i++) {
                if (data[i].dicValue == categoryId) {
                    //$("#category").html('<option data-id="'+categoryId+'" readonly="readonly">' + data[i].showName + '</option>');
                    $("#category").val(data[i].showName).attr("data-id", categoryId);
                    break;
                }
            }
        }, function error() {});
        //三级分类
        PullAjax(basePath + "customCategoryController/dataGrid.do", "", function success(data) {
            var customCategoryId_hidden = $("#customCategoryId_hidden").val();
            var s1 = new CreateClassInformation(customCategoryId_hidden, data, $("#select1"));
            s1.init();
        }, function error() {});
    },
    /*
     * 标签块
     * @param
     *      dom为字符串
     *      rules标签规则
     *      perMax为每个标签的长度
     *      lengthMax为标签的个数
     * @return
     *      验证规则
     *
     */
    tagAction: function(dom, rules, perMax, lengthMax) {
        var init_length = $("." + dom + "Con li").length;
        if (init_length >= lengthMax) {
            $("#" + dom).parent().addClass("hide");
        } else {
            $("#" + dom).parent().removeClass("hide");
        }
        $("#" + dom).keyup(function(e) {
            var domArr = [];
            if (e.keyCode == 13) {
                var value = $.trim($(this).val());
                var dom_li = $("." + dom + "Con li");
                for (var i = 0; i < dom_li.length; i++) {
                    var text = $(dom_li[i]).text();
                    domArr.push(text);
                    if (value == text) {
                        alertfn.danger(LCT("不能重复"));
                        return;
                    }
                }
                if (value != "") {
                    if (!rules.test(value) || vrsFn.getStringLen(value) > perMax) {
                        alertfn.danger(LCT("不能输入特殊字符,每个最多" + perMax / 2 + "个字符"));
                    } else {
                        $("." + dom + "Con ul").append("<li>" + value + "<span></span></li>");
                        domArr.push(value);
                        $("#" + dom + "-result").val(domArr.join("/"));
                        $(this).val("");
                        $("#" + dom).css("border", "1px #ccc solid");
                        $("#" + dom + "-result-error").remove();
                    }
                }
                if (dom_li.length >= lengthMax) {
                    $("#" + dom).parent().addClass("hide");
                }
            }
        });
        $("." + dom + "Con").on("click", "li span", function() {
            var domArr = [];
            var dom_li = $("." + dom + "Con li");
            var length = $("." + dom + "Con li").length;
            $(this).parent().remove();
            if (length < lengthMax) {
                $("#" + dom).parent().removeClass("hide");
            }
            for (var i = 0; i < dom_li.length; i++) {
                var text = $(dom_li[i]).text();
                domArr.push(text);
            }
            $("#" + dom + "-result").val(domArr.join("/"));
        });
    },
    infomationValidate: function() { //自定义表单验证规则，提示
        //自定义标签内容验证
        $.validator.addMethod("hundred", function(value, element) {
            var name = /^([1-9]\d{0,1}|100)$/;
            return this.optional(element) || (name.test(value));
        }, LCT("请您输入100以内的数字"));
        /*$.validator.addMethod("episodeCount_result", function(value, element) {
            var zjs = parseInt($("input[name=episodeCount]").val());
            var current = parseInt($("input[name=episodeNow]").val());
            var boo = false;
            current > zjs ? boo = false : boo = true;
            return boo;
        }, LCT("当前更新集数不能大于总集数"));*/
        $.validator.addMethod("decimal_1", function(value, element) {
            var name = /^(\d+\.\d{1,1}|\d+)$/;
            return this.optional(element) || (name.test(value));
        }, LCT("只能输入一位小数"));
        $.validator.addMethod("albumName_rules", function(value, element) {
            var name = /^[\u4e00-\u9fa5 a-zA-Z0-9\•\！\【\】\？\“\”\‘\’\《\》\（\）\，\。\—\*\：\!\[\]\?\"\'\<\>\(\)\,\.\-\_\*\:]{1,40}$/;
            var boo = true;
            if (vrsFn.getStringLen(value) < 2 || vrsFn.getStringLen(value) > 40) {
                boo = false;
            }
            return (this.optional(element) || name.test(value)) && boo;
        }, LCT("专辑名称由") + " 2-40 " + LCT("个字母，数字，汉字，空格组成") + LCT("中文字符") + "：• ！ 【】 ？ “” 《》 （） ， 。 — * ：" + LCT("英文字符") + "：! [] ? “” <> () , . - _ * :");
        $.validator.addMethod("threeformat", function(value, element) {
            var name = /^[a-zA-Z\u4E00-\u9FA5\s-]{1,10}$/;
            var sArr = value.split(",");
            var boo = true;
            if (sArr.length == 0 || sArr.length > 3) {
                boo = false;
            } else {
                for (var i = 0; i < sArr.length; i++) {
                    if (!name.test(sArr[i])) {
                        boo = false;
                    }
                }
            }
            return this.optional(element) || boo;
        }, LCT("您输入的格式有误"));

        $.validator.addMethod("tenformat", function(value, element) {
            var name = /^[a-zA-Z\u4E00-\u9FA5\s-]{1,10}$/;
            var sArr = value.split(",");
            var boo = true;
            if (sArr.length == 0 || sArr.length > 10) {
                boo = false;
            } else {
                for (var i = 0; i < sArr.length; i++) {
                    if (!name.test(sArr[i])) {
                        boo = false;
                    }
                }
            }
            return this.optional(element) || boo;
        }, LCT("您输入的格式有误"));
        $.validator.addMethod("checkRepeat_video", function(value, element) {
            var boo = true;
            var videoId = $("#videoId_hidden").val();
            $.ajax({
                url: basePath + "videoController/checkVideoName.do",
                data: "videoName=" + value + "&videoId=" + videoId,
                type: "get",
                async: false,
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        boo = true;
                    } else {
                        boo = false;
                    }
                }
            });
            return this.optional(element) || boo;
        }, LCT("您输入的视频名称已存在"));
        $.validator.addMethod("checkRepeat_album", function(value, element) {
            var boo = true;
            var albumId = $("#albumId").val();
            $.ajax({
                url: basePath + "albumController/checkAlbumdName.do",
                data: "albumName=" + value + "&albumId=" + albumId,
                type: "get",
                async: false,
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        boo = true;
                    } else {
                        boo = false;
                    }
                }
            });
            return this.optional(element) || boo;
        }, LCT("您输入的专辑名称已存在"));
        $.validator.addMethod("ip_10", function(value, element) {
            var name = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
            var sArr = $.trim(value).split("/"); //按/切割
            var boo = true;
            if (sArr.length == 0 || sArr.length > 10) {
                boo = false;
            } else {
                for (var i = 0; i < sArr.length; i++) {
                    if (!name.test(sArr[i])) {
                        boo = false;
                    }
                }
            }
            return this.optional(element) || boo;
        }, LCT("请输入正确的审核IP，最多10个IP，IP之间用‘/’间隔"));
        $.validator.addMethod("length_50", function(value, element) {
            var boo = true;
            if (vrsFn.getStringLen(value) < 2 || vrsFn.getStringLen(value) > 50) {
                boo = false;
            }
            return this.optional(element) || boo;
        }, LCT("长度在2到50"));

        $.validator.addMethod("length_80", function(value, element) {
            var boo = true;
            if (vrsFn.getStringLen(value) > 80) {
                boo = false;
            }
            return this.optional(element) || boo;
        }, LCT("长度不能超过80"));
        $.validator.addMethod("length_400", function(value, element) {
            var boo = true;
            if (vrsFn.getStringLen(value) < 2 || vrsFn.getStringLen(value) > 400) {
                boo = false;
            }
            return this.optional(element) || boo;
        }, LCT("长度在2到400"));

        $.validator.addMethod("max_rules", function(value, element) {
            var categoryId = $("#categoryId_hidden").val();
            var boo = true;
            if (categoryId == 100002 && value > 1000) {
                boo = false;
            } else if (value > 30000000) {
                boo = false;
            }
            return this.optional(element) || boo;
        }, LCT("电视剧最大值不能超过1000，非电视剧最大值不能超过30000000"));

        //自定义标签内容验证
        $("#information").validate({
            rules: {
                albumId: {
                    number: true
                },
                videoName: { //视频名称
                    required: true,
                    length_50: true,
                    //albumName_rules: true,
                    checkRepeat_video: true,
                },
                albumName: { //专辑名称
                    required: true,
                    length_50: true,
                    //albumName_rules: true,
                    checkRepeat_album: true,
                },
                subTitle: {
                    length_50: true
                },
                tag: { //标签
                    required: true,
                },
                synopsis: { //简介
                    length_400: true,
                    required: true,
                },
                score: { //评分 10以内的一位小数
                    number: true,
                    max: 10,
                    decimal_1: true
                },
                episodeCount: { //总集数
                    // required: true,
                    digits: true,
                },
                /*episodeNow: { //当前更新集数
                    digits: true,
                    max: 30000000,
                },*/
                episode: { //集数
                    // required: true,
                    digits: true,
                },
                releaseDate: {
                    // required: true,
                    date: true
                },
                // copyrightStart: {
                //     date: true
                // },
                // copyrightEnd: {
                //     date: true
                // },
                // director: { //导演
                //     required: true,
                // },
                // actor: { //演员
                //     required: true,
                //     //Label_10: true
                // },
                // guest: { //嘉宾
                //     required: true
                // },
                // host: { //主持人
                //     required: true
                // },
                // lyrics: { //作词
                //     required: true,
                // },
                // composer: { //作曲
                //     required: true,
                // },
                // singer: { //歌手
                //     required: true
                // },
                // master: { //达人
                //     required: true
                // },
                // copyrightCompany: { //版权公司
                //     length_80: true
                // },
                // ip: {
                //     required: true,
                //     ip_10: true
                // }
            },
            messages: {
                albumId: {
                    number: LCT("请输入合法数字"),
                },
                videoName: { //视频名称
                    required: LCT("请输入视频名称"),
                    //albumName_rules: LCT("视频名称由") + " 2-40 " + LCT("个字母，数字，汉字，空格组成") + LCT("中文字符") + "：• ！ 【】 ？ “” 《》 （） ， 。 — * ：" + LCT("英文字符") + "：! [] ? “” <> () , . - _ * :",
                    length_50: LCT("长度在1到25"),
                    checkRepeat_video: "您输入的视频名称已存在",
                },
                albumName: { //专辑名称
                    required: LCT("请输入专辑名称"),
                    length_50: LCT("长度在1到25"),
                    //albumName_rules: LCT("专辑名称由") + " 2-40 " + LCT("个字母，数字，汉字，空格组成") + LCT("中文字符") + "：• ！ 【】 ？ “” 《》 （） ， 。 — * ：" + LCT("英文字符") + "：! [] ? “” <> () , . - _ * :",
                    checkRepeat_album: LCT("您输入的专辑名称已存在"),

                },
                subTitle: {
                    length_50: LCT("长度在1到25"),
                },
                tag: { //标签
                    required: LCT("请输入标签"),
                },
                synopsis: {
                    length_400: LCT("长度在2到400"),
                    required: LCT("请输入简介"),
                },
                score: { //评分 10以内的一位小数
                    number: LCT("请输入合法的数字"),
                    max: LCT("评分在10以内")
                },
                episode: { //期数
                    // required: LCT("请输入集数"),
                    digits: LCT("请输入整数"),
                },
                episodeCount: { //总集数
                    // required: LCT("请输入总集数"),
                    digits: LCT("请输入整数"),
                },
                /*episodeNow: { //当前更新集数
                    number: LCT("请输入合法的数字"),
                    max: LCT("请输入当前集数或者yyyymmdd格式的当前期数"),
                    digits: LCT("请输入整数")
                },*/
                releaseDate: { //上映日期
                    required: LCT("请输入上映时间"),
                    date: LCT("请输入正确的时间格式")
                },
                // copyrightStart: {
                //     date: LCT("请输入正确的时间格式")
                // },
                // copyrightEnd: {
                //     date: LCT("请输入正确的时间格式")
                // },
                // director: { //导演
                //     required: LCT("请输入导演"),
                // },
                // actor: { //演员(变化)
                //     required: LCT("请输入姓名"),
                // },
                //
                // guest: { //嘉宾
                //     required: LCT("请输入嘉宾"),
                // },
                // host: { //主持人
                //     required: LCT("请输入主持人"),
                // },
                // lyrics: { //作词
                //     required: LCT("请输入作词人"),
                // },
                // composer: { //作曲
                //     required: LCT("请输入作曲人"),
                // },
                // singer: { //歌手
                //     required: LCT("请输入歌手"),
                // },
                // master: { //达人
                //     required: LCT("请输入达人"),
                // },
                // copyrightCompany: { //版权公司
                //     length_80: LCT("长度不能超过") + " 80"
                // },
                // ip: {
                //     required: LCT("请输入审核IP"),
                //     ip_10: LCT("请输入审核IP，最多10个IP，IP之间用‘/’间隔")
                // }
            }
        });
        //区分电视剧与非电视剧下边的集数最大值
        // if ($("#categoryId_hidden").val() == 100002) {
        //     try {
        //         $("input[name='episode']").rules("add", {
        //             max: 1000,
        //             messages: {
        //                 max: LCT("最大值不能超过1000"),
        //             }
        //         });
        //     } catch (e) {}
        //
        //     $("input[name='episodeCount']").rules("add", {
        //         max: 1000,
        //         messages: {
        //             max: LCT("最大值不能超过1000"),
        //         }
        //     });
        // } else {
        //     try {
        //         $("input[name='episode']").rules("add", {
        //             max: 30000000,
        //             messages: {
        //                 max: LCT("最大值不能超过30000000"),
        //             }
        //         });
        //     } catch (e) {}
        //     $("input[name='episodeCount']").rules("add", {
        //         max: 30000000,
        //         messages: {
        //             max: LCT("最大值不能超过30000000"),
        //         }
        //     });
        // }
    },
    /*
     * 获取指定时间
     * @param
     *      AddDayCount单位是天，今天之前是负数，今天之后是正数
     *      hms是否需要时分秒
     *          hms=1,显示时分秒
     *          hms=0,不显示时分秒
     * @return
     *      返回指定时间
     *
     */
    GetDateStr: function(AddDayCount, hms) {
        var dd = new Date();
        dd.setDate(dd.getDate() + AddDayCount); //获取AddDayCount天后的日期
        var y = dd.getFullYear();
        var m = (dd.getMonth() + 1) < 10 ? "0" + (dd.getMonth() + 1) : (dd.getMonth() + 1); //获取当前月份的日期，不足10补0
        var d = dd.getDate() < 10 ? "0" + dd.getDate() : dd.getDate(); //获取当前几号，不足10补0
        var hh = dd.getHours() < 10 ? "0" + dd.getHours() : dd.getHours();
        var mm = dd.getMinutes() < 10 ? "0" + dd.getMinutes() : dd.getMinutes();
        var ss = dd.getSeconds() < 10 ? "0" + dd.getSeconds() : dd.getSeconds();
        if (hms == 1) {
            return y + "-" + m + "-" + d + " " + hh + ":" + mm + ":" + ss;
        } else {
            return y + "-" + m + "-" + d;
        }

    },
    /*
     * 单个/批量--删除/恢复--视频
     * @param
 *      videoId 视频id，ids
 *      action
 *          action=1,恢复
 *          action=0,删除
     * @return
     *  单个/批量--删除/恢复--视频
     *
     */
    deteleRecoverVideo: function(videoId, action) {
        var tips;
        if (action == 1) {
            tips = "恢复";
        } else if (action == 2) {
            tips = "删除";
        }
        var params = {
            "discription": "您是否确认" + tips + "当前所选视频",
            "iconType": "triangle",
            "confirmBtn": true,
            "cancelBtn": true,
            "confirmEvent": function() {
                $.ajax({
                    url: basePath + "videoController/batchToggleOnOffLine.do",
                    data: {
                        videoIds: videoId,
                        action: action
                    },
                    type: "post",
                    dataType: "json",
                    success: function(data) {
                        if (data.success) {
                            alertfn.success(LCT(tips + "成功"));
                            $(".btn_search").click();
                        } else {
                            alertfn.danger(data.msg);
                        }
                    }
                });
            }
        };
        $("body").toolsalert(params);
        return;
    },
};
$(function() {
    vrsFn.init();
})

function CreateClassInformation(id, data, dom) {
    this.id = id;
    this.oParentData = data;
    this.data = "";
    this.oParentDom = dom;
    this.aSel = $(this.oParentDom).find("select");
}
CreateClassInformation.prototype = {
    init: function() {
        this.searchData();
        this.createDom();
    },
    createDom: function() {

        for (var i = 0; i < this.data.length; i++) {
            var opt = $('<option>');
            opt.html(this.data[i].text);
            opt.attr("data-id", this.data[i].id);
            opt.attr("readonly", true);
            this.aSel.eq(i).append(opt);
        }
        this.ifHasData(this.data.length);
    },
    ifHasData: function(len) {
        for (var i = 0; i <= 2 - len; i++) {
            var opt = $('<option>');
            opt.html(LCT("请选择"));
            opt.attr("readonly", true);
            this.aSel.eq(2 - i).append(opt);
        }
    },
    searchData: function() {
        var arr = [];
        for (var i in this.oParentData) {
            if (this.oParentData[i].id == this.id) {
                this.data = this.oParentData[i];

                var obj = {};
                obj.text = this.oParentData[i].text;
                obj.id = this.oParentData[i].id;
                arr.push(obj);

                this.data = arr;
                return
            }
            if (this.oParentData[i].children.length != 0) {
                for (var j in this.oParentData[i].children) {
                    if (this.oParentData[i].children[j].id == this.id) {

                        var obj = {};
                        obj.text = this.oParentData[i].text;
                        obj.id = this.oParentData[i].id;
                        arr.push(obj);
                        var obj = {};
                        obj.text = this.oParentData[i].children[j].text;
                        obj.id = this.oParentData[i].children[j].id;
                        arr.push(obj);
                        this.data = arr;
                        return
                    }
                    if (this.oParentData[i].children[j].children != 0) {
                        for (var k in this.oParentData[i].children[j].children) {
                            if (this.oParentData[i].children[j].children[k].id == this.id) {

                                var obj = {};
                                obj.text = this.oParentData[i].text;
                                obj.id = this.oParentData[i].id;
                                arr.push(obj);
                                var obj = {};
                                obj.text = this.oParentData[i].children[j].text;
                                obj.id = this.oParentData[i].children[j].id;
                                arr.push(obj);
                                var obj = {};
                                obj.text = this.oParentData[i].children[j].children[k].text;
                                obj.id = this.oParentData[i].children[j].children[k].id;
                                arr.push(obj);
                                this.data = arr;
                                return
                            }
                        }
                    }
                }
            }
        }
        this.data = "";
        return
    }
}

function PullAjax($url, $data, callback, errorCallBack) {
    $.ajax({
        url: $url,
        data: $data,
        type: "POST",
        dataType: "json",
        success: function(json) {
            callback(json);
        },
        error: function(data) {
            errorCallBack(data);
        }
    })
}

function PublicPullSubmitSelected(name) {
    var dom = $("input[name=" + name + "]");
    return dom.val() ? true : false;
}

function PublicSuccessError(name, ifPass) {
    if (ifPass) {
        var dom = $("#" + name).find(".tab-error");
        dom.remove(".tab-error");
    } else {
        var content = "";
        switch (name) {
            case "tab-videoType":
                content = LCT("请选择视频类型");
                break;
            case "tab-subCategory":
                content = LCT("请选择影视分类");
                break;
            case "tab-language":
                content = LCT("请选择至少一种语言类型");
                break;
            case "tab-area":
                content = LCT("请选择内容所属地区");
                break;
            case "tab-playPlatform":
                content = LCT("请选择播放平台类型");
                break;
            case "tab-contentRating":
                content = LCT("请选择一种年龄分级类型");
                break;
            case "tab-shieldingRule":
                content = LCT("请选择一种海外屏蔽类型");
                break;
            case "tab-copyrightType":
                content = LCT("请选择一种版权类型");
                break;
        }
        var dom = $("#" + name).find(".tab-error");
        if (dom.length > 0) {

        } else {
            var errorLabel = "<label class='tab-error' name='tab-error'>" + content + "</label>";
            $("#" + name).append(errorLabel);
        }
    }
}
// 多选 单选 样式切换 取值操作对象
var multiRadio = {
    multi: function(d) {
        var dom = $(d).find("i");
        var domfirst = $(d).closest("dl");
        var domdiv = domfirst.find("div");
        var boo = false;
        domfirst = domfirst.find("div").eq(0);
        if (dom.hasClass("active")) {
            dom.removeClass("active");
            domfirst.find("i").removeClass("active");
            domfirst.attr("data-flag", "");
        } else {
            dom.addClass("active");
            for (var i = 1; i < domdiv.length; i++) {
                var dom = domdiv.eq(i).find("i");
                if (dom.hasClass("active")) {

                } else {
                    boo = true;
                }
            }
            if (!boo) {
                domfirst.attr("data-flag", "1");
                domfirst.find("i").addClass("active");
            }
        }


    },
    select: function(d) { //新增地区全选功能
        var index = $(d).closest("div").index();
        if (d.hasClass("allArea")) {
            var op = $(d).closest("dl");
            var dom = op.find("div");
            var len = dom.length;
            var domfirst = dom.eq(0);
            for (var i = 0; i < len; i++) {
                var domi = dom.eq(i).find("i");
                if (!domfirst.attr("data-flag")) {
                    if (!domi.hasClass("active")) {
                        domi.addClass("active");
                    }
                } else {
                    domi.removeClass("active");
                }
            }
            if (!domfirst.attr("data-flag")) {
                domfirst.attr("data-flag", "1")
            } else {
                domfirst.attr("data-flag", "")
            }
            return true;
        }
        return false;
    },
    radio: function(d, c) {
        var len = $(c).length;
        for (var i = 0; i < len; i++) {
            var dom = $(c).eq(i).find("i");
            dom.removeClass("active");
        }
        $(d).find("i").addClass("active");
    },
    multiValue: function(key, c) {
        var len = $(c).length;

        var str = "";
        for (var i = 0; i < len; i++) {
            var dom = $(c).eq(i).find("i");
            if (dom.hasClass("active")) {
                var input = dom.siblings("input");
                if (str) {
                    str += "," + input.val();
                } else {
                    str += input.val();
                }
            }
        }
        $("input[name=" + key + "]").val(str);
        return str.length ? true : false;

    },
    radioValue: function(key, c, name) {
        var len = $(c).length;
        var str = "";
        for (var i = 0; i < len; i++) {
            var dom = $(c).eq(i).find("i");
            if (dom.hasClass("active")) {
                var input = dom.siblings("input");
                str += input.val();
            }
        }
        $("input[name=" + key + "]").val(str);
        return str.length ? true : false;

    }
};
// 初始化radio

function initRadio(dom, value) {
    $(dom).each(function() {
        if ($(this).find("input").val() == value) {
            $(this).find("i").addClass("active");
        }


    });
}
// 初始化checkbox

function initCheckbox(dom, values) {
    var value = values.split(",");
    $(dom).each(function() {
        if (value.indexOf($(this).find("input").val()) > -1 && $(this).find("input").val() != "") {
            $(this).find("i").addClass("active");
        }
    });
    if(dom==".area"){
        var dt=$("#tab-area dt");
        var dd=$("#tab-area dd");
        console.log(dd.length);
        for(var i=0;i<dd.length;i++){
            var i_length=$(dd[i]).find("i").length;
            var iActive_length=$(dd[i]).find("i.active").length;
            console.log(i_length,iActive_length)
            if(iActive_length==i_length){
                $(dt[i]).find("i").addClass("active");
                $(dt[i]).find("div").attr("data-flag", "1");
            }
        }
    }
}



//获取视频列表图片的方法

function getListPicUrl(d) {
    if (d != null && d != "" && d != undefined && d != "undefined") {
        return d;
    } else {
        return "http://yweb0.cnliveimg.com/image/mz/chulizhong.jpg";
    }
}
function getListPicUrlForAlbum(d) {
    if (d != null && d != "" && d != undefined && d != "undefined") {
        return d;
    } else {
        return "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
    }
}
function getCategoryName(d) {
    if (d != null && d != "" && d != undefined && d != "undefined"){
        return d;
    }else {
        return "暂未设置";
    }
}
//数组去重

function unique(arr) {
    var newarr = [];
    arr.sort();
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] != newarr[newarr.length - 1])
            newarr.push(arr[i]);
    }
    return newarr;
}

//需要刷新页面时，去除maintable全选状态
$(".page-main").on("click", "a", function() {
    $(this).closest("tr").find(".checkall").prop("checked", false);
});
$("#setClass").on("change", "select", function() {
    $("#maintable").find(".checkall").prop("checked", false);
});
$(".btn_search").bind("click", function() {
    $("#maintable").find(".checkall").prop("checked", false);
});

//左侧导航统一
$(".main").on("click", ".icon-set", function() {
    jumpOutUrl("vrsCategory"); //分类设置
});
$(".main").on("click", "#media-upload", function() {
    jumpOutUrl("vrs");
});

//页面滚动到error

function error_scroll() {
    if ($(".error:visible").length) {
        var error_top = $(".error:visible").eq(0).closest(".form-group").offset().top;
    }
    if ($(".tab-error").length) {
        var tab_error_top = $(".tab-error").eq(0).closest(".form-group").offset().top;
    }
    if (error_top && tab_error_top) {
        var top = error_top < tab_error_top ? error_top : tab_error_top;
    } else if (error_top) {
        var top = error_top;
    } else if (tab_error_top) {
        var top = tab_error_top;
    }
    $('html, body').animate({
        scrollTop: top
    }, 500);
}

//判断当前分类
var classfiyObject = (function() {
    function classfiyObject() {}
    classfiyObject.getPidAndId = function(id, children, level) {
        for (var i = 0; i < children.length; i++) {
            var classObj = children[i];
            if (classObj.id == id) {
                return {
                    _id: classObj.id,
                    _pid: classObj.pid,
                    _level: level
                };
            } else {
                if (classObj.children.length > 0) {
                    var temp_obj = classfiyObject.getPidAndId(id, classObj.children, level + 1);
                    if (temp_obj) {
                        return temp_obj;
                    }
                }
            }
        }
    };
    return classfiyObject;
})();

/*
 * 加入/修改专辑
 * @param
 *      列表筛选条件，
 *      数据分类categoryId
 *      自定义分类customCategoryId，有则选中当前分类
 *      数据分类albumId，当前有所属专辑--修改专辑--默认选中当前专辑
 *                       当前无所属专辑--加入专辑
 * @return
 *      专辑列表
 *
 */

function joinEditor_table(categoryId, customCategoryId, albumId) {
    //渲染数据分类，必有，只读
    PullAjax(basePath + "customCategoryController/getCategorys.do", "", function success(data) {
        var system_channel = '';
        system_channel += '<option data-id="0" value=' + LCT("请选择") + '>' + LCT("请选择") + '</option>';
        for (var i = 0; i < data.length; i++) {
            var showName = data[i].showName;
            var dicValue = data[i].dicValue;
            if (categoryId && (dicValue == categoryId)) {
                $(".category").html('<option data-id=' + categoryId + ' readonly="readonly">' + data[i].showName + '</option>').attr({
                    "disabled": "disabled",
                    "data-id": categoryId
                });
                break;
            } else {
                system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
            }
        }
        if (categoryId == '0') {
            $(".category").attr("data-id", '0').html(system_channel).removeAttr("disabled");
        }
    }, function error() {});
    //渲染三级分类
    if (categoryId == '0') {
        category_obj = {};
        $("#customCategory_con").html(vrsFn.customCategoryInitDom);
    } else {
        category_obj.category = categoryId;
        if (buildEdit.start) {
            return
        }
        buildEdit.init("customCategory_con");
        if (customCategoryId != 0 && customCategoryId != null) {
            var obj = classfiyObject.getPidAndId(customCategoryId, window.classfiyObject_obj, 1);
            if (obj._level == 1) {
                $("#customCategory_con").find("select").eq(0).find("option[data-id=" + customCategoryId + "]").prop("selected", true);
            } else if (obj._level == 2) {
                $("#customCategory_con").find("select").eq(0).find("option[data-id=" + obj._pid + "]").prop("selected", true);
                $("#customCategory_con").find("select").eq(0).change();
                $("#customCategory_con").find("select").eq(1).find("option[data-id=" + obj._id + "]").prop("selected", true);
            } else if (obj._level == 3) {
                var obj3 = classfiyObject.getPidAndId(obj._pid, window.classfiyObject_obj, 1);
                $("#customCategory_con").find("select").eq(0).find("option[data-id=" + obj3._pid + "]").prop("selected", true);
                $("#customCategory_con").find("select").eq(0).change();
                $("#customCategory_con").find("select").eq(1).find("option[data-id=" + obj._pid + "]").prop("selected", true);
                $("#customCategory_con").find("select").eq(1).change();
                $("#customCategory_con").find("select").eq(2).find("option[data-id=" + obj._id + "]").prop("selected", true);
            }
            $("#customCategory_con select").prop("disabled", "disabled");
        }
    }
    $(".category").change(function() {
        var categoryId = $(this).children('option:selected').attr("data-id");
        $(".category").attr("data-id", categoryId);
        category_obj.category = categoryId;
        if (categoryId == '0') {
            $("#customCategory_con").html(vrsFn.customCategoryInitDom);
        } else {
            $("#customCategory_con").html('');
            buildEdit.init("customCategory_con");
        }
    });
    //渲染专辑列表
    var lcsetting_modal = {
        "ajax": basePath + "albumController/dataGrid.do?albumStatus=1",
        "pagekey": "page",
        "rowskey": "rows",
        "rowsvalue": 5,
        "dataType": "text", //到时候去掉此参数
        "highlight": true,
        "columns": [{
            "data": "lcall",
            "format": function(i, j, d) {
                return '<input data-albumId=' + d.albumId + ' category-id="' + d.category + '" customcategory-id="' + d.customCategoryId + '" type="radio" class="icheckFlatRed" name="albumId">';
            }
        }, {
            "data": "albumId"
        }, {
            "data": "lcall",
            "format": function(i, j, d) {
                var albumName = d.albumName;
                albumName_modal_arr.push(albumName);
                return '';
            }
        }, {
            "data": "videoCount"
        }],
        "pages": "#pages",
        "emptymsg": LCT("暂无数据"),
        "errormsg": LCT("数据请求错误，请稍后再试"),
        "waitmsg": LCT("加载中，请稍后") + "...",
        "callback": function(data) {
            $('.icheckFlatRed').iCheck({
                cursor: true,
                checkboxClass: 'icheckbox_flat-red',
                radioClass: 'iradio_flat-red',
                increaseArea: '20%'
            });
            $("#maintable_modal input[data-albumId='" + albumId + "']").iCheck('check');
            //专辑名称title
            var tr = $("#maintable_modal tbody tr");
            for (var i = 0; i < tr.length; i++) {
                var remark_html = albumName_modal_arr[i];
                $(tr[i]).find("td:eq(2)").text(remark_html);
            }
            albumName_modal_arr = [];
        }
    };
    if (categoryId == "0") {
        delete params_modal["category"];
    } else {
        params_modal["category"] = categoryId;
    }
    if (customCategoryId == "0") {
        delete params_modal["customCategoryId"];
    } else {
        params_modal["customCategoryId"] = customCategoryId;
    }
    $("#maintable_modal").lctable(lcsetting_modal, params_modal, ".page-zj");
    //加入专辑搜索
    $(".btn_search_modal").bind("click", function() {
        var value_name = $.trim($(".search_name_modal").val());
        var value_id = $.trim($(".search_id_modal").val());
        var arr = $("#customCategory_con option:selected");
        var categoryId = $(".category").attr("data-id");
        var customCategoryId = "";
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                customCategoryId = $(arr).eq(i).attr("data-id");
                break;
            }
        }
        if (value_name) {
            params_modal["albumName"] = value_name;
        } else {
            delete params_modal["albumName"];
        }
        if (value_id) {
            params_modal["albumId"] = value_id;
        } else {
            delete params_modal["albumId"];
        }
        if (categoryId == "") {
            delete params_modal["category"];
        } else {
            params_modal["category"] = categoryId;
        }
        if (customCategoryId == "") {
            delete params_modal["customCategoryId"];
        } else {
            params_modal["customCategoryId"] = customCategoryId;
        }
        lcsetting_modal.thisPage = 1;
        $("#maintable_modal").lctable(lcsetting_modal, params_modal, ".page-zj");
    });
    //去除搜索bind事件
    $('#modal-select-zhuanjiId').on('hide.bs.modal', function() {
        $(".btn_search_modal").unbind("click");
        $(".search_id_modal").val("");
        $("#customCategory_con").html("");
        params_modal = {};
    });
}

//上下线

function toggleOnOffLine(Id, url, txt) {
    $("#maintable").on("click", ".toggleLine", function() {
        var $this = $(this);
        var data_id = $this.attr("data-id");
        var isDelete = $this.attr("isDelete");
        var discription_add = isDelete == 1 ? LCT("是否上线") : LCT("是否下线");
        var discription = isDelete == 1 ? LCT("上线") : LCT("下线");
        var a_html = isDelete == 1 ? LCT("下线") : LCT("上线");
        var isDelete_value = isDelete == 1 ? 2 : 1;
        var span_html = isDelete == 1 ? '<span class="link-blue-txt">' + LCT("上线") + '</span>' : '<span class="link-greenrou">' + LCT("下线") + '</span>';
        var params = {
            "discription": discription_add + txt + data_id + LCT("？"),
            "iconType": "triangle",
            "confirmBtn": true,
            "cancelBtn": true,
            "confirmEvent": function() {
                $.ajax({
                    type: "post",
                    url: basePath + url + Id + "=" + data_id + "&action=" + isDelete,
                    dataType: "json",
                    success: function(data) {
                        if (data.success) {
                            alertfn.success(discription + LCT("成功"));
                            $(".btn_search").click();
                        } else {
                            alertfn.danger(data.msg);
                        }
                    },
                    error: function() {
                        //console.log("fail");
                    }
                });
            }
        };
        $("body").toolsalert(params);
        return;
    });
}

//批量上线

function mulToggleOnOffLine(target, action) {
    var txt_manger = target == 0 ? LCT("视频") : LCT("专辑");
    var url = target == 0 ? "videoController/batchToggleOnOffLine.do?videoIds=" : "albumController/batchToggleOnOffLine.do?albumIds=";
    var txt_status_modal_add = action == 1 ? LCT("是否批量上线") : LCT("是否批量下线");
    var txt_status_modal = action == 1 ? LCT("上线") : LCT("下线");
    var txt_status = action == 1 ? '<span class="link-blue-txt">' + LCT("上线") + '</span>' : '<span>' + LCT("下线") + '</span>';
    var txt_action_null = action == 1 ? LCT("请选择已下线") : LCT("请选择已上线");
    var txt_action = action == 1 ? LCT("下线") : LCT("上线");
    var isdelete_value = action == 1 ? 2 : 1;
    var isdelete_status = action == 1 ? 1 : 2;
    var mulToggleOnOffLine = [];
    var videoIds = [];
    var arr = $("#maintable .checkItem:checked");
    for (var i = 0; i < arr.length; i++) {
        mulToggleOnOffLine.push($(arr[i]).attr("isdelete"));
        videoIds.push($(arr[i]).attr("data-id"));
    }
    if (arr.length > 0) {
        if (unique(mulToggleOnOffLine).length == 1 && unique(mulToggleOnOffLine) == isdelete_status) {
            var params = {
                "discription": txt_status_modal_add + LCT("选中") + txt_manger + LCT("？"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function() {
                    $.ajax({
                        type: "post",
                        url: basePath + url + videoIds + "&action=" + action,
                        success: function(data) {
                            data = typeof(data) == "string" ? JSON.parse(data) : data;
                            if (data.success) {
                                alertfn.success(LCT("批量") + txt_status_modal + LCT("成功"));
                                $(".btn_search").click();
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function() {}
                    });
                }
            };
        } else {
            var params = {
                "title": LCT("错误"),
                "discription": txt_action_null + txt_manger,
                "iconType": "triangle",
                "confirmBtn": true
            };
        }
    } else {
        var params = {
            "title": LCT("错误"),
            "discription": LCT("请先选中一条记录"),
            "iconType": "triangle",
            "confirmBtn": true
        };
    }
    $("body").toolsalert(params);
    return;
}
//页面导航统一

function jumpOutUrl(menuKey) {
    var a = $("#leyun-warp-navbar a[data-menu='" + menuKey + "']", parent.document);
    var url = a.attr("data-url");
    window.location.href = url;
    var dd;
    if (a.parent().is("p")) {
        var p = a.parent();
        p.addClass("active").siblings().removeClass("active");
        dd = p.parent().parent();
    } else if (a.parent().is("dd")) {
        dd = a.parent();
    }
    dd.addClass("active").siblings().removeClass("active");
    var li = dd.parent().parent();
    li.addClass("active").siblings().removeClass("active");
    li.siblings().find("*").removeClass("active");
}

//返回

function showInIFrame(url) {
    var iframe = $(document).find(".lc_inner_iframe");
    if (iframe.length > 0) {
        iframe.attr("src", url);
        $(".lc_inner_wraper").show();
    } else {
        var h = $(window).height();
        var html = '<div class="lc_inner_wraper" style="height:' + h + 'px"><iframe class="lc_inner_iframe" style="width: 100%;height:98%" ' +
            'frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0"' +
            'allowtransparency="true" scrolling="0-" src="' + url + '"></iframe></div>';
        $("body").append($(html));
    }
    $(window).scrollTop(0);
    $("div.main:eq(0)").hide();
}


function closeIframeFromInner(type) {
    window.parent.closeIframeFromOuter(type);
}