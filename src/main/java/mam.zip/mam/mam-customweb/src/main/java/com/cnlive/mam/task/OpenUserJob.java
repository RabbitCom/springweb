package com.cnlive.mam.task;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.utils.OpenUtil;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.service.CustomService;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * open 用户数据调度
 *
 * @author liyi
 */
@Component
public class OpenUserJob {

    private static Logger _log = LoggerFactory.getLogger(OpenUserJob.class);

    @Value("#{configProperties['devMode']}")
    private String devMode;

    @Value("#{configProperties['sync_user_url']}")
    private String syncUserUrl;

    @Resource
    private CustomService customService;

    public void updateUsers() {
        if (!Boolean.parseBoolean(devMode)) {
            //API wiki http://bj.gitlab.cnlive.com/boss-team/open/wikis/api/auser/authdata2
            try {
                //获取库中最大的tm
                String tm = customService.findMaxTm() + "";
                while (tm != null) {
                    Map<String, String> map = new HashMap<>();
                    map.put("timestamp", System.currentTimeMillis() / 1000 + "");
                    map.put("tm", tm);
                    String sign = OpenUtil.sign(map, "fb97a2d9-3a1f-4f86-b4e4-9aab6987f347");
                    HttpUriRequest httpUriRequest = RequestBuilder.post()
                            .setUri(syncUserUrl)
                            .addParameter("timestamp", map.get("timestamp"))
                            .addParameter("tm", map.get("tm"))
                            .addParameter("sign", sign)
                            .build();

                    CloseableHttpResponse closeableHttpResponse = HttpClients.createDefault().execute(httpUriRequest);
                    String data = EntityUtils.toString(closeableHttpResponse.getEntity(), "utf-8");
                    closeableHttpResponse.close();
                    JSONObject jsonObject = JSON.parseObject(data);
                    _log.info("get userInfo from userCenter = {}",jsonObject.toJSONString());
                    if (jsonObject.getInteger("errorCode") == 0) {
                        com.alibaba.fastjson.JSONArray datas = jsonObject.getJSONArray("data");
                        for (int i = 0; i < datas.size(); i++) {
                            JSONObject item = datas.getJSONObject(i);
                            CustomModel customModel = new CustomModel();
                            customModel.setContacts(item.getString("contacts"));
                            customModel.setCustomId(item.getLong("sid"));
                            customModel.setEmail(item.getString("email"));
                            customModel.setIsParent(item.getBoolean("master") ? 1 : 0);
                            customModel.setName(item.getString("username"));
                            customModel.setPhone(item.getString("mobile"));
                            customModel.setSpId(item.getLong("new_sp_id"));
                            customModel.setInstitutionId(item.getString("institution_id"));
                            customModel.setInstitutionName(item.getString("institution_name"));
                            customModel.setStatus(item.getInteger("status"));
                            customModel.setTm(item.getLongValue("tm"));
                            CustomModel c = customService.getById(customModel.getCustomId());
                            if (c == null) {
                                customService.create(customModel);
                            } else {
                                customService.modify(customModel);
                            }
                        }
                    }
                    tm = jsonObject.getString("next_tm");
                }

            } catch (Exception e) {
                _log.error("OpenUserJob error ,msg = {}", e.getMessage());
            }
        }
    }

}
