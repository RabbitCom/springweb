/**
 * Created by Administrator on 7/31/2017.
 */

var params = {},
    index = 0;
var lcsetting = {
    "ajax": basePath + "storageController/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [
    //     {
    //     "data": "lcall",
    //     "format": function (i, j, d) { //编号
    //         return d.id;
    //     }
    // },
        {
        "data": "lcall",
        "format": function (i, j, d) { //名称
            if (d.showName == '')
                return d.name;
            return d.showName;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //类型
            if (d.type == 0) {
                return '未设置';
            }
            if (d.type == 1) {
                return '金山云';
            }
            if (d.type == 2) {
                return '七牛云';
            }
            if (d.type == 3) {
                return '自建存储';
            }
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //用途
            if (d.yongtu == 0) {
                return '未设置';
            }
            if (d.yongtu == 1) {
                return '生产';
            }
            if (d.yongtu == 2) {
                return '运营';
            }
            if (d.yongtu == 3) {
                return '生产+运营';
            }
        }
    }, {
            "data": "lcall",
            "format": function (i, j, d) { //存储内容
                if (d.contentType == 0) {
                    return '未设置';
                }
                if (d.contentType == 1) {
                    return '视音频';
                }
                if (d.contentType == 2) {
                    return '图片';
                }
                if (d.contentType == 3) {
                    return '视音频+图片';
                }
            }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //状态
            if (d.useState == 0) {
                return '禁用';
            }
            if (d.useState == 1) {
                return '<span style="color: red">启用</span>';
            }
            if (d.useState == 2) {
                return '禁用';
            }
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //操作类型
            // var configUrl = basePath + "storageConfigsController/manager.do?storageId=" + d.id;
            var editBtn = '<a href="#modal-storage-edit" data-toggle="modal"  class="ml-10 storage_edit" ' +
                'storageId="' + d.id + '" name="' + d.name + '" type="' + d.type + '" yongtu="' + d.yongtu + '" useState="' + d.useState + '" contentType="' + d.contentType + '" showName="' + d.showName + '">' +
                LCT("编辑") + '</a>';
            var enabledBtn = '<a href="javascript:;" class="storage_enabled ml-10" storageId="' + d.id + '" contentType="' + d.contentType + '" type="' + d.type + '">' + LCT("启用") + '</a>';
            var configBtn = '<a href="javascript:;" class="storage_config ml-10" storageId ="' + d.id + '">' + LCT("配置") + '</a>';
            var deleteBtn = '<a href="javascript:;" class="storage_del ml-10" storageId="' + d.id + '">' + LCT("删除") + '</a>';
            var viewBtn = '<a href="#modal-storage-view" data-toggle="modal"  class="ml-10 storage_view" ' +
                'storageId="' + d.id + '" name="' + d.name + '" type="' + d.type + '" yongtu="' + d.yongtu + '" useState="' + d.useState + '" contentType="' + d.contentType + '" showName="' + d.showName + '">' +
                LCT("查看") + '</a>';
            if (d.type == 3) {
                return '<a href="javascript:;" class="handle"> </a><p>' + editBtn + configBtn + viewBtn +'</p>';
            }
            if (d.useState == 1) {
                return '<a href="javascript:;" class="handle"> </a><p>' + configBtn + viewBtn +'</p>';
            } else if (d.useState == 2) {
                return '<a href="javascript:;" class="handle"> </a><p>' + enabledBtn + editBtn + configBtn + viewBtn +'</p>';
            } else {
                return '<a href="javascript:;" class="handle"> </a><p>' + enabledBtn + editBtn + configBtn + deleteBtn + viewBtn +'</p>';
            }
        }
    }
    ],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "..."
};
var storageFn = {
    init: function () {
        this.add(); //增加storage
        this.del(); //删除
        this.edit(); //编辑
        this.enabled(); //启用该存储
        this.view();//查看信息
        this.config();//跳转配置
    },
    add: function () {
        $("#buildAdd").click(function () {
            $("#storage_name_add").val("");
            $("#storage_showName_add").val("");
            $('input:radio[typeKey="type_add"]').removeAttr("checked");
            $('input:radio[yongtuKey="yongtu_add"]').removeAttr("checked");
            $('input:radio[contentTypeKey="contentType_add"]').removeAttr("checked");
        });
        $("#addSubmit").click(function () {
            var storageName = $("#storage_name_add").val();
            var storageShowName = $("#storage_showName_add").val();
            var type = $('input:radio[typeKey="type_add"]:checked').val();
            var yongtu = $('input:radio[yongtuKey="yongtu_add"]:checked').val();
            var contentType = $('input:radio[contentTypeKey="contentType_add"]:checked').val();
            if ($.trim(storageName) == "") {
                alertfn.danger("存储名称不可为空");
                return;
            } else if (checkE(storageName)) {
                alertfn.danger("存储名称必须由英文、数字、下划线组成");
                return;
            }
            if ($.trim(type) == "") {
                alertfn.danger("请选择类型");
                return;
            }
            if ($.trim(yongtu) == "") {
                alertfn.danger("请选择用途");
                return;
            }
            if ($.trim(contentType) == "") {
                alertfn.danger("请选择用途内容类型");
                return;
            }
            if ($.trim(storageShowName) == "") {
                $("#storage_showName_add").val(storageName);
            }
            $.post(
                basePath + "storageController/add.do",
                $.serializeObject(($('#addStorageInfo'))),
                function (data) {
                    if (data.success) {
                        $('#modal-storage-add').modal("hide");
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    } else {
                        var params = {
                            "title": LCT("提示"),
                            "discription": LCT(data.msg),
                            "iconType": "triangle",
                            "confirmBtn": true //确定按钮显示与否true or fasle
                        };
                        $("body").toolsalert(params);
                    }
                },
                'json'
            );
        });
    },
    edit: function () {
        $("#maintable").on("click", ".storage_edit", function () {
            $('input:radio[typeKey="type"]').prop("checked", false);
            $('input:radio[yongtuKey="yongtu"]').prop("checked", false);
            var $this = $(this);
            var storageId = $this.attr("storageId");
            $('#storage_edit_id').val(storageId);
            var contentType = $this.attr("contentType");
            var storageName = $this.attr("name");
            var storageShowName = $this.attr("showName");
            var type = $this.attr("type");
            var yongtu = $this.attr("yongtu");
            $("#storage_name_edit").val(storageName);
            $("#storage_showName_edit").val(storageShowName);
            if (type != 0 && type != undefined) {
                $('#type_' + type).prop("checked", "true");
            }
            if (yongtu != 0 && yongtu != undefined) {
                $('#yongtu_' + yongtu).prop("checked", "true");
            }
            if (contentType != 0 && contentType != undefined) {
                $('#contentType_' + contentType).prop("checked", "true");
            }
        });

        $("#modal-storage-edit").on("click", "#editSubmit", function () {
            var storageName = $("#storage_name_edit").val();
            var storageShowName = $("#storage_showName_edit").val();
            var type = $('input:radio[typeKey="type"]:checked').val();
            var yongtu = $('input:radio[yongtuKey="yongtu"]:checked').val();
            var contentType = $('input:radio[contentTypeKey="contentType"]:checked').val();
            if ($.trim(storageName) == "") {
                alertfn.danger("存储名称不可为空");
                return;
            } else if (checkE(storageName)) {
                alertfn.danger("存储名称必须由英文、数字、下划线组成");
                return;
            }
            if ($.trim(type) == "") {
                alertfn.danger("请选择类型");
                return;
            }
            if ($.trim(yongtu) == "") {
                alertfn.danger("请选择用途");
                return;
            }
            if ($.trim(contentType) == "") {
                alertfn.danger("请选择用途内容类型");
                return;
            }
            if ($.trim(storageShowName) == "") {
                $("#storage_showName_add").val(storageName);
            }
            $.post(
                basePath + "storageController/edit.do",
                $.serializeObject(($('#editStorageInfo'))),
                function (data) {
                    if (data.success) {
                        $('#modal-storage-edit').modal("hide");
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    } else {
                        var params = {
                            "title": LCT("提示"),
                            "discription": LCT(data.msg),
                            "iconType": "warningCircle",
                            "confirmBtn": true //确定按钮显示与否true or fasle
                        };
                        $("body").toolsalert(params);
                    }
                },
                'json'
            );
        });
    },
    del: function () {
        $("#maintable").on("click", ".storage_del", function () {
            var $this = $(this);
            var storageId = $this.attr("storageId");
            var params_alert = {
                "title": LCT("删除"),
                "discription": LCT("是否删除该存储"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function () {
                    $.ajax({
                        type: "post",
                        url: basePath + "storageController/del.do",
                        dataType: "json",
                        data: {
                            id: storageId
                        },
                        success: function (data) {
                            if (data.success) {
                                $("#maintable").lctable(lcsetting, params);
                                alertfn.success(data.msg);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function () {
                            //console.log("fail");
                        }
                    });
                }
            };
            $("body").toolsalert(params_alert);

        })
    },
    enabled: function () {
        $("#maintable").on("click", ".storage_enabled", function () {
            var $this = $(this);
            var storageId = $this.attr("storageId");
            var contentType = $this.attr("contentType");
            var type = $this.attr("type");
            $.post(
                basePath + "storageController/enabled.do",
                {storageId: storageId, contentType: contentType, type: type},
                function (data) {
                    if (data.success) {
                        $("#maintable").lctable(lcsetting, params);
                        alertfn.success(data.msg);
                    } else {
                        // alertfn.danger(data.msg);
                        var params = {
                            "title": LCT("提示"),
                            "discription": LCT(data.msg),
                            "iconType": "warningCircle",
                            "confirmBtn": true //确定按钮显示与否true or fasle
                        };
                        $("body").toolsalert(params);
                    }
                },
                'json'
            );
        });
    },
    view : function () {
        $("#maintable").on("click", ".storage_view", function () {
            $('input:radio[typeKey="type_view"]').prop("checked", false);
            $('input:radio[yongtuKey="yongtu_view"]').prop("checked", false);
            var $this = $(this);
            var storageId = $this.attr("storageId");
            $('#storage_edit_id').val(storageId);
            var contentType = $this.attr("contentType");
            var storageName = $this.attr("name");
            var storageShowName = $this.attr("showName");
            var type = $this.attr("type");
            var yongtu = $this.attr("yongtu");
            $("#storage_name_view").val(storageName);
            $("#storage_showName_view").val(storageShowName);
            if (type != 0 && type != undefined) {
                $('#type_view_' + type).prop("checked", "true");
            }
            if (yongtu != 0 && yongtu != undefined) {
                $('#yongtu_view_' + yongtu).prop("checked", "true");
            }
            if (contentType != 0 && contentType != undefined) {
                $('#contentType_view_' + contentType).prop("checked", "true");
            }
        });
    },
    config: function () {
        $("#maintable").on("click", ".storage_config", function () {
            var $this = $(this);
            var storageId = $this.attr("storageId");
            var lc_inner_href = basePath + "storageConfigsController/manager.do?storageId=" + storageId;
            showInIFrame(lc_inner_href);
        });
    }
};
$(function () {
    $("#maintable").lctable(lcsetting, params);
    storageFn.init();
});

function checkE(param) {
    var pattern = new RegExp("[^\x00-\xff]");
    if (pattern.test(param)) {
        return true;
    }
    return false;
}
function closeIframeFromOuter(type) {
    videoName_arr = [];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}