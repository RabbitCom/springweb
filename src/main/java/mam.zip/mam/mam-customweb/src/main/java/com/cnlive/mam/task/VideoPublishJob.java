package com.cnlive.mam.task;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.alibaba.dubbo.common.json.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.vo.JsonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.controller.BaseController;
import com.cnlive.mam.model.PublishTaskModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.PublishTaskService;
import com.cnlive.mam.service.VideoPublishService;
import com.cnlive.mam.service.VideoService;
@Component
public class VideoPublishJob {
    private static Logger _log = LoggerFactory.getLogger(VideoPublishJob.class);
    
    @Resource(name = "publishTaskService")
    private PublishTaskService publishTaskService;
    
    @Resource(name = "videoPublishService")
    private VideoPublishService videoPublishService;
    
    @Resource(name = "videoService")
    private VideoService videoService;

    @Value("#{configProperties['devMode']}")
    private String devMode;

    public void videoPublishRequest(){
        if (!Boolean.parseBoolean(devMode)) {
            try {
                //获取所有待发布任务表中信息
                PublishTaskModel model = new PublishTaskModel();
                model.setPublishTime(getTimeByMinute(-5));
                List<PublishTaskModel> publishTaskModelList = publishTaskService.getTaskListByState(model);
                if (publishTaskModelList != null && publishTaskModelList.size() > 0) {
                    for (PublishTaskModel publishTask : publishTaskModelList) {
                        //更改视频状态为发布中
                        VideoModel videoModel = videoService.getById(publishTask.getVideoId());
                        if (videoModel != null && Const.PUBLISHTASK_STATUS_PUBLISHTIME == publishTask.getPublishState()) {
                            VideoModel update = new VideoModel();
                            update.setVideoId(videoModel.getVideoId());
                            update.setStatus(ModelStatus.ReleaseIng);
                            update.setUpdateTime(new Date());
                            update.setCustomId(videoModel.getCustomId());
                            update.setUpdateUserId(videoModel.getCustomId());
                            videoService.modify(update);
                        }
                        JsonResult result = videoPublishService.publishVideo(publishTask.getVideoId(), publishTask.getCustomId());
                        _log.info("发布任务返回结果：{}", JSONObject.toJSONString(result));
                        publishTaskService.delete(publishTask.getTaskId());

                    }
                }
            } catch (Exception e) {
                _log.error("VideoPublishJob-publishing error ,msg = {}", e.getMessage());
            }
        }
    }
    
    
    public static Date getTimeByMinute(Integer minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, minute);
        return calendar.getTime();
    }
}
