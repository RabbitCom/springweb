package com.cnlive.mam.controller;


import com.cnlive.mam.model.StorageConfigsModel;
import com.cnlive.mam.service.StorageConfigsService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by zhangxiaobin on 2017/7/18.
 */
@Controller
@RequestMapping("/storageConfigsController")
public class StorageConfigsController extends BaseController {
    @Autowired
    private StorageConfigsService storageConfigsService;

    @RequestMapping(value = "/manager", method = RequestMethod.GET)
    public String manager(HttpServletRequest request, Integer storageId) {
        request.setAttribute("storageId", storageId);
        return "/storage/storage_config";
    }

    @RequestMapping(value = "/dataGrid", method = RequestMethod.GET)
    @ResponseBody
    public DataGrid dataGrid(HttpServletRequest request, Integer storageId) {
        List<StorageConfigsModel> list = storageConfigsService.getByStorageId(storageId);
        return new DataGrid(Long.valueOf(list.size()), list);
    }

    @RequestMapping("/add")
    @ResponseBody
    public JsonResult addStorageConfigs(HttpServletRequest request, StorageConfigsModel storageConfigsModel) {
        storageConfigsService.save(storageConfigsModel);
        return JsonResult.createSuccessInstance("添加成功");
    }

    @RequestMapping("/del")
    @ResponseBody
    public JsonResult delStorageConfigs(HttpServletRequest request, Integer id) {
        storageConfigsService.delete(id);
        return JsonResult.createSuccessInstance("删除成功");
    }

    @RequestMapping("/edit")
    @ResponseBody
    public JsonResult editStorageConfigs(HttpServletRequest request, StorageConfigsModel modifyModel) {
        StorageConfigsModel oldModel = storageConfigsService.getById(modifyModel.getId());
        if(oldModel == null){
            return JsonResult.createErrorInstance("信息不存在");
        }
        StorageConfigsModel update = new StorageConfigsModel();
        update.setId(oldModel.getId());
        update.setStorageId(oldModel.getStorageId());
        update.setProtocol(modifyModel.getProtocol());
        update.setHostName(modifyModel.getHostName());
        update.setIoType(modifyModel.getIoType());
        update.setUserName(modifyModel.getUserName());
        update.setPassWord(modifyModel.getPassWord());
        update.setPath(modifyModel.getPath());
        update.setPort(modifyModel.getPort());
        update.setWeight(modifyModel.getWeight());
        storageConfigsService.modify(update);
        return JsonResult.createSuccessInstance("修改成功");
    }
}
