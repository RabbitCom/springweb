var params = {},
    index = 0;
var menus = '';
var roleId = '';
var roleName = '';
var description = '';
var rpsetting = {
    "ajax": basePath + "customPermissionController/getCustomMenus.do",
    // "pagekey": "page",
    // "rowskey": "rows",
    // "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function (i, j, d) { //角色名称
            return d.roleName;
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //显示的菜单
            var menuNames = '';
            if (d.menus.length > 0) {
                for (var k = 0; k < d.menus.length; k++) {
                    menuNames += d.menus[k].menuName + ",";
                }
                menuNames = menuNames.substring(0, menuNames.length - 1);
            }
            return '<span class="link-blue-txt permission">' + menuNames + '</span>';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //角色描述
            var des = d.description;
            if(des != null && des != "" && des != undefined && des != "undefined"){
                return des;
            }else {
                return "";
            }
        }
    },{
        "data": "lcall",
        "className": 'commentSet-permission',
        "format": function (i, j, d) { //操作类型
            var menuIds = '';
            if (d.menus.length > 0) {
                for (var k = 0; k < d.menus.length; k++) {
                    menuIds += d.menus[k].menuId + ",";
                }
                menuIds = menuIds.substring(0, menuIds.length - 1);
            }
            var editBtn = '<a href="#modal-permission-edit" data-toggle="modal"  class="ml-10 permission_edit" ' +
                'roleId="' + d.roleId + '" roleName="' + d.roleName + '" description ="' +d.description +
                '" menus-select ="' + menuIds + '">' + LCT("编辑") + '</a>'
            // var editBtn = '<a href="#modal-permission-edit"  class="btn-primary ml-10">' + LCT("编辑") + '</a>';
            var deleteBtn = '<a href="javascript:void(0)" class="permission_del ml-10" roleId="' + d.roleId + '">' + LCT("删除") + '</a>';
            return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' +
                editBtn + deleteBtn + '</p>';
        }
    }],
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function (data) {
        checkall("#maintable"); //table全选
        $("#maintable").on("mouseover", ".commentSet-permission", function () {
            $(this).find("a.handle").hide();
            $(this).find("p").show();
        }).on("mouseout", ".commentSet-permission", function () {
            $(".commentSet-permission a.handle").show();
            $(".commentSet-permission p").hide();
        });
    }
};
var permissionFn = {
    init: function () {
        this.add(); //增加角色
        this.del(); //角色删除
        this.edit(); //编辑返回
    },
    add: function () {
        $("#addSubmit").click(function () {
            roleName = $("[name='roleName']").val();
            description =$("[name='description']").val();
            if (roleName == null || roleName == '') {
                return alertfn.danger("角色不能为空");
            }
            if (tripSpecial(roleName)) {
                return alertfn.danger("角色不能包含特殊字符");
            }
            if (menus == '' || menus == undefined) {
                return alertfn.danger("请至少选择一个菜单");
            }
            $.ajax({
                    type: "post",
                    url: basePath + "customPermissionController/inserCustomPermission.do",
                    data: {
                        "menus": menus,
                        "roleName": roleName ,
                        "description" :description
                    },
                    dataType: "json",
                    success: function (data) {
                        $('#modal-permission-add').modal("hide");
                        $("#maintable").lctable(rpsetting, params);
                        menus = '';
                        roleName = '';
                        description = '';
                        alertfn.success(data.msg);
                    }
                }
            );
        });
        $("#buildedit").click(function () {
            $("[name='roleName']").val("");
            $("[name='description']").val("");
            $.ajax({
                type: "get",
                url: basePath + "customPermissionController/getPermissionMenus.do",
                dataType: "json",
                success: function (data) {
                    var menu_checkbox = '';
                    for (var i = 0; i < data.obj.length; i++) {
                        menu_checkbox += ' <div class="col-md-3" style=" min-width: 150px"><label class="checkbox-inline checkbox-position permission_menus"> ' +
                            '<input type="hidden"  id="' + data.obj[i].menuId + '"/>' + data.obj[i].menuName +
                            '<i class="icon-checkbox"></i></label></div>'
                    }
                    $("#permission-menus").empty();
                    $("#permission-menus").attr("menuId", '0').append(menu_checkbox);
                    $(".permission_menus").click(function (e) {
                        var that = $(this).parent();
                        multiMenus.multi(that); // 选择并改变状态
                        menus = multiMenus.multiValue("permission_menu", ".permission_menus");
                    });
                }
            });
        });

    },
    del: function () {
        $("#maintable").on("click", ".permission_del", function () {
            var $this = $(this);
            var roleId = $this.attr("roleId");
            var params_alert = {
                "title": LCT("删除"),
                "discription": LCT("是否删除该角色"),
                "iconType": "triangle",
                "confirmBtn": true,
                "cancelBtn": true,
                "confirmEvent": function () {
                    $.ajax({
                        type: "get",
                        url: basePath + "customPermissionController/delCustomPermission.do?roleId=" + roleId,
                        dataType: "json",
                        success: function (data) {
                            if (data.success) {
                                alertfn.success(data.msg);
                                lcsetting.thisPage = 1;
                                $("#maintable").lctable(lcsetting, params);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        },
                        error: function () {
                            //console.log("fail");
                        }
                    });
                }
            };
            $("body").toolsalert(params_alert);
            return;
        });
    },
    edit: function () {
        var roleId;
        var menus_select;
        var menus_select_array;
        $("#maintable").on("click", ".permission_edit", function () {
            roleId = $(this).attr("roleId");
            var edit_des = $(this).attr("description");
            if(edit_des != null && edit_des != "" && edit_des != undefined && edit_des != "undefined"){
                $("#description_edit").val(edit_des);
            }else {
                $("#description_edit").val("");
            }
            $("#roleName_edit").val($(this).attr("roleName"));

            menus_select = $(this).attr("menus-select");
            menus_select_array = menus_select.split(",");
            // menus = $(this).attr("id");
            $.ajax({
                type: "get",
                url: basePath + "customPermissionController/getPermissionMenus.do",
                dataType: "json",
                success: function (data) {
                    var menu_checkbox = '';
                    for (var i = 0; i < data.obj.length; i++) {
                        menu_checkbox += ' <div class="col-md-3" style=" min-width: 150px"><label class="checkbox-inline checkbox-position permission_edit_menus"> ' +
                            '<input type="hidden"  id="' + data.obj[i].menuId + '" value="' + data.obj[i].menuName + '"/>' + data.obj[i].menuName +
                            '<i class="icon-checkbox"></i></label></div>'
                    }
                    $("#permission-menus-edit").empty();
                    $("#permission-menus-edit").attr("menuId", '0').append(menu_checkbox);
                    multiMenus.select(menus_select_array, ".permission_edit_menus");
                    $(".permission_edit_menus").click(function (e) {
                        var that = $(this).parent();
                        multiMenus.multi(that); // 选择并改变状态
                        menus_select = multiMenus.multiValue("permission_menu", ".permission_edit_menus");
                    });
                }
            });
        });
        $("#editSubmit").click(function () {
            var roleName_edit = $("#roleName_edit").val();
            if (roleName_edit == null || roleName_edit == '') {
                return alertfn.danger("角色不能为空");
            }
            if (tripSpecial(roleName_edit)) {
                return alertfn.danger("角色不能包含特殊字符");
            }
            if (menus_select == '' || menus_select == undefined) {
                return alertfn.danger("请至少选择一个菜单");
            }
            $.ajax({
                type: "post",
                url: basePath + "customPermissionController/updateCustomPermission.do",
                data: {
                    "roleId": roleId,
                    "menus": menus_select,
                    "roleName": roleName_edit,
                    "description":$("#description_edit").val()
                },
                dataType: "json",
                success: function (data) {
                    // window.location.href = basePath + "customPermissionController/toCustomPermission.do";
                    $('#modal-permission-edit').modal("hide");
                    $("#maintable").lctable(rpsetting, params);
                }
            });
        });
    }
};
$(function () {
    $("#maintable").lctable(rpsetting, params);
    permissionFn.init();
});

function tripSpecial(param) {
    var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");
    if (pattern.test(param)) {
        return true;
    }
    return false;
}