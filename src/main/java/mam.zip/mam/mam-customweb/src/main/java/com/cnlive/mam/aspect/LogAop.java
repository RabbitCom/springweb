package com.cnlive.mam.aspect;

import com.alibaba.fastjson.JSON;
import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.common.log.LogAnnotation;
import com.cnlive.mam.model.OptionLogInfo;
import com.cnlive.mam.service.OptionLogInfoService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * zhangxiaobin
// */
//@Aspect
//@Component
//public class LogAop {
//
//    private final static Logger LOGGER = LoggerFactory.getLogger(LogAop.class);
//
//    @Pointcut(value = "@annotation(com.cnlive.mam.common.log.LogAnnotation)")
//    public void LogAopPointCut() {
//
//    }
//
//    @Resource(name="optionLogInfoService")
//    private OptionLogInfoService optionLogInfoService;
//
//
//    @After(value = "LogAopPointCut()")
//    public void after(JoinPoint pjp) throws Throwable {
//        try{
//            MethodSignature signature = (MethodSignature) pjp.getSignature();
//            LogAnnotation annotation = signature.getMethod().getAnnotation(LogAnnotation.class);
//
//            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
//            Object customId = request.getSession().getAttribute("customId");
////            String queryString = request.getQueryString();
//            if (customId != null) {
//                OptionLogInfo info = new OptionLogInfo();
//                info.setCreateTime(new Date());
//                info.setOptionComent(annotation.message());//+",请求参数：【"+ queryString+"】");
//                info.setOptionType(annotation.type() == null ? OptionType.SELECT : annotation.type());
//                info.setOptionUserId(Long.valueOf(customId.toString()));
//                Object customName = request.getSession().getAttribute("username");
//                info.setOptionUserName(String.valueOf(customName));
//
//                Object spId = request.getSession().getAttribute("spId");
//                if (spId != null) {
//                    info.setSpId(Long.valueOf(spId.toString()));
//                }
//                optionLogInfoService.create(info);
//            }
//        }catch (Exception ex){
//            LOGGER.error("log aspect error,ex={}",ex);
//        }
//
//    }
//}
