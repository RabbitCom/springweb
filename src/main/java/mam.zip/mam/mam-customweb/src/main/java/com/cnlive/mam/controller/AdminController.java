package com.cnlive.mam.controller;

import com.cnlive.mam.condition.AdminCondition;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.service.CustomSpInfoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * Created by zhangxiaobin on 2017/6/6.
 */
@RequestMapping("admin")
@Controller
public class AdminController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(AdminController.class);

    @RequestMapping("manager")
    public String manager(HttpServletRequest request) {
        return checkCustom(request) ? "/admin/admin_spList" : "/error/error";
    }

    @RequestMapping("dataGrid")
    @ResponseBody
    public DataGrid dataGrid(HttpServletRequest request, AdminCondition condition){
        DataGrid dataGrid = new DataGrid();
        if(checkCustom(request)) {
            dataGrid = customSpInfoService.pageSpInfoForAdmin(condition);
        }
        return dataGrid;
    }

}
