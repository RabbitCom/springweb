/**
 * Created by zhangxiaobin on 2017/5/8.
 */
var params = {},
    index = 0;
var lcsetting = {
    "ajax": basePath + "videoController/optionLogDataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) { //视频业务id
            return d.videoId;
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //视频名称
            return d.videoName;
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //操作人
            return d.optionUserName;
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //操作时间
            return d.createTime;
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //操作类型
            function parese(type) {
                if(type == 0){
                    return '<span class="link-blue-txt">' + LCT("查询") + '</span>';
                }
                if(type == 1){
                    return '<span class="link-blue-txt">' + LCT("新增") + '</span>';
                }
                if(type == 2){
                    return '<span class="link-blue-txt">' + LCT("修改") + '</span>';
                }
                if(type == 3){
                    return '<span class="link-blue-txt">' + LCT("删除") + '</span>';
                }
            }
            return parese(d.optionType); //媒资状态
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //备注
            return d.optionComent;
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "..."
};
var logManagerFn = {
    init: function() {
        this.handleTable(); //表格数据筛选
    },
    handleTable: function() {
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".search_select").change(function() {
            $(".btn_search").click();
        });
        $(".btn_search").bind("click", function() {
            var value_id = $.trim($(".search_id").val());
            var value_name = $.trim($(".search_name").val());
            var starTime = $.trim($(".fromtime").val());
            var endTime = $.trim($(".totime").val());
            var optionUserName = $.trim($(".search_optonUser").val());
            var optionType = $.trim($(".search_select option:selected").val());
            if (value_id) {
                params["videoId"] = value_id;
            } else {
                delete params["videoId"];
            }
            if (value_name) {
                params["videoName"] = encodeURIComponent(value_name);
            } else {
                delete params["videoName"];
            }

            if (starTime) {
                params["starTime"] = starTime;
            } else {
                delete params["starTime"];
            }

            if (endTime) {
                params["endTime"] = endTime;
            } else {
                delete params["endTime"];
            }

            if (optionUserName) {
                params["optionUserName"] = optionUserName;
            } else {
                delete params["optionUserName"];
            }

            if (optionType) {
                params["optionType"] = optionType;
            } else {
                delete params["optionType"];
            }


            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
};
$(function() {
    logManagerFn.init();
});
