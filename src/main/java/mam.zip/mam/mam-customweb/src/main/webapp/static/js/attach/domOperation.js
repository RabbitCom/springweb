var category_obj = {},
    params_modal = {},
    uploadIngCount = 0,
    uploadQueArr = [],
    uploadFileList = {};//上传文件列表
uploadFlag = 0;
successFiles = [];
var domOperationFn = {
    init: function () {
        this.remove(); //删除
        this.upload(); //上传
    },

    addFiles: function (fileDetail, element) {
        var lastIndex = fileDetail.file.name.lastIndexOf(".");
        var nameLength = fileDetail.file.name.length;
        var md5 = fileDetail.md5;
        var name = fileDetail.file.name.substring(0, lastIndex);
        var fileSuffix = fileDetail.file.name.substring(lastIndex + 1, nameLength);
        var size = fileDetail.file.size;
        var material_pid = $("#material_pid").val();
        var type = fileDetail.file.type;
        type = type.substring(0, type.lastIndexOf("/"));
        if (type == "video") {
            type = "Media";
        } else if (type == "image") {
            type = "Picture";
        } else {
            type = "File";
        }

        var uploadFileParams = {};//上传文件对应的配置参数
        uploadFileParams["file"] = fileDetail.file;
        uploadFileParams["pid"] = material_pid;
        uploadFileParams["fileSuffix"] = fileSuffix;
        uploadFileParams["type"] = type;
        uploadFileParams["fileSize"] = size;
        uploadFileParams["uploadStatus"] = "0";//待上传
        uploadFileList[md5] = uploadFileParams;

        var addFiles_html = '';
        addFiles_html += '<tr md5="' + md5 + '">';
        //基本信息
        addFiles_html += '<td>';
        addFiles_html += '<p class="videoName" style="text-align: left;">' + LCT("名称：") + name + '</p>';
        addFiles_html += '<p style="text-align: left;">' + LCT("类型：") + type + '</p>';
        // addFiles_html += '<p style="text-align: left">' + LCT("大小：") + formatMb(size) + '</p>';
        addFiles_html += '<p style="text-align: left">' + LCT("大小：") + size + '</p>';
        addFiles_html += '</td>';
        //视频名称
        addFiles_html += '<td><input type="text" class="form-control" id="' + md5 + '_name" videoname="videoName" maxlength="50" value="' + name + '"></td>';
        //上传状态
        addFiles_html += '<td><p uploadStatus="uploadStatus">' + LCT("待上传") + '</p>';
        addFiles_html += '<span id="' + md5 + '_progress"><progress id="' + md5 + '_progressBar" value="0" max="100" style="width: 100%"></progress></span>';
        addFiles_html += '<p id="' + md5 + '_baifenbi" style="display: none;"> </p></td><td>';
        //分类

        if (element == 0) {
            addFiles_html += '<input type="button" id="upload_' + md5 + '" class="uploadItem" style="background:transparent;border:0px;outline: none;" value="' + LCT("上传") + '"><br>';
            addFiles_html += '<input type="hidden" id="upload_Id_' + md5 + '" value="1"/>';
        } else {
            addFiles_html += '<input type="hidden" id="upload_' + md5 + '" class="uploadItem" style="background:transparent;border:0px;outline: none;" value="' + LCT("上传") + '"><br>';
            addFiles_html += '<input type="hidden" id="upload_Id_' + md5 + '" value="0"/>';
        }

        addFiles_html += '<input type="button" id="startOrstop_' + md5 + '" class="startOrstopItem" style="background:transparent;border:0px;outline: none;display: none;" value="' + LCT("暂停") + '"><br>';
        addFiles_html += '<input type="button" id="del_' + md5 + '" class="delItem" style="background:transparent;border:0px;outline: none;" value="' + LCT("删除") + '">';
        addFiles_html += '<input type="hidden" id="vid_' + md5 + '" value=""/>';
        addFiles_html += '<input type="hidden" id="star_state_' + md5 + '" value="0"/>';
        addFiles_html += '<input type="hidden" id="time_' + md5 + '" value=""/>';
        addFiles_html += '<input type="hidden" id="uploadstatus_' + md5 + '" value=""/>';
        addFiles_html += '<input type="hidden" id="uploadId_' + md5 + '" value=""/>';
        addFiles_html += '<input type="hidden" id="vidkey_' + md5 + '" value=""/></td>';

        addFiles_html += '</tr>';
        $("#maintable tbody").append(addFiles_html);
    },
    remove: function () {
        //删除--单个
        $("#maintable").on("click", ".delItem", function () {
            var md5 = $(this).parents("tr").attr("md5");
            var uploadFile = uploadFileList[md5];
            var star_state_ = $("#star_state_" + md5).val();
            var uploadStatus = $("#uploadstatus_" + md5).val();
            var uploadListId = $("#uploadListId_" + md5).val();
            var upload_Id = $("#upload_Id_" + md5).val();
            if (uploadStatus == "1") {
                if (star_state_ == "1" || (upload_Id != '1' && uploadListId == '1')) {

                    var delVal = 0;
                    for (var i = 0; i < successFiles.length; i++) {
                        if (successFiles.length == 1) {
                            uploadFlag = 0;
                        }
                        if (successFiles[i].md5 == md5) {
                            successFiles.splice(i, 1);
                            delVal = i;
                        }
                    }
                    var vId = $("#vid_" + md5).val();
                    delete leFileOperation.fileUploadList[md5];
                    delete uploadFileList[md5];

                    $(this).parents("tr").remove();
                    uploader.removeFile(uploadFile.file);

                    if (successFiles.length > 0 && delVal == 0) {
                        for (var i = 1; i < uploadQueArr.length; i++) {
                            var url = basePath + "fileSourceMaterialController/remove.do";
                            $.post(url, {materialId: vId}, function (data) {
                            });
                        }
                        $("#maintable tbody").html("");
                        for (var i = 0; i < successFiles.length; i++) {
                            domOperationFn.addFiles(successFiles[i], i);
                        }
                        if (uploadQueArr.length > 0) {

                            uploadQueArr.splice(0, uploadQueArr.length)

                        }
                    }

                    var url = basePath + "fileSourceMaterialController/remove.do";

                    $.post(url, {materialId: vId}, function (data) {
                    });
                    if (uploadIngCount > 0) {
                        uploadIngCount--;
                    }
                    if (uploadQueArr.length > 0) {
                        var que_md5 = uploadQueArr.shift();
                        $("#upload_" + que_md5).click();
                        return;
                    }
                    return;
                }
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("文件正在上传,不允许删除"),
                    "iconType": "triangle",
                    "confirmBtn": true //确定按钮显示与否true or fasle
                };
                $("body").toolsalert(params);
                return false;
            } else {
                var delVal = 0;
                for (var i = 0; i < successFiles.length; i++) {
                    if (successFiles.length == 1) {
                        uploadFlag = 0;
                    }
                    if (successFiles[i].md5 == md5) {
                        successFiles.splice(i, 1);
                        delVal = i;
                    }
                }

                if (successFiles.length > 0 && delVal == 0) {
                    $("#maintable tbody").html("");
                    // successFiles.shift();
                    for (var i = 0; i < successFiles.length; i++) {
                        domOperationFn.addFiles(successFiles[i], i);
                    }
                }

                delete leFileOperation.fileUploadList[md5];
                delete uploadFileList[md5];
                $(this).parents("tr").remove();
                uploader.removeFile(uploadFile.file);

                // if(uploadIngCount > 0){
                //     uploadIngCount--;
                // }
                // if(uploadStatus == "3"){
                //     uploadQueArr.remove(md5);
                // }
            }
        });
        //删除--批量
        $("#delMulti").click(function () {

            $("#maintable tbody tr").each(function () {
                var md5 = $(this).attr("md5");
                var uploadFile = uploadFileList[md5];
                var star_state_ = $("#star_state_" + md5).val();
                var uploadStatus = $("#uploadstatus_" + md5).val();
                var uploadListId = $("#uploadListId_" + md5).val();
                var upload_Id = $("#upload_Id_" + md5).val();
                if (uploadStatus == "1") {
                    if (star_state_ == "1" || (upload_Id != '1' && uploadListId == '1')) {
                        var delVal = 0;
                        for (var i = 0; i < successFiles.length; i++) {
                            if (successFiles.length == 1) {
                                uploadFlag = 0;
                            }
                            if (successFiles[i].md5 == md5) {
                                successFiles.splice(i, 1);
                                delVal = i;
                            }
                        }

                        var vId = $("#vid_" + md5).val();
                        delete leFileOperation.fileUploadList[md5];
                        delete uploadFileList[md5];
                        uploader.removeFile(uploadFile.file);
                        if (uploadIngCount > 0) {
                            uploadIngCount--;
                        }

                        if (successFiles.length > 0 && delVal == 0) {
                            $("#maintable tbody").html("");
                            // successFiles.shift();
                            for (var i = 0; i < successFiles.length; i++) {
                                domOperationFn.addFiles(successFiles[i], i);
                            }
                        }
                        $(this).remove();
                        if (uploadQueArr.length > 0) {
                            uploadQueArr.remove(md5);
                        }
                        var url = basePath + "videoController/uploadRemove.do?videoId=" + vId;
                        $.post(url, function (data) {
                        });

                        return;
                    }

                } else { // 队列中
                    var delVal = 0;
                    for (var i = 0; i < successFiles.length; i++) {
                        if (successFiles.length == 1) {
                            uploadFlag = 0;
                        }
                        if (successFiles[i].md5 == md5) {
                            successFiles.splice(i, 1);
                            delVal = i;
                        }
                    }
                    delete leFileOperation.fileUploadList[md5];
                    delete uploadFileList[md5];
                    $("tr[md5='" + md5 + "']").remove();
                    if (uploadIngCount > 0) {
                        uploadIngCount--;
                    }
                    if (uploadStatus == "3") {
                        uploadQueArr.remove(md5);
                    }
                    if (uploadQueArr.length > 0) {
                        uploadQueArr.remove(md5);
                    }
                    if (successFiles.length > 0 && delVal == 0) {
                        $("#maintable tbody").html("");
                        // successFiles.shift();
                        for (var i = 0; i < successFiles.length; i++) {
                            domOperationFn.addFiles(successFiles[i], i);
                        }
                    }
                }
            });
            $("#piLiangAbumlId").val("");
            // $("#logosite_all option[value='0']").prop("selected", true);
            $("#addDataType").attr("data-id", '0');
            $("#addDataType option[data-id='0']").prop("selected", true);
            $("#addDataType_con").html('<select class="form-control"><option>' + LCT("请选择") + '</option></select><select class="form-control ml-3"><option>' + LCT("请选择") + '</option></select>');
        });
    },
    upload: function () {
        console.log("xxx");
        //使用demo
        leFileOperation.init({
            multipleDomElement: [$("#addFiles")[0]], //一次允许选择多个文件，需要传递页面元素对象
            multipleCallback: function (data) {
                return "";
            }, //如果需要额外加什么参数在这里设置如果不需要则 return "";
            // videoUpload_fileList:window.vaasFileUpload.fileUploadList, //上传列表中现有的文件列表//临时需要传递null
            addFileCallback: function (data) {
                var errorFiles = data.errorFiles;
                Array.prototype.push.apply(successFiles, data.successFiles);
                var successFileLists = data.successFiles;

                if (errorFiles.length) {
                    var code_101 = 0,
                        code_102 = 0,
                        code_103 = 0,
                        code_104 = 1,
                        code_105 = 0;
                    var errormsg_html = "";
                    for (var i = 0; i < errorFiles.length; i++) {
                        var code = errorFiles[i].code;
                        if (code == 101) {
                            code_101++;
                        } else if (code == 103) {
                            code_103++;
                        } else if (code == 104) {
                            code_104++;
                        } else if (code == 105) {
                            code_105++;
                        }
                    }
                    if (code_101 > 0) {
                        errormsg_html += LCT("文件大小为零！") + "<br/>";
//                        errormsg_html += LCT("大小为0的文件数量为：") + code_101 + "<br/>";
                    }
                    if (code_103 > 0) {
                        errormsg_html += LCT("文件已在上传列表当中！") + "<br/>";
//                        errormsg_html += LCT("文件已在上传列表当中的数量为：") + code_103 + "<br/>";
                    }
                    if (code_104 > 1) {
                        errormsg_html += LCT("已经存在相同的文件！");
//                        errormsg_html += LCT("相同的文件的数量为：") + code_104;
                    }
                    if (code_105 > 1) {
                        errormsg_html += LCT("名字不合法！");
//                        errormsg_html += LCT("相同的文件的数量为：") + code_104;
                    }
                    var params = {
                        "title": LCT("错误！"),
                        "discription": errormsg_html,
                        "iconType": "text",
                        "confirmBtn": true //确定按钮显示与否true or fasle
                    };
                    $("body").toolsalert(params);
                }

                if (successFiles.length > 0) {
                    uploadFlag++;
                }

                if (successFiles.length && uploadFlag == 1) {
                    $("#maintable tbody").html("");
                    for (var i = 0; i < successFiles.length; i++) {
                        domOperationFn.addFiles(successFiles[i], i);
                    }
                } else {
                    for (var i = 0; i < successFileLists.length; i++) {
                        domOperationFn.addFiles(successFileLists[i], i + 1);
                    }
                }

            } //本次选择文件的回调函数
            // types: "wmv|avi|dat|asf|rm|rmvb|ram|mpg|mpeg|mp4|mov|m4v|mkv|flv|vob|qt|divx|cpk|fli|flc|mod|dvix|dv|f4v|ts"
        });

        $("#maintable").on("click", ".startOrstopItem", function () {
            var md5 = $(this).parents("tr").attr("md5");
            var star_state_ = $("#star_state_" + md5).val();
            if (star_state_ == "0") {
                // $("#uploadstatus_"+md5).val("0");
                uploader.stop();
                $("#star_state_" + md5).val("1");
                $("#startOrstop_" + md5).val(LCT("继续"));
                $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html(LCT("上传暂停")).css({
                    color: "red"
                });
                // uploadFileParams["uploadStatus"] = "-1";
            }
            if (star_state_ == "1") {
                uploader.start();
                // uploadFileParams["uploadStatus"] = "1";
                // $("#uploadstatus_"+md5).val("1");
                $("#star_state_" + md5).val("0");
                $("#startOrstop_" + md5).val(LCT("暂停"));

                $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html('').css({
                    color: "#333"
                });

                // upload2(md5);
            }

        });

        //上传--单个
        $("#maintable").on("click", ".uploadItem", function () {
            // console.log("come in");

            // if(!spInfoInitCheck()){
            //     var params = {
            //         "title": LCT("错误"),
            //         "discription": LCT("请先完善bucket、域名等信息"),
            //         "iconType": "triangle",
            //         "confirmBtn": true //确定按钮显示与否true or fasle
            //     };
            //     $("body").toolsalert(params);
            //     return false;
            // }

            var md5 = $(this).parents("tr").attr("md5");
            var uploadFileParams = uploadFileList[md5];
            if ($("#uploadstatus_" + md5).val() == "1") {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("文件正在上传中......"),
                    "iconType": "triangle",
                    "confirmBtn": true //确定按钮显示与否true or fasle
                };
                $("body").toolsalert(params);
                return false;
            } else {
                var fileName = $(this).parents("tr").find("input[videoname='videoName']").val();
                uploadFileParams["fileName"] = fileName;
                var boo = true;
                if (vrsFn.getStringLen(fileName) < 2 || vrsFn.getStringLen(fileName) > 50) {
                    boo = false;
                }
                if (!boo) {
                    var params = {
                        "title": LCT("错误"),
                        "discription": LCT("视频名称最小长度为2，上限长度为50"),
                        "iconType": "triangle",
                        "confirmBtn": true //确定按钮显示与否true or fasle
                    };
                    $("body").toolsalert(params);
                    $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html(LCT("视频名称格式不正确")).css({
                        color: "red"
                    });
                    return false;
                } else {
                    $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html(LCT("待上传")).css({
                        color: "#333"
                    });
                    uploader.start();
                }

                // uploadFileParams["uploadStatus"] = "1";//上传中
                // $("#uploadstatus_" + md5).val("1");
                // uploadQueArr.push(md5);
                // var material_pid = $("#material_pid").val();
                // uploadFileParams["param"] = "&name=" + fileName + "&md5=" + md5 + "&pid=" + material_pid;
                //
                // $("#upload_" + md5).css("display", "none");
                // qiniuUpload(md5);
            }
        });

        // //上传--批量
        $("#allUpload_Btn").on("click", function () {
            // 每条数据都要加上 leFileOperation.fileUploadList[md5].fileName = "";
            // 全部上传的时候需要对 leFileOperation.fileUploadList[md5].parameter 进行参数传递  如：parameter = "&hsc=1&album=123";
            //parent.window.vaasFileUpload.addFileCallback();
            var tr = $("#maintable tbody tr");
            var md5_arr = [];
            if (tr.length) {
                //校验bucket、域名信息
                // if(!spInfoInitCheck()){
                //     var params = {
                //         "title": LCT("错误"),
                //         "discription": LCT("请完善bucket、域名等信息"),
                //         "iconType": "triangle",
                //         "confirmBtn": true //确定按钮显示与否true or fasle
                //     };
                //     $("body").toolsalert(params);
                //     return;
                // }

                var fileName_arr = [];
                for (var i = 0; i < tr.length; i++) {
                    var md5 = $(tr[i]).attr("md5");
                    var uploadFileParams = uploadFileList[md5];
                    var star_state_ = $("#star_state_" + md5).val();

                    if (star_state_ == "1") {
                        uploader.start();
                        // uploadFileParams["uploadStatus"] = "1";
                        // $("#uploadstatus_"+md5).val("1");
                        $("#star_state_" + md5).val("0");
                        $("#startOrstop_" + md5).val(LCT("暂停"));

                        $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html('').css({
                            color: "#333"
                        });
                    }

                    if ($("#uploadstatus_" + md5).val() == "1" || uploadFileParams["uploadStatus"] == "1" || uploadFileParams["uploadStatus"] == "2") {
                        continue;
                    }
                    var fileName = $(tr[i]).find("input[videoname='videoName']").val();
                    uploadFileParams["fileName"] = fileName;
                    //var reg = /^[\u4e00-\u9fa5 a-zA-Z0-9\•\！\【\】\？\“\”\‘\’\《\》\（\）\，\。\—\*\：\!\[\]\?\"\'\<\>\(\)\,\.\-\_\*\:]{1,50}$/;
                    var boo = true;
                    if (vrsFn.getStringLen(fileName) < 2 || vrsFn.getStringLen(fileName) > 50) {
                        boo = false;
                    }
                    if (!boo) {
                        var params = {
                            "title": LCT("错误"),
                            "discription": LCT("视频名称最小长度为2，上限长度为50"),
                            "iconType": "triangle",
                            "confirmBtn": true //确定按钮显示与否true or fasle
                        };
                        $("body").toolsalert(params);
                        $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html(LCT("视频名称格式不正确")).css({
                            color: "red"
                        });
                        return false;
                    } else {
                        $("tr[md5='" + md5 + "']").find("p[uploadStatus='uploadStatus']").html(LCT("待上传")).css({
                            color: "#333"
                        });
                    }
                    // fileName_arr.push(fileName);
                    //
                    // md5_arr.push(md5);
                    // uploadQueArr.push(md5);
                    // uploadFileParams["uploadStatus"] = "1";//上传中
                    // $("#uploadstatus_" + md5).val("1");
                    // $("#uploadListId_" + md5).val("1");
                    // uploadFileParams["param"] = "&name=" + fileName + "&md5=" + md5;

                }
                // if (unique(fileName_arr).length != fileName_arr.length) {
                //     var params = {
                //         "title": LCT("错误"),
                //         "discription": LCT("当前视频列表中有名称相同的视频"),
                //         "iconType": "triangle",
                //         "confirmBtn": true //确定按钮显示与否true or fasle
                //     };
                //     $("body").toolsalert(params);
                //     return false;
                // } else {
                //     for (var i = 0; i < md5_arr.length; i++) {
                //         var md5 = md5_arr[i];
                //         $("#upload_" + md5).css("display", "none");
                //         qiniuUpload(md5);
                //     }
                // }
                uploader.start();
            } else {
                var params = {
                    "title": LCT("错误"),
                    "discription": LCT("没有要上传的视频"),
                    "iconType": "triangle",
                    "confirmBtn": true //确定按钮显示与否true or fasle
                };
                $("body").toolsalert(params);
                return false;
            }

        });
        $(".back").click(function () {
            if (successFiles.length > 0) {
                var params = {
                    "title": LCT("确定要离开此页？"),
                    "discription": LCT("请确认没有正在上传的视频"),
                    "iconType": "triangle",
                    "confirmBtn": true, //确定按钮显示与否true or fasle
                    "confirmEvent": function () {
                        closeIframeFromInner('refresh')
                    }
                };
                $("body").toolsalert(params);
                return true;
            } else {
                closeIframeFromInner('refresh')
            }
        });
    }
};

$(function () {
    domOperationFn.init();
    // $("#customCategory_con select").removeClass("ml-3");
});
