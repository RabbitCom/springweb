package com.cnlive.mam.task;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.model.VideoDeleteTaskModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.VideoDeleteTaskService;
import com.cnlive.mam.service.VideoService;
@Component
public class VideoDeleteJob extends DeleteResourcePublic{
    private static Logger _log = LoggerFactory.getLogger(VideoDeleteJob.class);
    
    @Resource(name = "videoDeleteTaskService")
    private VideoDeleteTaskService videoDeleteTaskService;

    @Resource(name = "videoService")
    private VideoService videoService;

    @Value("#{configProperties['devMode']}")
    private String devMode;
    
    public void deleteVideo(){
        if (!Boolean.parseBoolean(devMode)) {
            //获取所有彻底删除任务表中信息
            List<VideoDeleteTaskModel> tasks = videoDeleteTaskService.getAll();
            for (VideoDeleteTaskModel task : tasks) {
                deleting(task);
            }
        }
    }

    /**
     *删除任务
      *
     */
    private void deleting(VideoDeleteTaskModel task){
        try{
        	VideoModel video = videoService.getById(task.getVideoId());
        	//删除-1和10的状态
        	if(video != null
					&& (video.getStatus()==null ||
					ModelStatus.Delete.getDbValue() == video.getStatus().getDbValue()  ||
					ModelStatus.New.getDbValue() == video.getStatus().getDbValue() )){

        		boolean deleteFlag = deleteVideo(video);
        		if(deleteFlag){
        			videoDeleteTaskService.delete(task);
        		}
        	}else{
        		videoDeleteTaskService.delete(task.getId());
        		_log.warn("VideoDeleteJob-deleting warn ,video status exception,videoId:"+task.getVideoId());
        	}
        }catch(Exception ex){
        	_log.error("VideoDeleteJob-deleting error ,msg = {}",ex.getMessage());
        }
    }


}
