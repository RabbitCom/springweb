(function(window) {
	window.console || (console = {
		log: function() {},
		dir: function() {},
		error: function() {}
	});
	

	var ver = {
		"header": "other/",
		"header.min": "other/",
		"WdatePicker": "my97DatePicker/",
		"WdatePicker_en": "my97DatePicker/lang/",
		"WdatePicker_zh_tw": "my97DatePicker/lang/",
		"jquery.validate.min": "other/",
		"jquery-page": "other/",
		"icheck": "album/",
		"jquery-form": "album/",
		"jquery.mousewheel": "videoPublish/",
		"jquery.nicescroll": "videoPublish/",
		"jquery.ztree.all.min": "videoPublish/",
		"jquery.jedate": "videoPublish/",
		"album-edit-base": "album/",
		"video-edit-base": "video/",
		"video-manager-list": "video/",
		"album-manager-list": "album/",
		"album-video-manager": "album/",
		"album-video-public": "video/",
		"audit-log": "videoAudit/",
		"audit-manager": "videoAudit/",
		"video-release":"videoPublish/",
		"video-recover":"other/",
		"media-costomCategory": "customCategory/",
		"domOperation": "video/",
		//"_": "lc02_lecloud/201512/30/18/19/"
	};

	var nameArr = ["WdatePicker", "zh_CN.js"];

	window.__loadjs = function(js) {
		var path = js;
		if (nameArr.indexOf(js) > -1) {
			path = js + getLanguage();
		}
		// var time = new Date().getTime();
		document.write('<script type="text/javascript" src="/static/js/' + (ver[path] || ver._).split('|')[0] + js + '.js?v=8171010"></script>');
	};

	function getLanguage() {
		try {
			var l = lctu.getLanguage();
			if (l == "zh_cn") {
				return "";
			} else {
				return "_" + l;
			}
		} catch (e) {
			return "";
		}
	}
	//异步加载js文件，可加回调
	window._loadJs = function(js, callback) {
		var script = document.createElement("script");
		script.type = "text/javascript";
		if (script.readyState) { //IE
			script.onreadystatechange = function() {
				if (script.readyState == "loaded" ||
					script.readyState == "complete") {
					script.onreadystatechange = null;
					if (typeof callback != "undefined") {
						callback();
					}
				}
			};
		} else { //Others: Firefox, Safari, Chrome, and Opera
			script.onload = function() {
				if (typeof callback != "undefined") {
					callback();
				}
			};
		}
		script.src = '/static/js/' + (ver[js] || ver._).split('|')[0] + js + '.js';
		document.body.appendChild(script);
	};
	//异步加载css文件
	window._loadCss = function(css) {
		var cssLink = document.createElement("link");
		cssLink.rel = "stylesheet";
		cssLink.rev = "stylesheet";
		cssLink.type = "text/css";
		cssLink.media = "screen";
		cssLink.href = '/static/css' + (verCss[css] || verCss._).split('|')[0] + css + '.css';
		document.getElementsByTagName("head")[0].appendChild(cssLink);
	};
})(window);