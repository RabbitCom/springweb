package com.cnlive.mam.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.common.enums.VideoSources;
import com.cnlive.mam.common.log.LogAnnotation;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.service.StorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.VideoService;

/**
 * Created by zhangxiaobin on 2017/3/16.
 */
@RequestMapping("playInfo")
@Controller
public class PlayController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(PlayController.class);


    @Resource(name = "fileService")
    private FileService fileService;

    @Value("#{configProperties['xuanchuan_play_url']}")
    private String defaultPlayUrl;

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "storageService")
    private StorageService storageService;

    /**
     * @Title: getDownloadVideo
     * @Description: 视频下载
     * @param: fileId 
     */
    @RequestMapping("getDownloadVideo")
//    @LogAnnotation(message = "操作视频下载",type = OptionType.SELECT)
    public void getDownloadVideo(HttpServletRequest request,String fileId,String vId, HttpServletResponse response){
        Long fileIdLong = CommonUtil.parseNumber("fileId",fileId).longValue();
        Long videoId = CommonUtil.parseNumber("videoId",vId).longValue();
        VideoModel video = videoService.getById(videoId);
        if(video == null){
            return;
        }
        FileModel fileModel = fileService.getById(fileIdLong);

        Integer storageTranscode = fileModel.getStorageTranscode();
        String domain = storageService.getDomainSimpleOutByStorageId(storageTranscode);

        String transCodeFmt = fileModel.getGfmt();
        String fileName= "";
        String downLoadUrl = "";
        fileName = video.getVideoName()+ "." + transCodeFmt;
        downLoadUrl = domain + Const.SEPARATE_XIE +fileModel.getOriginUri();
        if(!StringUtils.isEmpty(downLoadUrl)) {
            int byteread = 0;
            try {
                URL url = new URL(downLoadUrl);
                URLConnection conn = url.openConnection();
                InputStream inStream = conn.getInputStream();
                BufferedInputStream bins = new BufferedInputStream(inStream);// 放到缓冲流里面
                // 清空response
                response.reset();
                // 设置response的Header
                response.setHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(fileName, "UTF-8"));
                response.setContentType("application/x-download");

                OutputStream out = response.getOutputStream();
                BufferedOutputStream bouts = new BufferedOutputStream(out);

                byte[] buffer = new byte[1204];
                while ((byteread = bins.read(buffer)) != -1) {
                    bouts.write(buffer, 0, byteread);
                }
                bouts.flush();
                bins.close();
                inStream.close();
                out.close();
                bouts.close();
            } catch (FileNotFoundException e) {
                _log.error("下载出错,error={}",e);
                e.printStackTrace();
            } catch (IOException e) {
                _log.error("下载出错,error={}",e);
                e.printStackTrace();
            }
        }
    }
}
