package com.cnlive.mam.controller;

import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.JsonResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * Created by cuilongcan on 2017/6/7.
 */
@Controller
@RequestMapping("/excelExport")
public class ExcelExportController {
    @Resource(name = "videoService")
    private VideoService videoService;

    @RequestMapping("/export")
    public String export() {
        return "/excelExport/excelExport";
    }

    @RequestMapping("/getVideoInfos")
    @ResponseBody
    public JsonResult getVideoInfos(HttpServletRequest request, VideoCondition condition) {
        JsonResult result = new JsonResult();
        result.setSuccess(false);
        String startTime = condition.getStartTime();
        String endTime = condition.getEndTime();
        if (StringUtils.isEmpty(startTime) && StringUtils.isEmpty(endTime)) {
            condition = new VideoCondition();
            Date now = new Date();
            condition.setStartTime(CalendarUtil.getDefaultDateString(CalendarUtil.addOrBeforeNDay(now, -30)));
            condition.setEndTime(CalendarUtil.getDefaultDateString(now));
        }
        Object customId = request.getSession().getAttribute("customId");
        condition.setCustomId(Long.valueOf(customId.toString()));
        Long count = videoService.getVideoCountByCondition(condition);
        if (count > 0) {
            result.setObj(condition);
            result.setSuccess(true);
        } else {
            result.setMsg("时间段内未查询到视频信息");
        }
        return result;
    }
}
