package com.cnlive.mam.controller;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.vo.JsonResult;
import com.google.gson.Gson;
import com.ksyun.ks3.dto.CannedAccessControlList;
import com.ksyun.ks3.dto.HeadObjectResult;
import com.ksyun.ks3.dto.ObjectMetadata;
import com.ksyun.ks3.dto.PutObjectResult;
import com.ksyun.ks3.exception.serviceside.NotFoundException;
import com.ksyun.ks3.service.Ks3;
import com.ksyun.ks3.service.request.HeadObjectRequest;
import com.ksyun.ks3.service.request.PutObjectRequest;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 图片上传并截图的控制类
 *
 * @author ZhangXiaoBin
 */
@Controller
@RequestMapping("/uploadController")
public class UploadController extends BaseController {

	private static Logger _log = LoggerFactory.getLogger(UploadController.class);

	@Value("#{configProperties['upload_root']}")
	private String upload_root;

	/**
	 * 图片素材上传并上传至图床返回一个图片地址
	 *
	 * @param request
	 */
	@RequestMapping({ "/uploadPicSource" })
	@ResponseBody
	public JsonResult uploadPicSource(String uploadType, HttpServletRequest request, HttpServletResponse response) {
		_log.info("start upload img time :  {}", CalendarUtil.getDefaultDateString(new Date()));
		response.setHeader("Access-Control-Allow-Origin", "*");
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		MultipartFile multipartFile = multipartRequest.getFile("myfile");
		
		if (multipartFile != null) {
			try {
				String errorMsg = null;
				// 验证图片的宽高比
				if (!"logo".equals(uploadType)) {
					this.validatePicSize(multipartFile.getInputStream(), request.getParameter("scale"));
				}

				if (StringUtils.isNotBlank(errorMsg)) {
					return JsonResult.createErrorInstance(errorMsg);
				} else {
					Map<String, Object> map = new HashMap<String, Object>();
					// 获取图片后缀名
					String resultSuffix = "";
					String originalFileName = multipartFile.getOriginalFilename();
					if (!StringUtils.isBlank(originalFileName)) {
						int start = originalFileName.lastIndexOf(Const.VALUE_POINT);
						start = start == -1 ? 0 : start;
						String suffix = originalFileName.substring(start, originalFileName.length());
						resultSuffix = suffix.startsWith(Const.VALUE_POINT) ? suffix : Const.VALUE_POINT + suffix;
					}
					resultSuffix = StringUtils.isBlank(resultSuffix) ? Const.SUFFIX_PIC_CDN : resultSuffix;

					Long customId = this.getCustomId(request);
					CustomModel model = customService.getById(customId);
					Long spId = model.getSpId();

					StorageModel outImgStorage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Picture);
					String imgDomain = storageService.getDomainSimpleOutByStorageId(outImgStorage.getId());
					String bucketName = outImgStorage.getName();
					String location = "";

					if (StringUtils.isBlank(bucketName)) {
						return JsonResult.createErrorInstance(("未设置 bucket "));
					}

					if (StringUtils.isBlank(imgDomain)) {
						return JsonResult.createErrorInstance(("未设置图片展示域名"));
					}
					
					// 存储路径 格式 spid/img/yyyy/mmdd/
					String uploadRealPathDir = getUploadImgPath(model.getSpId());
					String localUploadFilePath = uploadRealPathDir + spId + Const.XIA_HUA_XIAN + CalendarUtil
							.getDateString(Calendar.getInstance(), CalendarUtil.SIMPLE_DATE_FORMAT_NO_DASH)
							+ resultSuffix;
					String result = "";//图片访问路径
					 
					if (StorageTypeEnum.QINIUYUN==outImgStorage.getType()) {//七牛
						Configuration cfg = new Configuration(Zone.zone1());
						UploadManager uploadManager = new UploadManager(cfg);
						bucketName = outImgStorage.getName();
						String upToken = getTokenForQN(bucketName);
						byte[] bytes = multipartFile.getBytes();
						Response response1 = uploadManager.put(bytes, localUploadFilePath, upToken);
						DefaultPutRet putRet = new Gson().fromJson(response1.bodyString(), DefaultPutRet.class);
						result = imgDomain+Const.SEPARATE_XIE+localUploadFilePath;
					} else {
						//金山图片上传
						Ks3 client = getKs3Client();
						client.setEndpoint(uploadImgRegion);
						ObjectMetadata meta = new ObjectMetadata();
						PutObjectRequest request1 = new PutObjectRequest(bucketName, localUploadFilePath,
								new ByteArrayInputStream(multipartFile.getBytes()), meta);
						// 上传一个公开文件
						request1.setCannedAcl(CannedAccessControlList.PublicRead);
						PutObjectResult putObject = client.putObject(request1);
						try {
							HeadObjectRequest request2 = new HeadObjectRequest(bucketName, localUploadFilePath);
							HeadObjectResult h = client.headObject(request2);
							ObjectMetadata matedata = h.getObjectMetadata();
						} catch (NotFoundException e) {
							return JsonResult.createErrorInstance(("图片生成错误！"));
						}
						result = imgDomain + Const.SEPARATE_XIE + localUploadFilePath;
						_log.info("end upload img time: {}", CalendarUtil.getDefaultDateString(new Date()));
					}
					map.put("pic_fineshed", result);
					JsonResult jsonResult = JsonResult.createSuccessInstance(map);
					return jsonResult;
				}
			} catch (Exception e) {
				_log.error("上传图片报错，uploadPicSource", e);
				return JsonResult.createErrorInstance(("图片生成错误！"));
			}
		} else {
			return JsonResult.createErrorInstance(("未获取到上传的文件,请稍后重试!"));
		}
	}


	/**
	 * 富文本图片上传
	 *
	 * @param request
	 */
	@RequestMapping({"/uploadPicForEdit"})
    @ResponseBody
    public Map uploadPicForEdit(HttpServletRequest request, HttpServletResponse response) {
        _log.info("start upload img time :  {}", CalendarUtil.getDefaultDateString(new Date()));
        response.setHeader("Access-Control-Allow-Origin", "*");
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        Map<String, String> resultMap = new HashedMap();
        resultMap.put("state", "FAILURE");
        if (multipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile multipartFile = multipartRequest.getFile("myfile");
            if (multipartFile != null) {
                try {
                    // 获取图片后缀名
                    String resultSuffix = "";
                    String originalFileName = multipartFile.getOriginalFilename();
                    if (!StringUtils.isBlank(originalFileName)) {
                        int start = originalFileName.lastIndexOf(Const.VALUE_POINT);
                        start = start == -1 ? 0 : start;
                        String suffix = originalFileName.substring(start, originalFileName.length());
                        resultSuffix = suffix.startsWith(Const.VALUE_POINT) ? suffix : Const.VALUE_POINT + suffix;
                    }
                    resultSuffix = StringUtils.isBlank(resultSuffix) ? Const.SUFFIX_PIC_CDN : resultSuffix;

                    Long customId = this.getCustomId(request);
                    CustomModel model = customService.getById(customId);
                    Long spId = model.getSpId();

                    StorageModel outImgStorage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Picture);
                    String imgDomain = storageService.getDomainSimpleOutByStorageId(outImgStorage.getId());
                    String bucketName = outImgStorage.getName();
                    if (StringUtils.isBlank(bucketName)) {
                        return resultMap;
                    }
                    if (StringUtils.isBlank(imgDomain)) {
                        return resultMap;
                    }
                    // 存储路径 格式 spid/img/yyyy/mmdd/
                    String uploadRealPathDir = getUploadImgPath(model.getSpId());
                    String localUploadFilePath = uploadRealPathDir + spId + Const.XIA_HUA_XIAN + CalendarUtil
                            .getDateString(Calendar.getInstance(), CalendarUtil.SIMPLE_DATE_FORMAT_NO_DASH)
                            + resultSuffix;
                    String result = "";//图片访问路径

                    if (StorageTypeEnum.QINIUYUN == outImgStorage.getType()) {//七牛
                        Configuration cfg = new Configuration(Zone.zone1());
                        UploadManager uploadManager = new UploadManager(cfg);
                        bucketName = outImgStorage.getName();
                        String upToken = getTokenForQN(bucketName);
                        byte[] bytes = multipartFile.getBytes();
                        Response response1 = uploadManager.put(bytes, localUploadFilePath, upToken);
                        DefaultPutRet putRet = new Gson().fromJson(response1.bodyString(), DefaultPutRet.class);
                        result = imgDomain + Const.SEPARATE_XIE + localUploadFilePath;
                    } else {
                        //金山图片上传
                        Ks3 client = getKs3Client();
                        client.setEndpoint(uploadImgRegion);
                        ObjectMetadata meta = new ObjectMetadata();
                        PutObjectRequest request1 = new PutObjectRequest(bucketName, localUploadFilePath,
                                new ByteArrayInputStream(multipartFile.getBytes()), meta);
                        // 上传一个公开文件
                        request1.setCannedAcl(CannedAccessControlList.PublicRead);
						PutObjectResult putObject = client.putObject(request1);
						try {
							HeadObjectRequest request2 = new HeadObjectRequest(bucketName, localUploadFilePath);
							HeadObjectResult h = client.headObject(request2);
							ObjectMetadata matedata = h.getObjectMetadata();
						} catch (NotFoundException e) {
							_log.error("ks upload img error {}",e);
							e.printStackTrace();
						}
						result = imgDomain + Const.SEPARATE_XIE + localUploadFilePath;
					}
					_log.info("end upload img time: {}", CalendarUtil.getDefaultDateString(new Date()));
					resultMap.put("state", "SUCCESS");
                    resultMap.put("url", result);
                } catch (Exception e) {
                    _log.error("上传图片报错，uploadPicSource", e);
                }
            } else {
                return resultMap;
            }
            return resultMap;
        }
        return resultMap;
    }

	/**
	 * @param @param
	 *            originalWight
	 * @param @param
	 *            originalHeight
	 * @throws IOException
	 *             验证图片大小
	 * @Title: validatePicSize
	 */
	private String validatePicSize(InputStream input, String scale) throws IOException {

		String[] scales = scale.split("\\*");

		Integer scale_wight = Integer.parseInt(scales[0]);
		Integer scale_height = Integer.parseInt(scales[1]);

		BufferedImage inputBufImage = ImageIO.read(input);
		int originalWight = inputBufImage.getWidth();
		int originalHeight = inputBufImage.getHeight();
		StringBuilder errMsg = new StringBuilder();
		if (originalWight < scale_wight) {
			errMsg.append(("宽度不能小于") + scale_wight + "！");

		}
		if (originalHeight < scale_height) {
			errMsg.append(("高度不能小于") + scale_height + "！");
		}
		return errMsg.toString();
	}

	private boolean deleteFile(File file) {
		// 路径为文件且不为空则进行删除
		if (file.isFile() && file.exists()) {
			file.getAbsoluteFile().delete();
			return true;
		}
		return false;
	}
}
