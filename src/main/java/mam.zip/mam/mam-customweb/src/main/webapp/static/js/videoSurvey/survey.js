option_char = {
    backgroundColor: '#ECF2F9',
    title: {
        // text: 'Customized Pie',
        left: 'center',
        top: 20,
        textStyle: {
            color: '#1E08CC'
        }
    },
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
    }
};
var countAll = {
    init : function () {
        $.ajax({
            url: basePath + "surveyController/surveyCount.do",
            type: "post",
            dataType: "json",
            success: function(data) {
                if (data.success) {
                    var resultMap = data.obj;
                    $("#uploadCount").text(resultMap.uploadCount);
                    $("#onLineCount").text(resultMap.onLineCount);
                    $("#publishCount").text(resultMap.publishCount);
                    $("#albumCount").text(resultMap.albumCount);
                    $("#pvCount").text(resultMap.pvCount);
                }
            }
        });
    }
};
var pie_chart = {
    init: function () {
        var chart = echarts.init(document.getElementById('main-chart'));
        $.post(basePath + "surveyController/surveyChart.do", function (count) {
            var Series = {
                name: '类型',
                type: 'pie',
                radius: '55%',
                data: [].sort(function (a, b) {
                    return a.value - b.value;
                }),
                // roseType: 'radius',
                label: {
                    normal: {
                        formatter:'{b}: {c}'
                    }
                },
                labelLine: {
                    normal: {
                        smooth: 0.2,
                        length: 10,
                        length2: 20
                    }
                },

                animationType: 'scale',
                animationEasing: 'elasticOut',
                animationDelay: function (idx) {
                    return Math.random() * 200;
                }
            };
            var result = eval('(' + count + ')');
            var obj = result.obj;
            for (var i = 0; i < obj.length; i++) {
                Series.data.push(obj[i]);
            }
            option_char.series = Series; // 设置图表series
            chart.setOption(option_char);// 重新加载图表
        });
    }
};
var line_chart = {
    init: function () {

        //基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));

        // 指定图表的配置项和数据
        option = {
            backgroundColor: '#ECF2F9',
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: []
            },
            grid: {
                left: '4%',
                right: '6%',
                top:'10%',
                bottom: '5%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    dataView: {show: true, readOnly: false},
                    restore: {show: true},
                    saveAsImage: {show: true}
                }
            },
            smooth: true,
            xAxis: {
                name: '日期',
                type: 'category',
                boundaryGap: false,
                data: []
            },
            yAxis: {
                name: '数量/次',
                type: 'value'
            },
            series: []
        };

        $.post(basePath + "surveyController/surveyLineCount.do", function (count) {
            var Item = function () {
                return {
                    name: '',
                    type: 'line',
                    data: []
                }
            };
            var legends = [];
            var Series = [];
            var jsons = eval('(' + count + ')');
            var json = jsons.obj.jsonList;
            for (var i = 0; i < json.length; i++) {
                var it = new Item();
                it.name = json[i].name;
                legends.push(json[i].name);
                it.data = json[i].data;
                Series.push(it);
            }
            option.xAxis.data = jsons.obj.dataTime;
            option.legend.data = legends;
            option.series = Series; // 设置图表series
            myChart.setOption(option);// 重新加载图表
        });
        //      初次加载图表(无数据)
        myChart.setOption(option);
    }
};
$(function () {
    countAll.init();
    pie_chart.init();
    line_chart.init();
});