function initPager(pageNum,pageTotal){
    var dom = $(".page-main");
    var html = "";
    dom.empty();
    if(pageNum>pageTotal){
        return;
    }

    if(pageNum != 1){
        html += "<a class='prev' href='#'><i class='ui-page-prev'></i></a>";
    }

    if(pageTotal<7){
        for(var i=0;i<pageTotal;i++){
            var j = i+1;
            html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
        }
    }else if(pageTotal<10){
        if(pageNum<7){
            for(var i=0;i<pageNum;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            var k = pageNum+4<pageTotal?pageNum+4:pageTotal;
            for(var i=pageNum;i<k;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            if(k+1<pageTotal){
                html += "<span>......</span><a href='#' data-page='"+pageTotal+"'>"+pageTotal+"</a>";
            }
            if(k+1==pageTotal){
                html += "<a href='#' data-page='"+pageTotal+"'>"+pageTotal+"</a>";
            }
            
        }else{
            html += "<a href='#' data-page='1'>1</a><span>......</span>";
            for(var i=pageNum-5;i<pageTotal;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
        }
    }else{
        if(pageNum<7){
            for(var i=0;i<pageNum;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            var k = pageNum+4<pageTotal?pageNum+4:pageTotal;
            for(var i=pageNum;i<k;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            if(k+1<pageTotal){
                html += "<span>......</span><a href='#' data-page='"+pageTotal+"'>"+pageTotal+"</a>";
            }
            if(k+1==pageTotal){
                html += "<a href='#' data-page='"+pageTotal+"'>"+pageTotal+"</a>";
            }
        }else if(pageNum+5<pageTotal){
            html += "<a href='#' data-page='1'>1</a><span>......</span>";
            for(var i=pageNum-5;i<pageNum;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            for(var i=pageNum;i<pageNum+4;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            html += "<span>......</span><a href='#' data-page='"+pageTotal+"'>"+pageTotal+"</a>";
        }else{
            html += "<a href='#' data-page='1'>1</a><span>......</span>";
            for(var i=pageNum-5;i<pageNum;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
            for(var i=pageNum;i<pageTotal;i++){
                var j = i+1;
                html += "<a href='#' data-page='"+j+"'>"+j+"</a>";
            }
        }
    }
    if(pageNum != pageTotal){
        html += "<a class='next' href='#'><i class='ui-page-next'></i></a>";
    }
    dom.append(html);
    $("a[data-page='"+pageNum+"']").addClass("active");
}