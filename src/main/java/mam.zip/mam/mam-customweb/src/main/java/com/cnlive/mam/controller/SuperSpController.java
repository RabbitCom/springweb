package com.cnlive.mam.controller;

import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.common.enums.VideoSources;
import com.cnlive.mam.common.exception.ValidateException;
import com.cnlive.mam.common.log.LogAnnotation;
import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.model.*;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.PublishHistoryService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ReleaseObj;
import com.fasterxml.jackson.databind.deser.Deserializers;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin on 2017/3/31.
 */
@RequestMapping("super")
@Controller
public class SuperSpController extends BaseController {


    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "publishHistoryService")
    private PublishHistoryService publishHistoryService;

    @RequestMapping("/manager")
    public String toVideoSp(HttpServletRequest request, Model model) {
        return checkCustom(request) ? "/superSP/superSp_video" : "/error/error";
    }

    @RequestMapping("dataGrid")
    @ResponseBody
//    @LogAnnotation(message = "superSP查询视频列表信息",type = OptionType.SELECT)
    public DataGrid dataGrid(HttpServletRequest request,SuperSpCondition condition){
        DataGrid dataGrid = new DataGrid();
        if(checkCustom(request)) {
//            condition.setSort("videoId");
            if (StringUtils.isNotBlank(condition.getOnoffStatus())) {
                condition.setOnoffStatusArray(condition.getOnoffStatus().split(","));
                condition.setOnoffStatus(null);
            }
            if (condition.getCategory() != null) {
                if ("0".equals(condition.getCategory().toString())) {
                    condition.setCategory(null);
                }
            }
            condition.setSpAdmin(Const.IS_PARENT_YES);
            dataGrid = videoService.getPageByCondition(condition);
        }
        return dataGrid;
    }

    /**
     * @Description: 跳转到视频编辑页面
     */
    @RequestMapping("/viewVideo")
    public String toVideoEdit(HttpServletRequest request, Long videoId, String editCategory, Model model) {

        // 扩展属性存放
        List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();
        if (videoId != null) {
            VideoModel video = videoService.getById(videoId);
            video = super.unescapeHtmlStr(video);
            request.setAttribute("video", video);
            if (StringUtils.isNotEmpty(editCategory)) {
                video.setVideoType(null);
                video.setSubCategory(null);
                video.setLanguage(null);
                video.setArea(null);
                video.setExtendProperties(null);
            }
            Integer category = StringUtils.isEmpty(editCategory) ? video.getCategory() : Integer.parseInt(editCategory);
            super.setRequestPublicInfo(request, category);
            showPropertyList = super.getPropertyList(0, video, null, category);
            request.setAttribute("videoMmsType", video.returnMmsType().getCode());
            request.setAttribute("showPropertyList", showPropertyList);
            request.setAttribute("picFinished", videoService.returnLayerPicAllpicScale(video.getPicOriginal(),video.getPicFinishedImg(),video.getStorageImgId()));

        }
        return "/superSP/supersp_video_view";
    }

    /**
     * @Description: 获取视频转码信息
     */
    @RequestMapping("/getTranCodeInfos")
    @ResponseBody
    public JsonResult getTranCodeInfos(String videoId, HttpServletRequest request) {
        Long vid = CommonUtil.parseNumber("videoId",videoId).longValue();
        List<FileModel> fileModels = fileService.getByVid(vid);
        if(fileModels == null || fileModels.size() <=0){
            return JsonResult.createErrorInstance("暂无数据！");
        }
        VideoModel videoModel = videoService.getById(vid);
        Long spid = videoModel.getSpid();
        for (FileModel fileModel : fileModels){
            fileModel.setCodeRateName(DefinitionEnum.getShowName(fileModel.getCodeRate()));
            Integer storageTranscode = fileModel.getStorageTranscode();
            String playStr = "";
            String domain = "";
            if(StringUtils.isEmpty(domain)) {
                domain = storageService.getDomainSimpleOutByStorageId(storageTranscode);
            }
            // 判断是否为从老媒资同步过来的数据
            if (videoModel.getIsIcms2Mam() == null || VideoSources.mam == videoModel.getIsIcms2Mam()) {
				playStr = domain + Const.SEPARATE_XIE + fileModel.getStoreUri();
			} else {
				playStr = fileModel.getStoreUri();
			}
            fileModel.setStoreUriDomain(playStr);
        }
        return JsonResult.createSuccessInstance(fileModels);
    }

    /**
     * @Description:视频查看
     */
    @RequestMapping("/getPublishFailMsg")
    @ResponseBody
    public JsonResult getPublishFailMsg(HttpServletRequest request,Long videoId) {
        if(videoId == null){
            return JsonResult.createErrorInstance("查询参数缺失！");
        }
        try{
            String description="";
            PublishHistory publishHistory = publishHistoryService.selectByVideoId(videoId);
            if(publishHistory!=null && StringUtils.isNotBlank(publishHistory.getDescription())){
                description=publishHistory.getDescription();
            }
            return JsonResult.createSuccessInstance("success", description);
        } catch (Exception e) {
            return JsonResult.createErrorInstance("请求失败");
        }
    }

}
