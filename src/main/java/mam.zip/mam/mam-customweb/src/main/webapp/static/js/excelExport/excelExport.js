function calcDate(date, range, type) {
    var strDate = date.getDate();
    var month = date.getMonth();
    if (range != 0) {
        switch (type) {
            case "day":
                strDate = strDate - range;
                date.setDate(strDate);
                break;
            case "week":
                strDate = strDate - range * 7;
                date.setDate(strDate);
                break;
            case "month":
                month = month - range;
                date.setMonth(month);
                break;
            default:
                break;
        }
    }
    return date;
}
var excelFn = {
    init: function () {
        this.export();
        this.selectTime();
    },
    selectTime: function () {
        $(".btn-query").click(function () {
            var range = $(this).attr("data-time");
            var strs = new Array();
            strs = range.split("_");
            var fromtime = calcDate(new Date(), strs[1], strs[0])
            $("#d4311-result").val(formatDateL(fromtime));
            $("#d4312-result").val(formatDateL(new Date()));
        });
    },
    export: function () {
        checkall("#modal-excel"); //excel全选
        $("#btn-excel").on("click", function () {
            var startTime = $("#d4311-result").val();
            var endTime = $("#d4312-result").val();
            $.post(basePath + 'excelExport/getVideoInfos.do', {
                startTime: startTime,
                endTime: endTime
            }, function (data) {
                if (data.success) {
                    var arr_hearders = [];
                    var hearders = $("#modal-excel label");
                    var arr_fields = [];
                    var checkbox = $("#modal-excel input:checkbox");
                    if (startTime == "" && endTime == "") {
                        alertfn.success(LCT("默认导出一个月视频信息"));
                    }
                    for (var i = 1; i < checkbox.length; i++) {
                        if (checkbox[i].checked) {
                            arr_hearders.push($(checkbox[i]).closest("label").text());
                            arr_fields.push($(checkbox[i]).val());
                        }
                    }
                    if (arr_hearders.length == 0) {
                        alertfn.danger(LCT("未选择任何excel导出项"));
                    } else {
                        var url = basePath + "exportExcelVideo.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                        if (data.obj != null) {
                            url += "&startTime=" + data.obj.startTime + "&endTime=" + data.obj.endTime;
                        }
                        window.open(url, "_blank");
                    }
                } else {
                    alertfn.danger(LCT(data.msg));
                }
            }, 'json');
        });
    }
};
$(function () {
    excelFn.init();
});