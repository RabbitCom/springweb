package com.cnlive.mam.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.StatService;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.SurveyLineData;
import com.cnlive.mam.vo.SurveyLineDataList;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

/**
 * author zhengChao
 */
@Controller
@RequestMapping("/surveyController")
public class VideoSurveyController extends BaseController {
    private static Logger _log = LoggerFactory.getLogger(VideoSurveyController.class);

    @Resource(name = "statService")
    private StatService statService;

    @Value("#{configProperties['vv_count_url']}")
    private String vvCount;

    /**
     * @Description:跳转到点播概况页面(统计)
     */
    @RequestMapping("/survey")
    public ModelAndView survey(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("/videoSurvey/survey");
        return mv;
    }

    @RequestMapping("/surveyCount")
    @ResponseBody
    public JsonResult surveyCount(HttpServletRequest request) {
        Map<String, Long> map = new HashMap<String, Long>();
        ModelAndView mv = new ModelAndView();
        //判断当前登录用户是spId 还是customId
        Long spId = super.getSpId(request);
        String jigouId = super.getInstitutionId(request);
        boolean isSpAdmin = checkIsSpAdmin(request);
        VideoCondition videoCondition = new VideoCondition();
        videoCondition.setSpid(spId);
        videoCondition.setCreateTime(CalendarUtil.getDayBegin());
        videoCondition.setInstitutionId(jigouId);
        videoCondition.setSpAdmin(isSpAdmin ? Const.IS_PARENT_YES : Const.IS_PARENT_NO);

        try {
            String res = HttpClientUtils.get(vvCount + "?spId=" + spId, HttpClientUtils.UTF_8);
            JSONObject resultObject = JSON.parseObject(res);
            if(resultObject.containsKey("vv")){
                map.put("pvCount",resultObject.getLongValue("vv"));//对接数据统计
            }else {
                map.put("pvCount", 0L);//对接数据统计
            }
        } catch (IOException e) {
            map.put("pvCount",0L);//对接数据统计
            _log.error("获取vv数据异常，ex={}",e);
        }

        List<Map<String, Object>> countGroupByStatus = statService.getCountGroupByStatus(videoCondition);
        Long uploadCount = 0L,onlineCount=0L,publishCount = 0L;
        for(Map<String,Object> countMap : countGroupByStatus){
            Long status = Long.parseLong(countMap.get("status").toString());
            Long count = Long.parseLong(countMap.get("cvt").toString());
            if(ModelStatus.New.getDbValue() == status.intValue() || ModelStatus.Delete.getDbValue() == status.intValue())continue;
            uploadCount = count + uploadCount;
            if(ModelStatus.ReleaseSuccess.getDbValue() == status.intValue() || ModelStatus.ReleaseFail.getDbValue() == status.intValue()){
                publishCount = count+publishCount;
                onlineCount = count + onlineCount;
            }
            if(ModelStatus.OnLine.getDbValue() == status.intValue()){
                onlineCount = count + onlineCount;
            }
        }
        map.put("uploadCount", uploadCount);
        map.put("publishCount", publishCount);
        map.put("onLineCount", onlineCount);
        map.put("albumCount",statService.countAlbumBySpId(spId,jigouId,isSpAdmin));

        return JsonResult.createSuccessInstance(map);
    }

    @RequestMapping("/surveyLineCount")
    @ResponseBody
    public JsonResult videoSurveyLineCount(HttpServletRequest request) {
        Map<String, Long> map1 = null;
        Map<String, Long> map2 = null;
        Map<String, Long> map3 = null;
        //判断当前登录用户是spId 还是customId
        String parentId = super.getParentId(request);
        Long spId = super.getSpId(request);
        String jigouId = super.getInstitutionId(request);
        boolean isSpAdmin = checkIsSpAdmin(request);
        map1 = statService.count7DayPublishFailureVideoBySpId(spId,jigouId,isSpAdmin);
        map2 = statService.count7DayPublishSucceedVideoBySpId(spId,jigouId,isSpAdmin);
        map3 = statService.count7DayUploadVideoBySpId(spId,jigouId,isSpAdmin);

        JSONArray arrayUpload = new JSONArray();
        JSONArray arraypublishSucceed = new JSONArray();
        JSONArray arraypublishFailure = new JSONArray();

        List list = get7Days();

        for (int i = 0; i < list.size(); i++) {
            Long count1 = map1.get(list.get(i));
            Long count2 = map2.get(list.get(i));
            Long count3 = map3.get(list.get(i));
            arraypublishFailure.add(count1);
            arraypublishSucceed.add(count2);
            arrayUpload.add(count3);
        }

        SurveyLineData json1 = new SurveyLineData();
        json1.setName("上传视频总量");
        json1.setData(arrayUpload);

        SurveyLineData json2 = new SurveyLineData();
        json2.setName("发布成功量");
        json2.setData(arraypublishSucceed);

        SurveyLineData json3 = new SurveyLineData();
        json3.setName("发布失败量");
        json3.setData(arraypublishFailure);

        List listCount = new ArrayList();
        listCount.add(json3);
        listCount.add(json2);
        listCount.add(json1);

        SurveyLineDataList jsonList = new SurveyLineDataList();
        jsonList.setDataTime(list);
        jsonList.setJsonList(listCount);

        return JsonResult.createSuccessInstance(jsonList);
    }

    @RequestMapping("/surveyChart")
    @ResponseBody
    public JsonResult surveyChart(HttpServletRequest request) {
        List<Map<String, Object>> resultList = new ArrayList<>();
        boolean isSpAdmin = checkIsSpAdmin(request);
        Long spId = super.getSpId(request);
        List<Map<String,Object>> categoryCountBySpId = statService.getCountGroupByCategory(spId, getInstitutionId(request), isSpAdmin);
        List<Dictionary> categorys = dictionaryService.getCategorys();
        for(Dictionary dic : categorys){
            Map<String, Object> resultMap = new HashedMap();
            Integer dicValue = dic.getDicValue();
            resultMap.put("name", dic.getShowName());
            resultMap.put("value", 0);
            if(categoryCountBySpId!=null && categoryCountBySpId.size()>0){
                for(Map<String,Object> countMap : categoryCountBySpId){
                    Integer categoryValue = Integer.parseInt(String.valueOf(countMap.get("category")));
                    if(categoryValue.intValue() == 0)continue;
                    if(dicValue.intValue() == categoryValue.intValue()){
                        resultMap.put("value", countMap.get("cvt"));
                        break;
                    }
                }
            }
            resultList.add(resultMap);
        }
        return JsonResult.createSuccessInstance(resultList);
    }

    //获取当前时间的前7天日期(包含当天)
    private List get7Days() {
        List list = new ArrayList<>();
        Date nowDate = new Date();
        for (int i = 0; i < 7; i++) {
            String dateStr = CalendarUtil.getShortDateString(CalendarUtil.addOrBeforeNDay(nowDate, -1 * i));
            list.add(dateStr);
        }
        Collections.sort(list);
        return list;
    }
}

