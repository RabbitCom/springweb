package com.cnlive.mam.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.common.log.LogAnnotation;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.OptionLogInfo;
import com.cnlive.mam.service.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.VideoRemoveCondition;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.model.VideoRemoveModel;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Splitter;

/**
 * Created by zhangxiaobin
 * 
 */
@Controller
@RequestMapping("/videoRecycleController")
public class VideoRecycleController extends BaseController
{

    private static Logger _log = LoggerFactory.getLogger(VideoRecycleController.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "videoRemoveService")
    private VideoRemoveService videoRemoveService;

    @Resource(name="optionLogInfoService")
    private OptionLogInfoService optionLogInfoService;
    /**
     * @Description:跳转到视频回收站页面
     */
    @RequestMapping("/manager")
    public String manager(HttpServletRequest request, Model model) {
        return "/videoRecycle/videoRecycle";
    }
    
    /**
     * @Description: 分页查询视频数据
     */
    @RequestMapping("/dataGrid")
    @ResponseBody
//    @LogAnnotation(message = "分页查询视频删除列表",type = OptionType.SELECT)
    public DataGrid dataGrid(HttpServletRequest request, VideoRemoveCondition video) throws Exception {
        DataGrid dg = new DataGrid();
        try {

            JsonResult result = this.checkCustomerExist(request);
            if(result.isSuccess()){
                CustomModel customModel = (CustomModel)result.getObj();
                video.setRemoveSpId(customModel.getSpId());
                return videoRemoveService.pageRemoveVideo(video);
            }else {
                return dg;
            }
        } catch (Exception e) {
            _log.error("查询出错，ex= {}",e.getMessage());
        }
        return dg;
    }

    /**
     * 根据视频回收表id，恢复视频数据
     * @Description: 视频恢复(支持批量操作)
     * @param: videoIds 视频回收表id字符串，多个时逗号分隔
     */
    @RequestMapping("/reinState")
    @ResponseBody
//    @LogAnnotation(message = "恢复删除的视频",type = OptionType.UPDATE)
    public JsonResult reinState(HttpServletRequest request, String videoIds, HttpServletResponse response) throws Exception {
    	JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);

        JsonResult checkCustomerExist = this.checkCustomerExist(request);
        if(!checkCustomerExist.isSuccess()){
            return JsonResult.createErrorInstance("用户认证失败！");
        }
        CustomModel customModel = (CustomModel)checkCustomerExist.getObj();

        String[] videoRemoveIdArray = videoIds.split(Const.VALUE_DECOLLATOR);
         List<Long> errorVideoList = new ArrayList<>();
         Long videoRemoveId = 0L;
         //循环恢复视频数据
         for (String videoRemoveIdStr : videoRemoveIdArray) {
    		 videoRemoveId = Long.valueOf(videoRemoveIdStr);
        	 if(videoRemoveId != null){
        		 VideoRemoveModel videoRemoveModel = videoRemoveService.getOne(videoRemoveId);
        		 VideoModel videoModel = videoService.getById(videoRemoveModel.getVideoId());
        		 if(videoModel != null){
        			 //不属于同一个spId不能恢复该视频
        			 if(customModel.getSpId().longValue() != videoModel.getSpid().longValue()){
        				 errorVideoList.add(Long.valueOf(videoRemoveId));
        				 continue;
        			 }
                     VideoModel update = new VideoModel();
                     update.setVideoId(videoModel.getVideoId());
                     update.setStatus(videoRemoveModel.getOldStatus());
                     update.setUpdateTime(new Date());
                     update.setCustomId(customModel.getCustomId());
                     update.setUpdateUserId(customModel.getCustomId());
        			 videoService.save(update);

                     OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE,customModel.getCustomId(),customModel.getContacts(),"恢复删除的视频信息",customModel.getSpId(),videoModel.getBusinessUUID(),videoModel.getVideoName());
                     optionLogInfoService.create(logInfo);


                 }
        		 videoRemoveService.deleteRemoveVideo(Long.valueOf(videoRemoveId));
        	 }else{
        		 jsonResult.setSuccess(false);
        	 }
         }
         response.setHeader("Access-Control-Allow-Origin", "*");
         if (errorVideoList.isEmpty()) {
        	 return JsonResult.createSuccessInstance(null);
         } else {
             return JsonResult.createErrorInstance(("video_") + errorVideoList.toString() + ("fail_"));
         }
        
    }
    
    /**
     * @Title: removeVideo
     * @Description: 视频删除(支持批量操作)
     * @param: videoIds 视频id，多个时逗号分隔
     * @param: removeMsg
     */
    @RequestMapping("/removeVideo")
    @ResponseBody
//    @LogAnnotation(message = "操作彻底删除视频",type = OptionType.DELETE)
    public JsonResult removeVideo(HttpServletRequest request, String videoIds, String removeMsg) {
    	//校验videoIds参数是否为空
    	if (StringUtils.isEmpty(videoIds)) {
            return JsonResult.createErrorInstance(("视频") + "ID" + ("参数缺失！"));
        }
    	for (String videoId : Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().splitToList(videoIds)) {
    		Long vid = 0L;
    		try {
    			vid = CommonUtil.formatString2Long("videoId", videoId);
    		} catch (BusinessException ex) {
    			return JsonResult.createErrorInstance(("参数错误"));
    		}
    		VideoRemoveModel videoRemoveModel = videoRemoveService.getOne(vid);
    		if (videoRemoveModel == null) {
    			return JsonResult.createErrorInstance(("视频不存在"));
    		}
//    		VideoModel video = videoService.getById(videoRemoveModel.getVideoId());
            long curSpId = this.getSpId(request);
            long curCustomId = this.getCustomId(request);
            if(videoRemoveModel.getRemoveSpId().longValue() != curSpId){
                return JsonResult.createErrorInstance(("视频:"+videoRemoveModel.getVideoName()+" 用户无权限删除！"));
            }
            videoRemoveService.removeVideo(videoRemoveModel,curSpId,curCustomId,videoRemoveModel.getRemoveUserId());

            OptionLogInfo logInfo = new OptionLogInfo(OptionType.DELETE,curCustomId,videoRemoveModel.getRemoveUser(),"彻底删除视频信息",curSpId,videoRemoveModel.getBusinessUUID(),videoRemoveModel.getVideoName());
            optionLogInfoService.create(logInfo);

    	}
    	return JsonResult.createSuccessInstance(null);
    }
    
}
