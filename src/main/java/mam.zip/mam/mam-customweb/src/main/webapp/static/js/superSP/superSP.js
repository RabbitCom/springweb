var params = {},
    index = 0,
    category_obj = {},
    videoName_arr = [];
var lcsetting = {
    "ajax": basePath + "super/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<dl class="clearfix">' +
                '<dt class="ui-fl img">' +
                '<a class="video-view"  videoPlyUrl =' + d.playUrl + ' videoPlyImgUrl = '+ d.picOriginal +' href="#modal-video-view" data-toggle="modal" ><img src=' + getListPicUrl(d.listPicUrl) + '></a>' +
                '</dt>' +
                '<dd class="ui-fl album-info">' +
                '<p>' + LCT("ID") + '：' + d.businessUUID + '</p>' +
                '<p class="videoName"></p>' +
                '<p>' + LCT("时长") + '：<span class="video-duration">' + vrsFn.formatSeconds(d.duration) + '</span></p>' +
                '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                '</dd>' +
                '</dl>';
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //上传时间
            return d.createTime;
        }
    },{
        "data": "lcall",
        "format": function(i, j, d) { //发布时间
            var publishTime =  d.publishTime;
            if(typeof(publishTime) == undefined){
                return '未发布';
            }else if(publishTime==null){
                return '未发布';
            }else{
                return publishTime ;
            }
        }
    }, {
        "data": "lcall",
        "className": 'videoStatus',
        "format": function(i, j, d) {
            function parese(s) {
            	if (s == -1) {
                    return '<span class="link-blue-txt">' + LCT("初始化") + '</span>';
                }
                if (s == 0) {
                    return '<span class="link-blue-txt">' + LCT("待编辑") + '</span>';
                }
                if (s == 1) {
                    return '<span class="link-blue-txt">' + LCT("已编辑") + '</span>';
                }
                if (s == 2) {
                    return '<span class="link-blue-txt">' + LCT("审核中") + '</span>';
                }
                if (s == 3) {
                    return '<span class="link-blue-txt">' + LCT("审核通过") + '</span>';
                }
                if (s == 4) {
                    return '<span class="link-blue-txt">' + LCT("审核拒绝") + '</span><p>'
                        +'<a class="video-auditMes ml-10" style="color: red;" data-toggle="modal" href="#modal-auditFailDetails" data-id="' + d.videoId + '">' + "查看原因" + '</a >';
                }
                if (s == 5) {
                    return '<span class="link-blue-txt">' + LCT("上线") + '</span> ';
                }
                if (s == 6) {
                    return '<span class="link-blue-txt">' + LCT("下线") + '</span>';
                }
                if (s == 7) {
                    return '<span class="link-blue-txt">' + LCT("发布中") + '</span>';
                }
                if (s == 8) {
                    return '<span class="link-blue-txt">' + LCT("发布成功") + '</span>';
                }
                if (s == 9) {
                    return '<span class="link-blue-txt">' + LCT("发布失败") + '</span><p>'
                        +'<a href="javascript:void(0)" style="color: red;" onclick="publishHistoryView('+d.videoId +')" >' + "查看原因" + '</a >';
                }
            }
            return parese(d.status); //视频状态
        }
    }, {
        "data": "lcall",
        "className": 'fileStatus',
        "format": function(i, j, d) {
            function parese(z) {
            	if (z == -1) {
            		return '<span class="link-blue-txt">' + LCT("上传中") + '</span>';
            	} 
                if (z == 0) {
                    return '<span class="link-blue-txt">' + LCT("上传完成") + '</span><p>';
                        // +'<a href="javascript:void(0)" style="color: red;" onclick="uploadHaoShiView('+d.videoId +')" >' + "上传耗时" + '</a >';
                } 
                if (z == 1) {
                    return '<span class="link-blue-txt">' + LCT("转码中") + '</span><p>';
                        // +'<a href="javascript:void(0)" style="color: red;" onclick="uploadHaoShiView('+d.videoId +')" >' + "上传耗时" + '</a >';
                } 
                if (z == 2) {
                    return '<span class="link-blue-txt">' + LCT("转码成功") + '</span><p>';
                        // +'<a href="javascript:void(0)" style="color: red;" onclick="uploadHaoShiView('+d.videoId +')" >' + "上传耗时" + '</a >';
                } 
                if (z == 3) {
                    return '<span class="link-blue-txt">' + LCT("转码失败") + '</span><p>'
                        // +'<a href="javascript:void(0)" style="color: red;" onclick="uploadHaoShiView('+d.videoId +')" >' + "上传耗时" + '</a ><p>'
                        +'<a class="transcodingDetails" style="color: red;" data-toggle="modal" href="#modal-transcoding-details" data-duration="'+vrsFn.formatSeconds(d.duration)+'"  data-id="' + d.videoId + '">' + "查看原因" + '</a >';
                } 
            }
            return parese(d.fileStatus); //媒资状态
        }
    }, {
        "data": "lcall",
        "className": 'commentSet',
        "format": function(i, j, d) {
            // console.info(d);
            var showCmsUrl = '',viewUploadHaoShi='',viewTransCodeHaoShi='',viewChouzhenHaoShi='';
            var editPage = '<a href="javascript:void(0)" class="video-edit ml-10" category-id="' + d.category + '" customcategory-id="' + d.customCategoryId + '" data-albumId="' + d.albumId + '" data-id="' + d.videoId + '">' + LCT("视频信息") + '</a>';
            editPage+='<br>&nbsp;&nbsp;';
            if(d.status == 8){
                showCmsUrl =   '<a href="javascript:window.open(\'' + d.videoPlyUrl + '\')">播放页面</a>';
                showCmsUrl+='<br>&nbsp;&nbsp;';
            }
            if(d.fileStatus >= 0 ){
                viewUploadHaoShi = '<a href="javascript:void(0)"  onclick="uploadHaoShiView('+d.videoId +','+ d.showFileSize +')" >' + LCT("上传耗时") + '</a >';
                viewUploadHaoShi+='<br>&nbsp;&nbsp;';
            }
            if(d.fileStatus == 2){
                viewTransCodeHaoShi = '<a class="transcodingHaoShiDetails" data-toggle="modal" href="#modal-transcodeHaoShi" data-duration="'+vrsFn.formatSeconds(d.duration)+'" data-id="' + d.videoId + '">' + LCT("转码耗时") + '</a >';
                viewTransCodeHaoShi+='<br>&nbsp;&nbsp;';
            }
            viewChouzhenHaoShi='<a href="javascript:void(0)"  onclick="chouzhenHaoShiView('+d.videoId +')" >' + LCT("抽帧耗时") + '</a >';
            return editPage + showCmsUrl +viewUploadHaoShi +viewTransCodeHaoShi +viewChouzhenHaoShi ;
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        //视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(LCT("名称") + '：' + remark_html);
            $(tr[i]).find("a.video-view").attr("data-name", remark_html);
            $(tr[i]).find("a.playbackSettings").attr("data-name", remark_html);
        }
        videoName_arr = [];
    }
};
var videoFn = {
    init: function() {
    	this.mltiSelect(); //多状态查询
        this.handleTable(); //表格数据筛选
        this.systemCatagory(); //大数据分类
        this.editPreview();
        this.transcodingDetails();
        this.getAuditMessage();
        this.showTransCodeHaoshi();
    },
    mltiSelect: function() {
    	var input = $("input[name='video-status']");
    	var video_status;
        var video_status_valArr = [];
        var video_status_textArr = [];
        if (!$("input[name='video-status']:checked").length) {
            $(".video-status-result").html("请选择").attr("onoffStatus", "");;
        } else {
            for (i = 0; i < input.length; i++) {
                if (input[i].checked) {
                    var video_status_val = $(input[i]).val();
                    var video_status_text = $(input[i]).closest("li").text();
                    video_status_valArr.push(video_status_val);
                    video_status_textArr.push(video_status_text);
                    video_status = video_status_valArr.join(",")
                    if (video_status_valArr.length) {
                        $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                    }
                }
            }
        }
        $(".video-status-result").click(function() {
            if ($(".option-items").is(":visible")) {
                $(".option-items").addClass("hide");
            } else {
                $(".option-items").removeClass("hide");
            }
        });
        $(".select-checkbox").mouseleave(function() {
            $(".option-items").addClass("hide");
        })
        $("#video_status_choose").click(function(){
        	var input = $("input[name='video-status']");
        	if($("input[name='video-status']:checked").length){
        		for(i = 0; i < input.length; i++){
        			 if (input[i].checked) {
        				 input[i].checked = false;
        			 }
        		}
        	} 
        })
        $(".select-checkbox .btn_ok").click(function() {
        	var input = $("input[name='video-status']");
        	var video_status;
            var video_status_valArr = [];
            var video_status_textArr = [];
            if (!$("input[name='video-status']:checked").length) {
                $(".video-status-result").html("请选择").attr("onoffStatus", "");;
            } else {
                for (i = 0; i < input.length; i++) {
                    if (input[i].checked) {
                        var video_status_val = $(input[i]).val();
                        var video_status_text = $(input[i]).closest("li").text();
                        video_status_valArr.push(video_status_val);
                        video_status_textArr.push(video_status_text);
                        video_status = video_status_valArr.join(",")
                        if (video_status_valArr.length) {
                            $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                        }
                    }
                }
            }
            $(".option-items").addClass("hide");
            var onoff  = $(".video-status-result").attr("onoffstatus");
        	if (onoff) {
            	params["onoffStatus"] = onoff;
            } else {
            	params["onoffStatus"] = "0,1,2,3,4,5,6,7,8,9";
            }

            var fileStatus = $.trim($(".search_select option:selected").val());
            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }

            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    handleTable: function() {
    	var onoff  = $(".video-status-result").attr("onoffstatus");
    	if (onoff) {
        	params["onoffStatus"] = onoff;
        } else {
            delete params["onoffstatus"];
        }
        videoName_arr = [];
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".btn_search").bind("click", function() {
            var value_spid = $.trim($("#spid").val());
            var value_name = $.trim($("#videoName").val());
            var value_id = $.trim($("#videoId").val());
            var fileStatus = $.trim($(".search_select option:selected").val());

            var uploadStartTime = $.trim($("#d4313").val());
            var uploadEndTime = $.trim($("#d4314").val());

            var publishStartTime = $.trim($("#d4315").val());
            var publishEndTime = $.trim($("#d4316").val());

            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }
            if(value_spid){
                params["spId"] = value_spid;
            }else{
                delete params["spId"];
            }
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
            if (value_name) {
                params["videoName"] = value_name;
            } else {
                delete params["videoName"];
            }
            if(uploadStartTime){
                params["uploadStartTime"] = uploadStartTime;
            }else{
                delete params["uploadStartTime"];
            }
            if(uploadEndTime){
                params["uploadEndTime"] = uploadEndTime;
            }else{
                delete params["uploadEndTime"];
            }
            if(publishStartTime){
                params["publishStartTime"] = publishStartTime;
            }else{
                delete params["publishStartTime"];
            }
            if(publishEndTime){
                params["publishEndTime"] = publishEndTime;
            }else{
                delete params["publishEndTime"];
            }


            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    systemCatagory: function() {
        //获取大分类category
        $.getJSON(
            basePath + "customCategoryController/getCategorys.do",
            function(data) {
                var system_channel = '';
                system_channel += '<option data-id="0" value=' + LCT("请选择") + '>' + LCT("请选择") + '</option>';
                for (var i = 0; i < data.length; i++) {
                    var showName = data[i].showName;
                    var dicValue = data[i].dicValue;
                    system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
                }
                $(".systemCatagory").attr("data-id", '0').html(system_channel);
                $(".systemCatagory-modal").attr("data-id", '0').html(system_channel);
            }
        );
        //数据分类筛选
        $(".systemCatagory").on("change", function() {
        	  var categoryId = $(this).children('option:selected').attr("data-id");
              $(".systemCatagory").attr("data-id", categoryId);
              category_obj = {};
              category_obj.category = categoryId;
              if (categoryId == "0") {
                  $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>' + vrsFn.customCategoryInitDom);
              } else {
                  $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>');
                  buildEdit.start = false;
                  buildEdit.init("setClass");
              }

              delete params["customCategoryId"];
              params["category"] = categoryId;
              lcsetting.thisPage = 1;
              $("#maintable").lctable(lcsetting, params);
        });
        //分类设置-数据分类
        $(".systemCatagory-modal").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory-modal").attr("data-id", categoryId);
            category_obj.category = categoryId;
            $("#editClass").html("");
            buildEdit.init("editClass");
        });
    },
    editPreview: function() {
        $("#maintable").on("click", ".video-edit", function() {
            var customCategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumId");
            var lc_inner_href = basePath + "super/viewVideo.do?videoId=" + videoId;
            showInIFrame(lc_inner_href);
        });
        $("#maintable").on("click", ".video-view", function() {
            var videoPlyUrl = $(this).attr("videoPlyUrl");
            var data_name = $(this).attr("data-name");
            // $("#cnlivePlayer").attr("flashVars","hasBorder=false&model=2&videoURL="+videoPlyUrl);
            $("#cnlivePlayer").attr("flashVars","type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1&currRate=2&videoUrl_2="+videoPlyUrl);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $('#modal-video-view').on('hide.bs.modal', function() {
            // $("#player").html("");
        });
    },
    buWei: function(dom) {
        var value = $(dom).val();
        if (value.length == 0) {
            return value = "00";
        } else if (value.length == 1) {
            return value = "0" + value;
        } else {
            return value = value;
        }
    },
    totalSeconds: function(moment) {
        var moment_arr = moment.split(":");
        var totalSeconds = parseInt(moment_arr[0]) * 3600 + parseInt(moment_arr[1]) * 60 + parseInt(moment_arr[2]);
        return totalSeconds;
    },
    transcodingDetails: function() {
        $("#maintable").on("click", ".transcodingDetails", function() {
            var videoId = $(this).attr("data-id");
            // var duration = $(this).attr("data-duration");
            $.ajax({
                url: basePath + "videoController/showTranCodeFaildInfo.do?videoId=" + videoId,
                type: "get",
                dataType: "json",
                success: function(data) {
                    data = typeof(data) == "string" ? JSON.parse(data) : data;
                    var tranCode_html = '';
                    if (data.obj.length) {
                        for (var i = 0; i < data.obj.length; i++) {
                            var file = data.obj[i];
                            var codeRateText = file.codeRateName;
                            var errorMsg = file.transCodeFailMsg || '';
                            var gfmt = file.transCodeFmt;
                            var fileStatus = file.status;
                            var showStatus = '--';
                            if (fileStatus == -1) {
                                showStatus = "上传中";
                            }
                            else if (fileStatus == 0) {
                                showStatus = "上传完成";
                            }
                            else if (fileStatus == 1) {
                                showStatus = "转码中";
                            }
                            else if (fileStatus == 2) {
                                showStatus = "转码成功";
                            }
                            else if (fileStatus == 3) {
                                showStatus = '<span style="color: red">'+"转码失败"+'</span>';
                            }
                            tranCode_html += '<tr>';
                            tranCode_html += '<td>' + codeRateText + '</td>';
                            tranCode_html += '<td>' + gfmt + '</td>';
                            tranCode_html += '<td>' + showStatus + '</td>';
                            tranCode_html += '<td>' +'<span style="color: red">'+ errorMsg + '</span></td>';
                            tranCode_html += '</tr>';
                        }
                    } else {
                        tranCode_html += '<tr><td colspan="2">暂无记录</td></tr>';
                    }
                    // $("#total-duration-fileDetails").html("视频时长："+duration);
                    $("#modal-transcoding-details tbody").html(tranCode_html);

                },
                error: function(data) {
                    console.log(data);
                }
            });
        });
        $("#modal-transcoding-details").on("hide.bs.modal", function() {
            $("#modal-transcoding-details tbody").html("");
        });
    },
    getAuditMessage: function(){
        $("#maintable").on("click", ".video-auditMes", function() {
            var videoId = $(this).attr("data-id");
            $.ajax({
                type: "GET",
                url: basePath + 'videoController/getAuditMessage.do?videoId='+videoId,
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function(data) {
                    var showMsg = {};
                    showMsg.discription = LCT("拒绝原因:"+data.obj[0].auditMessage);
//                    showMsg.iconType = "success";
                    showMsg.confirmBtn = true;
                    $("body").toolsalert(showMsg);
                    return;
                }
            });
        })
    },
    showTransCodeHaoshi:function () {
        $("#maintable").on("click", ".transcodingHaoShiDetails", function() {
            var videoId = $(this).attr("data-id");
            var duration = $(this).attr("data-duration");
            $.ajax({
                url: basePath + "videoController/transcodeHaoShiView.do?videoId=" + videoId,
                type: "get",
                dataType: "json",
                success: function(data) {
                    data = typeof(data) == "string" ? JSON.parse(data) : data;
                    var tranCode_html = '';
                    if (data.obj.length) {
                        for (var i = 0; i < data.obj.length; i++) {
                            var file = data.obj[i];
                            var codeRateText = file.codeRateName;
                            var gfmt = file.transCodeFmt;
                            var fileStatus = file.status;
                            var showStatus = '--';
                            var showHaoshi = file.transcodeHaoshi || '--';
                            var bt = file.transcodeBtime || '--';
                            var et = file.transcodeEtime || '--';
                            if (fileStatus == -1) {
                                showStatus = "上传中";
                            }
                            else if (fileStatus == 0) {
                                showStatus = "上传完成";
                            }
                            else if (fileStatus == 1) {
                                showStatus = "转码中";
                            }
                            else if (fileStatus == 2) {
                                showStatus = "转码成功";
                            }
                            else if (fileStatus == 3) {
                                showStatus = '<span style="color: red">'+"转码失败"+'</span>';
                            }
                            tranCode_html += '<tr>';
                            tranCode_html += '<td>' + codeRateText + '</td>';
                            tranCode_html += '<td>' + gfmt + '</td>';
                            tranCode_html += '<td>' + showStatus + '</td>';
                            tranCode_html += '<td>' + bt + '</td>';
                            tranCode_html += '<td>' + et + '</td>';
                            tranCode_html += '<td>' + showHaoshi + '</td>';
                            tranCode_html += '</tr>';
                        }
                    } else {
                        tranCode_html += '<tr><td colspan="2">暂无记录</td></tr>';
                    }
                    $("#total-duration-transcodeHaoShi").html("视频时长："+duration);
                    $("#modal-transcodeHaoShi tbody").html(tranCode_html);

                },
                error: function(data) {
                    console.log(data);
                }
            });
        });
        $("#modal-transcodeHaoShi").on("hide.bs.modal", function() {
            $("#modal-transcodeHaoShi tbody").html("");
        });
    }
};
$(function() {
    videoFn.init();
});
var buildEdit = {
    init: function(id) {
        this.connect(id);
    },
    editNameDom: $("input[name=editName]").parent(),
    editClassDom: $("#editClass"),
    start: false,
    connect: function(id) {
        $.ajax({
            url: basePath + "customCategoryController/dataGrid.do",
            data: category_obj,
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                window.classfiyObject_obj = data;
                buildEdit.createDom(data, id);
                if (id == "editClass") {
                    buildEdit.start = true
                }

            }
        });
    },
    createDom: function(data, id) {
        var s1 = new createClass(id, data);
        s1.init(2, id);
    },
    setInformation: function() { //设置分类信息事件;
        var arr = $("#setClass option:selected");
        var classId = "";
        var categoryId = "";
        videoName_arr = [];
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                classId = $(arr).eq(i).attr("data-id");
                categoryId = $(arr).eq(i).attr("category-id");
                $(".systemCatagory").attr("data-id", categoryId);
                break;
            }
        }
        $(".systemCatagory option[data-id='" + categoryId + "']").prop("selected", true);
        var systemCatagoryId = $(".systemCatagory").attr("data-id");
        if (systemCatagoryId == "0") {
            delete params["category"];
        } else {
            params["category"] = systemCatagoryId;
        }
        $(".systemCatagory").change(function() {
            classId = "";
        });
        if (classId == "") {
            delete params["customCategoryId"];
        } else {
            params["customCategoryId"] = classId;
        }
        lcsetting.thisPage = 1;
        $("#maintable").lctable(lcsetting, params);
    }
};
createClass.prototype = {
    init: function(num, id) {
        var This = this;
        for (var i = 0; i < 2; i++) {
            var oSel = document.createElement("select");
            oSel.index = i;
            oSel.className = "form-control";
            this.oParent.appendChild(oSel);
            oSel.onchange = function() {
                This.change(this.index);
            }
        }
//        if (id == "setClass") {
//            var ahref = document.createElement("a")
//            $(this.oParent).append('<a data-menu="vrsCategory" class="icon-set link-gray3" href="' + basePath + 'customCategoryController/toCustomCategoryManager.do">' + LCT("设置分类信息") + '</a>');
//        }
        this.first();
    },
    change: function(iNow) {
        switch (iNow) {
            case 0: //改变1级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.zero(now);
                break;
            case 1: //改变2级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.one(now);
                break;
//            case 2: //改变3级时候处理
//                var now = this.aSel[iNow].selectedIndex;
//                this.two(now);
//                break;
        }
        if (this.oParent == document.getElementById("setClass")) {
            buildEdit.setInformation();
        }
    },
    noting: function() {
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i + 1].appendChild(opt);
        }
    },
    zero: function(n) { //改变一级处理函数

        for (var i = 0; i < 2; i++) { //清空源信息;
            if (i == 0) {
                continue
            }
            this.aSel[i].innerHTML = "";
        }
        if (n == 0) {
            this.noting();
            return
        }
        var arr = this.data[n - 1];
        if (arr.children.length) {
            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);
                this.aSel[1].appendChild(opt);
            }
        } else {
            this.noting();
            return;
        }

//        if (arr.children[0].children.length) {
//            for (var i = 0; i < arr.children[0].children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[0].children[i].text;
//                opt.setAttribute("data-id", arr.children[0].children[i].id);
//                opt.setAttribute("category-id", arr.children[0].children[i].category);
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }
    },
    one: function(n) { //改变二级处理函数
//        var a1 = this.aSel[0].selectedIndex - 1;
//        var arr = this.data[a1].children[n];
//        this.aSel[2].innerHTML = "";
//        if (arr.children.length != 0) {
//
//            for (var i = 0; i < arr.children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[i].text;
//                opt.setAttribute("data-id", arr.children[i].id);
//                opt.setAttribute("category-id", arr.children[i].category);
//
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }

    },
    two: function(n) {

    },
    first: function() { //上来初始化
        var arr = this.data;
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i].appendChild(opt);
        }
        for (var i = 0; i < arr.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = arr[i].text;
            $(opt).attr("data-id", arr[i].id);
            $(opt).attr("category-id", arr[i].category);
            this.aSel[0].appendChild(opt);
        }
    }
}

function createClass(id, data) {
    this.oParent = document.getElementById(id);
    this.data = data;
    this.aSel = this.oParent.getElementsByTagName("select");
}
//编辑-返回

function closeIframeFromOuter(type) {
    videoName_arr = [];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}

/**
 * 发布失败时查看
 * @param videoId
 */
function publishHistoryView(videoId){
    $.ajax({
        type: "post",
        url:basePath +"super/getPublishFailMsg.do?videoId="+videoId,
        success:function(data){
            data = typeof(data) == "string" ? JSON.parse(data) : data;
            if(data.success){
                $('#failMessage').text(data.obj);
                $('#modal-failMessage').modal("show");
            }else{
                alertfn.danger(LCT(data.msg));
            }
        }
    });
}

function uploadHaoShiView(videoId,fileSize) {
    $.ajax({
        type: "post",
        data:{videoId : videoId},
        url:basePath +"videoController/getUploadHs.do",
        success:function(data){
            data = typeof(data) == "string" ? JSON.parse(data) : data;
            if(data.success){
                var rs = data.obj;
                $('#upload_vId').text(rs.vBussinessId);
                $('#upload_ksId').text(rs.uploadId);
                $('#upload_fileSize').text(formatMb(fileSize));
                $('#upload_bt').text(rs.bt || '--');
                $('#upload_et').text(rs.et || '--');
                $('#upload_hs').text(rs.hst || '--');
                $('#modal-uploadHS').modal("show");
            }else{
                alertfn.danger(LCT(data.msg));
            }
        }
    });
}

function chouzhenHaoShiView(videoId) {
    $.ajax({
        type: "post",
        data:{videoId : videoId},
        url:basePath +"videoController/chouzhenHaoShiView.do",
        success:function(data){
            data = typeof(data) == "string" ? JSON.parse(data) : data;
            if(data.success){
                var rs = data.obj;
                $('#chouzhen_vId').text(rs.vBussinessId);
                $('#chouzhen_taskId').text(rs.taskId);
                $('#chouzhen_bt').text(rs.bt || '--');
                $('#chouzhen_et').text(rs.et || '--');
                $('#chouzhen_hs').text(rs.hst || '--');
                $('#modal-chouzhenHaoShi').modal("show");
            }else{
                alertfn.danger(LCT(data.msg));
            }
        }
    });
}