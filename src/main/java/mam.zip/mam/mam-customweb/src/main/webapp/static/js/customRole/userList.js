/**
 * Created by liyi on 2017/5/18.
 */

var params = {},
    index = 0;
var lcsetting = {
    "ajax": basePath + "customRoleController/userList.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function (i, j, d) { //用户名
            return d.contacts || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //邮箱
            return d.name || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //手机号
            return d.phone || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //所属机构
            return d.institutionName || '--';
        }
    }, {
        "data": "lcall",
        "format": function (i, j, d) { //操作类型
            return '<a data-toggle="modal" href="javascript:void(0)" class="link-blue-txt roleItems" data-roleId="' + d.roleId + '" data-uid="' + d.customId + '" data-target="#modal-video-view" data-toggle="modal">' + LCT("分配角色") + '</a>'; //媒资状态
        }
    }
    ],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "..."
};
var logManagerFn = {
    init: function () {
        this.handleTable(); //表格数据筛选
    },
    handleTable: function () {
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".search_select").change(function () {
            $(".btn_search").click();
        });
        $(".btn_search").bind("click", function () {
            params = {};
            var value_contacts = $.trim($(".search_contacts").val());
            var value_name = $.trim($(".search_name").val());

            if (value_contacts) {
                params["contacts"] = value_contacts;
            }
            if (value_name) {
                params["name"] = value_name;
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    }
};
$(function () {
    logManagerFn.init();
});

var current_roleId;
var current_uid;
var current_u;
//先择角色事件
$('#maintable').on('click', '.roleItems', function () {
    current_roleId = $(this).data('roleid');
    current_uid = $(this).data('uid');
    current_u = $(this);

});
//模态层弹出初始化选中状态
$("#modal-video-view").on("shown.bs.modal", function (e) {
    // $('#maintable_user :checked').prop('checked',true);
    if (current_roleId == "undefined" || current_roleId == "") {
        $('#maintable_user input').prop('checked', false);
    } else {
    $('#maintable_user input[value="' + current_roleId + '"]').prop('checked', true);
    }
});

//角色选中确认
$('#btnRoleS').click(function () {
    var roleId = $('#maintable_user input:checked').val();
    if (roleId == undefined || roleId == "") {
        alertfn.danger("未选择角色");
    } else {
    $.post(basePath + 'customRoleController/userBind.do', {uid: current_uid, roleId: roleId}, function (data) {
        if (data.success) {
            current_u.data('roleid', roleId);
            alertfn.success(data.msg);
        } else {
            alertfn.danger(data.msg);
        }
        $('#modal-video-view').modal('hide');
    }, 'json');
    }

});