package com.cnlive.mam.controller;

import java.beans.PropertyEditor;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.web.StringEscapeEditor;
import com.cnlive.mam.service.CustomSpInfoService;
import com.google.common.base.Joiner;
import com.ksyun.ks3.dto.HeadBucketResult;
import com.ksyun.ks3.service.Ks3;
import com.ksyun.ks3.service.Ks3Client;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.storage.BucketManager;
import com.qiniu.storage.Configuration;
import com.qiniu.util.Auth;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.MmsTypeEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.JsonResult;

/**
 * 基础控制器
 *
 * @author ZHANGXIABOIN
 *
 */
@Controller
@RequestMapping("/baseController")
public class BaseController{

    private static Logger _log = LoggerFactory.getLogger(BaseController.class);

    @Resource(name = "dictionaryService")
    DictionaryService dictionaryService;

    @Resource(name = "customService")
    CustomService customService;

    @Resource(name = "customSpInfoService")
    CustomSpInfoService customSpInfoService;
    
    @Resource(name = "storageService")
    StorageService storageService;

    @Value("#{configProperties['upload_img_AccessKeyID']}")
    String ksConfigAK;
    @Value("#{configProperties['upload_img_AccessKeySecret']}")
    String ksConfigSK;
    @Value("#{configProperties['upload_img_region']}")
    String uploadImgRegion;

    @Value("#{configProperties['qiniu.AK']}")
    String qiniu_ksConfigAK;
    @Value("#{configProperties['qiniu.Sk']}")
    String qiniu_ksConfigSK;
    @Value("#{configProperties['bucket_qiniu']}")
    String bucket_qiniu_default;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        try {
            PropertyEditor propertyEditor = new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true);
            binder.registerCustomEditor(Date.class, propertyEditor);
//            binder.registerCustomEditor(String.class, new StringTrimmerEditor(false));
            binder.registerCustomEditor(String.class, new StringEscapeEditor());
        } catch (Exception e) {
            _log.error("CommonController初始化时发生错误！");
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取客户信息parentId
     */
    protected String  getParentId(HttpServletRequest request) {
        Object  parentId = request.getSession().getAttribute("parentId");
        if (parentId != null) {
            return String.valueOf(parentId);
        }else{
            _log.error("getParentId error: parentId={}",parentId);
            return Const.PARENTID_DEFAULT_VAL;
        }
    }
    
    /**
     * 获取客户信息
     */
    protected Long getCustomId(HttpServletRequest request) {
        Object customId = request.getSession().getAttribute("customId");
        if (customId != null) {
            return Long.valueOf(customId.toString());
        }else{
        	_log.error("getCustomId error: customId={}",customId);
        	return Const.CUSTOMID_DEFAULT_VAL;
        }
    }
    
    /**
     * 获取客户SpId
     */
    protected Long getSpId(HttpServletRequest request) {
    	Object spId = request.getSession().getAttribute("spId");
    	if (spId != null) {
    		return Long.valueOf(spId.toString());
    	}else{
    		_log.error("getSpId error: spId={}",spId);
    		return 0L;
    	}
    }

    /**
     * 获取用户机构
     * @param request
     * @return
     */
    protected String getInstitutionId(HttpServletRequest request){
        Object  institutionId = request.getSession().getAttribute("institutionId");
        if (institutionId != null) {
            return String.valueOf(institutionId);
        }else{
            return "";
        }
    }
    
    /**
     * 获取客户信息
     */
    protected String getCustomName(HttpServletRequest request) {
    	Object customName = request.getSession().getAttribute("username");
		return String.valueOf(customName);
    }

    /**
     * 设置公用的字典值
     */
    protected void setRequestPublicInfo(HttpServletRequest request, Integer category) {
        // 语言
        List<Dictionary> languageList = dictionaryService.getDictionary("language", category);
        request.setAttribute("languageList", languageList);
        // 地区
        List<Dictionary> areaList = dictionaryService.getDictionary("area", category);
        request.setAttribute("areaList", areaList);
        // 视频类型
        List<Dictionary> videoTypeList = dictionaryService.getDictionary("videoType", category);
        request.setAttribute("videoTypeList", videoTypeList);

        //影片分类
        List<Dictionary> subCategoryList = dictionaryService.getDictionary("subCategory", category);
        request.setAttribute("subCategoryList", subCategoryList);

        // 版权类型
        List<Dictionary> copyrightTypeList  = dictionaryService.getDictionary("copyrightType", category);
        request.setAttribute("copyrightTypeList", copyrightTypeList);
        // 播放平台
        List<Dictionary> platformList  = dictionaryService.getDictionary("platform", category);
        request.setAttribute("playPlatformList", platformList);//播放平台
        request.setAttribute("payPlatformList", platformList); //计费平台
        request.setAttribute("downloadPlatformList", platformList);// 下载平台
        // 内容分级
        List<Dictionary> contentRatingList  = dictionaryService.getDictionary("contentRating", category);
        request.setAttribute("contentRatingList", contentRatingList);
        // 码流字典值
        List<Dictionary> rateList  = dictionaryService.getDictionary("rate", category);
        request.setAttribute("rateList", rateList);
        // 媒资类型值 0普通 1全景 23D ……
        List<Map<String,String>> mmsTypeList  = MmsTypeEnum.getAllMmsTypeMap();
        request.setAttribute("mmsTypeList", mmsTypeList);
    }

    /**
     * 根据专辑、视频设置不同的显示
     */
    @SuppressWarnings("unchecked")
    protected List<Map<String, String>> getPropertyList(int type,VideoModel video,AlbumModel album,int editCategory) {

        int category = 0;
        String extendPropertiesValues = null;
        Long id = 0L;
        if(type == 0){
            category  = editCategory ==0 ? video.getCategory().intValue() : editCategory;
            extendPropertiesValues = video.getExtendProperties();
            id = video.getVideoId();
        }
        if(type == 1){
            category  = editCategory ==0 ? album.getCategory().intValue() : editCategory;
            extendPropertiesValues = album.getExtendProperties();
            id = album.getAlbumId();
        }

        Map<String, String> extendPropertiesMap = new HashMap<String, String>();
        if (id != null && StringUtils.isNotBlank(extendPropertiesValues)) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                extendPropertiesMap = mapper.readValue(extendPropertiesValues, Map.class);
            } catch (JsonParseException e) {
                _log.error(e.getMessage());
            } catch (JsonMappingException e) {
                _log.error(e.getMessage());
            } catch (IOException e) {
                _log.error(e.getMessage());
            }
        }
        return this.getShowPropertyList(type,category, extendPropertiesMap);
    }

    /**
     * 根据专辑、视频设置不同的显示
     */
    private List<Map<String, String>> getShowPropertyList(int type,int category,Map<String, String> extendPropertiesMap){
        // 扩展属性存放
        List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();
        //("video")
        if(type == 0){
            if (category == Const.CHANNEL_FILM || category == Const.CHANNEL_TV) {

                Map<String, String> md = new HashMap<String, String>();
                md.put("showName", ("导演"));
                md.put("showCode", "director");

                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("演员"));
                my.put("showCode", "actor");

                Map<String, String> mb = new HashMap<String, String>();
                mb.put("showName", ("编剧"));
                mb.put("showCode", "screenwriter");

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("制片人"));
                mz.put("showCode", "filmProduce");

                if (extendPropertiesMap != null) {
                    md.put("codeValue", extendPropertiesMap.get("director"));
                    my.put("codeValue", extendPropertiesMap.get("actor"));
                    mb.put("codeValue", extendPropertiesMap.get("screenwriter"));
                    mz.put("codeValue", extendPropertiesMap.get("filmProduce"));
                }
                showPropertyList.add(md);
                showPropertyList.add(my);
                showPropertyList.add(mb);
                showPropertyList.add(mz);
            }
            if (category == Const.CHANNEL_VARIETY || category == Const.CHANNEL_ENTERTAIN || category == Const.CHANNEL_FASHION || category == Const.CHANNEL_HEALTHY) {
                Map<String, String> mj = new HashMap<String, String>();
                mj.put("showName", ("嘉宾"));
                mj.put("showCode", "guest");

                if (extendPropertiesMap != null) {
                    mj.put("codeValue", extendPropertiesMap.get("guest"));
                }

                showPropertyList.add(mj);
            }
            if (category == Const.CHANNEL_FASHION  || category == Const.CHANNEL_HEALTHY) {
                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("主持人"));
                mz.put("showCode", "host");
                if (extendPropertiesMap != null) {
                    mz.put("codeValue", extendPropertiesMap.get("host"));
                }
                showPropertyList.add(mz);
            }
            if(category == Const.CHANNEL_SPORTS ){
                Map<String, String> sport = new HashMap<String, String>();
                sport.put("showName", ("演员"));
                sport.put("showCode", "actor");
                if (extendPropertiesMap != null) {
                    sport.put("codeValue", extendPropertiesMap.get("actor"));
                }
                showPropertyList.add(sport);
            }
            if (category == Const.CHANNEL_MUSIC) {
                Map<String, String> mc = new HashMap<String, String>();
                mc.put("showName", ("作词"));
                mc.put("showCode", "lyrics");
                if (extendPropertiesMap != null) {
                    mc.put("codeValue", extendPropertiesMap.get("lyrics"));
                }

                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("作曲"));
                my.put("showCode", "composer");
                if (extendPropertiesMap != null) {
                    my.put("codeValue", extendPropertiesMap.get("composer"));
                }

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("制片人"));
                mz.put("showCode", "filmProduce");
                if (extendPropertiesMap != null) {
                    mz.put("codeValue", extendPropertiesMap.get("filmProduce"));
                }

                Map<String, String> md = new HashMap<String, String>();
                md.put("showName", ("导演"));
                md.put("showCode", "director");
                if (extendPropertiesMap != null) {
                    md.put("codeValue", extendPropertiesMap.get("director"));
                }

                showPropertyList.add(mc);
                showPropertyList.add(my);
                showPropertyList.add(mz);
                showPropertyList.add(md);
            }
        }
        //("album")
        if(type == 1){
            if (category == Const.CHANNEL_FILM || category == Const.CHANNEL_TV) { // 电影、电视剧

                Map<String, String> md = new HashMap<String, String>();
                md.put("showName", ("导演"));
                md.put("showCode", "director");

                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("演员"));
                my.put("showCode", "actor");

                Map<String, String> mb = new HashMap<String, String>();
                mb.put("showName", ("编剧"));
                mb.put("showCode", "screenwriter");

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("制片人"));
                mz.put("showCode", "filmProduce");

                if (extendPropertiesMap != null) {
                    md.put("codeValue", extendPropertiesMap.get("director"));
                    my.put("codeValue", extendPropertiesMap.get("actor"));
                    mb.put("codeValue", extendPropertiesMap.get("screenwriter"));
                    mz.put("codeValue", extendPropertiesMap.get("filmProduce"));
                }
                showPropertyList.add(md);
                showPropertyList.add(my);
                showPropertyList.add(mb);
                showPropertyList.add(mz);
            }
            // 人员信息- 主持人、嘉宾
            if (category ==  Const.CHANNEL_VARIETY || category == Const.CHANNEL_ENTERTAIN) { // 综艺、娱乐
                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("主持人"));
                mz.put("showCode", "host");

                Map<String, String> mj = new HashMap<String, String>();
                mj.put("showName", ("嘉宾"));
                mj.put("showCode", "guest");

                if (extendPropertiesMap != null) {
                    mz.put("codeValue", extendPropertiesMap.get("host"));
                    mj.put("codeValue", extendPropertiesMap.get("guest"));
                }
                showPropertyList.add(mz);
                showPropertyList.add(mj);
            }
            // 人员信息 - ("singer")
            if (category == Const.CHANNEL_MUSIC) { // 音乐
                Map<String, String> mg = new HashMap<String, String>();
                mg.put("showName", ("歌手"));
                mg.put("showCode", "singer");

                if (extendPropertiesMap != null) {
                    mg.put("codeValue", extendPropertiesMap.get("singer"));
                }
                showPropertyList.add(mg);

            }
            // 人员信息 - 原创、主创
            if (category == Const.CHANNEL_COMIC) { // 动漫
                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("原创"));
                my.put("showCode", "original");

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("主创"));
                mz.put("showCode", "creative");

                if (extendPropertiesMap != null) {
                    my.put("codeValue", extendPropertiesMap.get("original"));
                    mz.put("codeValue", extendPropertiesMap.get("creative"));
                }
                showPropertyList.add(my);
                showPropertyList.add(mz);

            }
            // 人员信息 - 玩家、主持人
            if (category == Const.CHANNEL_GAME) { // 游戏
                Map<String, String> mw = new HashMap<String, String>();
                mw.put("showName", ("玩家"));
                mw.put("showCode", "gamePlayer");

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("主持人"));
                mz.put("showCode", "host");

                if (extendPropertiesMap != null) {
                    mw.put("codeValue", extendPropertiesMap.get("gamePlayer"));
                    mz.put("codeValue", extendPropertiesMap.get("host"));
                }
                showPropertyList.add(mw);
                showPropertyList.add(mz);

            }
            // 人员信息 - ("lnfluencer")
            if (category == Const.CHANNEL_FASHION || category == Const.CHANNEL_HEALTHY) { // 风尚、健康
                Map<String, String> md = new HashMap<String, String>();
                md.put("showName", ("达人"));
                md.put("showCode", "master");

                if (extendPropertiesMap != null) {
                    md.put("codeValue", extendPropertiesMap.get("master"));
                }
                showPropertyList.add(md);

            }
            // 人员信息 - ("compere")
            if (category == Const.CHANNEL_DOCUMENTARY || category == Const.CHANNEL_SPORTS) { // 纪录片、体育
                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("主持人"));
                mz.put("showCode", "host");

                if (extendPropertiesMap != null) {
                    mz.put("codeValue", extendPropertiesMap.get("host"));
                }
                showPropertyList.add(mz);
            }
            if(category == Const.CHANNEL_SPORTS ){ //体育 ("actor")\("screenwriter")\("producer")
                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("球员"));
                my.put("showCode", "actor");

                Map<String, String> mb = new HashMap<String, String>();
                mb.put("showName", ("编剧"));
                mb.put("showCode", "screenwriter");

                Map<String, String> mz = new HashMap<String, String>();
                mz.put("showName", ("制片人"));
                mz.put("showCode", "filmProduce");

                if (extendPropertiesMap != null) {
                    my.put("codeValue", extendPropertiesMap.get("actor"));
                    mb.put("codeValue", extendPropertiesMap.get("screenwriter"));
                    mz.put("codeValue", extendPropertiesMap.get("filmProduce"));
                }
                showPropertyList.add(my);
                showPropertyList.add(mb);
                showPropertyList.add(mz);
            }
            // 人员信息 - ("lecturer")
            if (category == Const.CHANNEL_EDUCATE) { // 教育
                Map<String, String> mj = new HashMap<String, String>();
                mj.put("showName", ("讲师"));
                mj.put("showCode", "lecturer");

                if (extendPropertiesMap != null) {
                    mj.put("codeValue", extendPropertiesMap.get("lecturer"));
                }
                showPropertyList.add(mj);
            }
            // 人员信息 - ("actor")
            if (category == Const.CHANNEL_FOLKART) { // 曲艺
                Map<String, String> my = new HashMap<String, String>();
                my.put("showName", ("演员"));
                my.put("showCode", "actor");

                if (extendPropertiesMap != null) {
                    my.put("codeValue", extendPropertiesMap.get("actor"));
                }
                showPropertyList.add(my);
            }
        }
        return showPropertyList;
    }



    /**
     * 获取扩展属性返回值
     */
    protected String getExtPropertysValuesToJSONString(HttpServletRequest request,Integer type,VideoModel video,AlbumModel album) {
        Map<String, String> extendPropertiesMap = new HashMap<String, String>();

        // 扩展属性存放
        List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();

        // 获取扩展的属性页面展示
        showPropertyList = this.getPropertyList(type, video, album,0);

        // 获取扩展属性的数据值
        for (int i = 0; i < showPropertyList.size(); i++) {
            if (showPropertyList.get(i) != null) {
                String extendPropertie = showPropertyList.get(i).get("showCode");
                String extendPropertieValue = request.getParameter(extendPropertie);
                if(StringUtils.isNotBlank(extendPropertieValue)){
                    extendPropertiesMap.put(extendPropertie, extendPropertieValue);
                }
            }
        }

        // 转换为json存入到 实体的 extendproperties中
        return JSONObject.toJSONString(extendPropertiesMap);
    }

    protected VideoCondition updateCondition(VideoCondition condition){

//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 0){//客户可审核
//            //condition.setCustomAuditStatusArray(new String[]{"0", "1"});
//            condition.setCustomAuditStatus(1);
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 1){//("custom_audit_pass")
//            condition.setCustomAuditStatus(2);
//            condition.setLetvAuditStatus(2);
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 2){//("custom_audit_not_pass")
//            condition.setCustomAuditStatus(3);
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 3){//("leeco_has_not_pass")
//            condition.setCustomAuditStatus(2);
//            condition.setLetvAuditStatus(1);
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 4){//乐视未通过
//            condition.setCustomAuditStatus(2);
//            condition.setLetvAuditStatus(3);
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 5){//客户所有可审核
//            condition.setCustomAuditStatusArray(new String []{"1","3"});
//        }
//        if(condition.getAuditStatus() != null && condition.getAuditStatus() == 6){//乐视所有可审核
//            condition.setLetvAuditStatusArray(new String[]{"1","3"});
//        }
//        condition.setSort("videoId");
        return condition;
    }

    protected VideoModel unescapeHtmlStr(VideoModel videoModel){
        videoModel.setVideoName(StringEscapeUtils.unescapeHtml4(videoModel.getVideoName()));
        videoModel.setSynopsis(StringEscapeUtils.unescapeHtml4(videoModel.getSynopsis()));
        videoModel.setSubTitle(StringEscapeUtils.unescapeHtml4(videoModel.getSubTitle()));
        videoModel.setCopyrightCompany(StringEscapeUtils.unescapeHtml4(videoModel.getCopyrightCompany()));
        return videoModel;
    }

    protected AlbumModel unescapeHtmlStr(AlbumModel albumModel){
        albumModel.setAlbumName(StringEscapeUtils.unescapeHtml4(albumModel.getAlbumName()));
        albumModel.setSynopsis(StringEscapeUtils.unescapeHtml4(albumModel.getSynopsis()));
        albumModel.setSubTitle(StringEscapeUtils.unescapeHtml4(albumModel.getSubTitle()));
        albumModel.setCopyrightCompany(StringEscapeUtils.unescapeHtml4(albumModel.getCopyrightCompany()));
        return albumModel;
    }

    /**
      * 客户有效性校验
      * @param request
      * @return JsonResult
      * @author wangchaojie　2017年3月17日
      * 
     */
    protected JsonResult checkCustomerExist(HttpServletRequest request){
        Long customId = this.getCustomId(request);
        if(customId == null || customId.longValue() == 0){
            return JsonResult.createErrorInstance(("用户认证失败"));
        }
        CustomModel customModel = customService.getById(customId);
        if(customModel == null){
            return JsonResult.createErrorInstance(("用户认证失败"));
        }
        return JsonResult.createSuccessInstance(customModel);
    }

    /**
     * 对model反射赋值
     * @param model 操作的model
     * @param attributes 需要赋值的属性
     * @param voluationMap 以model属性名称为key带有值的map
     * @return
     */
    protected Object reflectSetVal(Object model,List<String> attributes,Map<String,Object> voluationMap){
        // 获取实体类的所有属性，返回Field数组
        try {
            Field[] field = model.getClass().getDeclaredFields();
            for (int i = 0; i < field.length; i++) {
                String name = field[i].getName();
                String getFromMapName = name;
                //校验是否在排除的属性里面
                if(attributes != null
                        && attributes.size() > 0
                        && (!attributes.contains(name))){
                    continue;
                }
                // 将属性的首字符大写，方便构造get，set方法
                name = name.substring(0, 1).toUpperCase() + name.substring(1);
                String type = field[i].getGenericType().toString();
                if (type.equals("class java.lang.String")) { // 如果type是类类型，则前面包含"class "，后面跟类名
                    Method m = model.getClass().getMethod("get" + name);
                    String value = (String) m.invoke(model); // 调用getter方法获取属性值
                    if (value == null) {
                        m = model.getClass().getMethod("set"+name,String.class);
                        m.invoke(model, voluationMap.get(getFromMapName));
                    }
                }
                if (type.equals("class java.lang.Integer")) {
                    Method m = model.getClass().getMethod("get" + name);
                    Integer value = (Integer) m.invoke(model);
                    if (value == null) {
                        m = model.getClass().getMethod("set"+name,Integer.class);
                        m.invoke(model, voluationMap.get(getFromMapName));
                    }
                }
                if (type.equals("class java.lang.Short")){
                    Method m = model.getClass().getMethod("get"+name);
                    Short value = (Short) m.invoke(model);
                    if (value == null) {
                        m = model.getClass().getMethod("set"+name,Integer.class);
                        m.invoke(model, voluationMap.get(getFromMapName));
                    }
                }
                if (type.equals("class java.lang.Boolean")) {
                    Method m = model.getClass().getMethod("get" + name);
                    Boolean value = (Boolean) m.invoke(model);
                    if (value == null) {
                        m = model.getClass().getMethod("set"+name,Boolean.class);
                        m.invoke(model, voluationMap.get(getFromMapName));
                    }
                }
                if (type.equals("class java.util.Date")) {
                    Method m = model.getClass().getMethod("get" + name);
                    Date value = (Date) m.invoke(model);
                    if (value == null) {
                        m = model.getClass().getMethod("set"+name,Date.class);
                        m.invoke(model, voluationMap.get(getFromMapName));
                    }
                }
            }
        }catch (Exception ex){

        }
        return model;
    }

    /**
     * 获取图片上传的拼接路径
     * @param spId
     * @return
     */
    protected String getUploadImgPath(Long spId){
       return Joiner.on(Const.SEPARATE_XIE).join(spId,"img",
                CalendarUtil.getFormatDateString(new Date(),CalendarUtil.SHORT_DATA_FORMAT_YYYY_MMDD)
                        .concat(Const.SEPARATE_XIE));
    }

    /**
     * 获取上传原视频的拼接路径
     * @param spId
     * @param bussinessUUID
     * @param gfmt
     * @return
     */
    protected String getUploadVodPath(Long spId,String bussinessUUID,String gfmt){
        return Joiner.on(Const.SEPARATE_XIE).join(spId,"raw",
                CalendarUtil.getFormatDateString(new Date(),CalendarUtil.SHORT_DATA_FORMAT_YYYY_MMDD),
                spId + Const.XIA_HUA_XIAN + bussinessUUID)
                .concat(Const.VALUE_POINT).concat(gfmt);
    }

    /**
     * 获取抽帧的图片拼接路径
     * @param spId
     * @return
     */
    protected String getChouzhenPath(Long spId){
        return Joiner.on(Const.SEPARATE_XIE).join(spId,"img",
                CalendarUtil.getFormatDateString(new Date(),CalendarUtil.SHORT_DATA_FORMAT_YYYY_MMDD));
    }

    protected boolean checkCustom(HttpServletRequest request){
        CustomModel customModel = customService.getById(getCustomId(request));
        if(customModel.getSpId() == null || 0!= customModel.getSpId().intValue()){
            return false;
        }
        return true;
    }

    protected boolean checkIsSpAdmin(HttpServletRequest request){
        Long customId = this.getCustomId(request);
        CustomModel customModel = customService.getById(customId);
        if(customModel.getIsParent() != null
                && Const.IS_PARENT_YES.intValue() == customModel.getIsParent().intValue()){
            return true;
        }
        return false;
    }

   /**
    * 去掉链接中域名http://www.cnlive.com/test/test.jpg ===>test/test.jpg
    * @param url
    * @return
    */
    protected  String replaceHost(String url) {
    	if(StringUtils.isNotBlank(url)){
	        Pattern pattern = Pattern.compile("^(http|https)://(.+?)/");
	        Matcher matcher = pattern.matcher(url);
	        url = matcher.replaceAll("");
    	}
        return url;
    }

    /**
     * Head请求一个bucket
     */
    public boolean checkBucketExtis(String bucketName, StorageTypeEnum type) {
        if(StorageTypeEnum.KSYUN == type){
            try{
                Ks3 client = this.getKs3Client();
                client.setEndpoint(uploadImgRegion);
                /**
                 * 通过result.getStatueCode()状态码 404则这个bucket不存在，403当前用户没有权限访问这个bucket
                 */
                HeadBucketResult result = client.headBucket(bucketName.trim());
                int statueCode = result.getStatueCode();
                if(HttpStatus.SC_NOT_FOUND == statueCode || HttpStatus.SC_FORBIDDEN == statueCode){
                    return false;
                }
            }catch (Exception ex){
                _log.error("ksyun checkBucketExtis error = {}",ex);
                return false;
            }
            return true;
        }
        if(StorageTypeEnum.QINIUYUN == type){
            try {
                Configuration configuration = new Configuration(Zone.autoZone());
                BucketManager bucketManager = new BucketManager(getQnAuth(),configuration);
                String[] strings = bucketManager.domainList(bucketName.trim());
                if(strings.length > 0){
                    return true;
                }
            } catch (QiniuException e) {
                _log.error("qnyun checkBucketExtis error =  {},msg={}",e.code(),e.getMessage());
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }

    /**
     * 获取金山client
     * @return
     */
    protected Ks3 getKs3Client(){
        Ks3 client = new Ks3Client(ksConfigAK, ksConfigSK);
        return client;
    }

    /**
     * 获取七牛 auth
     * @return
     */
    private Auth getQnAuth(){
        Auth auth = Auth.create(qiniu_ksConfigAK, qiniu_ksConfigSK);
        return auth;
    }

    /**
     * 获取七牛的token
     * @param bucketName
     * @return
     */
    protected String getTokenForQN(String bucketName){
        if(StringUtils.isEmpty(bucketName)){
            bucketName = bucket_qiniu_default;
        }
        Auth qnAuth = getQnAuth();
        return qnAuth.uploadToken(bucketName, null, 3600, null, true);
    }

}
