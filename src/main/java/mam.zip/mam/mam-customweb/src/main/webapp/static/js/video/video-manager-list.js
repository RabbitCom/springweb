var params = {},
    index = 0,
    category_obj = {},
    videoName_arr = [],
    solrRetrieve = false,//true为solr搜索
    timestamp = Date.parse(new Date());
var lcsetting = {
    "ajax": basePath + "videoController/dataGrid.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [{
        "data": "lcall",
        "format": function(i, j, d) {
            if (d.albumId != undefined) {
                return '<input type="checkbox"  createUser-id="' + d.createUserId + '" category-id="' + d.category + '" customCategory-id=' + d.customCategoryId + ' data-id="' + d.videoId + '" data-albumId="' + d.albumId + '" value="" name="ck" class="checkItem">';
            } else {
                return '<input type="checkbox"  createUser-id="' + d.createUserId + '" category-id="' + d.category + '" customCategory-id=' + d.customCategoryId + ' data-id="' + d.videoId + '" data-albumId="" value="" name="ck" class="checkItem">';
            }
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
            var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<dl class="clearfix">' +
                '<dt class="ui-fl img">' +
                '<a class="video-view"  videoPlyUrl ="' + d.playUrl + '" videoPlyImgUrl = "'+ d.listPicUrl +'" href="#modal-video-view" data-toggle="modal" ><img src=' + getListPicUrl(d.listPicUrl) + '></a>' +
                '</dt>' +
                '<dd class="ui-fl album-info">' +
                '<p>' + LCT("ID") + '：' + d.businessUUID + '</p>' +
                '<p class="videoName"></p>' +
                '<p>' + LCT("时长") + '：<span class="video-duration">' + vrsFn.formatSeconds(d.duration) + '</span></p>' +
                '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                '</dd>' +
                '</dl>';
        }
    },  {
        "data": "lcall",
        "className": 'videoStatus',
        "format": function(i, j, d) {
            function parese(s) {
            	if (s == -1) {
                    return '<span class="link-blue-txt">' + LCT("初始化") + '</span>';
                }
                if (s == 0) {
                    return '<span class="link-blue-txt">' + LCT("待编辑") + '</span>';
                }
                if (s == 1) {
                    return '<span class="link-blue-txt">' + LCT("已编辑") + '</span>';
                }
                if (s == 2) {
                    return '<span class="link-blue-txt">' + LCT("审核中") + '</span>';
                }
                if (s == 3) {
                    return '<span class="link-blue-txt">' + LCT("审核通过") + '</span>';
                }
                if (s == 4) {
                    return '<span class="link-blue-txt">' + LCT("审核拒绝") + '</span>';
                }
                if (s == 5) {
                    return '<span class="link-blue-txt">' + LCT("上线") + '</span> ';
                }
                if (s == 6) {
                    return '<span class="link-blue-txt">' + LCT("下线") + '</span>';
                }
                if (s == 7) {
                    return '<span class="link-blue-txt">' + LCT("发布中") + '</span>';
                }
                if (s == 8) {
                    return '<span class="link-blue-txt">' + LCT("发布成功") + '</span>';
                }
                if (s == 9) {
                    return '<span class="link-blue-txt">' + LCT("发布失败") + '</span>';
                }
            }
            return parese(d.status); //视频状态
        }
    }, {
        "data": "lcall",
        "className": 'fileStatus',
        "format": function(i, j, d) {
            function parese(z) {
            	if (z == -1) {
            		return '<span class="link-blue-txt">' + LCT("上传中") + '</span>';
            	} 
                if (z == 0) {
                    return '<span class="link-blue-txt">' + LCT("上传完成") + '</span>';
                } 
                if (z == 1) {
                    return '<span class="link-blue-txt">' + LCT("转码中") + '</span>';
                } 
                if (z == 2) {
                    return '<span class="link-blue-txt">' + LCT("转码成功") + '</span>';
                } 
                if (z == 3) {
                    return '<span class="link-blue-txt">' + LCT("转码失败") + '</span><p>'
                        +'<a class="transcodingDetails" style="color: red;" data-toggle="modal" href="#modal-transcoding-details" data-id="' + d.videoId + '">' + "查看原因" + '</a >';
                }
            }
            return parese(d.fileStatus); //媒资状态
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) { //上传时间
            return d.createTime;
        }
    },{
        "data": "lcall",
        "className": 'commentSet',
        "format": function(i, j, d) {
            var editorAlbum = "";
            if(d.albumId == 'undefined' || d.albumId == undefined || d.albumId == 0 || d.albumId == '0' || d.albumId == null){
                editorAlbum = '<br/><a data-toggle="modal" href="#modal-select-zhuanjiId" category-id="' + d.category + '" customCategory-id=' + d.customCategoryId + ' data-id="' + d.videoId + '" data-albumId="" class="ml-10 joinEditor">' + LCT("加入专辑") + '</a><br/><a data-toggle="modal" href="#modal-set-feilei" category-id="' + d.category + '" customCategory-id=' + d.customCategoryId + ' data-id="' + d.videoId + '"  class="ml-10 fenlei-set">' + LCT("分类设置") + '</a>'
            }
            var editPage = '<a href="javascript:void(0)" class="video-edit ml-10" category-id="' + d.category + '" customcategory-id="' + d.customCategoryId + '" data-albumId="' + d.albumId + '" data-id="' + d.videoId + '">' + LCT("编辑") + '</a>';
            //var preview = '<a href="#modal-video-view" data-toggle="modal" class="video-view ml-10" custom-id="' + d.customId + '" data-id="' + d.videoId + '">' + LCT("预览") + '</a>';
            var deleteBtn = '<br/><a href="#modal-detele" data-toggle="modal" data-id="' + d.videoId + '" class="ml-10 detele">' + LCT("删除") + '</a>';
            var onlineBtn = '<br/><a href="javascript:void(0)" data-id="' + d.videoId  +'" class="ml-10 online">' + LCT("上线") + '</a>';
            var downlineBtn = '<br/><a href="javascript:void(0)" data-id="' + d.videoId  +'" class="ml-10 downline">' + LCT("下线") + '</a>';
            var _content = '<br/><a href="javascript:void(0)"  class="video-audit ml-10" data-id="' + d.videoId + '">' + LCT("视频信息") + '</a>';
            var showcmsurl = '<br/><a href="####" onclick="javascript:window.open(\'' + d.videoPlyUrl + '\')">播放页面</a>';

            var sucai = d.isIcms2Mam;
            if(sucai == 1){
                return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  +editPage + _content +'</p>';
            }

            var reTransCodeBtn = '';
            if(d.fileStatus == 3){
                var reTransCodeBtn = '<br/><a href="javascript:void(0)"  data-id="' + d.videoId  +'" class="ml-10 reTransCode">' + LCT("重转码") + '</a>';
            }

            var playerCode = "";
            if(d.status >=5 && d.fileStatus == 2 && d.status != 6){
                playerCode = '<br/><a data-toggle="modal" href="#modal-playCode-details" data-id="' + d.spid +'_'+ d.businessUUID  +'"  data-picUrl="'+d.listPicUrl+'" class="playerCodeShow">' + LCT("外嵌播放代码") + '</a>';
            }

            function parese(vs,fs) {
                if(vs == 0){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + editorAlbum + deleteBtn  + reTransCodeBtn +'</p>';
            	}
            	//编辑、查看、删除
            	if(vs == 1 || (vs == 4 )){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage + editorAlbum+deleteBtn  + _content + reTransCodeBtn + '</p>';
            	}
            	//预览、查看
            	if(vs == 2 ){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + _content +editorAlbum+  reTransCodeBtn +'</p>';
            	}
            	//编辑、上线、查看、删除
            	if(vs == 3 ){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage  +editorAlbum+ onlineBtn + _content + deleteBtn + reTransCodeBtn +'</p>';
            	}
            	//编辑、下线、查看
            	if((vs == 5 ) ){
            		return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage +editorAlbum+ downlineBtn + _content + reTransCodeBtn+playerCode+'</p>';
            	}
                //编辑、上线、查看、删除
                if((vs == 6 )  ){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + editPage +editorAlbum+ onlineBtn + deleteBtn + _content + reTransCodeBtn +playerCode+'</p>';
                }
                //编辑、查看
                if(vs == 7 ){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>'  + editPage +editorAlbum+ _content + reTransCodeBtn +playerCode+'</p>';
                }
            	if(vs == 8){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + downlineBtn + _content +showcmsurl+playerCode+'</p>';
                }
                if(vs == 9){
                    return '<a href="javascript:void(0)" class="handle">' + LCT("操作") + '</a><p>' + downlineBtn + _content +showcmsurl+playerCode+'</p>';
                }

            }
            return parese(d.status,d.fileStatus);
        }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "emptymsg": LCT("暂无数据"),
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); //table全选
        //操作
        $("#maintable").on("mouseover", ".commentSet", function() {
            $(this).find("a.handle").hide();
            $(this).find("p").show();
        }).on("mouseout", ".commentSet", function() {
            $(".commentSet a.handle").show();
            $(".commentSet p").hide();
        });
        // $("#maintable").on("mouseover", ".videoStatus", function() {
        //     $(this).find("a.showTransCodeFailInfo").removeClass("hide");
        // }).on("mouseout", ".videoStatus", function() {
        //     $("a.showTransCodeFailInfo").addClass("hide");
        // });
        //视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(LCT("名称") + '：'+remark_html);
            $(tr[i]).find("a.video-view").attr("data-name", remark_html);
            $(tr[i]).find("a.playbackSettings").attr("data-name", remark_html);
        }
        videoName_arr = [];
    }
};
var videoFn = {
    init: function() {
    	this.mltiSelect(); //多状态查询
        this.handleTable(); //表格数据筛选
       // this.albumStatus(); //获取初始上下线状态
        this.systemCatagory(); //大数据分类
        this.fenlei(); //分类设置
        this.joinAlbum(); //加入专辑
        this.derivedExcel(); //Excel导出
        this.editPreview(); //编辑预览
        this.deteleVideo(); //视频删除
        this.transcodingDetails(); //转码情况
        this.onoffline();//上下线
        this.videoAudit(); //查看
        this.reTransCode();//重新转码
        this.showPlayerCode(); //播放器嵌入代码
        this.packToZip(); //打包zip下载
    },
    mltiSelect: function() {
    	var input = $("input[name='video-status']");
    	var video_status;
        var video_status_valArr = [];
        var video_status_textArr = [];
        if (!$("input[name='video-status']:checked").length) {
            $(".video-status-result").html("请选择").attr("onoffStatus", "");;
        } else {
            for (var i = 0; i < input.length; i++) {
                if (input[i].checked) {
                    var video_status_val = $(input[i]).val();
                    var video_status_text = $(input[i]).closest("li").text();
                    video_status_valArr.push(video_status_val);
                    video_status_textArr.push(video_status_text);
                    video_status = video_status_valArr.join(",")
                    if (video_status_valArr.length) {
                        $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                    }
                }
            }
        }
        $(".video-status-result").click(function() {
            if ($(".option-items").is(":visible")) {
                $(".option-items").addClass("hide");
            } else {
                $(".option-items").removeClass("hide");
            }
        });
        $(".select-checkbox").mouseleave(function() {
            $(".option-items").addClass("hide");
        });
        $("#video_status_choose").click(function(){
        	var input = $("input[name='video-status']");
        	if($("input[name='video-status']:checked").length){
        		for(i = 0; i < input.length; i++){
        			 if (input[i].checked) {
        				 input[i].checked = false;
        			 }
        		}
        	} 
        });
        $(".select-checkbox .btn_ok").click(function() {
        	var input = $("input[name='video-status']");
        	var video_status;
            var video_status_valArr = [];
            var video_status_textArr = [];
            if (!$("input[name='video-status']:checked").length) {
                $(".video-status-result").html("请选择").attr("onoffStatus", "");;
            } else {
                for (i = 0; i < input.length; i++) {
                    if (input[i].checked) {
                        var video_status_val = $(input[i]).val();
                        var video_status_text = $(input[i]).closest("li").text();
                        video_status_valArr.push(video_status_val);
                        video_status_textArr.push(video_status_text);
                        video_status = video_status_valArr.join(",")
                        if (video_status_valArr.length) {
                            $(".video-status-result").html(video_status_textArr + " ").attr("onoffStatus", video_status);
                        }
                    }
                }
            }
            $(".option-items").addClass("hide");
            var onoff  = $(".video-status-result").attr("onoffstatus");
        	if (onoff) {
            	params["onoffStatus"] = onoff;
            } else {
            	params["onoffStatus"] = "0,1,2,3,4,5,6,7,8,9";
            }

            var fileStatus = $.trim($(".search_select option:selected").val());
            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }

            lcsetting.thisPage = 1;
            solrRetrieve = false;
            selectSolr(solrRetrieve);
            $("#maintable").lctable(lcsetting, params);
        });
    },
    handleTable: function() {
        //初始化表格
//        if (videoFn.albumStatus().length) {
//            params["onoffStatus"] = videoFn.albumStatus();
//        } else {
//            delete params["onoffStatus"];
//        }
    	var onoff  = $(".video-status-result").attr("onoffstatus");
    	if (onoff) {
        	params["onoffStatus"] = onoff;
        } else {
            delete params["onoffstatus"];
        }
        videoName_arr = [];
        selectSolr(solrRetrieve);
        $("#maintable").lctable(lcsetting, params);
        //点击搜索按钮
        $(".btn_search").bind("click", function() {
//        	var param = {};
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var fileStatus = $.trim($(".search_select option:selected").val());

            if (fileStatus) {
                params["fileStatus"] = fileStatus;
            } else {
                delete params["fileStatus"];
            }
//            var onoffstatus = $(".video-status-result").attr("onoffstatus");
//            videoFn.albumStatus();
//            if (videoFn.albumStatus().length) {
//                params["onoffStatus"] = videoFn.albumStatus();
//            } else {
//                delete params["onoffStatus"];
//            }
            if (value_name) {
                params["videoName"] = value_name;
            } else {
                delete params["videoName"];
            }
//            if (onoffstatus) {
//            	param["onoffStatus"] = onoffstatus;
//            } else {
//                delete param["onoffstatus"];
//            }
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
            var custom_name = $.trim($(".search_customName").val());
            if(custom_name){
                params["createCustomName"] = custom_name;
            }else {
                delete params["createCustomName"];
            }
            var uploadStartTime = $.trim($("#d4311").val());
            var uploadEndTime = $.trim($("#d4312").val());
            if(uploadStartTime){
                params["startTime"] = uploadStartTime;
            }else{
                delete params["startTime"];
            }
            if(uploadEndTime){
                params["endTime"] = uploadEndTime;
            }else{
                delete params["endTime"];
            }
            lcsetting.thisPage = 1;
            solrRetrieve = false;
            selectSolr(solrRetrieve);
            $("#maintable").lctable(lcsetting, params);
        });

        $(".btn-solr").bind("click", function () {
            var value_name = $.trim($(".search_solr_name").val());
            if (value_name) {
                params["videoName_solr"] = value_name;
            } else {
                delete params["videoName_solr"];
            }
            lcsetting.thisPage = 1;
            solrRetrieve = true;
            selectSolr(solrRetrieve);
            $("#maintable").lctable(lcsetting, params);
        });
    },
    onoffline: function(){
    	$("#maintable").on("click", ".online", function() {
    		var videoId = $(this).attr("data-id");
    		console.log(videoId);
    		$.ajax({
    			url: basePath + "videoController/onlinestatus.do",
    			data: "videoId=" + videoId,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT( "成功"));
                        if (solrRetrieve) {
                            $(".btn-solr").click();
                        } else {
                            // $(".btn_search").click();
                            search_state();
                        }

                    } else {
                        alertfn.danger(data.msg);
                    }
                }
    		})
    	});
    	//批量上线
    	$("#mul-online").click(function() {
    		 var arr = $("#maintable .checkItem:checked");
             var ids = "";
             var flag = true;
             $(arr).each(function(i,e) {
            	var onlineArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(onlineArr).find("a.online");
         		if(!aArr[0]){
         			flag = false;
         			alertfn.danger("包含未达到上线条件的视频，请重新选择");
                    return false;
         		}
                 if (i >= arr.length - 1) {
                     ids += $(arr).eq(i).attr("data-id");
                     return false;
                 }
                 ids += $(arr).eq(i).attr("data-id") + ",";
             });
             if(flag){
            	 if (arr.length > 0) {
	            	 $.ajax({
	          			url: basePath + "videoController/onlinestatus.do",
	          			data: "videoId=" + ids,
	                     type: "post",
	                     dataType: "json",
	                      success: function(data) {
	                          if (data.success) {
	                              alertfn.success(LCT( "成功"));
	                              // $(".btn_search").click();
                                  if (solrRetrieve) {
                                      $(".btn-solr").click();
                                  } else {
                                      // $(".btn_search").click();
                                      search_state();
                                  }
	                          } else {
	                              alertfn.danger(data.msg);
	                          }
	                      }
	          		})
	             }else{
	            	 alertfn.danger(LCT("请先选中一条视频"));
                     return false;
	             }
             }
    	});
    	
    	$("#maintable").on("click", ".downline", function() {
    		var videoId = $(this).attr("data-id");
    		console.log(videoId);
    		$.ajax({
    			url: basePath + "videoController/downlinestatus.do",
    			data: "videoId=" + videoId,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                        alertfn.success(LCT( "成功"));
                        // $(".btn_search").click();
                        if (solrRetrieve) {
                            $(".btn-solr").click();
                        } else {
                            // $(".btn_search").click();
                            search_state();
                        }
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
    		})
    	});
    	//批量下线
    	$("#mul-offline").click(function() {
    		var arr = $("#maintable .checkItem:checked");
            var ids = "";
            var flag = true;
            $(arr).each(function(i,e) {
            	var downlineArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(downlineArr).find("a.downline");
        		if(!aArr[0]){
        			flag = false;
            		alertfn.danger("包含未达到下线条件的视频，请重新选择");
            		return;
        		}
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if(flag){
            	if (arr.length > 0) {
            		$.ajax({
             			url: basePath + "videoController/downlinestatus.do",
             			data: "videoId=" + ids,
                         type: "post",
                         dataType: "json",
                         success: function(data) {
                             if (data.success) {
                                 alertfn.success(LCT( "成功"));
                                 // $(".btn_search").click();
                                 if (solrRetrieve) {
                                     $(".btn-solr").click();
                                 } else {
                                     // $(".btn_search").click();
                                     search_state();
                                 }
                             } else {
                                 alertfn.danger(data.msg);
                             }
                         }
             		})
            	}else{
            		 alertfn.danger(LCT("请先选中一条视频"));
            	}
            	 
            }
    	});
    },
    videoAudit: function(){
    		$("#maintable").on("click", ".video-audit", function() {
    			var videoId = $(this).attr("data-id");
    			var lc_inner_href = basePath + "videoController/toVideoView.do?videoId=" + videoId;
                showInIFrame(lc_inner_href);
    		});
    },
    reTransCode:function(){
    	$("#maintable").on("click", ".reTransCode", function() {
    		var videoModel=$(this);
    		var videoId = videoModel.attr("data-id");
    		if(videoId!=null){
    			videoModel.text( LCT("转码中"));
    			videoModel.removeAttr("data-id");
    			$.ajax({
        			url: basePath + "videoController/reTransCode.do",
        			data: {videoId:videoId},
                    type: "post",
                    dataType: "json",
                    success: function(data) {
                        if(data.success) {
                            // $(".btn_search").click();
                            if (solrRetrieve) {
                                $(".btn-solr").click();
                            } else {
                                // $(".btn_search").click();
                                search_state();
                            }
                        }else{
                        	videoModel.text( LCT("重转码"));
                        	videoModel.attr("data-id",videoId);
                        }
                    }
        		})
    		}
    	});
    },
    showPlayerCode :function () {
        $("#maintable").on("click", ".playerCodeShow", function() {
            var jiemu_id = $(this).attr("data-id");
            var poster = $(this).attr("data-picUrl");
            var width = 800;
            var height = 450;
            $("#jiemu_id_hidden").val(jiemu_id);
            $("#poster_url").val(poster);
            $("#width_v").val(width);
            $("#height_v").val(height);
            var playCode = '<iframe src="http://z.cnlive.com/videoplay.html?'
                + 'vid='+jiemu_id+'&poster='+poster+'"'
                + ' style="border: 0;width: '+width+'px;height: '+height+'px;"></iframe>';

            var showHtml = '<textarea id="playerCode_text" disabled style="width: 100%;height: 100px;">'+playCode+'</textarea>'
            $("#showCode_div").html(showHtml);
        });

        $("#modal-playCode-details").on("hide.bs.modal", function() {
            $("#showCode_div").html("");
        });

        $("#copy-playCode").zclip({
            path: basePath + 'static/js/video/ZeroClipboard.swf', //记得把ZeroClipboard.swf引入到项目中
            copy: function(){
                var jiemu_id_get = $("#jiemu_id_hidden").val();
                var poster_get = $("#poster_url").val();
                var width_get = $("#width_v").val();
                var height_get = $("#height_v").val();
                var playCode_get = '<iframe src="http://z.cnlive.com/videoplay.html?'
                    + 'vid='+jiemu_id_get+'&poster='+poster_get+'"'
                    + ' style="border: 0;width: '+width_get+'px;height: '+height_get+'px;"></iframe>';
                $("#playerCode_text").text(playCode_get);
                return $("#playerCode_text").val();
            },
            afterCopy:function(){/* 复制成功后的操作 */
                var $copysuc = $("<div class='copy-tips' style='z-index:9999'><div class='copy-tips-wrap'>☺ 复制成功</div></div>");
                $("body").find(".copy-tips").remove().end().append($copysuc);
                $(".copy-tips").fadeOut(3000);
            }
        });

    },
    albumStatus: function() {
        var albumStatus_arr = [];
        var icon_checkbox = $(".search-info label");
        for (var i = 0; i < icon_checkbox.length; i++) {
            if ($(icon_checkbox[i]).find("input:checked").length) {
                albumStatus_arr.push($(icon_checkbox[i]).find("input").attr("albumstatus"));
            }
        }
        return albumStatus_arr;
    },
    systemCatagory: function() {
        //获取大分类category
        $.getJSON(
            basePath + "customCategoryController/getCategorys.do",
            function(data) {
                var system_channel = '';
                system_channel += '<option data-id="0" value=' + LCT("请选择") + '>' + LCT("请选择") + '</option>';
                for (var i = 0; i < data.length; i++) {
                    var showName = data[i].showName;
                    var dicValue = data[i].dicValue;
                    system_channel += '<option data-id=' + dicValue + ' value=' + showName + '>' + showName + '</option>';
                }
                $(".systemCatagory").attr("data-id", '0').html(system_channel);
                $(".systemCatagory-modal").attr("data-id", '0').html(system_channel);
            }
        );
        //数据分类筛选
        $(".systemCatagory").on("change", function() {
        	  var categoryId = $(this).children('option:selected').attr("data-id");
              $(".systemCatagory").attr("data-id", categoryId);
              category_obj = {};
              category_obj.category = categoryId;
              if (categoryId == "0") {
                  $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>' + vrsFn.customCategoryInitDom);
              } else {
                  $("#setClass").html('<label>' + LCT("自定义分类") + '：</label>');
                  buildEdit.start = false;
                  buildEdit.init("setClass");
              }

              delete params["customCategoryId"];
              params["category"] = categoryId;
              lcsetting.thisPage = 1;
              solrRetrieve = false;
              selectSolr(solrRetrieve);
              $("#maintable").lctable(lcsetting, params);
        });
        //分类设置-数据分类
        $(".systemCatagory-modal").on("change", function() {
            var categoryId = $(this).children('option:selected').attr("data-id");
            $(".systemCatagory-modal").attr("data-id", categoryId);
            category_obj.category = categoryId;
            $("#editClass").html("");
            buildEdit.init("editClass");
        });
    },
    fenlei: function() {
        $("#maintable").on("click", ".fenlei-set", function() {
            var videoId = $(this).attr("data-id");
            var categoryId = $(this).attr("category-id");
            var customcategoryId = $(this).attr("customcategory-id");
            if (categoryId != '0') {
                $(".systemCatagory-modal option[data-id='" + categoryId + "']").prop("selected", true);
                $(".systemCatagory-modal").attr("data-id", categoryId);
                category_obj.category = categoryId;
                category_obj.categorys = categoryId; //推荐分类
                if (buildEdit.start) {
                    return
                }
                buildEdit.init("editClass");
            } else {
                $("#editClass").html(vrsFn.customCategoryInitDom);
            }
            $("#modal-set-feilei").attr({
                "video-id": videoId,
                "customcategory-id": customcategoryId,
                "category-id": categoryId
            });

            if (customcategoryId != 0 && customcategoryId != null) {
                var obj = classfiyObject.getPidAndId(customcategoryId, window.classfiyObject_obj, 1);
                $("#set-feilei-ok").prop("flag", obj._level);
                if (obj._level == 1) {
                    $("#editClass").find("select").eq(0).find("option[data-id=" + customcategoryId + "]").prop("selected", true);
                } else if (obj._level == 2) {
                    $("#editClass").find("select").eq(0).find("option[data-id=" + obj._pid + "]").prop("selected", true);
                    $("#editClass").find("select").eq(0).change();
                    $("#editClass").find("select").eq(1).find("option[data-id=" + obj._id + "]").prop("selected", true);
                } else if (obj._level == 3) {
                    var obj3 = classfiyObject.getPidAndId(obj._pid, window.classfiyObject_obj, 1);
                    $("#editClass").find("select").eq(0).find("option[data-id=" + obj3._pid + "]").prop("selected", true);
                    $("#editClass").find("select").eq(0).change();
                    $("#editClass").find("select").eq(1).find("option[data-id=" + obj._pid + "]").prop("selected", true);
                    $("#editClass").find("select").eq(1).change();
                    $("#editClass").find("select").eq(2).find("option[data-id=" + obj._id + "]").prop("selected", true);
                }
            }
        });
        $("#set-feilei-ok").click(function() {
            var arr = $("#editClass option:selected");
            var videoId = $("#modal-set-feilei").attr("video-id");
            var categoryId = $("#modal-set-feilei").attr("category-id");
            var customcategoryId = $("#modal-set-feilei").attr("customcategory-id");
            var ids, category_selected;
            category_selected = $(".systemCatagory-modal").attr("data-id");
            for (var i = arr.length - 1; i >= 0; i--) {
                if ($(arr).eq(i).attr("data-id")) {
                    ids = $(arr).eq(i).attr("data-id");
                    break;
                }
            }

            if (typeof(ids) == "undefined") {
                ids = 0;
            }
            //直接保存or跳转编辑页
            if (category_selected != categoryId) {
                var lc_inner_href = basePath + 'videoController/toVideoEdit.do?videoId=' + videoId + '&editCategory=' + category_selected + '&editCustomCategory=' + ids;
                $('#modal-set-feilei').modal('hide');
                showInIFrame(lc_inner_href);
            } else {
                if (customcategoryId == ids) {
                    $('#modal-set-feilei').modal('hide');
                } else {
                    $.ajax({
                        url: basePath + "videoController/setVideoCustomCategory.do",
                        data: "category=" + category_selected + "&customCategoryId=" + ids + "&videoId=" + videoId,
                        type: "post",
                        dataType: "json",
                        success: function(data) {
                            if (data.success) {
                                var cur_tr = $("#maintable").find("input[data-id=" + videoId + "]").closest("tr");
                                $('#modal-set-feilei').modal('hide');
                                cur_tr.find("input").attr("customcategory-id", ids);
                                cur_tr.find("a").attr("customcategory-id", ids);
                                alertfn.success(data.msg);
                            } else {
                                alertfn.danger(data.msg);
                            }
                        }
                    });
                }
            }
            return false;
        });
        $('#modal-set-feilei').on('hide.bs.modal', function() {
            $("#editClass").html("");
            $(".systemCatagory-modal option[data-id='0']").prop("selected", true);
            $(".systemCatagory-modal").attr("data-id", 0);
            buildEdit.start = false;
            if (buildEdit.editNameDom.has("label").length) {
                buildEdit.editNameDom.find("label").remove();
            }
        });
        $("#maintable").on("click", ".icon-set", function() {
            jumpOutUrl("vrsCategory");
        });

    },
    joinAlbum: function() {
        //单个加入专辑
        $("#maintable").on("click", ".joinEditor", function() {
            var categoryId = $(this).attr("category-id");
            var customCategoryId = $(this).attr("customcategory-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumid");
            $("#modal-select-zhuanjiId").attr("video-id", videoId);
            $(".search_name_modal").val("");
            joinEditor_table(categoryId, customCategoryId, albumId);
        });
        //批量加入专辑
        $("#videoMulti").click(function() {
            var mul_albumId = [];
            var mul_categoryId = [];
            var mul_customcategoryId = [];
            $(this).attr("href", "");
            var arr = $("#maintable .checkItem:checked");
            var ids = "";
            $(arr).each(function(i) {
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if (arr.length > 0) {
                for (var i = 0; i < arr.length; i++) {
                    mul_albumId.push($(arr[i]).attr("data-albumid"));
                    mul_categoryId.push($(arr[i]).attr("category-id"));
                    mul_customcategoryId.push($(arr[i]).attr("customcategory-id"));
                }
                if ((unique(mul_albumId).length > 1) || (unique(mul_albumId).length == 1 && mul_albumId[0] != 0)) {
                    alertfn.danger(LCT("您所选择部分视频已有所属专辑，请重新选择"));
                    return false;
                }
                if (unique(mul_categoryId).length > 1 || unique(mul_customcategoryId).length > 1) {
                    alertfn.danger(LCT("所选视频不在同一分类下"));
                    return false;
                }
                var categoryId = $(arr[0]).attr("category-id");
                $(this).attr("href", "#modal-select-zhuanjiId");
                $("#modal-select-zhuanjiId").attr("video-id", ids);
                $(".search_name_modal").val("");
                var customCategoryId = mul_customcategoryId[0];
                joinEditor_table(categoryId, customCategoryId, null);
            } else {
                alertfn.danger(LCT("请先选中一条记录"));
            }
        });
        
        
        
        //提交加入专辑
        $("#btn-zhuanji").click(function() {
            var arr = [];
            var join_albumId_checked = $("#maintable_modal").find(".iradio_flat-red.checked").find("input");
            var join_albumId = join_albumId_checked.attr("data-albumid");
            var join_categoryId = join_albumId_checked.attr("category-id");
            var join_customcategoryId = join_albumId_checked.attr("customcategory-id");
            var join_videoId = $("#modal-select-zhuanjiId").attr("video-id");
            if (join_albumId_checked.length) {
                $.post(basePath + 'videoController/toJoinAlbum.do', {
                    videoIds: join_videoId,
                    albumId: join_albumId
                }, function(result) {
                    if (result.success) {
                        arr = join_videoId.split(",");
                        for (var i = 0; i < arr.length; i++) {
                            $("#maintable").find("a.joinEditor[data-id=" + arr[i] + "]").remove();
                            $("#maintable").find("a.fenlei-set[data-id=" + arr[i] + "]").remove();
                            $("#maintable").find("a.video-edit[data-id=" + arr[i] + "]").attr({
                                "category-id": join_categoryId,
                                "customcategory-id": join_customcategoryId
                            });
                            $("#maintable").find("input[data-id=" + arr[i] + "]").attr("data-albumid", join_albumId);
                        }
                        alertfn.success(LCT("加入专辑成功"));
                    } else {
                        alertfn.danger(result.msg);
                    }
                }, 'JSON');
            } else {
                alertfn.danger(LCT("未选择要加入的专辑"));
            }
        });
    },
    
    derivedExcel: function() {
        checkall("#modal-excel"); //excel全选
        $("#btn-excel").attr("href", "");
        $("#btn-excel").click(function() {
            var length = $("#maintable tbody td[colspan='6']").length;
            if (length) {
                alertfn.danger(LCT("没有要导出的视频"));
            } else {
                $("#btn-excel").attr("href", "#modal-excel");
            }
        });
        $("#modal-excel").on('hide.bs.modal', function() {
            $("#btn-excel").attr("href", "");
        });
        $("#modal-excel").on("click", ".btn-ok", function() {
            var arr_hearders = [];
            var arr_fields = [];
            var arr_customCategoryId = [];
            var arr_videos = [];
            var value_name = $.trim($(".search_name").val());
            var value_id = $.trim($(".search_id").val());
            var checkbox = $("#modal-excel input:checkbox");
            var checkbox_table = $("#maintable tbody input:checkbox");
            var setClass_option = $("#setClass option:selected");
            var categoryId = $(".systemCatagory").attr("data-id");

            for (i = 0; i < setClass_option.length; i++) {
                var data_id = $(setClass_option[i]).attr("data-id");
                if (data_id != undefined) {
                    arr_customCategoryId.push(data_id);
                }
            }
            var customCategoryId = arr_customCategoryId[arr_customCategoryId.length - 1];
            for (var i = 1; i < checkbox.length; i++) {
                if (checkbox[i].checked) {
                    arr_hearders.push($(checkbox[i]).closest("label").text());
                    arr_fields.push($(checkbox[i]).val());
                }
            }
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    arr_videos.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            if (arr_hearders.length == 0) {
                alertfn.danger(LCT("未选择任何excel导出项"));
            } else {
                videoFn.albumStatus();
                var url = basePath + "exportExcelVideo.do?hearders=" + arr_hearders + "&fields=" + arr_fields;
                if (value_name) {
                    url += "&videoName=" + value_name;
                }
                if (value_id) {
                    url += "&videoId=" + value_id;
                }
                if (videoFn.albumStatus().length) {
                    url += "&onoffStatus=" + videoFn.albumStatus();
                }
                if (customCategoryId) {
                    url += "&customCategoryId=" + customCategoryId;
                }
                if (categoryId != '0') {
                    url += "&category=" + categoryId;
                }
                if (arr_videos.length) {
                    url += "&videoIds=" + arr_videos;
                }
                window.open(url, "_blank");
            }
        });
    },
    editPreview: function() {
        $("#maintable").on("click", ".video-edit", function() {
            var customCategoryId = $(this).attr("customcategory-id");
            var categoryId = $(this).attr("category-id");
            var videoId = $(this).attr("data-id");
            var albumId = $(this).attr("data-albumId");

            if (categoryId && categoryId != "" && categoryId != "0") {
                var lc_inner_href = basePath + "videoController/toVideoEdit.do?videoId=" + videoId;
                showInIFrame(lc_inner_href);
            } else {
                if (albumId != null && albumId != 0) {
                    var params = {
//                        "discription": LCT("请先对专辑") + albumId + LCT("进行分类设置"),
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    }
                } else {
                    var params = {
                        "discription": LCT("请先进行分类设置"),
                        "iconType": "triangle",
                        "confirmBtn": true
                    };
                }
                $("body").toolsalert(params);
                return;
            }
        });
        $("#maintable").on("click", ".video-view", function() {
            var videoPlyUrl = $(this).attr("videoPlyUrl");
            var data_name = $(this).attr("data-name");
            var imgUrl = $(this).attr("videoPlyImgUrl");
            if(imgUrl == "" || imgUrl == null || imgUrl == undefined || imgUrl == "null" || imgUrl == "undefined"){
                imgUrl = "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
            }else {
                imgUrl = imgUrl;
            }
            $("#cnlivePlayer").attr("flashVars","type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1&currRate=2&cover="+imgUrl+"&videoUrl_2="+videoPlyUrl);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $('#modal-video-view').on('hide.bs.modal', function() {
           // $("#player").html("");
        });
    },
    
    deteleVideo: function() {
        $("#maintable").on("click", ".detele", function() {
            var videoId = $(this).attr("data-id");
            $("#modal-detele").attr("video-id", videoId);
            //vrsFn.deteleRecoverVideo(videoId, 2);
        });
        $("#mul-detele").click(function() {
            var arr = $("#maintable .checkItem:checked");
            var flag = true;
            var ids = "";
            var videoIds = [];
            $(arr).each(function(i,e) {
            	var deleteArr = $(e).parent().parent()[0].childNodes[5];
            	var aArr = $(deleteArr).find("a.detele");
        		if(!aArr[0]){
        			flag = false;
            		$("#modal-detele").modal("hide");
            		alertfn.danger(LCT("包含未达到删除条件的视频，请重新选择"));
            		return false;
        		}
                if (i >= arr.length - 1) {
                    ids += $(arr).eq(i).attr("data-id");
                    return false;
                }
                ids += $(arr).eq(i).attr("data-id") + ",";
            });
            if(flag){
            	 if (arr.length > 0) {
                	 $(this).attr("href", "#modal-detele");
                     $("#modal-detele").attr("video-id", ids);
                    //vrsFn.deteleRecoverVideo(ids, 2);
                } else {
                    alertfn.danger(LCT("请先选中一条视频"));
                     return false;
                }
            }
        });
        $("#detele-ok").click(function() {
            var videoId = $("#modal-detele").attr("video-id");
            var delMeg = $("#del-reason").val();
            $.ajax({
                url: basePath + "videoController/removeVideo.do",
            	data: "videoIds=" + videoId + "&delMeg=" + delMeg,
                type: "post",
                dataType: "json",
                success: function(data) {
                    if (data.success) {
                    	$("#modal-detele").modal("hide");
                        alertfn.success(LCT("删除成功"));
                        // $(".btn_search").click();
                        if (solrRetrieve) {
                            $(".btn-solr").click();
                        } else {
                            // $(".btn_search").click();
                            search_state();
                        }
                    } else {
                        alertfn.danger(data.msg);
                    }
                }
            });
        });
        
    },
    buWei: function(dom) {
        var value = $(dom).val();
        if (value.length == 0) {
            return value = "00";
        } else if (value.length == 1) {
            return value = "0" + value;
        } else {
            return value = value;
        }
    },
    totalSeconds: function(moment) {
        var moment_arr = moment.split(":");
        var totalSeconds = parseInt(moment_arr[0]) * 3600 + parseInt(moment_arr[1]) * 60 + parseInt(moment_arr[2]);
        return totalSeconds;
    },
    moveFn: function(con, Con) {
        var l;
        con = document.getElementById(con);
        Con = document.getElementById(Con);
        con.onmousedown = function(ev) {
            var oEvent = ev || event;
            var disX = oEvent.clientX - con.offsetLeft;

            function mouseMove(ev) {
                var oEvent = ev || event;
                var left_min, right_max, cur_seconds;
                var data_duration = $("#modal-playback-settings").attr("data-duration");
                l = oEvent.clientX - disX;
                if (con.id == "left-dot") {
                    left_min = -26;
                    right_max = Con.offsetWidth - con.offsetWidth;
                    cur_seconds = parseFloat((l + 26) * data_duration / 590);
                } else if (con.id == "right-dot") {
                    left_min = 0;
                    right_max = Con.offsetWidth;
                    cur_seconds = parseFloat(l * data_duration / 590);
                }
                if (cur_seconds > data_duration) {
                    cur_seconds = data_duration;
                } else if (cur_seconds < 0) {
                    cur_seconds = 0;
                }
                if (l < left_min) {
                    l = left_min;
                } else if (l > right_max) {
                    l = right_max;
                }
                player.sdk.seekTo(cur_seconds); //时时获取画面
                var cur_duration = vrsFn.formatSeconds(cur_seconds * 1000);
                var cur_duration_arr = cur_duration.split(":");
                con.style.left = l + "px";
                if (con.id == "left-dot") {
                    $(".cell").eq(0).val(cur_duration_arr[0]);
                    $(".cell").eq(1).val(cur_duration_arr[1]);
                    $(".cell").eq(2).val(cur_duration_arr[2]);
                } else if (con.id == "right-dot") {
                    $(".cell").eq(3).val(cur_duration_arr[0]);
                    $(".cell").eq(4).val(cur_duration_arr[1]);
                    $(".cell").eq(5).val(cur_duration_arr[2]);
                }
            }

            function mouseUp() {
                var cur_seconds;
                var left_active = document.getElementById("left-dot");
                var right_active = document.getElementById("right-dot");
                var left_curPos = parseInt(left_active.style.left);
                var right_curPos = parseInt(right_active.style.left);
                right_curPos = right_curPos - con.offsetWidth;
                var data_duration = $("#modal-playback-settings").attr("data-duration");
                if (con.id == "left-dot") {
                    cur_seconds = (l + 26) * data_duration / 590;
                } else if (con.id == "right-dot") {
                    cur_seconds = l * data_duration / 590;
                }
                player.sdk.seekTo(cur_seconds);
                player.sdk.pauseVideo(); //视频暂停
                var cur_duration = vrsFn.formatSeconds(cur_seconds * 1000);
                var cur_duration_arr = cur_duration.split(":");
                var dl = $("#setting-list dl");
                this.onmousemove = null;
                this.onmouseup = null;
                if (con.releaseCapture) {
                    con.releaseCapture();
                }
                for (var i = 0; i < dl.length - 1; i++) {
                    var left_seconds = $(dl[i]).find("input").eq(0).attr("left-moment");
                    var right_seconds = $(dl[i]).find("input").eq(1).attr("right-moment");
                    if (cur_seconds > left_seconds && cur_seconds < right_seconds) {
                        alertfn.danger(LCT("设置片段不能交叉、重复"));
                        break;
                    }
                }
                if (con.id == "left-dot") {
                    if (l > right_curPos) {
                        right_active.style.left = (l + con.offsetWidth) + "px";
                        $(".cell").eq(3).val(cur_duration_arr[0]);
                        $(".cell").eq(4).val(cur_duration_arr[1]);
                        $(".cell").eq(5).val(cur_duration_arr[2]);
                    }
                    $(".cell").eq(0).val(cur_duration_arr[0]);
                    $(".cell").eq(1).val(cur_duration_arr[1]);
                    $(".cell").eq(2).val(cur_duration_arr[2]);
                } else if (con.id == "right-dot") {
                    if ((l - con.offsetWidth) < left_curPos) {
                        left_active.style.left = (l - con.offsetWidth) + "px";
                        $(".cell").eq(0).val(cur_duration_arr[0]);
                        $(".cell").eq(1).val(cur_duration_arr[1]);
                        $(".cell").eq(2).val(cur_duration_arr[2]);
                    }
                    $(".cell").eq(3).val(cur_duration_arr[0]);
                    $(".cell").eq(4).val(cur_duration_arr[1]);
                    $(".cell").eq(5).val(cur_duration_arr[2]);
                }
            }
            if (con.setCapture) {
                con.onmousemove = mouseMove;
                con.onmouseup = mouseUp;
                con.setCapture();
            } else {
                document.onmousemove = mouseMove;
                document.onmouseup = mouseUp;
            }
            return false;
        }
    },
    transcodingDetails: function() {
        $("#maintable").on("click", ".transcodingDetails", function() {
            var videoId = $(this).attr("data-id");
            $.ajax({
                url: basePath + "videoController/showTranCodeFaildInfo.do?videoId=" + videoId,
                type: "get",
                dataType: "json",
                success: function(data) {
                    data = typeof(data) == "string" ? JSON.parse(data) : data;
                    var tranCode_html = '';
                    if (data.obj.length) {
                        for (var i = 0; i < data.obj.length; i++) {
                            var file = data.obj[i];
                            var codeRateText = file.codeRateName;
                            var errorMsg = file.transCodeFailMsg || '';
                            var gfmt = file.transCodeFmt;
                            var fileStatus = file.status;
                            var showStatus = '--';
                            if (fileStatus == -1) {
                                showStatus = "上传中";
                            }
                            else if (fileStatus == 0) {
                                showStatus = "上传完成";
                            }
                            else if (fileStatus == 1) {
                                showStatus = "转码中";
                            }
                            else if (fileStatus == 2) {
                                showStatus = "转码成功";
                            }
                            else if (fileStatus == 3) {
                                showStatus = '<span style="color: red">'+"转码失败"+'</span>';
                            }
                            tranCode_html += '<tr>';
                            tranCode_html += '<td>' + codeRateText + '</td>';
                            tranCode_html += '<td>' + gfmt + '</td>';
                            tranCode_html += '<td>' + showStatus + '</td>';
                            tranCode_html += '<td>' +'<span style="color: red">'+ errorMsg + '</span></td>';
                            tranCode_html += '</tr>';
                        }
                    } else {
                        tranCode_html += '<tr><td colspan="2">暂无记录</td></tr>';
                    }
                    $("#modal-transcoding-details tbody").html(tranCode_html);

                },
                error: function(data) {
                    console.log(data);
                }
            });
        });
        $("#modal-transcoding-details").on("hide.bs.modal", function() {
            $("#modal-transcoding-details tbody").html("");
        });
    },
    packToZip: function () {
        $('#btn-zip').click(function() {
            var url = basePath + "zipDownload.do";
            var pics = [];
            var checkbox_table = $("#maintable tbody input:checkbox");
            for (var i = 0; i < checkbox_table.length; i++) {
                if (checkbox_table[i].checked) {
                    pics.push($(checkbox_table[i]).attr("data-id"));
                }
            }
            url+="?picUrlMap="+pics;
            window.open(url, "_blank");
        });
    }
};
$(function() {
    videoFn.init();
});
var buildEdit = {
    init: function(id) {
        this.connect(id);
    },
    editNameDom: $("input[name=editName]").parent(),
    editClassDom: $("#editClass"),
    start: false,
    connect: function(id) {
        $.ajax({
            url: basePath + "customCategoryController/dataGrid.do",
            data: category_obj,
            type: "get",
            async: false,
            dataType: "json",
            success: function(data) {
                window.classfiyObject_obj = data;
                buildEdit.createDom(data, id);
                if (id == "editClass") {
                    buildEdit.start = true
                }

            }
        });
    },
    createDom: function(data, id) {
        var s1 = new createClass(id, data);
        s1.init(2, id);
    },
    setInformation: function() { //设置分类信息事件;
        var arr = $("#setClass option:selected");
        var classId = "";
        var categoryId = "";
        videoName_arr = [];
        for (var i = arr.length - 1; i >= 0; i--) {
            var val = $(arr).eq(i).val();
            if (val != LCT("请选择")) {
                classId = $(arr).eq(i).attr("data-id");
                categoryId = $(arr).eq(i).attr("category-id");
                $(".systemCatagory").attr("data-id", categoryId);
                break;
            }
        }
        $(".systemCatagory option[data-id='" + categoryId + "']").prop("selected", true);
        var systemCatagoryId = $(".systemCatagory").attr("data-id");
        if (systemCatagoryId == "0") {
            delete params["category"];
        } else {
            params["category"] = systemCatagoryId;
        }
        $(".systemCatagory").change(function() {
            classId = "";
        });
        if (classId == "") {
            delete params["customCategoryId"];
        } else {
            params["customCategoryId"] = classId;
        }
        lcsetting.thisPage = 1;
        selectSolr(solrRetrieve);
        $("#maintable").lctable(lcsetting, params);
    }
};
createClass.prototype = {
    init: function(num, id) {
        var This = this;
        for (var i = 0; i < 2; i++) {
            var oSel = document.createElement("select");
            oSel.index = i;
            oSel.className = "form-control";
            this.oParent.appendChild(oSel);
            oSel.onchange = function() {
                This.change(this.index);
            }
        }
//        if (id == "setClass") {
//            var ahref = document.createElement("a")
//            $(this.oParent).append('<a data-menu="vrsCategory" class="icon-set link-gray3" href="' + basePath + 'customCategoryController/toCustomCategoryManager.do">' + LCT("设置分类信息") + '</a>');
//        }
        this.first();
    },
    change: function(iNow) {
        switch (iNow) {
            case 0: //改变1级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.zero(now);
                break;
            case 1: //改变2级时候处理
                var now = this.aSel[iNow].selectedIndex;
                this.one(now);
                break;
//            case 2: //改变3级时候处理
//                var now = this.aSel[iNow].selectedIndex;
//                this.two(now);
//                break;
        }
        if (this.oParent == document.getElementById("setClass")) {
            buildEdit.setInformation();
        }
    },
    noting: function() {
        for (var i = 0; i < 1; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i+1].appendChild(opt);
        }
    },
    zero: function(n) { //改变一级处理函数

        for (var i = 0; i < 2; i++) { //清空源信息;
            if (i == 0) {
                continue
            }
            this.aSel[i].innerHTML = "";
        }
        if (n == 0) {
            this.noting();
            return
        }
        var arr = this.data[n - 1];
        if (arr.children.length) {
            for (var i = 0; i < arr.children.length; i++) {
                var opt = document.createElement("option");
                opt.innerHTML = arr.children[i].text;
                opt.setAttribute("data-id", arr.children[i].id);
                opt.setAttribute("category-id", arr.children[i].category);
                this.aSel[1].appendChild(opt);
            }
        } else {
            this.noting();
            return;
        }

//        if (arr.children[0].children.length) {
//            for (var i = 0; i < arr.children[0].children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[0].children[i].text;
//                opt.setAttribute("data-id", arr.children[0].children[i].id);
//                opt.setAttribute("category-id", arr.children[0].children[i].category);
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }
    },
    one: function(n) { //改变二级处理函数
//        var a1 = this.aSel[0].selectedIndex - 1;
//        var arr = this.data[a1].children[n];
//        this.aSel[2].innerHTML = "";
//        if (arr.children.length != 0) {
//
//            for (var i = 0; i < arr.children.length; i++) {
//                var opt = document.createElement("option");
//                opt.innerHTML = arr.children[i].text;
//                opt.setAttribute("data-id", arr.children[i].id);
//                opt.setAttribute("category-id", arr.children[i].category);
//
//                this.aSel[2].appendChild(opt);
//            }
//        } else {
//            var opt = document.createElement("option");
//            opt.innerHTML = LCT("请选择");
//            this.aSel[2].appendChild(opt);
//        }

    },
    two: function(n) {

    },
    first: function() { //上来初始化
        var arr = this.data;
        for (var i = 0; i < 2; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = LCT("请选择");
            this.aSel[i].appendChild(opt);
        }
        for (var i = 0; i < arr.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = arr[i].text;
            $(opt).attr("data-id", arr[i].id);
            $(opt).attr("category-id", arr[i].category);
            this.aSel[0].appendChild(opt);
        }
    }
}

function createClass(id, data) {
    this.oParent = document.getElementById(id);
    this.data = data;
    this.aSel = this.oParent.getElementsByTagName("select");
}
//编辑-返回

function closeIframeFromOuter(type) {
    videoName_arr = [];
    $("div.main:eq(0)").show();
    $(window).scrollTop(0);
    if (!type) {
        $(".lc_inner_wraper").hide();
    } else if (type == "refreshAll") {
        history.go(0);
    } else if (type == "refresh") {
        $(".lc_inner_wraper").hide();
        selectSolr(solrRetrieve);
        $("table[data-lctable='data-lctable']").lctable(lcsetting, params);
    }
    $(".lc_inner_iframe").attr("src", "");
}

function selectSolr(b) {
    if (b) {
        lcsetting.ajax = basePath + "solrRetrieve/dataGrid.do";
    } else {
        lcsetting.ajax = basePath + "videoController/dataGrid.do";
    }
}
function search_state() {
//        	var param = {};
    var value_name = $.trim($(".search_name").val());
    var value_id = $.trim($(".search_id").val());
    var fileStatus = $.trim($(".search_select option:selected").val());

    if (fileStatus) {
        params["fileStatus"] = fileStatus;
    } else {
        delete params["fileStatus"];
    }
//            var onoffstatus = $(".video-status-result").attr("onoffstatus");
//            videoFn.albumStatus();
//            if (videoFn.albumStatus().length) {
//                params["onoffStatus"] = videoFn.albumStatus();
//            } else {
//                delete params["onoffStatus"];
//            }
    if (value_name) {
        params["videoName"] = value_name;
    } else {
        delete params["videoName"];
    }
//            if (onoffstatus) {
//            	param["onoffStatus"] = onoffstatus;
//            } else {
//                delete param["onoffstatus"];
//            }
    if (value_id) {
        params["businessUUID"] = value_id;
    } else {
        delete params["businessUUID"];
    }
    var custom_name = $.trim($(".search_customName").val());
    if (custom_name) {
        params["createCustomName"] = custom_name;
    } else {
        delete params["createCustomName"];
    }
    var uploadStartTime = $.trim($("#d4311").val());
    var uploadEndTime = $.trim($("#d4312").val());
    if (uploadStartTime) {
        params["startTime"] = uploadStartTime;
    } else {
        delete params["startTime"];
    }
    if (uploadEndTime) {
        params["endTime"] = uploadEndTime;
    } else {
        delete params["endTime"];
    }
    lcsetting.thisPage = 1;
    selectSolr(solrRetrieve);
    $("#maintable").lctable(lcsetting, params);
}
