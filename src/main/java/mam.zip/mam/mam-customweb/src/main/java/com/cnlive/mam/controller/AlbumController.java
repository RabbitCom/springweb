package com.cnlive.mam.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.enums.OptionType;
import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.exception.ValidateException;
import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.DataProcessorUtil;
import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.model.CustomCategoryModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.OptionLogInfo;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.AlbumService;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.service.OptionLogInfoService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;

/**
 * @author zhangxiaobin
 */
@Controller
@RequestMapping("/albumController")
public class AlbumController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(AlbumController.class);

    // 扩展属性存放
    private static List<Map<String, String>> showPropertyList = new ArrayList<Map<String, String>>();

    @Resource(name = "albumService")
    private AlbumService albumService;

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name="optionLogInfoService")
    private OptionLogInfoService optionLogInfoService;
    /**
     * @Description:跳转到专辑管理页面
     */
    @RequestMapping("/manager")
    public String manager(HttpServletRequest request, String customCategoryId,Model model) {
        request.setAttribute("customCategoryId", customCategoryId);
        return "/album/album_manager";
    }

    /**
     * @Description: 跳转到专辑的视频管理页面
     */
    @RequestMapping("/toAlbumVideo")
    public String toAlbumVideo(HttpServletRequest request, HttpServletResponse response, Long albumId,Model model) {
        if (albumId == null) {
            throw new ValidateException("参数错误！");
        }
        AlbumModel album = albumService.getById(albumId);

        Long customId = getCustomId(request);
        if (customId == 0l) {
            throw new ValidateException(("用户非法"));
        }
        request.setAttribute("albumId", album.getAlbumId());
        request.setAttribute("albumName", album.getAlbumName());
        return "/album/album_video_manager";
    }

    /**
     * 获取专辑的列表(分页)
     */
    @RequestMapping("/dataGrid")
    @ResponseBody
//    @LogAnnotation(message = "分页查询专辑列表",type = OptionType.SELECT)
    public DataGrid dataGrid(HttpServletRequest request, AlbumCondition condition) throws Exception {
        DataGrid dg = new DataGrid();
        try {
            boolean isSpAdmin = this.checkIsSpAdmin(request);
            if(isSpAdmin){
                condition.setSpAdmin(Const.IS_PARENT_YES);
            }else{
                condition.setSpAdmin(Const.IS_PARENT_NO);
                condition.setInstitutionId(this.getInstitutionId(request));
            }
            condition.setSpId(this.getSpId(request));
            if (StringUtils.isNotBlank(condition.getAlbumStatus())) {
                condition.setAlbumStatusArray(condition.getAlbumStatus().split(","));
                condition.setAlbumStatus(null);
            }
            if (condition.getCategory() == null || "0".equals(condition.getCategory().toString())) {
                condition.setCategory(null);
            }

            dg = albumService.getPageByCondition(condition);
        } catch (Exception e) {
            _log.error(e.getMessage());
        }
        return dg;
    }

    /**
     * 跳转到专辑新增页面
     */
    @RequestMapping("/toadd")
    public String toadd(HttpServletRequest request,Model model) {
        return "/album/albumAddTest";
    }

    /**
     * 新增专辑
     */
//    @LogAnnotation(message = "新增专辑",type = OptionType.INSERT)
    @RequestMapping("/saveAlbum")
    @ResponseBody
    public JsonResult saveAlbum(HttpServletRequest request, AlbumModel albumModel) {
        JsonResult j = new JsonResult();
        try {
            if (albumModel.getCategory() == null || (albumModel.getCategory() != null && albumModel.getCategory() == 0)) {
                return JsonResult.createErrorInstance(("数据类型不能为空"));
            }
            Long customId = this.getCustomId(request);
            if (customId == 0) return JsonResult.createErrorInstance(("登录用户")+"id"+("获取失败"));
            //验证专辑名称是否重复
            if (!Strings.isNullOrEmpty(albumModel.getAlbumName()) && albumService.checkAlbumNameExist(customId, albumModel.getAlbumName(), 0L) > 0L)
                return JsonResult.createErrorInstance(("该专辑名称已经存在"));
            if (albumModel.getCustomCategoryId() != null) {
                if ("".equals(albumModel.getCustomCategoryId().toString()) || "0".equals(albumModel.getCustomCategoryId().toString())) {
                    albumModel.setCustomCategoryId(0L);
                }
            }
            Long spId = this.getSpId(request);
            StorageModel storage = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Picture);
            albumModel.setStorageImgId(storage.getId());
            albumModel.setCustomId(customId);
            albumModel.setCreateTime(new Date());
            albumModel.setCreateUserId(customId);
            albumModel.setUpdateTime(new Date());
            albumModel.setUpdateUserId(customId);
            albumModel.setStatus(ModelStatus.Edit);
            albumModel.setOriginAlbumId(0L);
            albumModel.setIsFee(-1);
            albumModel.setPayPlatform(null);
            albumModel.setSpId(spId);
            albumModel.setInstitutionId(this.getInstitutionId(request));
            // 专辑创建默认 当前更新级数为0
            albumModel.setEpisodeNow(0);
            albumService.save(albumModel);
            j.setSuccess(true);
            j.setMsg(("添加成功！"));
        } catch (Exception e) {
            j.setSuccess(false);
            j.setMsg(("添加失败"));
            _log.error(e.getMessage());
        }
        return j;
    }

    /**
     * 跳转到专辑的编辑页面
     */
    @RequestMapping("/toAlbumEdit")
    public String toAlbumEdit(HttpServletRequest request, Long albumId, String editCategory,Model model) {

        if (albumId != null) {
            AlbumModel album = albumService.getById(albumId);

            if (StringUtils.isNotEmpty(editCategory)) {
                album.setSubCategory(null);
                album.setLanguage(null);
                album.setArea(null);
                album.setExtendProperties(null);
            }
            Integer category = StringUtils.isEmpty(editCategory) ? album.getCategory() : Integer.parseInt(editCategory);
            album = super.unescapeHtmlStr(album);
            request.setAttribute("album", album);

            // 获取公用的字典值页面展示
            super.setRequestPublicInfo(request, category);

            // 获取扩展的属性页面展示
            showPropertyList = super.getPropertyList(1, null, album, category);

            request.setAttribute("showPropertyList", showPropertyList);

            request.setAttribute("picFinished", JSON.toJSONString(albumService.returnLayerPicAllpicScale(album.getPicFinishedImg(),album.getStorageImgId())));

        }
        return "/album/album_edit";
    }

    /**
     * 修改专辑
     *
     * @return
     */
//    @LogAnnotation(message = "修改专辑",type = OptionType.UPDATE)
    @RequestMapping(value = "updateAlbum", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateAlbum(HttpServletRequest request, AlbumModel newAlbumModel) {
        try {
            JsonResult customerExist = this.checkCustomerExist(request);
            if(!customerExist.isSuccess()){
                return customerExist;
            }
            CustomModel customModel = (CustomModel)customerExist.getObj();
            Long customId = customModel.getCustomId();
            String customName = customModel.getContacts();
            // 获取扩展属性的值
            String extendPropertiesValues = super.getExtPropertysValuesToJSONString(request, 1, null, newAlbumModel);
            newAlbumModel.setExtendProperties(extendPropertiesValues);

            //处理重复tag 并且验证长度
            String tagVal = DataProcessorUtil.processTag(newAlbumModel.getTag());
            newAlbumModel.setTag(tagVal);

            //验证专辑名称是否重复
            if (!Strings.isNullOrEmpty(newAlbumModel.getAlbumName()) && albumService.checkAlbumNameExist(customId, newAlbumModel.getAlbumName(), newAlbumModel.getAlbumId()) > 0L)
                return JsonResult.createErrorInstance(("该专辑名称已经存在"));

            //分类修改
            boolean isUpdateVideoCustomCategory = false;
            AlbumModel oldAlbumModel = albumService.getById(newAlbumModel.getAlbumId());
//            if (oldAlbumModel.getCustomId() != null && oldAlbumModel.getCustomId().longValue() != customId.longValue()) {
//                return JsonResult.createErrorInstance(("用户无权限"));
//            }

            //校验数据分类是否修改
            if (newAlbumModel.getCategory().intValue() != oldAlbumModel.getCategory().intValue()) {
                if (oldAlbumModel.getVideoCount() > 0) {
                    return JsonResult.createErrorInstance(("专辑下有视频")+","+("不允许修改一级分类"));
                } else {
                    isUpdateVideoCustomCategory = true;
                }
            }
            Long newCustomCategoryId = newAlbumModel.getCustomCategoryId();
            if (newCustomCategoryId == null || newCustomCategoryId.intValue() == 0) {
                newAlbumModel.setCustomCategoryId(0l);
            }

//            newAlbumModel.setCustomId(customId);
            newAlbumModel.setUpdateTime(new Date());
            newAlbumModel.setUpdateUserId(customId);
            //修改专辑状态
            newAlbumModel.fullProperty();

            //验证是否是自建视频(如果不是自建,则保持原有的版权信息不变)
            if (oldAlbumModel.getOriginAlbumId() != null && oldAlbumModel.getOriginAlbumId().intValue() != 0) {
                newAlbumModel.setPlayPlatform(oldAlbumModel.getPlayPlatform());
                newAlbumModel.setDownloadPlatform(oldAlbumModel.getDownloadPlatform());
                newAlbumModel.setCopyrightCompany(oldAlbumModel.getCopyrightCompany());
                newAlbumModel.setCopyrightType(oldAlbumModel.getCopyrightType());
                newAlbumModel.setCopyrightStart(oldAlbumModel.getCopyrightStart());
                newAlbumModel.setCopyrightEnd(oldAlbumModel.getCopyrightEnd());
            }

            //处理播放平台
            if (StringUtils.isEmpty(newAlbumModel.getPlayPlatform())) {
                if (StringUtils.isEmpty(oldAlbumModel.getPlayPlatform())) {
                    List<Integer> platformList = dictionaryService.getDictionaryValues("platform", oldAlbumModel.getCategory());
                    newAlbumModel.setPlayPlatform(StringUtils.join(platformList.toArray(), ","));
                } else {
                    newAlbumModel.setPlayPlatform(oldAlbumModel.getPayPlatform());
                }
            }

            if(oldAlbumModel.getEpisodeNow() == null){
                newAlbumModel.setEpisodeNow(0);
            }
            newAlbumModel = albumService.modify(newAlbumModel);
            if (oldAlbumModel.getVideoCount() > 0 && isUpdateVideoCustomCategory) {
                albumService.setCustomCategory(newAlbumModel);
            }
            return JsonResult.createSuccessInstance(("编辑专辑信息成功！"));
        } catch (Exception e) {
            _log.error(("编辑专辑信息失败,请稍后重试!"), e);
            return JsonResult.createErrorInstance(("编辑专辑信息失败,请稍后重试!"));
        }
    }

    /**
     * @Description: 获取所有专辑 附带分类信息 用于前端下拉选择专辑并关联分类
     */
//    @LogAnnotation(message = "获取所有专辑",type = OptionType.SELECT)
    @RequestMapping("/getAlbumAll")
    @ResponseBody
    public List<Map<String, String>> getAlbumAll(HttpServletRequest request, HttpServletResponse response) {
        Long customId = super.getCustomId(request);
        List<Map<String, String>> reMap = albumService.getAlbumAll(customId);
        return reMap;
    }

    /**
     * @param albumId    ("video")ID
     * @param customImg  用户自定义的图片地址
     * @param proportion 比例 ( 'ar169'.... )
     * @throws
     * @Title: getPicByDiffScale
     * @Description: 根据不通的分辨率生成成品图并保存
     */	
//    @LogAnnotation(message = "自定义专辑图片",type = OptionType.UPDATE)
    @RequestMapping("/getPicByDiffScale")
    @ResponseBody
    public JsonResult picByDiffScale(HttpServletRequest request, String albumId, String customImg, String proportion) {
        _log.info("用户自定义的图片params:{},{},{}",albumId,customImg,proportion);
        JsonResult customerExist = this.checkCustomerExist(request);
        if(!customerExist.isSuccess()){
            return customerExist;
        }
        CustomModel customModel = (CustomModel)customerExist.getObj();
        Long customId = customModel.getCustomId();
        String customName = customModel.getContacts();

        if (StringUtils.isEmpty(albumId) || StringUtils.isBlank(customImg) || StringUtils.isBlank(proportion)) {
            return JsonResult.createErrorInstance(("参数为空"));
        }
        try {
            Long aid = CommonUtil.parseNumber("albumId", albumId).longValue();
            AlbumModel album = albumService.getById(aid);
            if (album == null) return JsonResult.createErrorInstance(("专辑不存在"));
            Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
            if (StringUtils.isNotBlank(album.getPicFinishedImg()))
                finishedImgs_map = JSON.parseObject(album.getPicFinishedImg(), Map.class);
            // 处理一下比例 通过 16:9 获取 ar169
            String scalKey = "";
            for (Map.Entry entry : Const.videoImageScalCp.entrySet()) {
                if (proportion.equals(entry.getValue())) {
                    scalKey = String.valueOf(entry.getKey());
                    break;
                }
            }
            // 处理一下 customImg
          //  customImg = customImg.split(region)[1];
            Integer[] resolutions = Const.videoImageType.get(scalKey);
            Map<String, String> fbl_map = new HashMap<String, String>();
            String pic_url ="";
            customImg = replaceHost(customImg);
            StorageModel storageModel = new StorageModel();
            List<StorageModel> storageList = storageService.getStorageEnableBySpid(customModel.getSpId());
			for (StorageModel sm : storageList) {
				if(StorageContentTypeEnum.Picture==sm.contentType){
					storageModel=sm;
					break;
				}
			}
            for (int i = 0; i < resolutions.length; i = i + 2) {
                String pic_fbl = resolutions[i] + "*" + resolutions[i + 1];
               
				if(storageModel.getType()==StorageTypeEnum.QINIUYUN){
					pic_url = customImg + "?imageView2/1/w/" + resolutions[i] + "/h/" + resolutions[i + 1];
				}else{
                
					pic_url = customImg+"@base@tag=imgScale&w="+resolutions[i]+"&h="+resolutions[i + 1]+"&m=2&c=1";
				}
				fbl_map.put(pic_fbl, pic_url);
            }
            finishedImgs_map.put(scalKey, fbl_map);
            album.setPicFinishedImg(JSON.toJSONString(finishedImgs_map));
            album.setUpdateTime(new Date());
            album.setUpdateUserId(customId);
            albumService.save(album);
            return JsonResult.createSuccessInstance("设置成功",storageModel.getType());
        } catch (Exception e) {
            if (e instanceof BusinessException) {
                return JsonResult.createErrorInstance(((BusinessException) e).getErrorMessage());
            }
            _log.error("用户自定义专辑图片出错{}", e.getMessage());
            return JsonResult.createErrorInstance(("自定义图片设置异常"));
        }
    }

    /**
     * @Description: 根据专辑ID获取专辑信息
     */
//    @LogAnnotation(message = "获取专辑信息",type = OptionType.SELECT)
    @RequestMapping("/getAlbumInfoById")
    @ResponseBody
    public JsonResult getAlbumInfoById(String albumId) {
        if (StringUtils.isEmpty(albumId)) return JsonResult.createErrorInstance(("参数为空"));
        try {
            Long aid = CommonUtil.parseNumber("albumId", albumId).longValue();
            AlbumModel album = albumService.getById(aid);
            if (album == null) return JsonResult.createErrorInstance(("专辑不存在"));
            return JsonResult.createSuccessInstance(album);
        } catch (Exception e) {
            if (e instanceof BusinessException) {
                return JsonResult.createErrorInstance(((BusinessException) e).getErrorMessage());
            }
            _log.error(("获取专辑信息异常"), e.getMessage());
            return JsonResult.createErrorInstance(("获取专辑信息异常"));
        }
    }

    /**
     * 专辑上下线
     *
     * @param albumId  ("album_str")ID
     * @param action   上下线动作
     * @param request  请求
     * @param response 返回
     * @return json结果
    
    @RequestMapping(value = "/toggleOnOffLine",method = RequestMethod.POST)
    @ResponseBody
    public JsonResult toggleOnOffLine(Long albumId, Integer action, HttpServletRequest request, HttpServletResponse
            response) {

        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);

        if (albumId == null) {
            jsonResult.setMsg(("专辑")+"ID"+("参数缺失！"));
            return jsonResult;
        }

        if (action == null || action == ModelStatusAction.NO_ACTION.getDbValue()) {
            jsonResult.setMsg(("上下线动作参数缺失,请稍后重试!"));
            return jsonResult;
        }

        if(action == ModelStatus.OffLine.getDbValue() && getVideoCountByAlbumId(albumId,this.getCustomId(request)) > 0){
            return JsonResult.createErrorInstance(("不允许下线有视频的专辑"));
        }

        String operation = ("offline");
        ModelStatus status = ModelStatus.OffLine;
       // if (action == ModelStatusAction.ON_LINE.getDbValue()) {
       if(action==ModelStatus.OnLine.getDbValue()){
            operation = ("online");
            status = ModelStatus.OnLine;
        }

        response.setHeader("Access-Control-Allow-Origin", "*");
        return handleToggleOnOffLine(albumId, status, operation, request, new ArrayList<Long>());
    }
 */
    /**
     * 批量上下线
     *
     * @param albumIds ("album_str")ids
     * @param action   动作
     * @param request  请求
     * @param response 返回
     * @return jsonResult
     
    @RequestMapping(value = "/batchToggleOnOffLine",method = RequestMethod.POST)
    @ResponseBody
    public JsonResult batchToggleOnOffLine(String albumIds, Integer action, HttpServletRequest request,
                                           HttpServletResponse response) {

        Long customId = this.getCustomId(request);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);

        if (StringUtils.isEmpty(albumIds)) {
            jsonResult.setMsg(("专辑")+"ID"+("集合参数缺失！"));
            return jsonResult;
        }

        if (action == null || action == ModelStatusAction.NO_ACTION.getDbValue()) {
            jsonResult.setMsg(("上下线动作参数缺失,请稍后重试!"));
            return jsonResult;
        }

        String operation = ("offline");
        ModelStatus status = ModelStatus.OffLine;
        if (action == ModelStatusAction.ON_LINE.getDbValue()) {
            operation = ("online");
            status = ModelStatus.OnLine;
        }

        String[] albumIdArray = albumIds.split(Const.VALUE_DECOLLATOR);
        List<Long> errorAlbumList = new ArrayList<>();
        if(action == ModelStatus.OffLine.getDbValue()){
            for (String albumId : albumIdArray) {
                Long aid = CommonUtil.parseNumber("albumId",albumId).longValue();
                if(this.getVideoCountByAlbumId(aid,customId) > 0){
                    return JsonResult.createErrorInstance(("不允许下线有视频的专辑"));
                }
            }
        }

        for (String albumId : albumIdArray) {
            JsonResult result = handleToggleOnOffLine(Long.valueOf(albumId), status, operation, request,
                    errorAlbumList);
            if (!result.isSuccess()) {
                _log.error(result.getMsg());
            }
        }

        response.setHeader("Access-Control-Allow-Origin", "*");
        if (errorAlbumList.isEmpty()) {
            jsonResult.setSuccess(true);
            return jsonResult;
        } else {
            jsonResult.setMsg(("album_") + errorAlbumList.toString() + operation + ("fail_"));
            return jsonResult;
        }
    }
*/
    /**
     * 处理上下线逻辑
     *
     * @param albumId        ("album_str")id
     * @param status         状态
     * @param operation      操作
     * @param request        请求
     * @param errorAlbumList 出错专辑id集合
     * @return jsonResult
   
    private JsonResult handleToggleOnOffLine(Long albumId, ModelStatus status, String operation, HttpServletRequest
            request, List<Long> errorAlbumList) {

        JsonResult jsonResult = new JsonResult();
        jsonResult.setSuccess(false);
        try {
            Long customId = this.getCustomId(request);
            AlbumModel oldAlbumModel = albumService.getById(albumId);
            if (oldAlbumModel.getCustomId() != null && oldAlbumModel.getCustomId().longValue() != customId.longValue()) {
                jsonResult.setMsg(("user_no_permission"));
                errorAlbumList.add(albumId);
            }

            if (oldAlbumModel == null) {
                jsonResult.setMsg(("album_str") + albumId + ("not_exist_"));
                errorAlbumList.add(albumId);
                return jsonResult;
            }

            if (oldAlbumModel.getCustomId() == null || oldAlbumModel.getCustomId().longValue() != customId.longValue
                    ()) {
                jsonResult.setMsg(("no_permission_to_album") + albumId + operation);
                errorAlbumList.add(albumId);
                return jsonResult;
            }

            if (oldAlbumModel.getStatus() == ModelStatus.New) {
                jsonResult.setMsg(("album_str") + albumId + ("java_messaage_6") + operation);
                errorAlbumList.add(albumId);
                return jsonResult;
            }

            if (oldAlbumModel.getStatus() == status) {
                jsonResult.setMsg(("album_str") + albumId + ("is") + operation + ("java_messaage_1") + operation);
                errorAlbumList.add(albumId);
                return jsonResult;
            }

            AlbumModel albumModel = new AlbumModel();
            albumModel.setAlbumId(albumId);
            albumModel.setStatus(status);
            albumModel.setUpdateUserId(customId);
            albumModel.setUpdateTime(new Date());
            albumService.save(albumModel);
            _log.debug(("album_str")+"{}{}成功", albumId, operation);
            jsonResult.setSuccess(true);
            jsonResult.setMsg(("album_str") + operation + ("success_"));
        } catch (Exception e) {
            _log.error(("album_str")+"{}{}出错，{}", albumId, operation, e);
            jsonResult.setMsg(("album_str") + albumId + operation + ("error_"));
        }

        return jsonResult;
    }
  */
    /**
     * 根据专辑id查询专辑以及分类信息
     *
     * @param albumId
     * @return
     */
    @RequestMapping("/getAlbumAndCategoryInfoByAlbumId")
    @ResponseBody
    public JsonResult getAlbumAndCategoryInfoByAlbumId(String albumId) {
        try {
            if (StringUtils.isEmpty(albumId)) return JsonResult.createErrorInstance(("参数")+"albumdId"+("为空"));
            Long albumID = CommonUtil.parseNumber("albumId", albumId).longValue();
            AlbumModel albumModel = albumService.getById(albumID);
            if (albumModel == null) return JsonResult.createErrorInstance(("专辑不存在"));
            Long customCategoryId = albumModel.getCustomCategoryId();
            CustomCategoryModel customCategory = new CustomCategoryModel();
            if (customCategoryId != null && customCategoryId.longValue() != 0) {
                customCategory = customCategoryService.getById(albumModel.getCustomCategoryId().longValue());
            }
            AlbumModel responseAlbumModel = new AlbumModel();
            responseAlbumModel.setAlbumId(albumModel.getAlbumId());
            responseAlbumModel.setAlbumName(albumModel.getAlbumName());
            responseAlbumModel.setCustomCategoryId(albumModel.getCustomCategoryId());
            responseAlbumModel.setLevel(customCategory != null ? customCategory.getLevel() : null);
            responseAlbumModel.setParentCustomCategoryId(customCategory != null ? customCategory.getParentCustomCategoryId() : null);
            // 添加数据分类返回
            responseAlbumModel.setCategory(albumModel.getCategory());
            return JsonResult.createSuccessInstance(responseAlbumModel);
        } catch (Exception ex) {
            if (ex instanceof BusinessException) {
                return JsonResult.createErrorInstance(((BusinessException) ex).getErrorMessage());
            }
            _log.error("查询专辑以及分类信息异常", ex);
            return JsonResult.createErrorInstance(("查询专辑信息失败"));
        }
    }

    /**
     * @Description: 验证专辑名称，验证规则：同一个租户下不能重复
     */
    @RequestMapping("/checkAlbumdName")
    @ResponseBody
    public JsonResult checkAlbumdName(HttpServletRequest request, String albumName, String albumId) {
        try {
            Long customId = this.getCustomId(request);
            Long spId = this.getSpId(request);
            if (customId == 0 || Strings.isNullOrEmpty(albumName))
                return JsonResult.createErrorInstance(("专辑名称或者租户")+"id"+("为空"));
            Long albumIdLongVal = Strings.isNullOrEmpty(albumId) ? 0L : Long.parseLong(albumId);
            if (albumService.checkAlbumNameExist(spId, albumName, albumIdLongVal) > 0L)
                return JsonResult.createErrorInstance(("该专辑名称已经存在"));
            return JsonResult.createSuccessInstance(("验证通过，可以使用"));
        } catch (Exception e) {
            _log.error(("验证专辑名称异常,请稍后重试!"), e);
            return JsonResult.createErrorInstance(("验证专辑名称异常,请稍后重试!"));
        }
    }

    /**
     * 设置专辑的分类信息
     *
     * @param albumId
     * @param customCategoryId
     * @return
     */
    @RequestMapping(value = "setAlbumCustomCategory", method = RequestMethod.POST)
    @ResponseBody
//    @LogAnnotation(message = "设置专辑的分类信息",type = OptionType.UPDATE)
    public JsonResult setAlbumCustomCategory(HttpServletRequest request, String albumId, String category, String customCategoryId) {
        JsonResult customerExist = this.checkCustomerExist(request);
        if(!customerExist.isSuccess()){
            return customerExist;
        }
        CustomModel customModel = (CustomModel)customerExist.getObj();
        Long customId = customModel.getCustomId();
        String customName = customModel.getContacts();

        if (StringUtils.isEmpty(albumId) || StringUtils.isEmpty(category))
            return JsonResult.createErrorInstance(("参数错误"));
        AlbumModel albumModel = albumService.getById(CommonUtil.parseNumber("videoId", albumId).longValue());
        if (albumModel == null) return JsonResult.createErrorInstance(("专辑不存在"));
//        if (albumModel.getCustomId().intValue() != customId.intValue()) {
//            return JsonResult.createErrorInstance(("没有权限"));
//        }
        Integer categoryLong = CommonUtil.parseNumber("category", category).intValue();
        if (albumModel.getCategory().longValue() != categoryLong.longValue()) {
            return JsonResult.createErrorInstance(("一级分类变更")+","+("请完善相关属性"));
        }
        Long customCategory = StringUtils.isEmpty(customCategoryId) || customCategoryId.equals("0") ? 0L : CommonUtil.parseNumber("customCategoryId", customCategoryId).longValue();
        albumModel.setCategory(categoryLong);
        albumModel.setCustomCategoryId(customCategory);
        albumModel.setUpdateTime(new Date());
        albumModel.setUpdateUserId(customId);
        albumService.modify(albumModel);
        albumService.setCustomCategory(albumModel);
        return JsonResult.createSuccessInstance(("设置分类信息成功")+"!");
    }

    /**
     * 专辑移除视频
     *
     * @param videoIds
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "remoteVideoInAlbum", method = RequestMethod.POST)
    @ResponseBody
//    @LogAnnotation(message = "操作专辑内移除视频",type = OptionType.UPDATE)
    public JsonResult remoteVideoInAlbum(String videoIds,String albumId, HttpServletRequest request, HttpServletResponse response) {
        if (StringUtils.isEmpty(videoIds) || StringUtils.isEmpty(albumId)) {
            return JsonResult.createErrorInstance("videoIds or albumId "+("参数为空")+"!");
        }
        JsonResult customerExist = this.checkCustomerExist(request);
        if(!customerExist.isSuccess()){
            return customerExist;
        }
        CustomModel customModel = (CustomModel)customerExist.getObj();
        Long customId = customModel.getCustomId();
        String customName = customModel.getContacts();
        Long albumIdLongVal = CommonUtil.parseNumber("albumId",albumId).longValue();
        AlbumModel albumModel = albumService.getById(albumIdLongVal);
        if(albumModel == null){
            return JsonResult.createErrorInstance(("专辑不存在"));
        }
        List<String> videoIdList = Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().trimResults().splitToList(videoIds);
        List<VideoModel> canGetOutVideoList = Lists.newArrayList();
        for (String videoIdStr : videoIdList) {
            try{
                Long videoId = CommonUtil.parseNumber("videoId",videoIdStr).longValue();
                VideoModel videoModel = videoService.getById(videoId);
                if(videoModel == null){
                    return JsonResult.createErrorInstance(("视频不存在"));
                }
//                if(customId.longValue() != videoModel.getCustomId().longValue()){
//                    return JsonResult.createErrorInstance(("用户无权限"));
//                }
                if(videoModel.getAlbumId()==null || videoModel.getAlbumId() == 0){
                    return JsonResult.createErrorInstance(("视频所属专辑与当前专辑不一致"));
                }
                if(albumIdLongVal.longValue() != videoModel.getAlbumId().longValue()){
                    return JsonResult.createErrorInstance(("视频所属专辑与当前专辑不一致"));
                }
                canGetOutVideoList.add(videoModel);
            }catch (BusinessException ex){
                return JsonResult.createErrorInstance(("参数错误"));
            }
        }
        for (VideoModel videoModel : canGetOutVideoList) {
            VideoModel updateVideo = new VideoModel();
            updateVideo.setAlbumId(0L);
            updateVideo.setVideoId(videoModel.getVideoId());
            updateVideo.setUpdateTime(new Date());
            updateVideo.setUpdateUserId(customId);
            videoService.save(updateVideo);

            OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE,customId,customName,"视频移出专辑",customModel.getSpId(),videoModel.getBusinessUUID(),videoModel.getVideoName());
            optionLogInfoService.create(logInfo);

        }
//        albumService.updateAlbumEpisodeNow(albumIdLongVal);
        return JsonResult.createSuccessInstance(("移除成功"));
    }


    /**
     * 删除专辑
     * @param request
     * @param albumIds
     * @param removeMsg
     * @return
     */
    @RequestMapping("/removeAlbum")
    @ResponseBody
//    @LogAnnotation(message = "操作删除专辑",type = OptionType.DELETE)
    public JsonResult removeAlbum(HttpServletRequest request,String albumIds, String removeMsg) {
        if(StringUtils.isEmpty(albumIds)){
            return JsonResult.createErrorInstance(("专辑")+"ID"+("参数缺失！"));
        }
        Long customId = this.getCustomId(request);
        List<AlbumModel> albumList = new ArrayList<>();
        for (String albumId : albumIds.split(Const.VALUE_DECOLLATOR)){
            Long aid = 0L;
            try{
                aid = CommonUtil.formatString2Long("albumId",albumId);
            }catch (BusinessException ex){
                return JsonResult.createErrorInstance(("参数错误"));
            }
            AlbumModel albumModel = albumService.getById(aid);
            if(albumModel == null){
                return JsonResult.createErrorInstance(("专辑不存在"));
            }
            ModelStatus albumModelStatus = albumModel.getStatus();
            if(albumModelStatus == null){
                return JsonResult.createErrorInstance(("专辑状态不可用"));
            }
            if(!ModelStatus.OffLine.equals(albumModelStatus) && !ModelStatus.New.equals(albumModelStatus)){
                return JsonResult.createErrorInstance(("不允许删除上线状态的专辑"));
            }
            if(customId == null || albumModel.getCustomId() == null){
                return JsonResult.createErrorInstance(("用户无权限"));
            }
//            if(customId.longValue() != albumModel.getCustomId().longValue()){
//                return JsonResult.createErrorInstance(("用户无权限"));
//            }
            if(getVideoCountByAlbumId(aid,customId) > 0){
                return JsonResult.createErrorInstance(("当前专辑下有视频,不允许删除!"));
            }
            albumList.add(albumModel);
        }
        for (AlbumModel albumModel : albumList){
            try{
                albumService.delete(albumModel);
            }catch (Exception ex){
                _log.error("removeAlbum error,albumId = {} ,ex = {}",albumModel.getAlbumId(),ex);
                return JsonResult.createErrorInstance(("删除失败,请稍后重试!"));
            }
        }
        return JsonResult.createSuccessInstance(null);
    }

    private Long getVideoCountByAlbumId(Long albumId,Long customId){
        VideoCondition condition = new VideoCondition();
        condition.setAlbumId(albumId);
        condition.setCustomId(customId);
        return videoService.getVideoCountByCondition(condition);
    }
    
}
