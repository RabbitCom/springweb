
var zgwTree=null;

$(function(){
	releaseFn.init();// 页面列表功能初始化
	
	// InitTree();//树状结构初始化
});


/**
 * 发布管理列表页
 */
var params = {},
    index = 0,
    videoName_arr = [],
    tobePublishBlockNames_arr = [],
    publishBlockNames_arr = [];
var lcsetting = {
    "ajax": basePath + "videoPublishController/videoPublishList.do",
    "pagekey": "page",
    "rowskey": "rows",
    "rowsvalue": 10,
    "dataType": "text",
    "highlight": true,
    "columns": [
      {
        "data": "lcall",
        "format": function(i, j, d) { //基本信息
        	var videoName = d.videoName;
            videoName_arr.push(videoName);
            return '<dl class="clearfix">' +
                '<dt class="ui-fl img">' +
                '<a class="video-view"  videoPlyUrl =' + d.playUrl + ' videoPlyImgUrl = '+ d.listPicUrl +' href="#modal-video-view" data-toggle="modal" ><img src=' + getListPicUrl(d.listPicUrl) + '></a>' +
                '</dt>' +
                '<dd class="ui-fl album-info">' +
                '<p>' + LCT("ID") + '：' + d.businessUUID + '</p>' +
                '<p class="videoName"></p>' +
                '<p>' + LCT("时长") + '：<span class="video-duration">' + vrsFn.formatSeconds(d.duration) + '</span></p>' +
                '<p>' + LCT("分类") + '：' + getCategoryName(d.categoryName) + '</p>' +
                '</dd>' +
                '</dl>';
        	}
      },
      {
    	  "data": "lcall",
          "format": function(i, j, d) {
        	  var status=d.status;
        	  var flag=d.cancelPrePublishFlag;
              var publishState=d.publishState;
                if (status == 5) {
                	if(publishState=="1"){
                		return '<span class="link-blue-txt">' + LCT("待发布") + '</span>';
                	}else{
                		return '<span class="link-blue-txt">' + LCT("未发布") + '</span>';
                	}
                }
                if (status == 7) {
                    return '<span class="link-blue-txt">' + LCT("发布中") + '</span>';
                }
                if (status == 8) {
                    return '<span class="link-blue-txt">' + LCT("发布成功") + '</span>';
                }
                if (status == 9) {
                	if(publishState=="1"){
                		return '<span class="link-blue-txt">' + LCT("待发布") + '</span>';
                	}else{
                		 return '<span class="link-greenrou">' + LCT("发布失败") + '</span>';
                	}
                }
		        }
		    },{
		  	  "data": "lcall",
		      "format": function(i, j, d) {
		    	  var publishState=d.publishState;
		            if (publishState == "1") {
		            	return '<span class="link-blue-txt">' + LCT("是") + '</span>';
		            }else{
		            	return '<span class="link-blue-txt">' + LCT("否") + '</span>';
		            }
		    }
		},{
		  	  "data": "lcall",
		      "format": function(i, j, d) {
		    	  var publishState=d.publishState;
		    	  var prePublishedTime=d.prePublishedTime;
		            if (publishState == "1") {
		            	return '<span class="link-blue-txt">' + LCT(prePublishedTime) + '</span>';
		            }else{
		            	return '<span class="link-blue-txt">' + LCT("无") + '</span>';
		            }
		    }
		},{
        "data": "lcall",
        "format": function(i, j, d) {
        	var publishTime=d.publishTime;
        	if(typeof(publishTime) == undefined){
        		return '';
        	}else if(publishTime==null){
        		return '';
        	}else{
        		return publishTime ;
        	}
        }
    }, {
        "data": "lcall",
        "format": function(i, j, d) {
        	var videoId=d.videoId;
        	var videoPlyUrl=d.videoPlyUrl;
        	// var flag=d.cancelPrePublishFlag;
            var publishState=d.publishState;
            if (d.status == 7) { // 发布操作
                return '<div class="edit-ctrl">无</div>';
            }
            if (d.status == 8) {
                return '<div class="edit-ctrl"><a href="####" onclick="javascript:window.open(\'' + videoPlyUrl + '\')">查看</a></div>';
            }
            if (d.status == 5) { // 发布操作
            	if(publishState=="1"){
            		return '<div class="edit-ctrl"><a data-toggle="modal" href="javascript:void(0)" id="publishBtn_' + videoId + '" onclick="cancelPublish(' + videoId + ');" release-action="12" data-id="' + videoId + '" publishBlock-ids="' + d.publishBlockIds + '">取消发布</a></div>';
            	}else{
            		return '<div class="edit-ctrl"><a data-toggle="modal" href="javascript:void(0)" id="publishBtn_' + videoId + '" onclick="checkCategory(' + videoId + ');" release-action="12" data-id="' + videoId + '" publishBlock-ids="' + d.publishBlockIds + '">发布</a></div>';
            	}
            }
            else if (d.status == 9) {
                if(publishState=="1"){
                    return '<div class="edit-ctrl"><a data-toggle="modal" href="javascript:void(0)" id="publishBtn_' + videoId + '" onclick="cancelPublish(' + videoId + ');" release-action="12" data-id="' + videoId + '" publishBlock-ids="' + d.publishBlockIds + '">取消发布</a></div>';
                }else{
                    return '<div class="edit-ctrl"><a data-toggle="modal" href="javascript:void(0)" id="publishBtn_' + videoId + '" onclick="checkCategory(' + videoId + ');"  release-action="12" data-id="' + videoId + '" publishBlock-ids="' + d.publishBlockIds + '">发布</a>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="publishHistoryView(' + videoId + ')">失败原因</a></div>';
                }
            }
       }
    }],
    "total": ".all",
    "rows": ".rows",
    "pages": "#pages",
    "errormsg": LCT("数据请求错误，请稍后再试"),
    "waitmsg": LCT("加载中，请稍后") + "...",
    "callback": function(data) {
        checkall("#maintable"); // table全选
        // 视频名称title
        var tr = $("#maintable tbody tr");
        for (var i = 0; i < tr.length; i++) {
            var remark_html = videoName_arr[i];
            var tobePublishBlock_html = tobePublishBlockNames_arr[i];
            var publishBlock_html = publishBlockNames_arr[i];
            $(tr[i]).find("p.videoName").attr("title", remark_html).text(LCT("名称") + '：'+remark_html);
            $(tr[i]).find("p.to-publish-cloumns").attr("title", tobePublishBlock_html).text(tobePublishBlock_html);
            $(tr[i]).find("p.publish-cloumns").attr("title", publishBlock_html).text(publishBlock_html);
            $(tr[i]).find("a.video-view").attr("data-name", remark_html);
        }
        videoName_arr = [];
        tobePublishBlockNames_arr = [];
        publishBlockNames_arr = [];
    }
};


var releaseFn = {
    init: function() {
        this.handleTable(); // 表格数据筛选
        this.videoIdName(); // 搜索ID，名称
        this.switchDateEn_init(); // 日期插件初始化
        this.viewVideo();//查看视频
        // this.timedRelease(); // 发布
    },
    
    /**
     * 表格数据筛选
     */
    handleTable: function() {
    // 全部状态加载
         $("#maintable").lctable(lcsetting, params);
         $(".btn_search").bind("click", function() {
            var value_id = $.trim($(".search_id").val());
            var value_name = $.trim($(".search_name").val());
            var onoffstatus = $.trim($(".search_select option:selected").val());
            var fromtime = $.trim($(".fromtime").val());
            var totime = $.trim($(".totime").val());
            if (value_id) {
                params["businessUUID"] = value_id;
            } else {
                delete params["businessUUID"];
            }
            if (value_name) {
                params["videoName"] = encodeURIComponent(value_name);
            } else {
                delete params["videoName"];
            }
            if (onoffstatus) {
            	params["onoffStatus"] = onoffstatus;
            } else {
        		delete params["onoffStatus"];
            }
            if (fromtime) {
                params.publishStartTime = fromtime;
            } else {
                delete params["publishStartTime"];
            }
            if (totime) {
                params.publishEndTime = totime;
            } else {
                delete params["publishEndTime"];
            }
            lcsetting.thisPage = 1;
            $("#maintable").lctable(lcsetting, params);
        });
    },
    //搜索ID，名称
    videoIdName: function() {
        $("#video-id-name select").change(function() {
            var index = $(this).find("option:selected").index();
            $("#video-id-name input:text").val("").hide().eq(index).show();
        });
        // 日期控件
        $('#release-time').jeDate({
            isTime: true,
            format: "YYYY-MM-DD hh:mm:ss",
            minDate: $.nowDate(0)
        });
    },
    //日期插件初始化
    switchDateEn_init: function() {
        var startTime = $("#d4311").val();
        var endTime = $("#d4312").val();
        if (lctu.getLanguage() == "en") {
            $("#d4311-result").val(vrsFn.formatDateEn_short(startTime));
            $("#d4312-result").val(vrsFn.formatDateEn_short(endTime));
        } else {
            $("#d4311-result").val(startTime);
            $("#d4312-result").val(endTime);
        }
    },
    viewVideo:function(){
        $("#maintable").on("click", ".video-view", function() {
            var videoPlyUrl = $(this).attr("videoPlyUrl");
            var data_name = $(this).attr("data-name");
            var imgUrl = $(this).attr("videoPlyImgUrl");
            if(imgUrl == "" || imgUrl == null || imgUrl == undefined || imgUrl == "null" || imgUrl == "undefined"){
                imgUrl = "http://yweb2.cnliveimg.com/sites/170316122008945_143.jpg";
            }else {
                imgUrl = imgUrl;
            }
            $("#cnlivePlayer").attr("flashVars","type=2&model=3&appid=82_irej0pbo53&owner=1&autoplay=1&currRate=2&cover="+imgUrl+"&videoUrl_2="+videoPlyUrl);
            $("#modal-video-view .modal-title").text(data_name);
        });
        $('#modal-video-view').on('hide.bs.modal', function() {
            // $("#player").html("");
        });
    },
    //发布
    timedRelease: function() {
    	$("#maintable").on("click", ".release", function() {
    		var data_id = $(this).attr("data-id");
    		$("#modal-release").attr({
                "data-id": data_id
            });
        });
    	
        $("#timed-release").click(function() {
        	 var val=$('input:radio[name="category_publishradio"]:checked').val();
	       	 var preTime;
	       	 var publishStyle;
	       	 if(val=='3'){
	       		//定时发布
	       		 preTime=$("#category_publish_Time_input").val();
	       		 if(preTime==null ||preTime==''){
	       			alertfn.danger(LCT("请选择发布时间"));
	       			 return false;
	       		 }
	       		 publishStyle="1";
	       	 }else if(val=='2'){//立即发布
	       		 preTime="";
	       		publishStyle="0";
	       	 }
            var videoId = $("#modal-release").attr("data-id");
            if(zgwTree!=null){
            	var zgwnodes = zgwTree.getCheckedNodes(true);
            	if(zgwnodes!=null && zgwnodes.length>0){
            		var releaseObj = {
                    		videoIds: videoId,
                    		title: zgwnodes[0].title,
                    		columnId:zgwnodes[0].columnId,
                    		id:zgwnodes[0].id,
                    		pId:zgwnodes[0].pid,
                    		preTime:preTime,
                    		publishStyle:publishStyle
                    };

                    $.ajax({
                        type: "post",
                        url: basePath + "videoPublishController/addCategory.do",
                        data: releaseObj,
                        async: false,
                        success: function(data) {
                            data = typeof(data) == "string" ? JSON.parse(data) : data;
                            if (data.success) {
                            	 $("#modal-release").modal('hide');
                    			 $(".btn_search").click();//返回列表页
                            } else {
                                alertfn.danger(LCT(data.msg));
                            }
                        },
                        error: function(data) {
                        	alertfn.danger(LCT(data.msg));
                        }
                    });
            	}else{
            		alertfn.danger(LCT("请选择栏目"));
            	}
            }else{
            	alertfn.danger(LCT("没有对应的栏目"));
            }
        });
    }
};

/**
 * 树状结构初始化
 */
 function InitTree() {
	var cmsReqUrl=$("#cmsReqUrl").val();
	if(cmsReqUrl=='' ||cmsReqUrl==null){
		$("#categoryZtree").hide();
		return false;
	}
    var setting = {
    	check:{
    		enable:true,
    		chkStyle: "radio",
    		radioType:"all"
    	},
        async:{
    		autoParam: ["title","columnId"],
    		dataType: "json",
    		  enable: true
    	},
        data: {
            key: {
                name:"title"
            },
            simpleData: {
                enable: true,
                idKey: "id",
                pIdKey: "pid",
                rootPId: 0,
                checked: true
            }
        },
        callback: {
            onClick: onClick
        }
    };
    $.ajax({
        type: 'post',
        url: basePath +"videoPublishController/getAllCategory.do",
        dataType: "json", // 可以是text，如果用text，返回的结果为字符串；如果需要json格式的，可是设置为json
        success: function (data) {
        	if(data.success){
        		zgwTree=$.fn.zTree.init($("#lTree"), setting,JSON.parse(data.obj));
        	}else{
        		alertfn.danger(LCT(data.msg));
        	}
        },
        error: function (msg) {
        	alertfn.danger(LCT(data.msg));
        }
    })
  }
 
 function onClick(e, treeId, treeNode) {
	 
 }

/**
 * 发布失败时查看
 * @param videoId
 */
function publishHistoryView(videoId){
	var releaseObj = {
		videoIds: videoId
    };
	    $.ajax({
	 	   type: "post",
	 	   data:releaseObj,
	 	   url:basePath +"videoPublishController/publishHistoryView.do",
	 	   success:function(data){
	 		   data = typeof(data) == "string" ? JSON.parse(data) : data;
	 		   if(data.success){
	 			  $('#failMessage').text(data.obj);
	 			  $('#modal-failMessage').modal("show");
		 	   }else{
		 		  alertfn.danger(LCT(data.msg));
		 	   }
	 	  } 
    });
 }

function checkCategory(videoId){
	$("#videoId").val(videoId);
    $('#timePublish').modal("show");
	// if(videoId!=null){
	//  $.ajax({
 //         type: "post",
 //         url: basePath + "videoPublishController/checkCategory.do",
 //         data:{
 //        	 videoIds:videoId
 //         },
 //        async: false,
 // 		success: function(data) {
 //        	 data = typeof(data) == "string" ? JSON.parse(data) : data;
 //        	 if(data.success){
 //        		 if("0" == data.msg){
 //        			 $('#modal-release').modal("show");
 //        		 }else{
 //
 //        		 }
 //        	 }else{
 //        		 alertfn.danger(LCT(data.msg));
 //        	 }
 //         },
 //         error: function() {
 //        	 alertfn.danger("请求失败");
 //         }
 //     });
 // }
}

$("input[name=publishradio]").click(function(){
	 var val=$('input:radio[name="publishradio"]:checked').val();
     if(val=='1'){
    	 var time_html='';
    	 time_html=time_html+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
    	 time_html=time_html+'<label id="publish_Time_label">发布时间：</label>'
    	 time_html=time_html+'<input id="publish_Time_input" type="text" style="50px;" name="start" onFocus="WdatePicker({minDate:\'%y-%M-#{%d}\',onpicked:function(){vrsFn.swithDateEn($(this))},dateFmt:\'yyyy-MM-dd HH:mm:ss\',oncleared:function(){vrsFn.onclearedMy97($(this));},readOnly:true,name:\'en\', charset:\'UTF-8\'})"/>';
        $("#publish_time_div").append(time_html);
     }else if(val=='0'){
    	 $("#publish_time_div").find("label#publish_Time_label").remove();
    	 $("#publish_time_div").find("input#publish_Time_input").remove();
     }
  });

$("input[name=category_publishradio]").click(function(){
	 var val=$('input:radio[name="category_publishradio"]:checked').val();
    if(val=='3'){
   	 var time_html='';
   	 time_html=time_html+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
      	 time_html=time_html+'<label id="category_publish_Time_label">发布时间：</label>'
      	 time_html=time_html+'<input id="category_publish_Time_input" type="text" style="50px;" name="category_start" onFocus="WdatePicker({minDate:\'%y-%M-#{%d}\',onpicked:function(){vrsFn.swithDateEn($(this))},dateFmt:\'yyyy-MM-dd HH:mm:ss\',oncleared:function(){vrsFn.onclearedMy97($(this));},readOnly:true,name:\'en\', charset:\'UTF-8\'})"/>';
          $("#category_publish_time_div").append(time_html);
    }else if(val=='2'){
   	 $("#category_publish_time_div").find("label#category_publish_Time_label").remove();
      	 $("#category_publish_time_div").find("input#category_publish_Time_input").remove();
    }
 });

$("#publish_submit").click(function(){
	var videoId=$("#videoId").val();
	 var val=$('input:radio[name="publishradio"]:checked').val();
	 var preTime;
	 if(val=='1'){
		//定时发布
		 preTime=$("#publish_Time_input").val();
		 publishStyle="1";
	 }else if(val=='0'){//立即发布
		 preTime="";
		 publishStyle="0";
	 }
	 $.ajax({
         type: "post",
         url: basePath + "videoPublishController/videoPublishTask.do",
         data:{
        	 videoId:videoId,
        	 preTime:preTime,
        	 publishStyle:publishStyle
         },
        async: false,
        success: function(data) {
        	  data = typeof(data) == "string" ? JSON.parse(data) : data;
              if (data.success) {
              	 $("#timePublish").modal('hide');
      			 $(".btn_search").click();//返回列表页
              } else {
                  alertfn.danger(LCT(data.msg));
              }
        },
        error: function() {
       	 alertfn.danger("请求失败");
        }
	 });
 
});

/**
 * 取消定时发布
 */
function cancelPublish(videoId){
	$.ajax({
        type: "post",
        url: basePath + "videoPublishController/cancelPublish.do",
        data:{
        	videoId:videoId
        },
       async: false,
	   success: function(data) {
	       data = typeof(data) == "string" ? JSON.parse(data) : data;
	       if(data.success){
	       		$(".btn_search").click();
	       }else{
	       		 alertfn.danger(LCT(data.msg));
	       }
        },
        error: function() {
       	 alertfn.danger("请求失败");
        }
    });
}

