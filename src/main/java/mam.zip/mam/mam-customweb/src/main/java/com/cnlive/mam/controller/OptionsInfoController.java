package com.cnlive.mam.controller;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.condition.OptionsInfoCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.OptionsInfo;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.OptionsInfoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.collect.ImmutableMap;
/**
 * 附件上传
 *
 * @author Lixiaohui
 */
@Controller
@RequestMapping("/optionsInfoController")
public class OptionsInfoController extends BaseController {

	private static Logger _log = LoggerFactory.getLogger(OptionsInfoController.class);
	
	@Autowired
	private OptionsInfoService optionsInfoService;
	
	@RequestMapping(value={ "/optionsUpload" },method={RequestMethod.POST})
	@ResponseBody
	public JsonResult optionsUpload(OptionsInfoCondition condition, HttpServletRequest request, HttpServletResponse response) {
		OptionsInfo model = new OptionsInfo();
		if(optionsInfoService.selectByMd5(condition.getMd5()) != null){
			
		}else{
			try {
				model.setName(condition.getName());
				model.setPath("test/");
				model.setRelationId(condition.getRelationId());
				model.setMd5(condition.getMd5());
				model.setSize(condition.getSize());
				model.setStorageId(Long.valueOf("1231111"));
				model.setSuffix(condition.getSuffix());
				model.setType(condition.getType());
				Timestamp ts = new Timestamp(System.currentTimeMillis());  
				model.setCreateTime(ts);
				optionsInfoService.create(model);
				return JsonResult.createSuccessInstance(("附件添加成功"));
			} catch (Exception e) {
				return JsonResult.createErrorInstance(("附件添加失败,请稍后重试!"));
			}
		}
		return null;
	}
	@RequestMapping({ "/ksConfig" })
	@ResponseBody
	public JsonResult ksConfig(HttpServletRequest request,
            HttpServletResponse response){
		JsonResult checkCustomResult = checkCustomerExist(request);
        // 如果用户信息无效，返回错误信息
        if (!checkCustomResult.isSuccess()) {
            return checkCustomResult;
        }
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        JsonResult checkCustom = this.checkCustomerExist(request);
        if (!checkCustom.isSuccess()) {
            return JsonResult.createErrorInstance(("用户认证失败"));
        }
        CustomModel customModel = (CustomModel) checkCustom.getObj();
        Long spId = customModel.getSpId();
		StorageModel storageMediaIn = storageService.getStorageInBySpId(spId,StorageContentTypeEnum.Media);
		
		 return JsonResult.createSuccessInstance(ImmutableMap.of("bucket", storageMediaIn.getName(),
				 "ksak", ksConfigAK, "kssk", ksConfigSK ,"region",uploadImgRegion));
	}
	
	   /**
     * 客户有效性校验
     * @param request
     * @return JsonResult
     * @author wangchaojie　2017年3月17日
     * 
    */
   protected JsonResult checkCustomerExist(HttpServletRequest request){
       Long customId = this.getCustomId(request);
       if(customId == null || customId.longValue() == 0){
           return JsonResult.createErrorInstance(("用户认证失败"));
       }
       CustomModel customModel = customService.getById(customId);
       if(customModel == null){
           return JsonResult.createErrorInstance(("用户认证失败"));
       }
       return JsonResult.createSuccessInstance(customModel);
   }
   
   @RequestMapping("/dataGrid")
   @ResponseBody
   public DataGrid dataGrid(HttpServletRequest request) throws Exception {
       DataGrid dg = new DataGrid();
       dg = (DataGrid) optionsInfoService.getPage();
       return dg;
   }
   
   @RequestMapping("/delete")
   @ResponseBody
   public JsonResult delete(HttpServletRequest request,Long id) throws Exception {
	   try {
		optionsInfoService.delete(id);
		return JsonResult.createSuccessInstance(("删除成功"));
	} catch (Exception e) {
		return JsonResult.createErrorInstance(("删除失败,请稍后重试!"));
	}
   }
   
   
}
