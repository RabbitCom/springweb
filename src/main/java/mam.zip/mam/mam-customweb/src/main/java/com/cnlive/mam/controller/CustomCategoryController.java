package com.cnlive.mam.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cnlive.mam.common.ModelValueConst;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.utils.CommonUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.condition.CustomCategoryCondition;
import com.cnlive.mam.model.CategoryFreeReviewModel;
import com.cnlive.mam.model.CategoryRelation;
import com.cnlive.mam.model.CustomCategoryModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.CategoryFreeReviewService;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.vo.CustomCategoryTree;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;

@Controller
@RequestMapping("/customCategoryController")
public class CustomCategoryController extends BaseController {
    private static Logger _log = LoggerFactory.getLogger(CustomCategoryController.class);

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;
    
    @Resource(name="categoryFreeReviewService")
    private CategoryFreeReviewService categoryFreeReviewService;
    
    @RequestMapping("/manager")
    public String manager(Model model) {
        return "/customCategory/customCategoryManager";
    }

    /**
     * 新增分类
     *
     * @param customCategoryModel
     * @return
     */
    @RequestMapping("/save")
    @ResponseBody
//    @LogAnnotation(message = "新增自定义分类",type = OptionType.INSERT)
    public JsonResult save(@RequestBody CustomCategoryModel customCategoryModel, HttpServletRequest request) {
        Long customId = getCustomId(request);
        JsonResult jsonResult = new JsonResult();
        try {
            if (customId == null || customId == 0L) {
                JsonResult.createErrorInstance(("customId为空"));
                return jsonResult;
            }
            if (!StringUtils.isNotEmpty(customCategoryModel.getCustomCategoryName())) {
                JsonResult.createErrorInstance(("分类名称为空"));
                return jsonResult;
            }
            CustomModel customModel = customService.getById(customId);
            int level = Const.CustomCategory_Level_Step;
            Long parentCustomCategoryId = customCategoryModel.getParentCustomCategoryId();
            if (parentCustomCategoryId == null || parentCustomCategoryId == 0L) {
                customCategoryModel.setParentCustomCategoryId(0L);
            }
            CustomCategoryModel customCategory_Parent = customCategoryService.getById(parentCustomCategoryId);
            Boolean checkContentRes = true;
            if (customCategory_Parent != null) {
                level = customCategory_Parent.getLevel() + Const.CustomCategory_Level_Step;
                if (level > Const.CustomCategory_Level_Max) {
                    JsonResult.createErrorInstance(("只能有三级目录，该目录以是最后一级！"));
                    return jsonResult;
                }
                customCategoryModel.setCategory(customCategory_Parent.getCategory());
                checkContentRes = customCategoryService.checkContent(customCategory_Parent);
            }
            if (!checkContentRes) {
                JsonResult.createErrorInstance(("该分类下已有视频或专辑！"));
                return jsonResult;
            }
            customCategoryModel.setCustomId(customId);
            customCategoryModel.setLevel(level);
            customCategoryModel.setSpId(customModel.getSpId());
            CustomCategoryModel customCategory = customCategoryService.save(customCategoryModel);
            jsonResult.setSuccess(true);
            jsonResult.setObj(customCategory);
        } catch (BusinessException e) {
            _log.error("填加分类失败,Error info :", e.getErrorMessage());
            jsonResult.setMsg(e.getErrorMessage());
        }
        return jsonResult;
    }

    /**
     * 修改分类名称
     *
     * @param customCategoryModel
     * @return
     */
    @RequestMapping("/updateCustomCategoryName")
    @ResponseBody
//    @LogAnnotation(message = "操作修改分类名称",type = OptionType.UPDATE)
    public JsonResult updateCustomCategoryName(@RequestBody CustomCategoryModel customCategoryModel, HttpServletRequest request) {
        JsonResult j = new JsonResult();
        if (StringUtils.isEmpty(customCategoryModel.getCustomCategoryName())
                || customCategoryModel.getCustomCategoryId() == null) {
           return JsonResult.createErrorInstance("参数异常，请稍后重试");
        }
        try {
            Long spId = this.getSpId(request);
            if(customCategoryModel.getSpId().equals(spId)){
                CustomCategoryModel update = new CustomCategoryModel();
                update.setCustomCategoryId(customCategoryModel.getCustomCategoryId());
                update.setCustomCategoryName(customCategoryModel.getCustomCategoryName());
                update.setCustomId(this.getCustomId(request));
                update.setSpId(this.getSpId(request));
                customCategoryService.save(update);
                return JsonResult.createSuccessInstance("操作成功");
            }
            return JsonResult.createErrorInstance("无法操作其他sp的数据");
        } catch (Exception e) {
            _log.error("修改分类名称错误，msg={}，ex={}",e.getMessage(),e);
            return JsonResult.createErrorInstance("系统异常，请稍后重试");
        }
    }

    /**
     * 删除分类
     *
     * @return
     */
    @RequestMapping("/delCustomCategory")
    @ResponseBody
//    @LogAnnotation(message = "操作删除分类",type = OptionType.DELETE)
    public JsonResult delCustomCategory(HttpServletRequest request, String customCategoryIds) throws Exception {
        Long customId = super.getCustomId(request);
        JsonResult jsonResult = new JsonResult();
        try {
            if(StringUtils.isBlank(customCategoryIds)){
                jsonResult.setSuccess(false);
                jsonResult.setMsg(("删除分类参数错误,请稍后重试!"));
                return jsonResult;
            }
            List<String> ccIds =  Arrays.asList(customCategoryIds.split(Const.VALUE_DECOLLATOR));
            List<String> parentIds = new ArrayList<>();
            for(String id : ccIds){
                Long customCategoryId = CommonUtil.parseNumber("customCategoryIds",id).longValue();
                CustomCategoryModel customCategoryParent =  customCategoryService.getById(customCategoryId);
                if(customCategoryParent != null && customCategoryService.checkContent(customCategoryParent)){
                    if(customCategoryParent.getLevel().intValue() == 1 || customCategoryParent.getLevel() ==2){
                        parentIds.add(customCategoryParent.getCustomCategoryId().toString());
                        CustomCategoryCondition customCategoryCondition = new CustomCategoryCondition();
                        customCategoryCondition.setParentCustomCategoryId(customCategoryParent.getCustomCategoryId().toString());
                        List<CustomCategoryModel> customCategorysChirlds = customCategoryService.getInfosByCondition(customCategoryCondition);
                        if(customCategorysChirlds != null || customCategorysChirlds.size() > 0){
                            for (CustomCategoryModel customCategoryChirld : customCategorysChirlds){
                                if(customCategoryChirld != null && customCategoryService.checkContent(customCategoryChirld)){
                                    customCategoryService.delete(customCategoryChirld);
                                    customCategoryService.deleteByCustomCategoryId(customCategoryChirld.getCustomCategoryId());
                                }
                            }
                        }
                    }
                    customCategoryService.delete(customCategoryParent);
                    customCategoryService.deleteByCustomCategoryId(customCategoryParent.getCustomCategoryId());
                }
            }
            return JsonResult.createSuccessInstance(("删除成功"));
        } catch (Exception e) {
            _log.error("删除分类错误,exception={}", e.getMessage());
            jsonResult.setSuccess(false);
            jsonResult.setMsg(("删除失败,请稍后重试!"));
        }
        return jsonResult;
    }

    /**
     * @return
     */
    @RequestMapping("/getCategorys")
    @ResponseBody
    public List<Dictionary> getCategorys(HttpServletRequest request) {
        return dictionaryService.getCategorys();

    }

    /**
     * 组装分类信息的数据列表_新的
     *
     * @param requestCondition
     * @return
     */
    @RequestMapping("/dataGridNew")
    @ResponseBody
    public Object dataGridNew(HttpServletRequest request, CustomCategoryCondition requestCondition) {
        Long customId = super.getCustomId(request);

        CustomModel customModel = customService.getById(customId);
        requestCondition.setSpId(customModel.getSpId());
        requestCondition.setCustomId(null);

        Map<String, CustomCategoryTree> customCategorydata = new HashMap<String, CustomCategoryTree>();
        CustomCategoryTree tree = new CustomCategoryTree("0", "0", "0", new ArrayList<CustomCategoryTree>());
        customCategorydata.put("0", tree);
        List<CustomCategoryVo> list = customCategoryService.integratedData(requestCondition, customId);
        if (list != null && list.size() > 0) {
            customCategorydata = customCategoryService.getCustomCategoryData(list, customCategorydata);
            List<CustomCategoryTree> children = customCategorydata.get("0").getChildren();
            int page = requestCondition.getPage();
            int rows = requestCondition.getRows();
            int endRow = page * rows;
            int startRow = (page - 1) * rows;
            int childrenSize = children.size();
            if (startRow < childrenSize) {
                endRow = endRow > childrenSize ? childrenSize : endRow;
                children = children.subList(startRow, endRow);
            }
            return new DataGrid((long) childrenSize, children);
        }
        return new DataGrid();
    }

    /**
     * 组装分类的数据列表
     *
     * @param customCategoryCondition
     * @return
     */
    @RequestMapping("/dataGrid")
    @ResponseBody
    public Object dataGrid(HttpServletRequest request, CustomCategoryCondition customCategoryCondition) {
        Long customId = super.getCustomId(request);
        CustomModel customModel = customService.getById(customId);
        customCategoryCondition.setSpId(customModel.getSpId());
        customCategoryCondition.setCustomId(null);
        Map<String, CustomCategoryTree> customCategorydata = new HashMap<String, CustomCategoryTree>();
        CustomCategoryTree tree = new CustomCategoryTree("0", "0", "0", new ArrayList<CustomCategoryTree>());
        customCategorydata.put("0", tree);
        List<CustomCategoryVo> list = customCategoryService.integratedData(customCategoryCondition, customId);
        if (list != null && list.size() > 0) {
            customCategorydata = customCategoryService.getCustomCategoryData(list, customCategorydata);
        }
        List<CustomCategoryTree> customCategoryTrees = customCategorydata.get("0").getChildren();
        List<CustomCategoryTree> newTrees_list = new ArrayList<>();
        if(customCategoryCondition.getCategorys() != null && customCategoryCondition.getCategorys().intValue() != 0){
            List<CustomCategoryTree> newTrees_recommend = new ArrayList<>();
            List<CustomCategoryTree> newTrees_unrecommend = new ArrayList<>();
            Integer category = customCategoryCondition.getCategorys();
            for(int i=0;i<customCategoryTrees.size();i++){
                CustomCategoryTree t=customCategoryTrees.get(i);

                if(t.getCategory().intValue() == category.intValue()){
                   // t.setText( t.getText()+"("+("recommend")+")" );
                    t.setText( t.getText());
                    newTrees_recommend.add(t);
                }else{
                    newTrees_unrecommend.add(t);
                }
            }
            newTrees_list.addAll(newTrees_recommend);
            newTrees_list.addAll(newTrees_unrecommend);
        }else{
            newTrees_list.addAll(customCategoryTrees);
        }
        return newTrees_list;
    }

    /**
     * @param customCategoryCondition
     * @return
     */
    @RequestMapping("/toCustomCategoryManager")
    public String toCustomCategoryManager(HttpServletRequest request, CustomCategoryCondition customCategoryCondition,Model model) {
        return "/customCategory/customCategory_manager";
    }
    
    /**
     * @param customCategoryCondition
     * @return
     */
    @RequestMapping("/toCustomCategory")
    public String toCustomCategory(HttpServletRequest request, CustomCategoryCondition customCategoryCondition,Model model) {
        return "/customCategory/d-categoryManager";
    }

    /**
     * 获取一级分类信息返回页面展示
     */
    @RequestMapping("/getParentCustomCategoryInfo")
    @ResponseBody
    public JsonResult getParentCustomCategoryInfo(HttpServletRequest request) {
        JsonResult result = new JsonResult();
        try {
            result.setSuccess(true);
            result.setObj(this.getCustomCategoryInfosByCustomId(request));
        } catch (Exception e) {
            _log.error("获取一级分类信息错误", e.getMessage());
            result.setSuccess(false);
            result.setMsg(("获取一级分类信息错误！"));
        }
        return result;
    }

    /**
     * 获取一级分类的信息
     */
    private List<CustomCategoryModel> getCustomCategoryInfosByCustomId(HttpServletRequest request) {
        Long customId = this.getCustomId(request);
        CustomCategoryCondition condition = new CustomCategoryCondition();
        condition.setParentCustomCategoryId("0");
        condition.setCustomId(customId);
        return customCategoryService.getInfosByCondition(condition);
    }

    /**
     * 客户免审核分类设置
     */
    @RequestMapping("/freeAudit")
    @ResponseBody
    public JsonResult freeAudit(HttpServletRequest request, String categoryIds,String customCategoryIds) {
        try {
            if(StringUtils.isEmpty(categoryIds) && StringUtils.isEmpty(customCategoryIds)) return JsonResult.createErrorInstance(("param_is_null"));
            Long customId = this.getCustomId(request);
            //设置数据分类
            if(StringUtils.isNotBlank(categoryIds)) {
                CategoryFreeReviewModel cfm =categoryFreeReviewService.getByCustomId(customId);
                boolean isUpdate = cfm != null ? true: false;
                boolean isDelete =  "-1".equals(categoryIds) ?  true : false;

                if(isUpdate && isDelete){
                    categoryFreeReviewService.delete(cfm);
                }
                if(isUpdate && !isDelete){
                    cfm.setCustomId(customId);
                    cfm.setUpdateTime(new Date());
                    cfm.setCategoryIds(categoryIds);
                    categoryFreeReviewService.modify(cfm);
                }
                if(!isUpdate && !isDelete){
                    cfm = new CategoryFreeReviewModel();
                    cfm.setCustomId(customId);
                    cfm.setUpdateTime(new Date());
                    cfm.setCategoryIds(categoryIds);
                    cfm.setCreateTime(new Date());
                    categoryFreeReviewService.create(cfm);
                }
            }
            //设置客户分类
            if(StringUtils.isNotBlank(customCategoryIds)){
                Map<String, String[]> paramsMap = new HashMap<String, String[]>();
                String[] openIds = "-1".equals(customCategoryIds) ? null : customCategoryIds.split(Const.VALUE_DECOLLATOR);
                paramsMap.put("openIds", openIds);
                List<CustomCategoryModel> customCategoryList = this.getCustomCategoryInfosByCustomId(request);
                List<String> customCategoryAllIds = new ArrayList<String>();
                for (int i = 0; i < customCategoryList.size(); i++) {
                    CustomCategoryModel ccm = customCategoryList.get(i);
                    if(ccm == null)continue;
                    customCategoryAllIds.add(ccm.getCustomCategoryId().toString());
                }
                String[] ids = new String[customCategoryAllIds.size()];
                paramsMap.put("offIds", customCategoryAllIds.toArray(ids));
                customCategoryService.customCategoryFreeAuditSettingByIds(paramsMap);
            }
            return JsonResult.createSuccessInstance(("免审核分类设置成功"));
        } catch (Exception e) {
            _log.error("设置分类免审核错误", e.getMessage());
            return JsonResult.createErrorInstance(("免审核分类设置错误,请稍后重试!"));
        }
    }

    @RequestMapping("/freeAuditDisplay")
    @ResponseBody
    public JsonResult freeAuditDisplay(HttpServletRequest request){
        try {
            //数据校验
            Long customId = this.getCustomId(request);
            if(customId == null || customId == 0l) return JsonResult.createErrorInstance(("用户非法"));

            //根据客户id获取数据分类的免审核数据
            CategoryFreeReviewModel cfm =categoryFreeReviewService.getByCustomId(customId);
            List<Integer> freeCategorys = new ArrayList<>();
            if(cfm != null){
                freeCategorys = this.getIntValues(cfm.getCategoryIds());
            }

            //获取数据分类
            List<Dictionary> categorys = dictionaryService.getCategorys(null);
            List<Map<String,Object>> categorysShow = new ArrayList<>();
            for (Dictionary d : categorys){
                Map<String,Object> dicMap = new HashMap<>();
                dicMap.put("categoryName",d.getShowName());
                dicMap.put("categoryValue",d.getDicValue());
                if(freeCategorys != null && freeCategorys.size() >0 && freeCategorys.contains(d.getDicValue())){
                    dicMap.put("auditSetting",1);
                }else {
                    dicMap.put("auditSetting",0);
                }
                categorysShow.add(dicMap);
            }
            return JsonResult.createSuccessInstance(categorysShow);
        }catch (Exception e){
            _log.error("获取分类免审核错误",e.getMessage());
            return JsonResult.createErrorInstance(("免审核分类初始化异常,请稍后重试!"));
        }
    }
    
    /**
     * 保存分类和icms栏目对应关系
     * 
     * @return
     */
    @RequestMapping(value = "/saveCategoryRef",method = RequestMethod.POST)
    @ResponseBody
//    @LogAnnotation(message = "设置分类对应栏目关系",type = OptionType.UPDATE)
    public JsonResult saveCategoryRelation(HttpServletRequest request,@RequestBody CategoryRelation categoryRelation) {
    	//区分大分类和自定义分类
    	String type = "";
        JsonResult checkResult = checkCustomerExist(request);
        if(!checkResult.isSuccess()){
            _log.error("保存分类和icms栏目对应关系，用户认证失败，未获取到登录的用户id");
            return checkResult;
        }

    	CustomModel customModel = (CustomModel) checkResult.getObj();
//        if(!(customModel.getIsParent() != null && Const.IS_PARENT_YES.intValue() == customModel.getIsParent().intValue())){
//            return JsonResult.createErrorInstance("认证失败，普通用户没有设置权限");
//        }

        Long customId = customModel.getCustomId();
    	categoryRelation.setCustomId(customId);
        categoryRelation.setSpId(customModel.getSpId());
    	
    	CategoryRelation infosByDicId;

    	CustomCategoryModel customCategoryModel = new CustomCategoryModel();
    	Dictionary dictionary = new Dictionary();
    	try {
    		if(categoryRelation.getCategoryDicValue() != null){//大分类
    			infosByDicId = customCategoryService.getRelationBySpidAndCategory(categoryRelation.getCategoryDicValue(),customModel.getSpId());
    			dictionary = dictionaryService.getDictionaryByDicValue(ModelValueConst.DIC_DICWORD_CATEGORY,categoryRelation.getCategoryDicValue());
    			type = "category";
    		}else{//小分类
    			infosByDicId = customCategoryService.getRelationBySpidAndCustomCategory(categoryRelation.getCustomCategoryId(),customModel.getSpId());
    			customCategoryModel = customCategoryService.getById(categoryRelation.getCustomCategoryId());
    			type = "customeCategory";
    		}
    		
			if(infosByDicId == null){//保存
				if(StringUtils.equals(type, "category")){
					categoryRelation.setCustomCategoryName(dictionary.getShowName());
				}else if(StringUtils.equals(type, "customeCategory")){
					categoryRelation.setCustomCategoryName(customCategoryModel.getCustomCategoryName());
				}
				categoryRelation.setCreateUserId(customId);
                categoryRelation.setUpdateUserId(customId);
                categoryRelation.setCreateTime(new Date());
				customCategoryService.saveCategoryRelation(categoryRelation);
			}else{//更新
				infosByDicId.setIcmsCategoryId(categoryRelation.getIcmsCategoryId());
				infosByDicId.setIcmsCategoryName(categoryRelation.getIcmsCategoryName());
				infosByDicId.setMAM_NodeID(categoryRelation.getMAM_NodeID());
				infosByDicId.setMAM_NodeName(categoryRelation.getMAM_NodeName());
				infosByDicId.setCms_column_id(categoryRelation.getCms_column_id());
				infosByDicId.setCms_column_name(categoryRelation.getCms_column_name());
				infosByDicId.setUpdateTime(new Date());
                infosByDicId.setSpId(customModel.getSpId());
                infosByDicId.setUpdateUserId(customId);
				customCategoryService.updateCategoryRelation(infosByDicId);
			}
			return JsonResult.createSuccessInstance(("成功！"));
		} catch (Exception e) {
			_log.error("保存分类和icms栏目对应关系错误", e.getMessage());;
			return JsonResult.createErrorInstance("save_categoryRelation_error");
		}
    }
    
    
    /**
     * 获取根分类和icms栏目关系
     * 
     * @return
     */
    @RequestMapping(value = "/getCategoryRelationBy",method = RequestMethod.POST)
    @ResponseBody
    public JsonResult getCategoryRelationBy(HttpServletRequest request) {
    	Long customId = this.getCustomId(request);
    	Long spId = getSpId(request);
    	JsonResult result = new JsonResult();
    	try {
			List<Map<String, Object>> list = new ArrayList<>();
			List<Dictionary> categorys = dictionaryService.getCategorys();
			for (Dictionary dictionary : categorys) {
				Map<String,Object> map = new HashMap<String, Object>();
				CategoryRelation selectInfosByDicId = customCategoryService.getRelationBySpidAndCategory(dictionary.getDicValue(),spId);
				map.put("categorys", dictionary);
				if(selectInfosByDicId == null){
					map.put("CategoryRelation", "");
					map.put("flag", false);
				}else{
					map.put("CategoryRelation", selectInfosByDicId);
					map.put("flag", true);
				}
				list.add(map);
			}
			result.setSuccess(true);
			result.setObj(list);
			return result;
		} catch (Exception e) {
			_log.error("获取分类和icms栏目关系失败", e.getMessage());
			return result.createErrorInstance("get_categoryRelation_error");
		}
    }
    
    /**
     * 获取用户自定义的栏目树
     * 
     * @return
     */
    @RequestMapping(value = "/getCustomColumnTree",method = RequestMethod.POST)
    @ResponseBody
    public JsonResult getCustomColumnTree(HttpServletRequest request) {
        Long spId = this.getSpId(request);
    	CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);

    	String result="";
    	if(StringUtils.isNotBlank(customSpInfoModel.getCmsReqUrl())){
            try {
                result = HttpClientUtils.get(customSpInfoModel.getCmsReqUrl(),HttpClientUtils.UTF_8);
            } catch (IOException e) {
                _log.error("获取栏目树接口异常,ex={}",e);
            }
        }
        if(StringUtils.isNotBlank(result)){
            return JsonResult.createSuccessInstance("",result);
        }else{
            return JsonResult.createErrorInstance("huoquweikong");
        }
    }
    
    /**
     * 删除大分类对应栏目关系
     * 
     * @return
     */
    @RequestMapping(value = "/deleteCategoryRelation",method = RequestMethod.GET)
    @ResponseBody
//    @LogAnnotation(message = "删除分类对应栏目关系",type = OptionType.DELETE)
    public JsonResult deleteCategoryRelation(HttpServletRequest request,String categoryRelationId) {
    	Long customId = super.getCustomId(request);
        JsonResult jsonResult = new JsonResult();
        try {
            if(StringUtils.isBlank(categoryRelationId)){
                jsonResult.setSuccess(false);
                jsonResult.setMsg(("删除栏目关系参数错误,请稍后重试!"));
                return jsonResult;
            }
            customCategoryService.deleteByCategoryRelationId(Long.parseLong(categoryRelationId));
            
            return JsonResult.createSuccessInstance(("删除成功"));
        }catch (Exception e) {
        	 _log.error("删除分类错误,exception={}", e.getMessage());
             jsonResult.setSuccess(false);
             jsonResult.setMsg(("删除失败,请稍后重试!"));
		}
		return jsonResult;
    }
    
    

    private List<Integer> getIntValues(String splitValue){
        List<Integer> result = new ArrayList<Integer>();
        if(StringUtils.isNotBlank(splitValue)){
            String [] dicValues = splitValue.split(Const.VALUE_DECOLLATOR);
            for(String str : dicValues){
                if(StringUtils.isNotBlank(str)){
                    result.add(Integer.parseInt(str));
                }
            }
        }
        return  result;
    }
    
}
