var multiMenus = {
    multi: function (d) {
        var dom = $(d).find("i");
        var domfirst = $(d).closest("dl");
        var domdiv = domfirst.find("div");
        var boo = false;
        domfirst = domfirst.find("div").eq(0);
        if (dom.hasClass("active")) {
            dom.removeClass("active");
            domfirst.find("i").removeClass("active");
            domfirst.attr("data-flag", "");
        } else {
            dom.addClass("active");
            for (var i = 1; i < domdiv.length; i++) {
                var dom = domdiv.eq(i).find("i");
                if (dom.hasClass("active")) {

                } else {
                    boo = true;
                }
            }
            if (!boo) {
                domfirst.attr("data-flag", "1");
                domfirst.find("i").addClass("active");
            }
        }


    },
    select: function (key, c) {
        var len = $(c).length;
        for (var i = 0; i < len; i++) {
            var dom = $(c).eq(i).find("i");
            var input = $(c).eq(i).find("input");
            if ($.inArray(input.attr("id"), key) != -1) {
                dom.addClass("active");
            } else {
                dom.removeClass("active");
            }
        }
    },
    multiValue: function (key, c) {
        var len = $(c).length;

        var str = "";
        for (var i = 0; i < len; i++) {
            var dom = $(c).eq(i).find("i");
            if (dom.hasClass("active")) {
                var input = dom.siblings("input");
                if (str) {
                    str += "," + input.attr("id");
                } else {
                    str += input.attr("id");
                }
            }
        }
        return str;

    }
};