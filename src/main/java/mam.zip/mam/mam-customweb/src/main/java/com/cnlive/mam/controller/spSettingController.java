package com.cnlive.mam.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.model.SpExpModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.SpExpService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.vo.DefinitionVo;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Splitter;

/**
 * Created by zhangxiaobin on 2017/5/15.
 */
@Controller
@RequestMapping("/spSetting")
public class spSettingController extends BaseController {

    private static Logger _log = LoggerFactory.getLogger(spSettingController.class);

    @Autowired
    private SpExpService spExpService;

    /**
     * @Description:跳转到SP设置页面
     */
    @RequestMapping("/toVideoSp")
    public String toVideoSp() {
        return "/video/video_sp";
    }

    /**
     * 获取sp设置信息
     * @return
     */
    @RequestMapping(value = "/getSpSettingInfo",method = RequestMethod.GET)
    @ResponseBody
    public JsonResult getcustomInfo(HttpServletRequest request) {
        JsonResult result = new JsonResult();
        Long spId =this.getSpId(request);
        CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
        Map<String,Object> objMap = new HashMap<String,Object>();
        objMap.put("customId", this.getCustomId(request));
        objMap.put("spInfo", customSpInfoModel);
        result.setObj(objMap);
        result.setSuccess(true);
        return result;
    }

    @RequestMapping("/getCustomRate")
    @ResponseBody
    public Object getCustomRate(HttpServletRequest request) {
        Long spId = this.getSpId(request);
        CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
        if(customSpInfoModel != null && StringUtils.isNotEmpty(customSpInfoModel.getRealCodeRate())) {
            return Arrays.asList(customSpInfoModel.getRealCodeRate().split(","));
        }else {
            return new ArrayList<String>();
        }
    }

    @RequestMapping("/getSpDefinition")
    @ResponseBody
    public List<DefinitionVo> getSpDefinition(HttpServletRequest request){
        List<DefinitionVo> definitionVos = new ArrayList<>();
        Long spId = this.getSpId(request);
        CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
        if(customSpInfoModel == null){
            return definitionVos;
        }
        List<String> customDefinition = new ArrayList<>();
        if(StringUtils.isNotBlank(customSpInfoModel.getRealCodeRate())){
            List<String> customDefinitionUnAble = Splitter.on(Const.VALUE_DECOLLATOR).omitEmptyStrings().splitToList(customSpInfoModel.getRealCodeRate());
            customDefinition.addAll(customDefinitionUnAble);
        }
        for (DefinitionEnum definitionEnum:DefinitionEnum.values()){
            DefinitionVo definitionVo = new DefinitionVo(definitionEnum);
            if(customDefinition !=null && customDefinition.size()>0){
                String definitionId = definitionEnum.getDefinitionId().toString();
                if( customDefinition.contains(definitionId)) {
                    definitionVo.setSelected(true);
                    customDefinition.remove(definitionId);
                } else {
                    definitionVo.setSelected(false);
                }
            }else {
                definitionVo.setSelected(false);
            }
            definitionVos.add(definitionVo);
        }
        return definitionVos;
    }


    private boolean checkUrl(String reqUrl){
        return (reqUrl.startsWith("http") || reqUrl.startsWith("https"));
    }

    /**
     * 转码设置
     * @return
     */
    @RequestMapping(value = "/updateTransCodeSetting", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateTransCodeSetting(HttpServletRequest request, String rate, Long spId, String customImg, Integer target, Integer logoStatus) {
        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if(!checkCustomResult.isSuccess()){
            return checkCustomResult;
        }
        CustomModel customModel =  (CustomModel)checkCustomResult.getObj();
        if(customModel.getSpId().longValue() != spId.longValue()){
            return JsonResult.createErrorInstance("当前用户所属sp与操作的sp不符，更新失败");
        }

        String requestRates = "";
        if (StringUtils.isEmpty(rate)){
            requestRates = Const.SD;
        }else {
            requestRates = rate;
        }
        if(!requestRates.contains(Const.SD)){
            requestRates = requestRates+Const.VALUE_DECOLLATOR+Const.SD;
        }

        try{
            CustomSpInfoModel updateSpInfo = new CustomSpInfoModel();
            updateSpInfo.setSpId(spId);
            updateSpInfo.setLogoStatus(logoStatus);
            updateSpInfo.setCodeRate(requestRates);
            updateSpInfo.setLogoSite(target);
            updateSpInfo.setUpdateTime(new Date());
            updateSpInfo.setUpdateUserId(customModel.getCustomId());
            customSpInfoService.modify(updateSpInfo);

            //保存spExp
            String spimginfo = replaceHost(customImg);
            StorageTypeEnum type = storageService.getStorageTypeBySpId(spId,StorageContentTypeEnum.Picture);
            SpExpModel spExpModel = spExpService.getBySpIdAndStorageTypeAndContentType(spId, type, 1);
            if(spExpModel == null){
                StorageModel picStorage = storageService.getStorageInBySpId(spId, StorageContentTypeEnum.Picture);
                spExpModel = new SpExpModel();
                spExpModel.setLogUrl(spimginfo);
                spExpModel.setSpId(spId);
                spExpModel.setCreateTime(new Date());
                spExpModel.setUpdateTime(new Date());
                spExpModel.setCreateUserId(customModel.getCustomId());
                spExpModel.setUpdateUserId(customModel.getCustomId());
                spExpModel.setStorageType(type);
                spExpModel.setSpExpContentType(1);
                spExpModel.setStorageId(picStorage.getId());
                spExpService.create(spExpModel);
            }else{
                SpExpModel update = new SpExpModel();
                update.setId(spExpModel.getId());
                update.setLogUrl(spimginfo);
                update.setUpdateUserId(customModel.getCustomId());
                update.setUpdateTime(new Date());
                spExpService.modify(update);
            }
            return JsonResult.createSuccessInstance("保存成功");
        }catch (Exception ex){
            _log.error("保存sp转码设置失败；ex={}",ex);
            return JsonResult.createErrorInstance("保存失败");
        }
    }


    /**
     * 保存流程设置
     * @param request
     * @param spId
     * @param autoOnlie
     * @param autoPublish
     * @param autoAudit
     * @return
     */
    @RequestMapping(value = "/updateProcessSetting", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateProcessSetting(HttpServletRequest request, Long spId, Integer autoOnlie, Integer autoPublish, Integer autoAudit){
        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if(!checkCustomResult.isSuccess()){
            return checkCustomResult;
        }
        CustomModel customModel =  (CustomModel)checkCustomResult.getObj();
        if(customModel.getSpId().longValue() != spId.longValue()){
            return JsonResult.createErrorInstance("当前用户所属sp与操作的sp不符，更新失败");
        }

        if(autoAudit == null || autoOnlie == null || autoPublish == null){
            return JsonResult.createErrorInstance("设置参数值缺失，请重新设置并保存");
        }

        try{
            CustomSpInfoModel updateSpInfo = new CustomSpInfoModel();
            updateSpInfo.setSpId(spId);
            updateSpInfo.setAutoAudit(autoAudit);
            updateSpInfo.setAutoOnlie(autoOnlie);
            updateSpInfo.setAutoPublish(autoPublish);
            updateSpInfo.setUpdateTime(new Date());
            updateSpInfo.setUpdateUserId(customModel.getCustomId());
            customSpInfoService.modify(updateSpInfo);
            return JsonResult.createSuccessInstance("保存成功");
        }catch (Exception ex){
            _log.error("保存流程设置失败；ex={}",ex);
            return JsonResult.createErrorInstance("保存失败");
        }

    }


    /**
     * cms 配置更新
     * @param request
     * @param spId
     * @param cmsReqUrl
     * @param publishUrl
     * @param offLineUrl
     * @param isStartCategory
     * @return
     */
    @RequestMapping(value = "/updateCMSSetting", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updateCMSSetting(HttpServletRequest request, Long spId,String cmsReqUrl,String publishUrl,String offLineUrl,Integer isStartCategory){
        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if(!checkCustomResult.isSuccess()){
            return checkCustomResult;
        }
        CustomModel customModel =  (CustomModel)checkCustomResult.getObj();
        if(customModel.getSpId().longValue() != spId.longValue()){
            return JsonResult.createErrorInstance("当前用户所属sp与操作的sp不符，更新失败");
        }

        CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
        if(isStartCategory !=null
                && Const.IS_START_CATEGORY_YES.intValue()==isStartCategory.intValue()
                && StringUtils.isBlank(cmsReqUrl)){
            return JsonResult.createErrorInstance(("自定义栏目接口地址为空"));
        }

        CustomSpInfoModel update = new CustomSpInfoModel();
        update.setSpId(spId);
        update.setIsStartCategory(isStartCategory);

        if(StringUtils.isNotBlank(cmsReqUrl) ){
            if(!(cmsReqUrl.equals(customSpInfoModel.getCmsReqUrl()))){
                if(!checkUrl(cmsReqUrl)){
                    return JsonResult.createErrorInstance(("自定义栏目接口地址不正确"));
                }
                String checkResult = "";
                try {
                    checkResult = HttpClientUtils.get(cmsReqUrl,HttpClientUtils.UTF_8);
                } catch (IOException e) {
                    _log.error("自定义栏目接口地址返回异常,msg={},ex={}",e.getMessage(),e);
                    return JsonResult.createErrorInstance(("自定义栏目接口地址返回异常"));
                }
                if(StringUtils.isBlank(checkResult)){
                    return JsonResult.createErrorInstance(("自定义栏目接口地址返回格式不标准"));
                }
                JSONArray array = null;
                try{
                    array = JSON.parseArray(checkResult);
                }catch (Exception ex){
                    return JsonResult.createErrorInstance(("自定义栏目接口地址返回格式不标准"));
                }
                JSONObject object = new JSONObject();
                if (array.size() > 0 ){
                    object = array.getJSONObject(0);
                }else {
                    return JsonResult.createErrorInstance(("自定义栏目接口地址返回格式不标准"));
                }
                if ( !( object != null && object.containsKey("id") && object.containsKey("title")
                        && object.containsKey("pid") && object.containsKey("columnId"))) {
                    return JsonResult.createErrorInstance(("自定义栏目接口地址返回格式不标准"));

                }
                update.setCmsReqUrl(cmsReqUrl);
            }
        }
        if(StringUtils.isNotBlank(publishUrl)){
            if(!(publishUrl.equals(customSpInfoModel.getPublishUrl()))){
                if(!checkUrl(publishUrl)){
                    return JsonResult.createErrorInstance(("自定义发布内容地址不正确"));
                }
                update.setPublishUrl(publishUrl);
            }

        }
        if(StringUtils.isNotBlank(offLineUrl)){
            if(!(offLineUrl.equals(customSpInfoModel.getOffLineUrl()))){
                if(!checkUrl(offLineUrl)){
                    return JsonResult.createErrorInstance(("自定义内容下线地址不正确"));
                }
                update.setOffLineUrl(offLineUrl);
            }
        }

        try{
            update.setUpdateUserId(customModel.getCustomId());
            update.setUpdateTime(new Date());
            customSpInfoService.modify(update);
            return JsonResult.createSuccessInstance("保存成功");
        }catch (Exception ex){
            _log.error("保存流程设置失败；ex={}",ex);
            return JsonResult.createErrorInstance("保存失败");
        }


    }

    /**
     * 更新sp的片头片尾信息
     * @param request
     * @param spId
     * @param startUrl
     * @param endUrl
     * @return
     */
    @RequestMapping(value = "/updatePtPw", method = RequestMethod.POST)
    @ResponseBody
    public JsonResult updatePtPw(HttpServletRequest request, Long spId, String startUrl, String endUrl) {
        JsonResult checkCustomResult = this.checkCustomerExist(request);
        if(!checkCustomResult.isSuccess()){
            return checkCustomResult;
        }
        CustomModel customModel =  (CustomModel)checkCustomResult.getObj();
        if(customModel.getSpId().longValue() != spId.longValue()){
            return JsonResult.createErrorInstance("当前用户所属sp与操作的sp不符，更新失败");
        }
        try{
            //保存spExp
            StorageTypeEnum type = storageService.getStorageTypeBySpId(spId,StorageContentTypeEnum.Media);
            SpExpModel spExpModel = spExpService.getBySpIdAndStorageTypeAndContentType(spId, type, 2);
            if(spExpModel == null){
                StorageModel storage = storageService.getStorageInBySpId(spId, StorageContentTypeEnum.Media);
                spExpModel = new SpExpModel();
                spExpModel.setSpId(spId);
                spExpModel.setCreateTime(new Date());
                spExpModel.setUpdateTime(new Date());
                spExpModel.setCreateUserId(customModel.getCustomId());
                spExpModel.setUpdateUserId(customModel.getCustomId());
                spExpModel.setStorageType(type);
                spExpModel.setSpExpContentType(2);
                spExpModel.setStorageId(storage.getId());
                spExpModel.setStartUrl(startUrl);
                spExpModel.setEndUrl(endUrl);
                spExpService.create(spExpModel);
            }else{
                SpExpModel update = new SpExpModel();
                update.setId(spExpModel.getId());
                update.setUpdateUserId(customModel.getCustomId());
                update.setUpdateTime(new Date());
                update.setStartUrl(startUrl);
                update.setEndUrl(endUrl);
                spExpService.modify(update);
            }

            return JsonResult.createSuccessInstance("保存成功");
        }catch (Exception ex){
            _log.error("保存设置失败；ex={}",ex);
            return JsonResult.createErrorInstance("保存失败");
        }
    }
}
