package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.model.PublishTaskModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.PublishHistoryMapper;
import com.cnlive.mam.model.PublishHistory;
import com.cnlive.mam.service.PublishHistoryService;

/**
 */
@Service("publishHistoryService")
public class PublishHistoryServiceImpl implements PublishHistoryService {

    Logger logger = LoggerFactory.getLogger(PublishHistoryServiceImpl.class);

    @Autowired
    private PublishHistoryMapper publishHistoryMapper;

	@Override
	public void insert(PublishHistory publishHistory) {
		publishHistoryMapper.insert(publishHistory);
	}

	@Override
	public PublishHistory selectByVideoIdAndCustomId(PublishHistory publishHistory) {
		return publishHistoryMapper.selectByVideoIdAndCustomId(publishHistory);
	}

	@Override
	public void update(PublishHistory publishHistory) {
		publishHistoryMapper.update(publishHistory);
	}

	@Override
	public PublishHistory selectByVideoId(Long videoId) {
		return publishHistoryMapper.selectByVideoId(videoId);
	}

}
