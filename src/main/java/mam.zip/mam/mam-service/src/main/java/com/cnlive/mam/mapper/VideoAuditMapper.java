package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.model.VideoAuditModel;

import java.util.List;

public interface VideoAuditMapper {
    
    public void insert(VideoAuditModel entity);
    
    public List<VideoAuditModel> getByCondition(VideoAuditCondition condition);
    
    public Long getByConditionCount(VideoAuditCondition condition);
    
    public List<VideoAuditModel> getVideoAuditInfoByCondition(VideoAuditCondition condition) ;
    
    public void update(VideoAuditModel videoAuditModel);

}
