package com.cnlive.mam.mapper;

import com.cnlive.mam.model.PublishHistory;
import com.cnlive.mam.model.PublishTaskModel;

public interface PublishHistoryMapper {
	
	public void insert(PublishHistory publishHistory);

	public PublishHistory selectByVideoIdAndCustomId(PublishHistory publishHistory);
	
	public void update(PublishHistory publishHistory);

	PublishHistory selectByVideoId(Long videoId);

}
