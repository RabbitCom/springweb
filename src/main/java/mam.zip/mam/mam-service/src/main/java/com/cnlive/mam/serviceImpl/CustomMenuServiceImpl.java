package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.CustomMenuMapper;
import com.cnlive.mam.model.CustomMenuModel;
import com.cnlive.mam.service.CustomMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by cuilongcan on 2017/5/11.
 */
@Service("customMenuService")
public class CustomMenuServiceImpl implements CustomMenuService {
    @Autowired
    CustomMenuMapper customMenuMapper;

    @Override
    public List<CustomMenuModel> selectAll() {
        String cacheKey = Const.REDIS_KEY_MENU_ALL;
        List<CustomMenuModel> list = CacheUtils.get(cacheKey, List.class);
        if(list == null || list.size() == 0){
            list = customMenuMapper.selectAll();
            if(list != null && list.size() > 0)CacheUtils.set(cacheKey,list, ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public CustomMenuModel selectById(Integer menuId) {
        String cacheKey = Const.REDIS_KEY_MENU + menuId;
        CustomMenuModel model = CacheUtils.getJson(cacheKey, CustomMenuModel.class);
        if(model == null){
            model = customMenuMapper.selectByMenuId(menuId);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public List<CustomMenuModel> selectByIds(List<Integer> ids) {
        return customMenuMapper.selectByIds(ids);
    }
}
