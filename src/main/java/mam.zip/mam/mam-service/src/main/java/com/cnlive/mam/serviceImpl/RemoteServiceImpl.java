package com.cnlive.mam.serviceImpl;

import java.net.URLEncoder;
import java.util.*;

import com.cnlive.mam.model.*;
import com.cnlive.mam.service.*;
import com.google.common.base.Splitter;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.enums.TransCodeType;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.common.utils.MD5Util;
import com.cnlive.mam.constant.ServiceResultMessage;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ReqTransCodeVo;
import com.cnlive.mam.vo.ResTransCodeVo;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableMap;

@Service("remoteService")
public class RemoteServiceImpl implements RemoteService{
	
	private static Logger _log = LoggerFactory.getLogger(RemoteServiceImpl.class);

	@Autowired
	private VideoService videoService;
	
	@Autowired
    private FileService fileService;
	
	@Autowired
	private CustomSpInfoService customSpInfoService;

	@Autowired
	private StorageService storageService;

	@Autowired
	private StorageConfigsService storageConfigsServic;
	
	@Value("#{configProperties['bc_bokong_url']}")
    private String bc_bokong_url;

	@Value("#{configProperties['transCode_url']}")
	private String transCodeUrl;
	
	@Value("#{configProperties['appKey']}")
	private String appKey;
	
	@Value("#{configProperties['appSecret']}")
	private String appSecret;

	@Override
	public String remoteTransCode(String cbMethod, String cbUrl, TranscodeTaskModel task,String bucketName,String domain) {
    	String originUri = task.getFileOriginUri();
    	String logoPicUrl = task.getLogoPicUrl();
		ReqTransCodeVo transCodeReq = new ReqTransCodeVo();
		transCodeReq.setPlat(task.getPlat());
		transCodeReq.setPath(Const.SEPARATE_XIE+bucketName+Const.SEPARATE_XIE+originUri);
		transCodeReq.setType(TransCodeType.avop);
		transCodeReq.setSpId(String.valueOf(task.getSpId()));
		transCodeReq.setCbMethod(cbMethod);
		transCodeReq.setCbUrl(cbUrl);
		transCodeReq.setDstBucket(bucketName);
		transCodeReq.setDstDir(getTransCodePath(task.getFileOriginUri()));
        transCodeReq.setRates(task.getCodeRate());
        transCodeReq.setFormats(task.getTransCodeFmt());
        //如果用户设置了水印图片及位置，添加水印
        if(StringUtils.isNotBlank(logoPicUrl)){
        	int addLogoFlag = 1;
        	String attach = "{\"path\":\""+logoPicUrl+"\",\"position\":\""+task.getLogoSite()+"\"}";
        	transCodeReq.setAddLogoFlag(addLogoFlag);
        	transCodeReq.setAttach(attach);
        }
		//处理扩展属性
		JSONObject extParamObj = new JSONObject();
		if(1 == task.getPlat().intValue()){
			extParamObj.put("domain",domain);
		}
		JSONObject ptpwJson = new JSONObject();
		ptpwJson.put("headFile",task.getHeadFile());
		ptpwJson.put("endFile",task.getEndFile());
		extParamObj.put("avconcat",ptpwJson);
		transCodeReq.setExtParam(extParamObj);

        return this.startTransCode(transCodeReq,"转码服务");
	}
	
	@Override
	public String remoteChouZhen(String videoOriginUri, String spId,String cbMethod, String cbUrl,String bucketName,Integer plat,String domain) {
		ReqTransCodeVo chouzhenReq = new ReqTransCodeVo();
		chouzhenReq.setPlat(plat);
		if(1 == plat.intValue()){
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("domain",domain);
			chouzhenReq.setExtParam(jsonObject);
		}
		chouzhenReq.setPath(Const.SEPARATE_XIE+bucketName+Const.SEPARATE_XIE+videoOriginUri);
		chouzhenReq.setType(TransCodeType.avsample);
		chouzhenReq.setSpId(spId);
		chouzhenReq.setAddLogoFlag(0);
		chouzhenReq.setCbMethod(cbMethod);
		chouzhenReq.setCbUrl(cbUrl);
		chouzhenReq.setDstBucket(bucketName);
		chouzhenReq.setDstDir(Joiner.on(Const.SEPARATE_XIE).join(spId, "img",
				CalendarUtil.getFormatDateString(new Date(),CalendarUtil.SHORT_DATA_FORMAT_YYYY_MMDD)));
		return this.startTransCode(chouzhenReq,"抽帧服务");
	}

	@Override
	public JsonResult remoteDianBoPlay(Long videoId, ModelStatus status) {
		if(videoId == null){
			throw new BusinessException(ServiceResultMessage.PARAM_ERROR);
		}
		VideoModel videoModel = videoService.getById(videoId);
		if(videoModel == null){
			throw new BusinessException(ServiceResultMessage.VIDEO_NOT_EXTIS);
		}
		return dianBoSyn(videoModel, status);
	}

	@Override
	public JsonResult remoteCmsOffLine(String businessUUID, Long spId) {
		String cmsOfflineUrl="";
		if(StringUtils.isBlank(businessUUID) || spId == null){
			_log.error("请求cms下线接口参数异常,v-uuid={},spid={}",businessUUID,spId);
			return JsonResult.createErrorInstance("参数异常");
		}
		CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(spId);
		if(customSpInfoModel!=null){
			cmsOfflineUrl=customSpInfoModel.getOffLineUrl();
		}
		_log.info("请求cms下线接口，businessUUID={},spId={}",businessUUID,spId);
		String result = HttpClientUtils.get(cmsOfflineUrl,ImmutableMap.of("mediaId",businessUUID, "spId", spId),5000);
		_log.info("请求cms下线接口返回，result={}",result);

		JSONObject resultObject = JSON.parseObject(result);
		if(resultObject.containsKey("result")){
			if("Success".equals(resultObject.getString("result"))){
				return JsonResult.createSuccessInstance(null);
			}
		}
		return JsonResult.createErrorInstance("请求cms异常");
	}

	//转码接口
	private String startTransCode(ReqTransCodeVo req,String taskName){
		String retData = "";
		try {
			String paramsJson =  JSONObject.toJSON(req).toString();
			long timestamp = System.currentTimeMillis();
			String sign = MD5Util.md5(URLEncoder.encode(appKey + timestamp + paramsJson + appSecret, "utf-8"));
			_log.info("请求{}, url={} ,参数={}",taskName,transCodeUrl, paramsJson);

			Map<String,String> paramsmap = new HashedMap();
			paramsmap.put("params",paramsJson);
			paramsmap.put("appKey",appKey);
			paramsmap.put("timestamp",String.valueOf(timestamp));
			paramsmap.put("sign",sign);

			retData = HttpClientUtils.post(transCodeUrl,paramsmap,5000);
			_log.info("请求{}, 返回 retData={}",taskName, retData);
			if(StringUtils.isBlank(retData)){
				return retData;
			}
			ResTransCodeVo res = JSON.parseObject(retData,ResTransCodeVo.class, Feature.IgnoreNotMatch);
			return res.getTaskId();
		} catch (Exception e) {
			_log.error("请求{}系统失败,excetion={}",taskName,e.getMessage());
		}
		return retData;
	}

	/**
     * @Description:调用bokong接口进行视频同步
     */
    private JsonResult dianBoSyn(VideoModel video, ModelStatus status){
    	try {
    		JSONObject jsonObject=new JSONObject();
			jsonObject.put("spId",video.getSpid());
        	jsonObject.put("videoId",video.getBusinessUUID());		//	点播内容标识	*
        	jsonObject.put("title",video.getVideoName());			//	点播内容标题	*
        	jsonObject.put("subTitle",video.getSubTitle());		//	点播内容副标题	
        	jsonObject.put("description",video.getSynopsis());	//	点播内容描述
        	jsonObject.put("imgSmall",video.getAllPicScale().get("112*63"));		//	点播内容图片
        	jsonObject.put("imgMain",video.getAllPicScale().get("224*126"));		//	点播内容标题图片，336*220
        	jsonObject.put("imgBig",video.getAllPicScale().get("485*303"));		//16:10	点播内容图片，640*320
			jsonObject.put("createTime",video.getCreateTime());	//	点播内容创建时间格式 "yyyy-MM-dd HH: mm:ss"
			jsonObject.put("status",status.getDbValue()); //上线5  下线6
        	jsonObject=getStoreUri(video.getVideoId(),jsonObject);// 点播内容播放地址
    		_log.info("请求播控接口参数：__________________"+jsonObject.toJSONString());
    		Map<String,String> resultMap = new HashMap<>();
    		resultMap.put("json",jsonObject.toJSONString());
			String result = HttpClientUtils.post(bc_bokong_url, resultMap,5000);
			_log.info("请求播控接口返回：__________________"+result);
		} catch (Exception e) {
			 _log.error("请求播控接口失败：________________"+e.getMessage());
			 return JsonResult.createErrorInstance("失败");
		}
		return JsonResult.createSuccessInstance("ok");
    }
    
    
    /**
     * @Description:点播内容播放地址
     */
    private JSONObject getStoreUri(long videoId,JSONObject jsonObject){
    	List<FileModel> FileModelList = fileService.getByVid(videoId);
    	if(FileModelList!=null && FileModelList.size()>0){
    		Integer storageId = 0;
			String transCodeUrl_ = "";
			for(FileModel fileModel:FileModelList){
				if(fileModel.getStatus() != null && FileStatus.TranscodingSuccess.getDbValue() == fileModel.getStatus().getDbValue()){
					if(storageId.intValue() == 0){
						storageId = fileModel.getStorageTranscode();
					}
					if(StringUtils.isEmpty(transCodeUrl_)){
						String playDomain = storageService.getDomainSimpleOutByStorageId(fileModel.getStorageTranscode());
						transCodeUrl_ = playDomain + Const.SEPARATE_XIE;
					}
					Integer codeRate = fileModel.getCodeRate();//码率
					String transCodeFmt = fileModel.getTransCodeFmt();//转码后后缀
					if(Const.FMT_HLS.equalsIgnoreCase(transCodeFmt)){
						switch (codeRate) {
							case 400:
								jsonObject.put("hlsUrl_1", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 800:
								jsonObject.put("hlsUrl_2", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 1500:
								jsonObject.put("hlsUrl_3", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 3000:
								jsonObject.put("hlsUrl_4", transCodeUrl_+fileModel.getStoreUri());
								break;
							default:
								break;
						}
					}
					if(Const.FMT_MP4.equalsIgnoreCase(transCodeFmt)){
						switch (codeRate) {
							case 400:
								jsonObject.put("mp4Url_1", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 800:
								jsonObject.put("mp4Url_2", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 1500:
								jsonObject.put("mp4Url_3", transCodeUrl_+fileModel.getStoreUri());
								break;
							case 3000:
								jsonObject.put("mp4Url_4", transCodeUrl_+fileModel.getStoreUri());
								break;
							default:
								break;
						}
					}
    			}
    		}
//			List<Map<String,Object>> domainAndWeightMaps = new ArrayList<>();
			if(storageId.intValue() !=0){
//				List<StorageConfigsModel> storageConfigs = storageConfigsServic.getByStorageId(storageId);
//				for(StorageConfigsModel model : storageConfigs){
//					Map<String,Object> map = new HashMap<>();
//					map.put("domain",model.getHostName());
//					map.put("weight",model.getWeight());
//					domainAndWeightMaps.add(map);
//				}
				storageConfigsServic.getOutDomainWeightByStorageId(storageId);
				String cacheKey = Const.REDIS_KEY_STORAGE_DOMAIN_WEIGHT + storageId;
				jsonObject.put("storageCacheKey",cacheKey);
			}
//			jsonObject.put("domainWeight",domainAndWeightMaps);
    	}else{
    		jsonObject.put("hlsUrl_1","");		//	点播内容播放地址，流畅
        	jsonObject.put("hlsUrl_2","");		//	点播内容播放地址，标清	*
        	jsonObject.put("hlsUrl_3","");		//	点播内容播放地址，高清
        	jsonObject.put("hlsUrl_4","");		//	点播内容播放地址，超清
        	jsonObject.put("mp4Url_1","");		//	点播内容播放地址，流畅
        	jsonObject.put("mp4Url_2","");		//	点播内容播放地址，标清	*
        	jsonObject.put("mp4Url_3","");		//	点播内容播放地址，高清
        	jsonObject.put("mp4Url_4","");		//	点播内容播放地址，超清
//			jsonObject.put("domainWeight","");
			jsonObject.put("storageCacheKey","");
    	}
    	return jsonObject;
    }
    
    /**
     * 获取转码的拼接路径
     * @return
     */
    protected String getTransCodePath(String originUri){
		String transCodePath = originUri.replaceFirst("raw", "vod");
		return transCodePath.substring(0, originUri.lastIndexOf(Const.DOT_STRING));
	}
    
}
