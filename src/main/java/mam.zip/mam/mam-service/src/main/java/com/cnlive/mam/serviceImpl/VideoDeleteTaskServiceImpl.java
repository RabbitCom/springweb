package com.cnlive.mam.serviceImpl;

import java.util.Date;
import java.util.List;

import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cnlive.mam.mapper.FileMapper;
import com.cnlive.mam.mapper.VideoDeleteHistoryMapper;
import com.cnlive.mam.mapper.VideoDeleteTaskMapper;
import com.cnlive.mam.mapper.VideoMapper;
import com.cnlive.mam.model.VideoDeleteHistoryModel;
import com.cnlive.mam.model.VideoDeleteTaskModel;
import com.cnlive.mam.service.VideoDeleteTaskService;

@Service("videoDeleteTaskService")
public class VideoDeleteTaskServiceImpl implements VideoDeleteTaskService {

    public VideoDeleteTaskServiceImpl() {
    }

    @Autowired
    private VideoDeleteTaskMapper videoDeleteTaskMapper;
    
    @Autowired
    private VideoDeleteHistoryMapper videoDeleteHistoryMapper;

    @Autowired
    private VideoService videoService;
    
    @Autowired
    private FileService fileService;
    
    @Override
    public List<VideoDeleteTaskModel> getAll() {
        return videoDeleteTaskMapper.getAll();
    }

    @Override
    public void delVideoAndFile(Long videoId) {
        videoService.deleteVideo(videoId);
//        fileService.deleteFileByVideoId(videoId);
    }

    @Override
    public VideoDeleteTaskModel create(VideoDeleteTaskModel v) {
    	videoDeleteTaskMapper.insert(v);
        return v;
    }
    
    @Override
    @Transactional
    public void delete(VideoDeleteTaskModel v) {
    	videoService.deleteVideo(v.getVideoId());
//    	fileService.deleteFileByVideoId(v.getVideoId());
    	videoDeleteTaskMapper.delete(v);
    	
    	VideoDeleteHistoryModel history = new VideoDeleteHistoryModel();
    	history.setVideoId(v.getVideoId());
    	history.setVideoName(v.getVideoName());
    	history.setCustomId(v.getCustomId());
    	history.setDeleteCustomId(v.getDeleteCustomId());
    	history.setDeleteSpId(v.getDeleteSpId());
    	history.setDeleteTime(v.getDeleteTime());
    	history.setDeleteMsg(v.getDeleteMsg());
    	history.setCreateTime(new Date());
    	videoDeleteHistoryMapper.insert(history);
    }
    
    @Override
    public void delete(Long id) {
    	videoDeleteTaskMapper.delete(id);
    }


}
