package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.vo.CustomCategoryVo;

import java.util.List;
import java.util.Map;

public interface VideoMapper {

	List<Integer> getPageByCondition(VideoCondition condition);

	Long getCountByCondition(VideoCondition condition);

	void insert(VideoModel t);

	VideoModel selectById(Long Id);

	void update(VideoModel t);

	List<Map<String, Object>> getVideoCountByCustomCategoryIds(List<CustomCategoryVo> list);

	List<Integer> getVideoInfoByCondition(VideoCondition condition);

	void deleteVideo(Long videoId);

	VideoModel getbyChouZhenTaskId(String taskId);

	VideoModel getByBusinessUUID(String businessUUID);

	List<Integer> getPageByConditionForSuperSp(SuperSpCondition condition);

	Long getCountByConditionForSuperSp(SuperSpCondition condition);

	List<VideoModel> getUploadFaildVideos();

	void inserIcms2MamModel(VideoModel t);

	List<Integer> getVideoInfoForSolr(VideoCondition condition);

    void updateStorageBySpid(VideoModel t);
}
