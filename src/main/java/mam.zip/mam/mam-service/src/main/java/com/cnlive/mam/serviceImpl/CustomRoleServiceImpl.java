package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.CustomRoleMapper;
import com.cnlive.mam.model.CustomRoleModel;
import com.cnlive.mam.service.CustomRoleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author liyi
 */
@Service("customRoleService")
public class CustomRoleServiceImpl implements CustomRoleService {
    private static Logger _log = LoggerFactory.getLogger(CustomRoleServiceImpl.class);

    @Autowired
    private CustomRoleMapper customRoleMapper;

    @Override
    public CustomRoleModel selectById(Integer id) {
        String cacheKey = Const.REDIS_KEY_ROLE + id ;
        CustomRoleModel model = CacheUtils.getJson(cacheKey, CustomRoleModel.class);
        if(model == null){
            model= customRoleMapper.selectById(id);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public List<CustomRoleModel> selectBySpId(Integer spId) {
        String cacheKey = Const.REDIS_KEY_ROLE_SP + spId ;
        List<CustomRoleModel> list = CacheUtils.get(cacheKey, List.class);
        if(list == null || list.size() == 0){
            list = customRoleMapper.selectBySpId(spId);
            if(list != null && list.size() > 0)CacheUtils.set(cacheKey,list, ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public List<CustomRoleModel> selectByRoleNameAndSpid(CustomRoleModel customRoleModel) {
        return customRoleMapper.selectByRoleNameAndSpid(customRoleModel);
    }

    @Override
    public void insert(CustomRoleModel customRoleModel) {
        customRoleMapper.insert(customRoleModel);
    }

    @Override
    public void update(CustomRoleModel customRoleModel) {
        customRoleMapper.update(customRoleModel);
        String cacheKey = Const.REDIS_KEY_ROLE + customRoleModel.getRoleId() ;
        String cacheKey_sp = Const.REDIS_KEY_ROLE_SP + customRoleModel.getSpId() ;
        CacheUtils.del(cacheKey,cacheKey_sp);

    }

    @Override
    public void delete(Integer roleId) {
        customRoleMapper.delete(roleId);
        String cacheKey = Const.REDIS_KEY_ROLE + roleId ;
        CacheUtils.del(cacheKey);
    }
}
