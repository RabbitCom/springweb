package com.cnlive.mam.mapper;

import com.cnlive.mam.model.CategoryFreeReviewModel;

/**
 * Created by zhangxiaobin
 */
public interface CategoryFreeReviewMapper {

    int insert(CategoryFreeReviewModel categoryFreeReviewModel);

    int update(CategoryFreeReviewModel categoryFreeReviewModel);

    CategoryFreeReviewModel selectByCustomId(Long customId);

    int delete(CategoryFreeReviewModel categoryFreeReviewModel);
}
