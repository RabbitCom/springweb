package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.cache.DictionaryLocalCache;
import com.cnlive.mam.common.reflect.IdGetUtil;
import com.cnlive.mam.condition.DictionaryCondition;
import com.cnlive.mam.mapper.DictionaryMapper;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.vo.DataGrid;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhangxiaobin
 */
@Service("dictionaryService")
public class DictionaryServiceImpl implements DictionaryService
{

    @Autowired
    private DictionaryMapper dictionaryMapper;
 
    @Autowired
    DictionaryLocalCache dictionaryLocalCache;

    public DictionaryServiceImpl()
    {

    }

    public Dictionary getById(Long id) {
        if(id == null)return null;
        Dictionary dictionary = dictionaryMapper.selectById(id);
        return dictionary;
    }

    public void save(Dictionary t)
    {
        Object id = IdGetUtil.getId(t);
        if (id == null)
        {
            create(t);
        } else
        {
            modify(t);
        }
    }

    @Override
    public void create(Dictionary t)
    {
        dictionaryMapper.insert(t);
    }

    @Override
    public void modify(Dictionary t)
    {
        dictionaryMapper.update(t);
    }

    @Override
    public List<Dictionary> getDictionaryByDicWord(String dicWord)
    {
        return dictionaryLocalCache.getDictionaryByCache(dicWord);
    }

    public List<Dictionary> getDictionary(String dicWord, Integer category)
    {
        return getDictionary(dicWord, category, null);

    }

    @Override
    public List<Integer> getDictionaryValues(String dicWord, Integer category)
    {
        List<Integer> ids = new ArrayList<Integer>();
        List<Dictionary> dictionaries = getDictionary(dicWord, category);
        for (Dictionary dictionary : dictionaries)
        {
            ids.add(dictionary.getDicValue());
        }
        return ids;
    }

    public List<Dictionary> getCategorys()
    {
        return getCategorys(null);
    }

    @Override
    public List<Dictionary> getAllDictionary()
    {
//        return dictionaryMapper.selectByWord(null);
        return dictionaryLocalCache.getDictionaryByCache(null);
    }

    public List<Dictionary> getDictionary(String dicWord, Integer category, String language)
    {
        List<Dictionary> dictionaries = dictionaryLocalCache.getDictionaryByCache(dicWord);
        List<Dictionary> results = new ArrayList<Dictionary>(dictionaries.size());
        for (Dictionary dictionary : dictionaries)
        {
            if (dictionary.inCategory(category))
            {
                results.add(dictionary);
            }
        }
        return results;
    }

    public List<Dictionary> getCategorys(String language)
    {
        return getDictionary(Dictionary.CATEGORY_DIC_WORD, -1, language);
    }

    @Override
    public List<Dictionary> getByCondition(DictionaryCondition condition)
    {
        return dictionaryMapper.getByCondition(condition);
    }

    @Override
    public Map<String, String> getDicInfo(String dicWord, String dicValues, Integer category)
    {
        Map<String, String> map = new HashMap<String, String>();
        List<String> dicValueList = Splitter.on(",").omitEmptyStrings().trimResults().splitToList(dicValues);
        for (String dicValueStr : dicValueList)
        {
            //获取缓存关键字字典数据集
            List<Dictionary> dictionaries = dictionaryLocalCache.getDictionaryByCache(dicWord);
            for (Dictionary dictionary : dictionaries)
            {
                //匹配对应的dic
                if (dicValueStr.equals(Integer.toString(dictionary.getDicValue())) && dictionary.inCategory(category))
                {
                    map.put(dictionary.getDicValue().toString(), dictionary.getShowValue());
                }
            }

        }
        return map;
    }

    @Override
    public Dictionary getDictionaryByDicValue(String dicWord, Integer dicValue)
    {
        List<Dictionary> dictionaries = dictionaryLocalCache.getDictionaryByCache(dicWord);
        for (Dictionary dictionary : dictionaries)
        {
            if (dictionary.getDicValue().equals(dicValue)) return dictionary;
        }
        return null;
    }

    /**
     * 通过所在分类获取所有字典数据
     *
     * @param category
     * @return
     */
    @Override
    public List<Dictionary> getALLDictionaryInCategory(Integer category)
    {
        List<Dictionary> results = Lists.newArrayList();
        //查询所有dicword
        List<String> dicwordList = dictionaryMapper.getAllDictionaryDicword();
        for (String dicWord : dicwordList)
        {
            List<Dictionary> dictionaries = dictionaryLocalCache.getDictionaryByCache(dicWord);
            for (Dictionary dictionary : dictionaries)
            {
                if (dictionary.inCategory(category))
                {
                    results.add(dictionary);
                }
            }
        }
        return results;
    }

    @Override
    public Long getByConditionCount(DictionaryCondition condition)
    {
        return dictionaryMapper.getByConditionCount(condition);
    }

    @Override
    public DataGrid getPageByCondition(DictionaryCondition condition) {
        Long count = getByConditionCount(condition);
        List<Dictionary> list = new ArrayList<>();
        if (count > 0) {
            list = getByCondition(condition);
        }
        return new DataGrid(count, list);
    }

    @Override
    public void delete(Integer dicId) {
        dictionaryMapper.delete(dicId);
    }

    @Override
    public Integer getMaxdicValue(Dictionary t) {
        return dictionaryMapper.getMaxdicValue(t);
    }
}
