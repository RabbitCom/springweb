package com.cnlive.mam.serviceImpl;

import java.util.Date;
import java.util.List;

import com.cnlive.mam.vo.DataGrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cnlive.mam.condition.VideoRemoveCondition;
import com.cnlive.mam.mapper.VideoDeleteTaskMapper;
import com.cnlive.mam.mapper.VideoRemoveMapper;
import com.cnlive.mam.model.VideoDeleteTaskModel;
import com.cnlive.mam.model.VideoRemoveModel;
import com.cnlive.mam.service.VideoRemoveService;

/**
 * Created by zhangxiaobin on 16/7/13.
 */
@Service("videoRemoveService")
public class VideoRemoveServiceImpl implements VideoRemoveService {

    @Autowired
    private VideoRemoveMapper videoRemoveMapper;
    
    @Autowired
    private VideoDeleteTaskMapper videoDeleteTaskMapper;

    @Override
    public void create(VideoRemoveModel model) {
        videoRemoveMapper.insert(model);
    }

	@Override
	public List<VideoRemoveModel> getRemoveVideo(VideoRemoveCondition video) {
		List<VideoRemoveModel> list = videoRemoveMapper.getRemoveVideo(video);
		return list;
	}
    
	@Override
	public VideoRemoveModel getOne(long id) {
		VideoRemoveModel model =  videoRemoveMapper.getRemoveOne(id);
		return model;
	}
	
    @Override
    public void deleteRemoveVideo(long id) {
    	videoRemoveMapper.deleteRemoveVideo(id);
    }
    
    @Override
    @Transactional
    public void removeVideo(VideoRemoveModel videoRemoveModel,long curSpId,long curCustomId,long customId) {
    	VideoDeleteTaskModel task = new VideoDeleteTaskModel();
    	task.setVideoId(videoRemoveModel.getVideoId());
    	task.setVideoName(videoRemoveModel.getVideoName());
    	task.setCustomId(customId);
    	task.setDeleteCustomId(curCustomId);
    	task.setDeleteSpId(curSpId);
    	task.setDeleteTime(new Date());
    	task.setDeleteMsg(videoRemoveModel.getRemoveMsg());
    	videoDeleteTaskMapper.insert(task);
    	
    	videoRemoveMapper.deleteRemoveVideo(videoRemoveModel.getId());
    }

	@Override
	public void removeVideo(Long videoId, String videoName, Long curCustomId, Long curSpId, Long customId,String delMsg) {
		VideoDeleteTaskModel task = new VideoDeleteTaskModel();
		task.setVideoId(videoId);
		task.setVideoName(videoName);
		task.setCustomId(customId);
		task.setDeleteCustomId(curCustomId);
		task.setDeleteSpId(curSpId);
		task.setDeleteTime(new Date());
		task.setDeleteMsg(delMsg);
		videoDeleteTaskMapper.insert(task);

	}

	@Override
	public DataGrid pageRemoveVideo(VideoRemoveCondition removeCondition) {
		Long totalList = videoRemoveMapper.pageCountRemoveVideo(removeCondition);
		if(totalList > 0){
			return new DataGrid(totalList,videoRemoveMapper.pageRemoveVideo(removeCondition));
		}
		return new DataGrid();
	}

}
