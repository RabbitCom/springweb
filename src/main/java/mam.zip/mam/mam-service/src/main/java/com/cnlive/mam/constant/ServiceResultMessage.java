package com.cnlive.mam.constant;

import com.cnlive.mam.common.resultMessage.IResultMessage;

/**
 * zhangxiaobin
 */

public enum ServiceResultMessage implements IResultMessage {


    SUCCESS("3000", "处理成功", "处理成功"),
    SYS_ERROR("3999", "处理失败", "系统异常"),


    CUSTOM_CATEGORY_CANT_ADD_VIDEO("3001", "客户分类{0}下不能添加视频", "客户分类{0}下不能添加视频"),
    BUYER_SALER_CUSTOMID_ARE_SAME("3002", "买卖租户不能相同", "买卖租户不能相同"),
    BUYER_CUSTOMID_NOT_EXIST("3003", "订购、到期租户不存在", "订购、到期租户不存在"),
    PURCHASED_VIDEO_NOT_EXIST("3004", "订购、到期视频不存在", "订购、到期视频不存在"),
    SRC_VIDEO_CANNOT_SALE("3005", "源订购视频不允许出售", "源订购视频不允许出售"),
    PURCHASED_ALBUM_NOT_EXIST("3006", "订购、到期专辑不存在", "订购、到期专辑不存在"),
    SRC_ALBUM_CANNOT_SALE("3007", "源订购专辑不允许购买", "源订购专辑不允许购买"),
    EXPIRE_PLAYPLATFORM_NOT_EXIST("3008", "到期视频的播放平台不存在", "到期视频的播放平台不存在"),
    EXPIRE_DOWNPLATFORM_NOT_EXIST("3009", "到期视频的下载平台不存在", "到期视频的下载平台不存在"),
    EXPIRE_PLAYPLATFORM_MISS("3010", "到期视频的播放平台不在源视频播放平台中", "到期视频的播放平台不在源视频播放平台中"),
    EXPIRE_DOWNPLATFORM_MISS("3011", "到期视频的下载平台不在源视频播放平台中", "到期视频的下载平台不在源视频播放平台中"),
    ORDERING_ALBUM_SIZE_ERROR("3012", "专辑下视频数量不匹配", "专辑下视频数量不匹配"),
    PARAM_ERROR("3013","参数错误","参数错误"),
    VIDEO_NOT_EXTIS("3014","视频不存在","视频不存在"),
    ;



    public final String code;
    public final String message;
    public final String messageForDev;

    ServiceResultMessage(String code, String message, String messageForDev) {
        this.code = code;
        this.message = message;
        this.messageForDev = messageForDev;
    }

	public String getCode() {
		return this.code;
	}

	public String getMessage() {
		return this.message;
	}

	public String getMessageForDev() {
		return this.messageForDev;
	}

}
