package com.cnlive.mam.mapper;

import com.cnlive.mam.model.CustomPermissionModel;

import java.util.List;

/**
 * Created by cuilongcan on 2017/5/10.
 */
public interface CustomPermissionMapper {

    List<CustomPermissionModel> getCustomRolesByCustomId(Long roleId);

    void updateCustomPermissionInfo();

    void delCustomPermission(Integer roleId);

    void addCustomPermission(Integer roleId, List<String> menuIds);

    List<CustomPermissionModel> getPermissionByRoleId(Integer roleId);

}
