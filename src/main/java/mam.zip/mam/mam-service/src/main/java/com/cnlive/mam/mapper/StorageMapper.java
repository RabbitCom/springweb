package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.StorageCondition;
import com.cnlive.mam.model.StorageModel;

import java.util.List;

public interface StorageMapper {
    Integer insert(StorageModel storageModel);

    void delete(Integer id);

    void update(StorageModel storageModel);

    void updateUseState(StorageModel storageModel);

    StorageModel getStorageById(Integer id);

    List<StorageModel> getStorageAllBySpId(Long spid);

    List<StorageModel> getByStorage(StorageModel storageModel);

    Long checkNameExtis(StorageModel storageModel);

    Long getCountByCondition(StorageCondition condition);

    List<StorageModel> getPageByCondition(StorageCondition condition);
}
