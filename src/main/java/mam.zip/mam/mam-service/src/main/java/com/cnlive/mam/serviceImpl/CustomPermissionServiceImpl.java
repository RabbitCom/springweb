package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.CustomPermissionMapper;
import com.cnlive.mam.model.CustomMenuModel;
import com.cnlive.mam.model.CustomPermissionModel;
import com.cnlive.mam.model.CustomRoleModel;
import com.cnlive.mam.service.CustomMenuService;
import com.cnlive.mam.service.CustomPermissionService;
import com.cnlive.mam.service.CustomRoleService;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.vo.CustomPermissionVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 2017/5/11.
 */
@Service("customPermissionService")
public class CustomPermissionServiceImpl implements CustomPermissionService {
    @Autowired
    CustomPermissionMapper customPermissionMapper;
    @Autowired
    CustomRoleService customRoleService;
    @Autowired
    CustomService customService;
    @Autowired
    CustomMenuService customMenuService;

    @Override
    public CustomPermissionVo getCustomRolesByRoleId(Integer roleId) {
        List<CustomPermissionModel> customPermissionModels = getPermissionByRoleId(roleId);
        List<CustomMenuModel> customMenuModels = customMenuService.selectAll();
        Map<Integer, CustomMenuModel> menuMap = new HashMap<>();
        for (CustomMenuModel customMenuModel : customMenuModels) {
            menuMap.put(customMenuModel.getMenuId(), customMenuModel);
        }
        List<CustomMenuModel> menus = new ArrayList<>();
        for (CustomPermissionModel permission : customPermissionModels) {
            menus.add(menuMap.get(permission.getMenuId()));
        }
        CustomPermissionVo customPermissionVo = new CustomPermissionVo();
        customPermissionVo.setRoleId(roleId);
        customPermissionVo.setMenus(menus);
        return customPermissionVo;
    }


    @Override
    public void delCustomPermission(Integer roleId) {
        customRoleService.delete(roleId);
        customPermissionMapper.delCustomPermission(roleId);
        deleteRoleCache(roleId);
    }

    @Override
    public void insertCustomPermission(CustomRoleModel customRoleModel, List<String> menus) {
        customRoleService.insert(customRoleModel);
        customPermissionMapper.addCustomPermission(customRoleModel.getRoleId(), menus);
    }

    @Override
    public void updateCustomPermission(Integer roleId, String roleName, String description, List<String> menus) {
        CustomRoleModel customRoleModel = new CustomRoleModel();
        customRoleModel.setRoleName(roleName);
        customRoleModel.setRoleId(roleId);
        customRoleModel.setDescription(description);
        customRoleService.update(customRoleModel);
        customPermissionMapper.delCustomPermission(roleId);
        if (menus.size() > 0) {
            customPermissionMapper.addCustomPermission(roleId, menus);
        }
        deleteRoleCache(roleId);
    }

    @Override
    public List<CustomPermissionModel> getPermissionByRoleId(Integer roleId) {
        String cacheKey = Const.REDIS_KEY_ROLE_PERM + roleId ;
        List<CustomPermissionModel> list = CacheUtils.get(cacheKey, List.class);
        if(list == null || list.size() == 0){
            list = customPermissionMapper.getPermissionByRoleId(roleId);
            if(list != null && list.size() > 0)CacheUtils.set(cacheKey,list, ExpireTime.NONE);
        }
        return list;
    }

    private void deleteRoleCache(Integer roleId){
        CacheUtils.del(Const.REDIS_KEY_ROLE_PERM + roleId);
    }
}
