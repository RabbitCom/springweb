package com.cnlive.mam.serviceImpl;

import java.util.List;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.common.resultMessage.CommonResultMessage;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.FileMapper;
import com.cnlive.mam.mapper.TranscodeHistoryMapper;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.TranscodeHistoryModel;
import com.cnlive.mam.service.FileService;

/**
 * 该services新增方法的时候要注意，是否需要播放地址，如果需要则要进行播放地址的过滤
 * @author zhangxiaobin
 */
@Service("fileService")
public class FileServiceImpl implements FileService {

    Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);

    @Autowired
	private FileMapper fileMapper;

	@Autowired
    private TranscodeHistoryMapper transcodeHistoryMapper;
    

    public void save(FileModel t) {

        Long id = t.getFileId();
        if (id == null) {
            create(t);
        } else {
            modify(t);
        }

    }

    @Override
    public void create(FileModel t) {
        fileMapper.insert(t);
    }

    @Override
    public void modify(FileModel t) {
        fileMapper.update(t);
        String cacheKey = Const.REDIS_KEY_FILE + t.getFileId();
		String cacheKey_files = Const.REDIS_KEY_FILES_VIDEO + t.getVideoId();
		CacheUtils.del(cacheKey,cacheKey_files);
    }

	@Override
	public FileModel getById(Long id) {
		if(id == null)return null;
		String cacheKey = Const.REDIS_KEY_FILE + id;
    	FileModel model = CacheUtils.getJson(cacheKey,FileModel.class);
    	if(model == null){
			model = fileMapper.selectById(id);
			if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
		}
		return model;
	}
	
	@Override
	public List<FileModel> getByVid(Long vid) {
		String cacheKey = Const.REDIS_KEY_FILES_VIDEO + vid;
		List<FileModel> fileModels = CacheUtils.get(cacheKey,List.class);
		if(fileModels == null || fileModels.size() == 0){
			fileModels =fileMapper.getFileByVid(vid);
			if(fileModels != null && fileModels.size() > 0)CacheUtils.set(cacheKey,fileModels, ExpireTime.NONE);
		}
		return fileModels;
	}

	@Override
	public List<FileModel> getFileByVidAndCoderate(Long vid,Integer cr) {
		return fileMapper.getFileByVidAndCoderate(vid, cr);
	}

	@Override
	public void deleteFile(FileModel file) {
    	if(file == null)return;
		fileMapper.deleteFile(file);
		String cacheKey = Const.REDIS_KEY_FILE + file.getFileId();
		CacheUtils.del(cacheKey);
	}

	@Override
	public List<FileModel> getByTaskId(String taskId) {
		return fileMapper.getByTaskId(taskId);
	}

	@Override
	public FileModel getByTaskIdAndTransCodeFmtAndCodeRate(String taskId,String transCodeFmt,Integer codeRate) {
		return fileMapper.getByTaskIdAndTransCodeFmtAndCodeRate(taskId,transCodeFmt,codeRate);
	}

	@Override
	public void saveFileList(List<FileModel> fileModels) {
		if(fileModels != null && fileModels.size()>0){
			for (FileModel fileModel : fileModels){
				fileMapper.insert(fileModel);
			}
		}
	}

	@Override
	public FileModel getFileByVidAndCoderateAndTransCodeFmt(Long videoId, Integer codeRate, String transCodeFmt) {
		FileModel file = fileMapper.getFileByVidAndCoderateAndTransCodeFmt(videoId, codeRate, transCodeFmt);
		if(file != null){
			return file;
		}
		return null;
	}

	@Override
	public List<FileModel> getByVidAndTransCodeFmt(Long vid, String transCodeFmt) {
		return fileMapper.getByVidAndTransCodeFmt(vid,transCodeFmt);
	}

	@Override
	public void deleteFileByVideoId(Long videoId) {
		List<FileModel> files = getByVid(videoId);
		for (FileModel file : files){
			deleteFile(file);
		}
	}

	@Override
	public String getTranscodeErrorShowMsg(Long fileId,String taskId) {
		TranscodeHistoryModel transcodeHistory = transcodeHistoryMapper.selectNewByFileId(fileId,taskId);
		if(transcodeHistory != null){
			String errorCode = transcodeHistory.getErrorCode();
			Integer status = transcodeHistory.getStatus();
			if(status.intValue() == Const.TRANSCODEHISTORY_FAIL.intValue()){
				return CommonResultMessage.getTranscodeErrorMessage(errorCode);
			}
		}
		return "";
	}

}
