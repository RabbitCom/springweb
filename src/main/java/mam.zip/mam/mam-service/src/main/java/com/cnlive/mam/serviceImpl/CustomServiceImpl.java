package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.CustomCondition;
import com.cnlive.mam.mapper.CustomMapper;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.DataGrid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by zhangxiaobin
 */
@Service("customService")
public class CustomServiceImpl implements CustomService {

    private static Logger _log = LoggerFactory.getLogger(CustomServiceImpl.class);

    @Autowired
    private CustomMapper customMapper;

    @Autowired
    DictionaryService dictionaryService;

    @Autowired
    CustomCategoryService customCategoryService;

    @Resource
    CategoryFreeReviewService categoryFreeReviewService;

    @Resource(name = "videoService")
    VideoService videoService;

    @Resource(name = "albumService")
    AlbumService albumService;

    @Value("#{configProperties['getCustomDoamin_url']}")
    private String getCustomDoaminUrl;

    @Value("#{configProperties['getUserInfoByUserIdUrl']}")
    private String getUserInfoByUserIdUrl;
    
    public CustomModel getById(Long id) {
        if(id == null)return null;
        String cacheKey = Const.REDIS_KEY_CUSTOMER + id ;
        CustomModel model = CacheUtils.getJson(cacheKey, CustomModel.class);
        if(model == null){
            model= customMapper.selectById(id);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;

    }

    public void save(CustomModel t) {
        modify(t);
    }

    @Override
    public void create(CustomModel t) {
        customMapper.insert(t);
    }

    @Override
    public void modify(CustomModel customModel) {
        customMapper.update(customModel);
        String cacheKey = Const.REDIS_KEY_ALBUM + customModel.getCustomId();
        CacheUtils.del(cacheKey);
    }

    public void saveUcCustom(CustomModel customModel) {
        create(customModel);
    }

    @Override
    public DataGrid getCustomInfoList(CustomCondition customCondition) {
        List<CustomModel> customInfoList = customMapper.getCustomInfoList(customCondition);
        Long customCount = customMapper.getCountByCondition(customCondition);
        return new DataGrid(customCount, customInfoList);
    }

    @Override
    public List<CustomModel> getCustomsInfoByRoleId(Long roleId) {
        return customMapper.getCustomsInfoByRoleId(roleId);
    }

	@Override
	public long findMaxTm() {
		Long l = customMapper.findMaxTm();
		return l == null ? 0 : l;
	}

    @Override
	public Long getParentCutsomerBySpId(Long spId) {
		return customMapper.getParentCutsomerBySpId(spId);
	}

    @Override
    public Long countByCustom(CustomModel t) {
        return customMapper.countByCustom(t);
    }

    @Override
    public List<CustomModel> getByCustomName(String customName,Long spId) {
        return customMapper.getByCustomName(customName,spId);
    }
}
