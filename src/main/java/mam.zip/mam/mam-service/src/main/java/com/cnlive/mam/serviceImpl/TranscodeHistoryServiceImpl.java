package com.cnlive.mam.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.TranscodeHistoryMapper;
import com.cnlive.mam.model.TranscodeHistoryModel;
import com.cnlive.mam.service.TranscodeHistoryService;

/**
 * @author wangchaojie
 */
@Service("transcodeHistoryService")
public class TranscodeHistoryServiceImpl implements TranscodeHistoryService {

    public TranscodeHistoryServiceImpl() {
    }

    @Autowired
    private TranscodeHistoryMapper transcodeHistoryMapper;

    @Override
    public TranscodeHistoryModel create(TranscodeHistoryModel t) {
    	transcodeHistoryMapper.insert(t);
        return t;
    }
}
