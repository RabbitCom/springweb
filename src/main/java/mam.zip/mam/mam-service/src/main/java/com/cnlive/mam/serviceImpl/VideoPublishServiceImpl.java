package com.cnlive.mam.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.CategoryRelation;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.PublishHistory;
import com.cnlive.mam.model.PublishTaskModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.CustomSpInfoService;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.PublishHistoryService;
import com.cnlive.mam.service.PublishTaskService;
import com.cnlive.mam.service.VideoPublishService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ReleaseObj;

@Service("videoPublishService")
public class VideoPublishServiceImpl implements VideoPublishService {

	private static Logger _log = LoggerFactory.getLogger(VideoPublishServiceImpl.class);
	
	@Autowired
	private VideoService videoService;

    @Autowired
    private CustomCategoryService customCategoryService;
    
    @Autowired
    private FileService fileService;
    
    @Autowired
    private CustomService customService;
    
    @Autowired
    private PublishHistoryService publishHistoryService;
    
    @Autowired
    private PublishTaskService publishTaskService;
    
    @Autowired
    private CustomSpInfoService customSpInfoService;
    
    private static final Integer PUBLISH_STATUS_SUCCESS=0;//发布成功
    
    private static final Integer PUBLISH_STATUS_CATEGORYERROR=1;//发布失败，自动发布时没有目录
    
    private static final Integer PUBLISH_STATUS_APIERROR=2;//发布失败，接口错误
    
    /**
     * @Description:判断是否存在目录结构
     */
	@Override
	public JsonResult checkCategory(long videoId, Long customId) {
		CustomModel customModel = customService.getById(customId);
		CustomSpInfoModel customSpInfoModel = new CustomSpInfoModel();
		if(customModel != null){
			customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
		}
		if(customModel!=null && Const.IS_START_CATEGORY_NO==customSpInfoModel.getIsStartCategory()){
			//未启用栏目时
			return JsonResult.createSuccessInstance("1");
		}else{
			CategoryRelation categoryRelation = this.getCategoryRelation(videoId, customId);
			if(categoryRelation!=null && StringUtils.isNotBlank(categoryRelation.getCms_column_id()) && StringUtils.isNotBlank(categoryRelation.getCms_column_name())){//如果存在目录结构时，组装数据，直接发布
				return JsonResult.createSuccessInstance("1");
			}else{//如果不存在目录，在任务表中获取目录
				return JsonResult.createSuccessInstance("0");
			}
		}
	}
	
	/**
     * @Description:获取目录结构
     */
	public CategoryRelation getCategoryRelation(Long videoId, Long customId){
		CategoryRelation categoryRelation=new CategoryRelation();
		VideoModel videoModel = videoService.getById(videoId);
		if(videoModel!=null){
			Long customCategoryId = videoModel.getCustomCategoryId();
			categoryRelation.setCustomCategoryId(customCategoryId);
			categoryRelation.setCustomId(customId);
			categoryRelation.setCategoryDicValue(videoModel.getCategory());
			categoryRelation = customCategoryService.getPublishCategoryRelation(categoryRelation);
		}
		return categoryRelation;
	}
	

	/**
     * @Description:视频自动发布
     */
	@Override
	public JsonResult toReleaseVideo(Long videoId,Long customId) {
		ReleaseObj releaseObj=new ReleaseObj();
		releaseObj.setVideoIds(videoId);
		VideoModel videoModel = videoService.getById(videoId);
		CustomModel customModel = customService.getById(customId);
		PublishTaskModel publishTaskModel = new PublishTaskModel();
		Integer category = videoModel.getCategory();
		Long customCategory = videoModel.getCustomCategoryId();
		Long spId = customModel.getSpId() ;
		CategoryRelation relationbyselect=new CategoryRelation();

		if(customCategory != null && customCategory.intValue() != 0 ){
			relationbyselect = customCategoryService.getRelationBySpidAndCustomCategory(customCategory,spId);
		}else {
			relationbyselect = customCategoryService.getRelationBySpidAndCategory(category,spId);
		}
		if(relationbyselect ==null){
			addPublishHistory(videoId, customId, PUBLISH_STATUS_CATEGORYERROR,"分类信息未设置对应栏目");//添加到历史发布表
			return releaseFail(videoId,customId);//发布失败
		}else {
			publishTaskModel.setMamNodeId(relationbyselect.getMAM_NodeID());
			publishTaskModel.setMamNodeName(relationbyselect.getMAM_NodeName());
			publishTaskModel.setCmsColumnId(relationbyselect.getCms_column_id());
			publishTaskModel.setCmsColumnName(relationbyselect.getCms_column_name());
		}
		publishTaskModel.setCustomId(customId);
		publishTaskModel.setVideoId(videoId);
		publishTaskModel.setPublishState(0);
		publishTaskModel.setPrePublishedTime(new Date());

		CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
		if(StringUtils.isNotBlank(customSpInfoModel.getPublishUrl())){
			publishTaskService.insert(publishTaskModel);
			return JsonResult.createSuccessInstance("success");
		}else {
			this.addPublishHistory(videoId, customId, PUBLISH_STATUS_APIERROR,"未设置发布内容地址");//添加到历史发布表
			return releaseFail(releaseObj.getVideoIds(),customId);//发布失败
		}
	}
	
	/**
     * @Description:调用cms接口
     */
    private JSONObject getPageUrl(Long videoId,Long customId){
    	JSONObject returnJson=new JSONObject();
    	try {
    		VideoModel video=videoService.getById(videoId);
    		CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(video.getSpid());
//        	List<FileModel> fileList=fileService.getByVid(videoId);
        	JSONObject jsonObject = this.assemblyInterfaceData(video,customId);//组装cms接口数据
        	_log.info("请求cms接口参数:____________"+jsonObject.toJSONString());
        	Map<String,String> params = new HashedMap();
        	params.put("json",jsonObject.toString());
			String resStr = HttpClientUtils.post(customSpInfoModel.getPublishUrl(),params,50000);
        	_log.info("请求cms接口返回数据:____________"+resStr);
			returnJson = JSONObject.parseObject(resStr);
		} catch (Exception e) {
			_log.error("请求cms接口失败：_____________"+e.getMessage());
			returnJson.put("result", "fail");
			return returnJson;
		}
    	return returnJson;
    }
    
    /**
     * @Description:组装cms接口数据
     */
    private JSONObject assemblyInterfaceData(VideoModel video,Long customId){
    	return getVideoInfo(video,getCategoryInfo(customId,video,getPicture(video.getAllPicScale(),new JSONObject())));
    }
    
    /**
     * @Description:cms接口中获取url地址
     */
    private JSONObject getUrl(List<FileModel> fileList,JSONObject json){
//    	String VideoFlashHUrl="";					//Flash高清
//    	String VideoFlashLUrl="";					//Flash低码
//    	String VideoFlashUrl="";					//flash主视频
//    	String VideoHUrl="";						//节目高清播放地址M3u8
//    	String VideoLUrl="";						//节目低码播放地址M3u8
//    	String VideoUrl="";						//节目主视频播放地址M3u8
//    	for (int i = 0; i < fileList.size(); i++) {
//    		Integer rate=fileList.get(i).getCodeRate();
//    		String url=playDomain+Const.SEPARATE_XIE+fileList.get(i).getStoreUri();
//			String rui=url.substring(url.lastIndexOf("."));
//    		switch (rate) {
//    		case 400:
//    			if(rui.equals(".mp4")){
//					VideoFlashLUrl=url;
//				}else if(rui.equals(".m3u8")){
//					VideoLUrl=url;
//				}
//    				break;
//    		case 800:
//				if(rui.equals(".mp4")){
//					VideoFlashUrl=url;
//				}else if(rui.equals(".m3u8")){
//					VideoUrl=url;
//				}
//				break;
//    		case 1500:
//				if(rui.equals(".mp4")){
//					VideoFlashHUrl=url;
//				}else if(rui.equals(".m3u8")){
//					VideoHUrl=url;
//				}
//				break;
//			default:
//				break;
//			}
//    	}
//    	json.put("MAM_VideoFlashHUrl",VideoFlashHUrl);//Flash高清	  缺少字段
//    	json.put("MAM_VideoFlashLUrl", VideoFlashLUrl);//Flash低码	     缺少字段
//    	json.put("MAM_VideoFlashUrl",VideoFlashUrl);	//Flash主视频				如无值，默认设置为MAM_VideoUrl值			http://wideo03.cnlive.com/video/data1/2017/0310/193969/800/067deb327fd547a0890f576d32c71660_193969_800.mp4
//    	json.put("MAM_VideoHUrl",VideoHUrl);	//节目高清播放地址M3u8
//    	json.put("MAM_VideoLUrl",VideoLUrl);	//节目低码播放地址M3u8
//    	json.put("MAM_VideoUHUrl","");
//    	json.put("MAM_VideoFlashUHUrl","");
//    	json.put("MAM_VideoUrl",VideoUrl);//节目主视频播放地址M3u8					公网全路径     MediaX.cnlive.com 		http://wideo03.cnlive.com/video/data1/2017/0310/193969/800/067deb327fd547a0890f576d32c71660_193969_800.m3u8
    	return json;
    }
    
    /**
     * @Description:cms接口中获取获取图片
     */
    private  JSONObject getPicture(Map<String,String> map,JSONObject json){
    	try{
    		if(map == null || map.size() == 0){
    			return json;
			}
			String picOne = String.valueOf(map.get("224*126"));
			String picTwo = String.valueOf(map.get("485*303"));//大海报
//			String poster=picOne.substring(0,picOne.indexOf("@"));//标准海报
//			String poster2=picTwo.substring(0,picTwo.indexOf("@"));//标准海报
			json.put("MAM_PosterUrl",picOne);	//*必填//节目普通海报 	数据库少字段		存放加工单位   #
			json.put("MAM_BigPostUrl",picTwo);	//节目大海报地址 		*  不能为空					#
		}catch (Exception ex){
			_log.error("发布视频，接口中获取获取图片异常，error={}",ex);
			ex.printStackTrace();
		}
    	return json;
    }
    
    /**
     * @Description:获取目录结构数据
     */
    private JSONObject getCategoryInfo(Long customId,VideoModel video,JSONObject json){
    	try{
			if(video!=null && video.getCategory()!=null){
				PublishTaskModel task=new PublishTaskModel();
				task.setCustomId(customId);
				task.setVideoId(video.getVideoId());
				List<PublishTaskModel> publishTaskModelList = publishTaskService.getTaskByCondition(task);
				if(publishTaskModelList!=null && publishTaskModelList.size()>0){
					PublishTaskModel publishTaskModel = publishTaskModelList.get(0);
					json.put("MAM_NodeID", publishTaskModel.getMamNodeId());						//媒资的节点路径ID,		如：025-008-009  给出父子关系，横杠隔开				#
					json.put("MAM_NodeName",publishTaskModel.getMamNodeName());						//媒资的节点路径名字	//怀疑有问题	不能为空				#
					json.put("cms_column_id",publishTaskModel.getCmsColumnId());
					json.put("cms_column_name",publishTaskModel.getCmsColumnName());					//文档发布名称    路径名称
				}
			}
		}catch (Exception ex){
    		_log.error("发布视频，获取目录结构树异常，error={}",ex);
			ex.printStackTrace();
		}
    	return json;
    }
    
    /**
     * @Description:cms接口中获取视频信息
     */
    @SuppressWarnings("unchecked")
	private JSONObject getVideoInfo(VideoModel video,JSONObject json){
    	try{
			String extendProperties = video.getExtendProperties();
			String actors = "";
			String director = "";
			if(StringUtils.isNotBlank(extendProperties)){
				try{
					Map<String,String> map = (Map<String,String>)JSONObject.parse(extendProperties);
					if(map != null){
						actors = map.get("actor");
						director = map.get("director");
					}
				}catch(Exception e){
					_log.error("getVideoInfo-发布获取演员或导演失败，videoId："+video.getVideoId());
				}
			}

			json.put("MAM_Actors",actors);//演员#
			if(video.getReleaseDate()!=null){
				json.put("MAM_Airtime",CalendarUtil.getShortDateString(video.getReleaseDate()));	//上映年份
			}
			json.put("MAM_CreateDate", CalendarUtil.getDefaultDateString(video.getCreateTime()));
			json.put("ColName",video.getAlbumName());
			json.put("MAM_Description",video.getSynopsis());//没有数据库字段	  ！！！																		//描述			#
			json.put("MAM_Director",director);//导演
			json.put("MAM_Duration",getDurationMill(video.getDuration())); //时长																///时长
			json.put("MAM_PrgType",video.getCategory()); //视频分类
			json.put("MAM_ProducerID",String.valueOf(video.getCustomId()));	//存放加工单位   存放生产者 *必填    //上海制作中心
			json.put("MAM_PublishDate",CalendarUtil.getDefaultDateString(video.getPublishTime()));//发布时间
			json.put("MAM_SeriesOrder",video.getEpisode() == null ? "0" : video.getEpisode());//电视剧子集序号
			json.put("MAM_SeriesSum","0");//电视剧总集数
			json.put("MAM_SmallPosterUrl","");//节目小海报地址  缺少字段 240*160 不一定有值?
			json.put("MAM_SubTitle",String.valueOf(video.getSubTitle()));//副标题
			json.put("MAM_TVColumnMarkID","");//tv 标记列id    缺少字段
			json.put("MAM_TVColumnMarkName","");//tv标记列名称 		#  缺少字段

			if(StringUtils.isNotBlank(video.getTag())){
				List<String> tags = Splitter.on(Const.SEPARATE_XIE).omitEmptyStrings().splitToList(video.getTag());
				json.put("MAM_Tags",Joiner.on(" ").skipNulls().join(tags));//标签  		娱评 内地 刘汉强 资讯
			}

			json.put("MAM_Title",video.getVideoName());//标题   *必填
			json.put("MAM_UUID",video.getBusinessUUID());	//	节目标识  节目唯一标示   	必填
			json.put("MAM_VideoEditor",video.getCustomName());	//编辑员  *必填
			json.put("spId",String.valueOf(video.getSpid()));
			json.put("copyright_material_id","0");
			//增加详细描述属性 2017-08-22
			json.put("MAM_DetailDescription",StringUtils.isEmpty(video.getDescription())?"":video.getDescription());
		}catch (Exception ex){
			_log.error("发布视频，组装数据error,error={}",ex);
			ex.printStackTrace();
		}
    	return json;
    }
    
    /**
     * @Description:发布成功
     */
    private JsonResult releaseSuccess(ReleaseObj releaseObj,Long customId) {
    	try {
    		VideoModel video=new VideoModel();
        	video.setVideoPlyUrl(releaseObj.getVideoPlyUrl());
        	video.setPublishTime(new Date());
        	video.setStatus(ModelStatus.ReleaseSuccess);
        	video.setVideoId(releaseObj.getVideoIds());
			video.setCustomId(customId);
			video.setUpdateUserId(customId);
        	videoService.modify(video);
    	} catch (Exception e) {
    		_log.error("发布操作，更新视频信息失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("发布失败");
		}
    	return JsonResult.createSuccessInstance("发布成功");  	
    }
    
    /**
     * @Description:发布失败
     */
    public JsonResult releaseFail(Long videoId,Long customId) {
    	try {
    		VideoModel video=new VideoModel();
        	video.setStatus(ModelStatus.ReleaseFail);
        	video.setVideoId(videoId);
        	video.setUpdateTime(new Date());
        	video.setCustomId(customId);
        	video.setUpdateUserId(customId);
        	videoService.modify(video);
        	return JsonResult.createErrorInstance("发布失败");
		} catch (Exception e) {
			 _log.error("视频发布失败，失败信息：____________"+e.getMessage());
  			 return JsonResult.createErrorInstance("请求失败");
		}
    }
    
    /**
     * @Description:添加到历史发布表
     */
    public void addPublishHistory(Long videoId,Long customId,Integer status,String description){
    	PublishHistory publishHistory=new PublishHistory();
    	publishHistory.setVideoId(videoId);
    	publishHistory.setCustomId(customId);
    	PublishHistory videoPublishHistory = publishHistoryService.selectByVideoIdAndCustomId(publishHistory);
    	if(videoPublishHistory!=null){
    		videoPublishHistory.setDescription(description);
    		videoPublishHistory.setPublishTime(new Date());
    		publishHistoryService.update(videoPublishHistory);
    	}else{
    		PublishHistory pHistory=new PublishHistory();
    		pHistory.setVideoId(videoId);
    		pHistory.setCustomId(customId);
    		pHistory.setPublishUser(String.valueOf(customId));
    		pHistory.setPublishState(status);
    		pHistory.setPublishTime(new Date());
    		pHistory.setDescription(description);
    		publishHistoryService.insert(pHistory);
    	}
    	
    }

	@Override
	public JsonResult publishVideo(Long videoId, Long customId) {
		ReleaseObj releaseObj=new ReleaseObj();
		releaseObj.setVideoIds(videoId);
    	CustomModel customModel = customService.getById(customId);
    	CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
		if(StringUtils.isNotBlank(customSpInfoModel.getPublishUrl())){
			JSONObject jsonObject =this.getPageUrl(videoId,customId);// 调用icms接口
			String result = String.valueOf(jsonObject.get("result"));
			if("Success".equalsIgnoreCase(result)){
				String pageUrl = String.valueOf(jsonObject.get("pageUrl"));
				releaseObj.setVideoPlyUrl(pageUrl);
				this.releaseSuccess(releaseObj,customId);
				this.addPublishHistory(videoId, customId, PUBLISH_STATUS_SUCCESS,"发布成功");//添加到历史发布表
				return JsonResult.createSuccessInstance("success");
			}else{
				String description = String.valueOf(jsonObject.get("resultDesc"));
				this.addPublishHistory(videoId, customId, PUBLISH_STATUS_APIERROR,"ICMS接口错误："+description);//添加到历史发布表
				this.releaseFail(releaseObj.getVideoIds(),customId);//发布失败
				return JsonResult.createErrorInstance("fail");
			}
		}else {
			this.addPublishHistory(videoId, customId, PUBLISH_STATUS_APIERROR,"未设置发布内容地址");//添加到历史发布表
			this.releaseFail(releaseObj.getVideoIds(),customId);//发布失败
			return JsonResult.createErrorInstance("fail");
		}
	}

    private String getDurationMill(Long duration){
		if(duration == null || 0 == duration.longValue() ){
			return "0";
		}
		return String.valueOf(duration/1000);
	}
}
