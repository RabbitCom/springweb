package com.cnlive.mam.mapper;

import java.util.List;

import com.cnlive.mam.model.VideoDeleteTaskModel;

public interface VideoDeleteTaskMapper {

    void insert(VideoDeleteTaskModel t);

    void delete(VideoDeleteTaskModel t);
    
    List<VideoDeleteTaskModel> getAll();

	void delete(Long id);
}
