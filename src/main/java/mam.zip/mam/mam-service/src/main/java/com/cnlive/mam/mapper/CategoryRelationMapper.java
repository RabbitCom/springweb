package com.cnlive.mam.mapper;

import com.cnlive.mam.model.CategoryRelation;
import org.apache.ibatis.annotations.Param;

public interface CategoryRelationMapper {

	void insert(CategoryRelation t);

	CategoryRelation getRelationBySpidAndCustomCategory(@Param("customCategoryId")Long customCategoryId, @Param("spId")Long spId);
	
	CategoryRelation getRelationBySpidAndCategory(@Param("categoryDicValue")Integer categoryDicValue, @Param("spId")Long spId);
	
	void deleteByCategoryRelationId(Long categoryRelationId);
	
	void deleteByCustomCategoryId(Long customCategoryId);

	void updateCategoryRelation(CategoryRelation categoryRelation);
}
