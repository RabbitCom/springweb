package com.cnlive.mam.aspect;

import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.CustomSpInfoService;
import com.cnlive.mam.service.RemoteService;
import com.cnlive.mam.service.VideoPublishService;
import com.cnlive.mam.service.VideoService;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import java.util.Date;

/**
 * Created by zhangxiaobin on 2017/3/29.
 */
@Aspect
@Component
public class VideoUpdateAcpect {

    private final static Logger LOGGER = LoggerFactory.getLogger(VideoUpdateAcpect.class);

    @Resource(name="videoService")
    private VideoService videoService;

    @Resource(name="customService")
    private CustomService customService;

    @Resource(name = "videoPublishService")
    private VideoPublishService videoPublishService  ;
    
    @Resource(name="remoteService")
    private RemoteService remoteService;
    
    @Resource(name="customSpInfoService")
    private CustomSpInfoService customSpInfoService;

    @Pointcut("execution(* com.cnlive.mam.service.VideoService.modify(..))")
    public void  VideoUpdateCut(){

    }

    @AfterReturning(value="VideoUpdateCut()",returning = "videoModel")
    public void afterReturning(JoinPoint joinPoint, VideoModel videoModel){
        LOGGER.info("videoUpdate aspect begin");
        //视频转码成功以后才会走自动逻辑
        if(videoModel.getFileStatus() != null &&  FileStatus.TranscodingSuccess.getDbValue() == videoModel.getFileStatus().getDbValue()){
            Long videoId = videoModel.getVideoId();
            ModelStatus videostatus =  videoModel.getStatus();
            if(videoId == null || videostatus == null){
                LOGGER.error("videoUpdate aspect end videoStatus is null,videoId={}",videoId);
                return;
            }
            CustomModel customModel = customService.getById(videoModel.getUpdateUserId());
            if(customModel == null){
                LOGGER.error("videoUpdate aspect end customModel is null,customId={}",videoModel.getCustomId());
                return;
            }
            CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(customModel.getSpId());
            if(customSpInfoModel == null){
                LOGGER.error("videoUpdate aspect end customSpInfoModel is null,spid={}",customModel.getSpId());
                return;
            }
            Integer autoAudit = customSpInfoModel.getAutoAudit(); //全局自动送审设置
            Integer cAutoPublish = customSpInfoModel.getAutoPublish(); //全局自动发布设置
            Integer cAutoOnline = customSpInfoModel.getAutoOnlie(); //全局自动上线设置

            //自动送审逻辑
            if(ModelStatus.EditOver.getDbValue() == videostatus.getDbValue()
                    && autoAudit != null && Const.AUTOAUDIT_YES == autoAudit){
                LOGGER.info("videoUpdate aspect autoAudit");
                videoService.songShen(videoId, customModel);
            }

            //自动上线逻辑
            if(ModelStatus.AuditSuccess.getDbValue() == videostatus.getDbValue()){
                //视频设置了自动上线
                if(cAutoOnline != null && Const.AUTOAUDIT_YES ==cAutoOnline){
                    LOGGER.info("videoUpdate aspect autoOnline by self");
                    onLineVideo(videoId,customModel.getCustomId());

                }
            }

            //自动发布逻辑
            if(ModelStatus.OnLine.getDbValue() == videostatus.getDbValue()){
                //自动发布功能
                if(cAutoPublish != null && Const.AUTOAUDIT_YES ==cAutoPublish){
                    LOGGER.info("videoUpdate aspect autoPublish by videoSelf");
                    publishVideo(videoId,customModel.getCustomId());
                }

            }
        }

        LOGGER.info("videoUpdate aspect end success");
    }

    private void onLineVideo(Long videoId,Long customId){
        VideoModel updateVideo = new VideoModel();
        updateVideo.setVideoId(videoId);
        updateVideo.setUpdateTime(new Date());
        updateVideo.setStatus(ModelStatus.OnLine);
        updateVideo.setCustomId(customId);
        updateVideo.setUpdateUserId(customId);
        updateVideo.setFileStatus(FileStatus.TranscodingSuccess);
        videoService.modify(updateVideo);
        remoteService.remoteDianBoPlay(videoId,ModelStatus.OnLine);
    }

    private void publishVideo(Long videoId,Long customId){
        VideoModel update = new VideoModel();
        update.setVideoId(videoId);
        update.setStatus(ModelStatus.ReleaseIng);
        update.setUpdateTime(new Date());
        update.setCustomId(customId);
        update.setUpdateUserId(customId);
        update.setPublishTime(new Date());
        videoService.save(update);
        videoPublishService.toReleaseVideo(videoId, customId);
    }

}
