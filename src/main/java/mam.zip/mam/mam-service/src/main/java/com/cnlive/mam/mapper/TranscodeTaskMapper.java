package com.cnlive.mam.mapper;

import java.util.List;

import com.cnlive.mam.model.TranscodeTaskModel;

public interface TranscodeTaskMapper {

    void insert(TranscodeTaskModel t);

    void update(TranscodeTaskModel t);
    
    void delete(TranscodeTaskModel t);
    
    TranscodeTaskModel selectById(Long id);
    
    TranscodeTaskModel selectByFileTaskId(String fileTaskId);
    
    List<TranscodeTaskModel> getAll();

    Long getAllCount();
}
