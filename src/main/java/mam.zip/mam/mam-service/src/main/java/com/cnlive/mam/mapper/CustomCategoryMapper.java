package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.CustomCategoryCondition;
import com.cnlive.mam.model.CustomCategoryModel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhangxiaobin
 */
public interface CustomCategoryMapper {
    List<CustomCategoryModel> selectInfosByCondition(CustomCategoryCondition customCategoryCondition);

    List<CustomCategoryModel> getCustomCategoryByParentId(Long customCategoryId);

    void delete(CustomCategoryModel t);

    void insert(CustomCategoryModel t);

    CustomCategoryModel selectById(Long Id);

    void update(CustomCategoryModel t);

    List<CustomCategoryModel> selectByIds(List<String> ids);

    Long getCountByCondition(CustomCategoryCondition customCategoryCondition);

    List<CustomCategoryModel> selectByParentIds(List<String> ids);

    List<CustomCategoryModel> getParentCustomCategory(@Param("spid") Long spid);

    List<CustomCategoryModel> selectPageByCondition(CustomCategoryCondition customCategoryCondition);
}
