package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.DictionaryCondition;
import com.cnlive.mam.model.Dictionary;

import java.util.List;

/**
 * @author zhangxiaobin
 */
public interface DictionaryMapper {
    List<Dictionary> selectByWord(String dicWord);

    List<Dictionary> getByCondition(DictionaryCondition condition);

    Long getByConditionCount(DictionaryCondition condition);

    void insert(Dictionary t);

    Dictionary selectById(Long Id);

    void update(Dictionary t);

    void delete(Integer dicId);

    Dictionary getDictionaryByDicValue(Integer dicValue);

    List<Dictionary> getDictionaryByDicValues(List<String> dicValues);

    List<String> getAllDictionaryDicword();

    Integer getMaxdicValue(Dictionary t);
}
