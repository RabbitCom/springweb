package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.SpExpMapper;
import com.cnlive.mam.model.SpExpModel;
import com.cnlive.mam.service.SpExpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
/**
 * Created by zhangxiaobin on 2017/8/16.
 */
@Service("spExpService")
public class SpExpServiceImpl implements SpExpService {

    private static Logger _log = LoggerFactory.getLogger(SpExpServiceImpl.class);

    @Autowired
    private SpExpMapper mapper;

    @Override
    public SpExpModel save(SpExpModel t) {
        if (t.getId() == null) {
            return create(t);
        } else {
            return modify(t);
        }
    }

    @Override
    public SpExpModel create(SpExpModel t) {
        if(t==null)return null;
        mapper.insert(t);
        return t;
    }

    @Override
    public SpExpModel modify(SpExpModel t) {
        if(t == null) return null;
        mapper.update(t);
        String cacheKey = Const.REDIS_KEY_SP_EXP_ID + t.getId() ;
        String cacheKey_sp = Const.REDIS_KEY_SP_EXP_SPID + t.getSpId() ;
        CacheUtils.del(cacheKey,cacheKey_sp);
        return t;
    }

    @Override
    public SpExpModel getById(Long id) {
        if(id==null)return null;
        String cacheKey = Const.REDIS_KEY_SP_EXP_ID + id ;
        SpExpModel model = CacheUtils.getJson(cacheKey, SpExpModel.class);
        if(model == null){
            model = mapper.selectById(id);
            if(model != null) CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public List<SpExpModel> getBySpId(Long spId) {
        String cacheKey = Const.REDIS_KEY_SP_EXP_SPID + spId ;
        List<SpExpModel> list = CacheUtils.get(cacheKey,List.class);
        if(list == null || list.size() == 0){
            list = mapper.selectBySpId(spId);
            if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public List<SpExpModel> getBySpIdAndStorageType(Long spId, StorageTypeEnum type) {
        List<SpExpModel> returnList = new ArrayList<>();
        List<SpExpModel> spList = getBySpId(spId);
        for (SpExpModel m : spList){
            if(type.getDbValue() == m.getStorageType().getDbValue()){
                returnList.add(m);
            }
        }
        return returnList;
    }

    @Override
    public SpExpModel getBySpIdAndStorageTypeAndContentType(Long spId, StorageTypeEnum type, Integer contenType) {
        SpExpModel model = null;
        List<SpExpModel> list = getBySpIdAndStorageType(spId, type);
        for (SpExpModel m : list){
            int contentVal = contenType.intValue();
            int mcontentVal = m.getSpExpContentType().intValue();
            if(contentVal == mcontentVal){
                model =  m;
                break;
            }
        }
        return model;
    }
}
