package com.cnlive.mam.serviceImpl;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.AdminCondition;
import com.cnlive.mam.model.SpExpModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.SpExpService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.DataGrid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.CustomSpInfoMapper;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.service.CustomSpInfoService;

@Service("customSpInfoService")
public class CustomSpInfoServiceImpl implements CustomSpInfoService {

    @Autowired
    private CustomSpInfoMapper customSpInfoMapper;

    @Autowired
    private SpExpService spExpService;

    @Autowired
    private StorageService storageService;

    @Override
    public CustomSpInfoModel getBySpId(Long spId) {
        String cacheKey = Const.REDIS_KEY_SP + spId ;
        CustomSpInfoModel model = CacheUtils.getJson(cacheKey,CustomSpInfoModel.class);
        if(model == null) {
            model= customSpInfoMapper.selectBySpId(spId);
            if(model == null)return null;
            JSONObject logoUrlInfo = getLogoUrl(spId);
            JSONObject ptPwInfo = getPtPw(spId);
            model.setLogoDomainUrl(StringUtils.isNotBlank(logoUrlInfo.getString("path")) ? logoUrlInfo.getString("domain") + Const.SEPARATE_XIE + logoUrlInfo.getString("path") : "");
            model.setPtDomainUrl( ptPwInfo.getString("pt"));
            model.setPwDomainUrl( ptPwInfo.getString("pw"));
            CacheUtils.setJson(cacheKey, model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public void save(CustomSpInfoModel customSpInfoModel) {
        modify(customSpInfoModel);
    }

    @Override
    public void create(CustomSpInfoModel customSpInfoModel) {
    	customSpInfoMapper.insert(customSpInfoModel);
    }

    @Override
    public void modify(CustomSpInfoModel customSpInfoModel) {
    	customSpInfoMapper.update(customSpInfoModel);
        String spExpCache = Const.REDIS_KEY_SP_EXP_SPID + customSpInfoModel.getSpId();
        CacheUtils.del(Const.REDIS_KEY_SP + customSpInfoModel.getSpId()  ,spExpCache);
    }

    @Override
    public DataGrid pageSpInfoForAdmin(AdminCondition condition) {
        DataGrid dataGrid = new DataGrid();
        Long count = customSpInfoMapper.countSpInfoForAdmin(condition);
        if(count > 0){
            dataGrid.setTotal(count);
            dataGrid.setRows(customSpInfoMapper.pageSpInfoForAdmin(condition));
        }
        return dataGrid;
    }

    //{'path':'xxxx','bucket':'xxxx','domain':'xxxx'}
    @Override
    public JSONObject getLogoUrl(Long spId) {
        JSONObject returnMap = new JSONObject();
        StorageTypeEnum storageType = storageService.getStorageTypeBySpId(spId, StorageContentTypeEnum.Picture);
        SpExpModel model = spExpService.getBySpIdAndStorageTypeAndContentType(spId, storageType, 1);
        if(model != null){
            StorageModel storage = storageService.getById(model.getStorageId());
            String domain = storageService.getDomainSimpleOutByStorageId(storage.getId());
            returnMap.put("path",model.getLogUrl());
            returnMap.put("bucket",storage.getName());
            returnMap.put("domain",domain);
        }
        return returnMap;
    }

    //{'pt':'xxx','pw':'xxx','bucket':'xxx','domain':'xxxx'}
    @Override
    public JSONObject getPtPw(Long spId) {
        JSONObject returnMap = new JSONObject();
        StorageTypeEnum storageType = storageService.getStorageTypeBySpId(spId, StorageContentTypeEnum.Media);
        SpExpModel model = spExpService.getBySpIdAndStorageTypeAndContentType(spId, storageType, 2);
        if(model != null){
            StorageModel storage = storageService.getById(model.getStorageId());
            String domain = storageService.getDomainSimpleOutByStorageId(storage.getId());
            returnMap.put("pt",model.getStartUrl());
            returnMap.put("pw",model.getEndUrl());
            returnMap.put("bucket",storage.getName());
            returnMap.put("domain",domain);
        }
        return returnMap;
    }

}
