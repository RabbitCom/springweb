package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.CustomCondition;
import com.cnlive.mam.model.CustomModel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhangxiaobin
 */
public interface CustomMapper {

    void insert(CustomModel t);

    public CustomModel selectById(Long Id);

    public void update(CustomModel t);

    List<CustomModel> getCustomInfoList(CustomCondition customCondition);

    Long getCountByCondition(CustomCondition customCondition);

    List<CustomModel> getCustomsInfoByRoleId(Long roleId);

    Long findMaxTm();

	Long getParentCutsomerBySpId(Long spId);

	Long countByCustom(CustomModel customModel);

    List<CustomModel> getByCustomName(@Param("customName") String customName, @Param("spId") Long spId);
}
