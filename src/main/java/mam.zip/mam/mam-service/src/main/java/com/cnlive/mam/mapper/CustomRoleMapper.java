package com.cnlive.mam.mapper;

import com.cnlive.mam.model.CustomRoleModel;

import java.util.List;

public interface CustomRoleMapper {

    CustomRoleModel selectById(Integer id);

    Integer insert(CustomRoleModel customRoleModel);

    List<CustomRoleModel> selectAll();

    List<CustomRoleModel> selectBySpId(Integer spId);

    List<CustomRoleModel> selectByRoleNameAndSpid(CustomRoleModel customRoleModel);

    void delete(Integer roleId);

    void update(CustomRoleModel customRoleModel);
}
