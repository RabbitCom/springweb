package com.cnlive.mam.serviceImpl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.CustomSpInfoModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.CustomSpInfoService;
import com.cnlive.mam.service.SolrRetrieveService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.SolrRetrieveVo;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 7/17/2017.
 */
@Service("solrRetrieveService")
public class SolrRetrieveServiceImpl implements SolrRetrieveService {
    private static Logger _log = LoggerFactory.getLogger(SolrRetrieveServiceImpl.class);
    private static String collectionName = "mam";//点播云solr索引库名称

    @Value("#{configProperties['solrAddUrl']}")
    private String solrAddUrl;
    @Value("#{configProperties['solrQueryUrl']}")
    private String solrQueryUrl;

    @Override
    public String getByKeyWord(String keyWord, Integer page, Integer rows, Long spId, String institutionId) {
        try {
            Map<String, String> params = new HashedMap();
            params.put("keywords", keyWord);
            params.put("page", String.valueOf(page));
            params.put("pageSize", String.valueOf(rows));
            params.put("spId", String.valueOf(spId));
            params.put("institutionId", institutionId);
            Map<String, String> map = new HashedMap();
            map.put("fulltextParams", JSONObject.toJSONString(params));
            map.put("collectionName", collectionName);
            String resultJson = HttpClientUtils.post(solrQueryUrl, map, 5000);
            JSONObject resultObj = JSONObject.parseObject(resultJson);
            Integer errorCode = resultObj.getInteger("errorCode");
            if (errorCode != 0) {
                String errorMsg = resultObj.getString("errorMessage");
                _log.info("errorMsg={}", errorMsg);
            } else {
                return resultJson;
            }
        } catch (Exception e) {
            _log.info("solrRetrieve  query  exception msg={}", e.getMessage());
        }
        return "";
    }

    @Override
    public void add(VideoModel videoModel) {
        try {
            SolrRetrieveVo retrieveVo = new SolrRetrieveVo();
            retrieveVo = retrieveVo.videoToSolr(videoModel);
            retrieveVo.setCustomName(videoModel.getCustomName());

            Map<String, String> map = new HashedMap();
            map.put("fulltextParams", JSONObject.toJSONString(retrieveVo));
            map.put("collectionName", collectionName);
            HttpClientUtils.post(solrAddUrl, map, 5000);
//            JSONObject obj = JSONObject.parseObject(resultJson);
//            Integer errorCode = obj.getInteger("errorCode");
//            if (errorCode == -1) {
//                String errorMsg = obj.getString("errorMessage");
//                _log.info("solrRetrieve  add  errorMsg={}", errorMsg);
//            }
        } catch (Exception e) {
            _log.error("solrRetrieve  add  exception msg={}", e.getMessage());
        }
    }
}
