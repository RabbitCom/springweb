package com.cnlive.mam.mapper;

import java.util.List;

import com.cnlive.mam.condition.VideoPublishCondition;
import com.cnlive.mam.model.PublishTaskModel;

public interface PublishTaskMapper {

    public void insert(PublishTaskModel publishTaskModel);

    public void update(PublishTaskModel publishTaskModel);
    
    public void delete(Long taskId);
    
    public PublishTaskModel selectByTaskId(Long taskId);
    
    public List<PublishTaskModel> getAll();
    
    public List<PublishTaskModel> getTaskListByState(PublishTaskModel publishTaskModel);

    Long getTaskListByStateCount(PublishTaskModel publishTaskModel);
    
    public List<PublishTaskModel> getTaskByCondition(PublishTaskModel publishTaskModel);

    List<PublishTaskModel> PagePublishTaskInfos(VideoPublishCondition condition);

    Long PageCountPublishTaskInfos(VideoPublishCondition condition);
}
