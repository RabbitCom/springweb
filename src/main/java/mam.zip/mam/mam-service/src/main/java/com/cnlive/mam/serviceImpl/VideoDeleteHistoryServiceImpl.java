package com.cnlive.mam.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.VideoDeleteHistoryMapper;
import com.cnlive.mam.model.VideoDeleteHistoryModel;
import com.cnlive.mam.service.VideoDeleteHistoryService;

@Service("videoDeleteHistoryService")
public class VideoDeleteHistoryServiceImpl implements VideoDeleteHistoryService {

    public VideoDeleteHistoryServiceImpl() {
    }

    @Autowired
    private VideoDeleteHistoryMapper videoDeleteHistoryMapper;

    @Override
    public VideoDeleteHistoryModel create(VideoDeleteHistoryModel v) {
    	videoDeleteHistoryMapper.insert(v);
        return v;
    }
    
}
