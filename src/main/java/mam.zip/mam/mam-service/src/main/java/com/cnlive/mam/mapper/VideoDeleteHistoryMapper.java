package com.cnlive.mam.mapper;

import com.cnlive.mam.model.VideoDeleteHistoryModel;

public interface VideoDeleteHistoryMapper {

    void insert(VideoDeleteHistoryModel t);

}
