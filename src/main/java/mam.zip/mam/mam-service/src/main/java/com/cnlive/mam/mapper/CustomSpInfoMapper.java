package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.AdminCondition;
import com.cnlive.mam.model.CustomSpInfoModel;
import org.apache.ibatis.annotations.Param;

import java.util.LinkedHashMap;
import java.util.List;

public interface CustomSpInfoMapper {

    void insert(CustomSpInfoModel t);

    CustomSpInfoModel selectBySpId(Long spId);

    void update(CustomSpInfoModel t);

    List<CustomSpInfoModel> pageSpInfoForAdmin(AdminCondition condition);

    Long countSpInfoForAdmin(AdminCondition condition);

}
