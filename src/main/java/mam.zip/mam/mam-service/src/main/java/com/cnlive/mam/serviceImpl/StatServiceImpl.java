package com.cnlive.mam.serviceImpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.mapper.StatMapper;
import com.cnlive.mam.service.StatService;
import org.springframework.util.StringUtils;

/**
 * @author GuoYaqi
 */
@Service("statService")
public class StatServiceImpl implements StatService{
	
	@Autowired
    private StatMapper statMapper;

	@Override
	public Map<String, Long> count7DayUploadVideoBySpId(Long spid,String jigouId,boolean isSpAdmin) {
		String cacheKey = Const.REDIS_KEY_COUNT_7DAY_UPLOAD + spid ;
		Map<String,Long> result = CacheUtils.get(cacheKey, Map.class);
		if(result == null || result.size() == 0) {
			VideoCondition videoCondition = new VideoCondition();
			videoCondition.setSpid(spid);
			videoCondition.setInstitutionId(jigouId);
			videoCondition.setSpAdmin(isSpAdmin ? Const.IS_PARENT_YES : Const.IS_PARENT_NO);
			result = listToMap(statMapper.get7DayCountVideosBySpId(videoCondition));
			if(result!=null&&result.size()>0)CacheUtils.set(cacheKey,result, ExpireTime.ONE_DAY);
		}
		return result;
	}

	@Override
	public Map<String, Long> count7DayPublishSucceedVideoBySpId(Long spid,String jigouId,boolean isSpAdmin) {
		String cacheKey = Const.REDIS_KEY_COUNT_7DAY_PUBLISH_SUCESS + spid ;
		Map<String,Long> result = CacheUtils.get(cacheKey, Map.class);
		if(result == null || result.size() == 0) {
			VideoCondition videoCondition = new VideoCondition();
			videoCondition.setSpid(spid);
			videoCondition.setStatus(ModelStatus.ReleaseSuccess.getDbValue());
			videoCondition.setInstitutionId(jigouId);
			videoCondition.setSpAdmin(isSpAdmin ? Const.IS_PARENT_YES : Const.IS_PARENT_NO);
			result = listToMap(statMapper.get7DayCountVideoBySpIdAndStatus(videoCondition));
			if(result!=null&&result.size()>0)CacheUtils.set(cacheKey,result, ExpireTime.ONE_DAY);
		}
		return result;


	}

	@Override
	public Map<String, Long> count7DayPublishFailureVideoBySpId(Long spid,String jigouId,boolean isSpAdmin) {
		String cacheKey = Const.REDIS_KEY_COUNT_7DAY_PUBLISH_FAILD + spid ;
		Map<String,Long> result = CacheUtils.get(cacheKey, Map.class);
		if(result == null || result.size() == 0) {
			VideoCondition videoCondition = new VideoCondition();
			videoCondition.setSpid(spid);
			videoCondition.setStatus(ModelStatus.ReleaseFail.getDbValue());
			videoCondition.setInstitutionId(jigouId);
			videoCondition.setSpAdmin(isSpAdmin ? Const.IS_PARENT_YES : Const.IS_PARENT_NO);
			result = listToMap(statMapper.get7DayCountVideoBySpIdAndStatus(videoCondition));
			if(result!=null&&result.size()>0)CacheUtils.set(cacheKey,result, ExpireTime.ONE_DAY);
		}
		return result;
	}


	@Override
	public Long countAlbumBySpId(Long spId,String jigouId,boolean isSpAdmin) {
		String cacheKey = Const.REDIS_KEY_COUNT_ALBUM + spId;
		Long cval= CacheUtils.getLong(cacheKey);
		if(cval == null){
			cval = statMapper.getCountAlbumBySpId(spId,jigouId,isSpAdmin ? Const.IS_PARENT_YES : Const.IS_PARENT_NO);
			if(cval!=null)CacheUtils.set(cacheKey,cval,ExpireTime.ONE_DAY);
		}
		return cval;
	}

	@Override
	public List<Map<String,Object>> getCountGroupByCategory(Long spId, String institutionId, boolean isAdmin) {
		String cacheKey = Const.REDIS_KEY_COUNT_GROUP_CATEGORY + spId;
		List<Map<String,Object>> list = CacheUtils.get(cacheKey, List.class);
		if(list == null || list.size() ==0 ){
			list = statMapper.getCountGroupByCategory(spId,institutionId,isAdmin?1:0);
			if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.ONE_DAY);
		}
		return list;
	}

	@Override
	public List<Map<String, Object>> getCountGroupByStatus(VideoCondition condition) {
		String cacheKey = Const.REDIS_KEY_COUNT_GROUP_STATUS + condition.getSpid();
		List<Map<String,Object>> list = CacheUtils.get(cacheKey, List.class);
		if(list == null || list.size() ==0 ){
			list = statMapper.getCountGroupByStatus(condition);
			if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.ONE_DAY);
		}
		return list;
	}


	public Map<String,Long> listToMap(List<Map<String, Object>> list){
		Map<String, Long> newMap = new HashMap<>();
		for(Map<String, Object> map : list){
			String date = map.get("dateStr").toString();
            Long count = Long.parseLong(map.get("count").toString());
            newMap.put(date, count);
		}
		return complement7DayMap(newMap);
	}
	
	public Map<String,Long>  complement7DayMap(Map<String, Long> map){
		Map<String, Long> newMap = new HashMap<>();
		Date now = new Date();
		for(int i = 0; i < 7; i++){
			String dateStr = CalendarUtil.getShortDateString(CalendarUtil.addOrBeforeNDay(now, -1 * i));
			Object obj = map.get(dateStr);
			newMap.put(dateStr, (obj != null)? Long.valueOf(obj.toString()) : 0l);
		}
		return newMap;
	}
	

}
