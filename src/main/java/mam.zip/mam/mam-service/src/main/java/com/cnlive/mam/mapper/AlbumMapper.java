package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.vo.CustomCategoryVo;

import java.util.List;
import java.util.Map;

public interface AlbumMapper {

    void insert(AlbumModel t);

    AlbumModel selectById(Long Id);

    void update(AlbumModel t);

    List<AlbumModel> getPageByCondition(AlbumCondition condition);

    Long getCountByCondition(AlbumCondition condition);

    List<Map<String,Object>> getAlbumCountByCustomCategoryId(List<CustomCategoryVo> customCategoryList);
    
    List<AlbumModel> getAlbumInfoByCondition(AlbumCondition condition);

    Long checkAlbumName(AlbumCondition condition);

    void delete(AlbumModel t);
}
