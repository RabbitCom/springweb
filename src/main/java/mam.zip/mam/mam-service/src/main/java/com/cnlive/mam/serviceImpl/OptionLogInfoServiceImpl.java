package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.condition.LogInfoCondition;
import com.cnlive.mam.mapper.OptionLogInfoMapper;
import com.cnlive.mam.model.OptionLogInfo;
import com.cnlive.mam.service.OptionLogInfoService;
import com.cnlive.mam.vo.DataGrid;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zhangxiaobin on 2017/5/2.
 */
@Service("optionLogInfoService")
public class OptionLogInfoServiceImpl implements OptionLogInfoService {

    Logger _log = LoggerFactory.getLogger(OptionLogInfoServiceImpl.class);

    @Autowired
    private OptionLogInfoMapper mapper;

    @Override
    public void create(OptionLogInfo optionLogInfo) {
        mapper.insert(optionLogInfo);
    }

    @Override
    public DataGrid dataGrid(LogInfoCondition condition) {
        try{
            Long total = mapper.pageInfoCount(condition);
            if(total > 0){
                return new DataGrid(total,mapper.pageInfoByCondition(condition));
            }
        }catch (Exception ex){
            _log.error("service查询日志出错，{}",ex);
        }
        return new DataGrid(0L,null);
    }

    @Override
    public List<OptionLogInfo> getByVideoBusinessId(String videoBusinessId) {
        if(StringUtils.isBlank(videoBusinessId)){
            return null;
        }
        return mapper.selectByVideoId(videoBusinessId);
    }
}
