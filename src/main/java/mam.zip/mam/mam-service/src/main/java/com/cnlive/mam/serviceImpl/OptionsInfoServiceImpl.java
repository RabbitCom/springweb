package com.cnlive.mam.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.OptionsInfoMapper;
import com.cnlive.mam.model.OptionsInfo;
import com.cnlive.mam.service.OptionsInfoService;

@Service("optionsInfoService")
public class OptionsInfoServiceImpl implements OptionsInfoService{

	  Logger _log = LoggerFactory.getLogger(OptionsInfoServiceImpl.class);

      @Autowired
      private OptionsInfoMapper mapper;
		
	  @Override
	  public void create(OptionsInfo optionsInfo) {
		// TODO Auto-generated method stub
		  mapper.insert(optionsInfo);
	  }

	  @Override
	  public OptionsInfo selectByMd5(String md5) {
		// TODO Auto-generated method stub
		  
		  return mapper.selectByMd5(md5);
	  }

	@Override
	public List<OptionsInfo> getPage() {
		return mapper.getPage();
	}

	@Override
	public void delete(Long id) {
		mapper.delete(id);
	}

}
