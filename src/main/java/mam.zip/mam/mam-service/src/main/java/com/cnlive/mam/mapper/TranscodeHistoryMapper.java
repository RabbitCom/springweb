package com.cnlive.mam.mapper;

import com.cnlive.mam.model.TranscodeHistoryModel;
import org.apache.ibatis.annotations.Param;

public interface TranscodeHistoryMapper {

    void insert(TranscodeHistoryModel t);
    
    TranscodeHistoryModel selectNewByFileId(@Param("fileId") Long fileId, @Param("taskId") String taskId);
}
