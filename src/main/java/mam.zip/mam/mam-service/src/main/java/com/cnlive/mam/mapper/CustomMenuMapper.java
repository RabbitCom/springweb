package com.cnlive.mam.mapper;

import com.cnlive.mam.model.CustomMenuModel;

import java.util.List;

/**
 * Created by cuilongcan on 2017/5/10.
 */
public interface CustomMenuMapper {

    List<CustomMenuModel> selectAll();

    CustomMenuModel selectByMenuId(Integer menuId);

    List<CustomMenuModel> selectByIds(List<Integer> ids);
}
