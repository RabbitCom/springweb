package com.cnlive.mam.mapper;

import java.util.List;

import com.cnlive.mam.model.OptionsInfo;

public interface OptionsInfoMapper {

	void insert(OptionsInfo optionsInfo);
	
	OptionsInfo selectByMd5(String md5);
	
	List<OptionsInfo> getPage();
	
	void delete(Long id);
	
}
