package com.cnlive.mam.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.ModelValueConst;
import com.cnlive.mam.common.enums.*;
import com.cnlive.mam.common.reflect.IdGetUtil;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.CodecUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.mapper.VideoMapper;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

import static com.cnlive.mam.common.utils.Const.*;

/**
 * @author zhangxiaobin
 */
@Service("videoService")
public class VideoServiceImpl implements VideoService {
	private static Logger _log = LoggerFactory.getLogger(VideoServiceImpl.class);

	public VideoServiceImpl() {

	}

	@Autowired
	private VideoMapper videoMapper;

	@Resource(name = "fileService")
	FileService fileService;

	@Resource(name = "customCategoryService")
	private CustomCategoryService customCategoryService;

	@Resource(name = "albumService")
	private AlbumService albumService;

	@Resource(name = "customService")
	private CustomService customService;

	@Resource(name = "transcodeTaskService")
	private TranscodeTaskService transcodeTaskService;

	@Resource(name = "dictionaryService")
	private DictionaryService dictionaryService;

	@Resource(name = "customSpInfoService")
	private CustomSpInfoService customSpInfoService;

	@Resource(name = "optionLogInfoService")
	private OptionLogInfoService optionLogInfoService;

	@Resource(name = "publishTaskService")
	private PublishTaskService publishTaskService;
	@Resource(name = "solrRetrieveService")
	private SolrRetrieveService solrRetrieveService;

	@Resource(name = "storageService")
	private StorageService storageService;

	@Value("#{configProperties['xuanchuan_play_url']}")
	private String defaultPlayUrl;

	@Value("#{configProperties['shenhe_call_url']}")
	private String shenheCallUrl;

	@Value("#{configProperties['songshen_url']}")
	private String songshenUrl;


	@Override
	public DataGrid getPageByCondition(VideoCondition condition) {
		Long videoCount = videoMapper.getCountByCondition(condition);
		List<VideoModel> videoList = new ArrayList<>();
		if (videoCount > 0) {
			if(condition.isPublishList()) {
				videoList = videoListAddExpPublish(videoMapper.getPageByCondition(condition));
			}else {
				videoList = videoListAddExp(videoMapper.getPageByCondition(condition));

			}
		}

		return new DataGrid(videoCount, videoList);
	}

	@Override
	public DataGrid getPageByCondition(SuperSpCondition condition) {
		Long videoCount = videoMapper.getCountByConditionForSuperSp(condition);
		List<VideoModel> videoList = new ArrayList<>();
		if (videoCount > 0) {
			videoList = videoListAddExp(videoMapper.getPageByConditionForSuperSp(condition));
		}
		return new DataGrid(videoCount, videoList);
	}

	@Override
	public List<VideoModel> getByAlbumId(Long aLong) {
		VideoCondition condition = new VideoCondition();
		condition.setSort("episode");
		condition.setAlbumId(aLong);
		return this.getVideoInfoByCondition(condition);
	}

	@Override
	public VideoModel getById(Long id) {
		if(id == null)return null;
		String videoCacheKey = REDIS_KEY_VIDEO + id ;
		VideoModel videoModel = CacheUtils.getJson(videoCacheKey, VideoModel.class);
		if(videoModel == null){
			videoModel = videoMapper.selectById(id);
			if (videoModel == null) return null;
			setPicInfo(videoModel);
			videoExtendParams(videoModel);
			CacheUtils.setJson(videoCacheKey,videoModel,ExpireTime.NONE);
		}
		return videoModel;
	}

//	@Override
//	public VideoModel getAllInfoById(Long id) {
//		VideoModel video = getById(id);
//		videoExtendParams(video);
//		return video;
//	}

	private void videoExtendParams(VideoModel video) {
		if(video != null) {
			if (video.getAlbumId() != null && video.getAlbumId().intValue() != 0) {
				AlbumModel albumModel = albumService.getById(video.getAlbumId());
				if (albumModel != null) {
					video.setAlbumName(albumModel.getAlbumName());
				}

			}
			if (video.getCustomId() != null) {
				CustomModel customModel = customService.getById(video.getCustomId());
				if (customModel != null) {
					video.setCustomName(customModel.getContacts());
					video.setInstitutionName(customModel.getInstitutionName());
				}
			}
			if (video.getUpdateUserId() != null) {
				CustomModel customModel = customService.getById(video.getUpdateUserId());
				if (customModel != null) {
					video.setUpdateCustomName(customModel.getContacts());
				}
			}
			if (video.getCustomCategoryId() != null && video.getCustomCategoryId().intValue() != 0) {
				CustomCategoryModel ccm = customCategoryService.getById(video.getCustomCategoryId());
				if (ccm != null) {
					video.setCustomCategoryName(ccm.getCustomCategoryName());
				}
			}
			// 添加数据分类名称返回
			if (video.getCategory() != null && video.getCategory().intValue() != 0) {
				Dictionary dictionary = dictionaryService.getDictionaryByDicValue(ModelValueConst.DIC_DICWORD_CATEGORY, video.getCategory());
				if (dictionary != null) {
					video.setCategoryName(dictionary.getShowName());
				}
			}
			//添加视频播放地址(缓存方式)
			String storeUri = defaultPlayUrl;
			List<FileModel> files = fileService.getByVid(video.getVideoId());
			for (FileModel file : files){
				if(FileStatus.TranscodingSuccess.getDbValue() == file.getStatus().getDbValue() &&
						DefinitionEnum.SD.getDefinitionId().intValue() == file.getCodeRate().intValue()){
					String playDomain = storageService.getDomainSimpleOutByStorageId(file.getStorageTranscode());
					if(FMT_HLS.equals(file.getTransCodeFmt())) {
						storeUri = playDomain + SEPARATE_XIE + file.getStoreUri();
						video.setShowFileSize(file.getFileSize());
						break;
					}
					if(FMT_MP4.equals(file.getTransCodeFmt())) {
						storeUri = playDomain + SEPARATE_XIE + file.getStoreUri();
						video.setShowFileSize(file.getFileSize());
					}
				}
			}
			video.setPlayUrl(StringUtils.isNotBlank(storeUri) ? storeUri : defaultPlayUrl);
//			FileModel fileModel = fileService.getFileByVidAndCoderateAndTransCodeFmt(video.getVideoId(), DefinitionEnum.SD.getDefinitionId(), "mp4");
//			if (fileModel != null) {
//				if (FileStatus.TranscodingSuccess.getDbValue() == fileModel.getStatus().getDbValue()) {
//					String playDomain = storageService.getDomainSimpleOutByStorageId(fileModel.getStorageTranscode());
//					storeUri = playDomain + Const.SEPARATE_XIE + fileModel.getStoreUri();
//				}
//				video.setShowFileSize(fileModel.getFileSize());
//			}
		}
	}

	public VideoModel save(VideoModel t) {

		Object id = IdGetUtil.getId(t);
		if (id == null) {
			return create(t);
		} else {
			return modify(t);
		}
	}

	@Override
	public VideoModel create(VideoModel t) {
		videoMapper.insert(t);
		pushSolrRetrieveUpdate(t);
		return t;
	}

	@Override
	public VideoModel modify(VideoModel t) {
		videoMapper.update(t);
		String videoCacheKey = REDIS_KEY_VIDEO + t.getVideoId() ;
		String videoCacheKey2 = REDIS_KEY_VIDEO + t.getBusinessUUID() ;
		CacheUtils.del(videoCacheKey,videoCacheKey2);
		pushSolrRetrieveUpdate(t);
		return t;
	}

	public int getVideoByCustomCategory(Long customCatgroyId) {
		VideoCondition condition = new VideoCondition();
		condition.setCustomCategoryId(customCatgroyId);
		Long cutVideo = videoMapper.getCountByCondition(condition);
		return cutVideo == null ? 0 : Integer.parseInt(cutVideo.toString());
	}

	@Override
	public Map<Long, Long> getVideoCountByCustomCategoryId(List<CustomCategoryVo> list) {
		List<Map<String, Object>> videoCountByCustomCategoryId = videoMapper.getVideoCountByCustomCategoryIds(list);
		Map<Long, Long> resMap = new HashMap<Long, Long>();
		for (Map<String, Object> videoMap : videoCountByCustomCategoryId) {
			Long customCategoryId = Long.parseLong(videoMap.get("customCategoryId").toString());
			Long count = Long.parseLong(videoMap.get("count").toString());
			resMap.put(customCategoryId, count);
		}
		return resMap;
	}

	@Override
	public List<VideoModel> getVideoInfoByCondition(VideoCondition condition) {
		List<VideoModel> videoList = videoListAddExp(videoMapper.getVideoInfoByCondition(condition));
		return videoList;
	}

	private List<VideoModel> videoListAddExp(List<Integer> videoIds) {
		List<VideoModel> returnList = new ArrayList<>();
        for (Integer videoId : videoIds) {
			VideoModel video = this.getById(Long.parseLong(videoId.toString()));
			returnList.add(video);
		}
		return returnList;
    }

	private List<VideoModel> videoListAddExpPublish(List<Integer> videoIds) {
		List<VideoModel> returnList = new ArrayList<>();
		for (Integer videoId : videoIds) {
			VideoModel video = getById(Long.parseLong(videoId.toString()));
			PublishTaskModel taskCondition = new PublishTaskModel();
			taskCondition.setVideoId(video.getVideoId());
			taskCondition.setCustomId(video.getCustomId());
			taskCondition.setPublishState(1);
			List<PublishTaskModel> taskModels = publishTaskService.getTaskByCondition(taskCondition);
			if(taskModels.size() > 0){
				PublishTaskModel publishTaskModel = taskModels.get(0);
				video.setCancelPrePublishFlag(PUBLISHCANCEL_STATUS_CAN);
				video.setPublishState(1);
				video.setPrePublishedTime(publishTaskModel.getPrePublishedTime());
			}else {
				video.setCancelPrePublishFlag(PUBLISHCANCEL_STATUS_NOTCAN);
				video.setPublishState(0);
			}
			returnList.add(video);
		}
		return returnList;
	}

	@Override
	public void deleteVideo(Long videoId) {
		if(videoId == null)return;
		videoMapper.deleteVideo(videoId);
		List<FileModel> files = fileService.getByVid(videoId);
		for (FileModel updateFile : files) {
			if (updateFile != null) {
				fileService.deleteFile(updateFile);
			}
		}
		String videoCacheKey = REDIS_KEY_VIDEO + videoId ;
		String videoFileCacheKey = REDIS_KEY_FILES_VIDEO + videoId ;
		CacheUtils.del(videoCacheKey,videoFileCacheKey);
	}

	@Override
	public Long getVideoCountByCondition(VideoCondition condition) {
		return videoMapper.getCountByCondition(condition);
	}

	@Override
	public VideoModel getbyChouZhenTaskId(String taskId) {
		return videoMapper.getbyChouZhenTaskId(taskId);
	}

	@Override
	public VideoModel getByBusinessUUID(String businessUUID) {
		String videoCacheKey = REDIS_KEY_VIDEO + businessUUID ;
		VideoModel videoModel = CacheUtils.getJson(videoCacheKey, VideoModel.class);
		if(videoModel == null){
			videoModel = videoMapper.getByBusinessUUID(businessUUID);
			if (videoModel == null) return null;
			setPicInfo(videoModel);
			videoExtendParams(videoModel);
			CacheUtils.setJson(videoCacheKey,videoModel,ExpireTime.NONE);
		}
		return videoModel;

	}

//	@Override
//	public VideoModel getAllInfoByBusinessUUID(String businessUUID) {
//		VideoModel video = getByBusinessUUID(businessUUID);
//		videoExtendParams(video);
//		return video;
//	}

	@Override
	public boolean createTranscodeTask(Long videoId, String codeRates, String transCodeFmts, Long customId,Long spId) {
		try {
			VideoModel videoModel = getById(videoId);
			Integer ptpwState = videoModel.getCanSearch();
			//判断是否金山、七牛存储 --begin
			Integer plat = 0;
			StorageModel storage = storageService.getById(videoModel.getStorageId());
			if(StorageTypeEnum.QINIUYUN.getDbValue()  == storage.getType().getDbValue()){
				plat = 1;
			}
			//判断是否金山、七牛存储 --end

			List<FileModel> files = fileService.getByVid(videoId);
			for (FileModel updateFile : files) {
				if (updateFile != null) {
					codeRates = checkCodeRate(codeRates);
					CustomModel custom = customService.getById(customId);
					CustomSpInfoModel customSpInfoModel = customSpInfoService.getBySpId(custom.getSpId());
					Integer logoStatus = customSpInfoModel.getLogoStatus();
					Integer logoSiteByUpload = videoModel.getLogosite();
					Integer logoSite = logoSiteByUpload != null ? logoSiteByUpload : customSpInfoModel.getLogoSite();
					String fileOriginUri = updateFile.getOriginUri();
					TranscodeTaskModel task = new TranscodeTaskModel(videoId, customId, custom.getSpId(), codeRates,
							fileOriginUri);
					task.setIsReTranscode(IS_RETRANSCODE_YES);
					task.setTransCodeFmt(transCodeFmts);
					task.setPlat(plat);
					JSONObject logoInfo = customSpInfoService.getLogoUrl(spId);
					// 如果用户的logo水印启用，并且logo图片存在时，在转码任务中添加水印图片及水印位置

					if(logoSite != null && -1 !=  logoSite.intValue()){
						if (logoStatus != null
								&& LOGOSTATUS_ON.intValue() == logoStatus.intValue()
								&& logoInfo != null && logoInfo.size() > 0) {
							if(1 == plat.intValue()) {
								task.setLogoPicUrl(logoInfo.getString("domain")  + SEPARATE_XIE + logoInfo.getString("path") );
							}else {
								task.setLogoPicUrl(SEPARATE_XIE + logoInfo.getString("bucket") + SEPARATE_XIE + logoInfo.getString("path"));
							}
							task.setLogoSite(logoSite);
						}
					}

					JSONObject ptpwInfo = customSpInfoService.getPtPw(customSpInfoModel.getSpId());
					//处理片头片尾
					if(ptpwState != null && ptpwState.intValue() == 1){
						String startUrl = ptpwInfo.getString("pt");
						String endUrl =  ptpwInfo.getString("pw");
						String ptpwBucketName = ptpwInfo.getString("bucket");
						task.setHeadFile(StringUtils.isNotBlank(startUrl) ? Const.SEPARATE_XIE + ptpwBucketName +Const.SEPARATE_XIE + startUrl : "");
						task.setEndFile(StringUtils.isNotBlank(endUrl) ? Const.SEPARATE_XIE + ptpwBucketName +Const.SEPARATE_XIE + endUrl : "");
					}

					transcodeTaskService.create(task);
					break;
				}
			}
		} catch (Exception ex) {
			_log.error("pendingTranscodeTask error ,msg = {}", ex.getMessage());
			return false;
		}
		return true;
	}

	public FileStatus transcodeSuccessCheck(Long videoId) {
		FileStatus status = FileStatus.TranscodingSuccess;
		try {
			List<FileModel> fileList = fileService.getFileByVidAndCoderate(videoId,
					DefinitionEnum.SD.getDefinitionId());
			// 判断标清的文件转码状态是否为成功
			for (FileModel file : fileList) {
				if (FileStatus.TranscodingSuccess.getDbValue() != file.getStatus().getDbValue()) {
					status = FileStatus.TranscodingFail;
					break;
				}
			}
		} catch (Exception e) {
			_log.error("视频转码回调后判断文件媒资状态异常，参数信息：{},错误信息{}", videoId, e);
			status = FileStatus.TranscodingFail;
		}
		return status;
	}

	/**
	 * 检查码率并处理成正确的码率字符串<br>
	 * 默认标清码率；移除重复的码率
	 *
	 * @param codeRates
	 *            码率
	 * @return
	 *
	 */
	private String checkCodeRate(String codeRates) {
		codeRates = StringUtils.isBlank(codeRates) ? SD : codeRates;
		String codeRateArray[] = codeRates.split(VALUE_DECOLLATOR);
		Set<String> codeRateSet = new HashSet<String>();
		for (String codeRate : codeRateArray) {
			codeRateSet.add(codeRate);
		}
		codeRates = StringUtils.join(codeRateSet, VALUE_DECOLLATOR);
		return codeRates;
	}

	// 送审操作
	@Override
	public void songShen(Long videoId, CustomModel customModel) {
//		if (StringUtils.isBlank(playDomain)) {
//			return JsonResult.createErrorInstance("请联系SP管理员设置播放域名");
//		}
//		JsonResult jsonResult = new JsonResult();
		Map<String, Object> map = new HashMap<>();
		VideoModel videoModel = this.getById(videoId);
		FileModel fileModel = fileService.getFileByVidAndCoderateAndTransCodeFmt(videoId, Integer.parseInt(SD),"mp4");
		if (fileModel != null) {
			String playDomain = storageService.getDomainSimpleOutByStorageId(fileModel.getStorageTranscode());
			map.put("videoId", customModel.getSpId() + "_" + videoModel.getBusinessUUID());// 点播id
			map.put("videoTitle", videoModel.getVideoName());// 点播名称
			map.put("videoUrl", playDomain + SEPARATE_XIE + fileModel.getStoreUri());// 点播视频url
			map.put("uploadTime", videoModel.getCreateTime());// 上传时间
			map.put("priority", "1");// 默认优先级
			map.put("videoCoverUrl", JSONObject.toJSONString(videoModel.getAllPicScale()));// 封面图
			map.put("callback", shenheCallUrl);// 回调函数(审核通过或者不通过,推过去的地址)
			map.put("videoIntro", videoModel.getSynopsis());// 点播描述
			map.put("videoTag", videoModel.getCategoryName());// 点播标签
			map.put("videoKeyword", "");// 点播关键字
			map.put("spId", customModel.getSpId());// spId

			Map<String, Object> extendMap = new HashedMap();
			extendMap.put("uploader", customModel.getContacts());//上传人
			extendMap.put("contactInfo", customModel.getPhone());//联系方式
			map.put("extendField", JSONObject.toJSONString(extendMap));
			String jsonString = JSONObject.toJSONString(map);
			_log.info("送审的数据_____________________" + jsonString.toString());
			String url = songshenUrl;
			Map<String, String> json = new HashMap<String, String>();
			json.put("param", jsonString);
			String post = HttpClientUtils.post(url, json, 5000);

			JSONObject parseObject = JSONObject.parseObject(post);
			String errorCode = parseObject.getString("errorCode");
			String errorMessage = CodecUtil.decodeURL(parseObject.getString("errorMessage"));
			_log.info("审核云返回的信息____________________errorCode:" + errorCode + ",errorMessage:" + errorMessage);
			VideoModel updateVideo = new VideoModel();
			updateVideo.setVideoId(videoModel.getVideoId());
			updateVideo.setStatus(ModelStatus.AuditIng);
			updateVideo.setUpdateTime(new Date());
			updateVideo.setCustomId(videoModel.getCustomId());
			updateVideo.setUpdateUserId(customModel.getCustomId());
			this.modify(updateVideo);
//			if ("0".equals(errorCode)) {// 送审成功
//				VideoModel updateVideo = new VideoModel();
//				updateVideo.setVideoId(videoModel.getVideoId());
//				updateVideo.setStatus(ModelStatus.AuditIng);
//				updateVideo.setUpdateTime(new Date());
//				updateVideo.setCustomId(videoModel.getCustomId());
//				updateVideo.setUpdateUserId(videoModel.getCustomId());
//				this.modify(updateVideo);
//				jsonResult.setSuccess(true);
//				;
//			} else {// 送审失败
//				_log.error("送审失败，请稍后重试！");
//				jsonResult.setSuccess(false);
//				jsonResult.setMsg(errorMessage);
//			}
		} else {
			_log.error("送审失败，转码视频为空，videoId={}", videoId);
		}

		OptionLogInfo logInfo = new OptionLogInfo(OptionType.UPDATE, customModel.getCustomId(),
				customModel.getContacts(), "送审视频", customModel.getSpId(), videoModel.getBusinessUUID(),
				videoModel.getVideoName());
		optionLogInfoService.create(logInfo);

//		return jsonResult;
	}

	@Override
	public List<VideoModel> getUploadFaildVideos() {
		return videoMapper.getUploadFaildVideos();
	}

	@Override
	public VideoModel createIcms2MamModel(VideoModel t) {
		videoMapper.inserIcms2MamModel(t);
		return t;
	}

	@Override
	public List<Integer> getVideoInfoForSolr(VideoCondition condition){
		return  videoMapper.getVideoInfoForSolr(condition);
	}

	private void pushSolrRetrieveUpdate(VideoModel videoModel) {
//		videoModel = this.getById(videoModel.getVideoId());
		solrRetrieveService.add(videoModel);
	}


	//设置视频的图片信息
	private void setPicInfo(VideoModel videoModel){
		//设置 allPicScale
		Map<String, String> resultMap = new HashMap<String, String>();
		if (videoModel == null) {
			videoModel.setAllPicScale(resultMap);
			videoModel.setListPicUrl("");
			return;
		}
		String picFinishedImg = videoModel.getPicFinishedImg();
		String picOriginal = videoModel.getPicOriginal();
		if(StringUtils.isEmpty(picOriginal) && StringUtils.isEmpty(picFinishedImg)){
			return;
		}
		Integer storageImgId = videoModel.getStorageImgId();
		StorageModel storage = storageService.getById(storageImgId);
		int storageType = storage.getType().getDbValue();
		String domain = storageService.getDomainSimpleOutByStorageId(storageImgId);
		String picUrl = domain + SEPARATE_XIE + picOriginal;
		videoModel.setPicOriginDomain(picUrl);

		Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
		if (StringUtils.isNotBlank(picFinishedImg)) {
			finishedImgs_map = JSON.parseObject(picFinishedImg, Map.class);
		}
		Set<Map.Entry<String, Integer[]>> setmap = videoImageType.entrySet();
		for (Map.Entry<String, Integer[]> entry : setmap) {
			String ar_key = entry.getKey();
			Integer[] sizes = entry.getValue();
			// 如果不存在的比例，则通过原视频地址拼接并返回
			if (!(finishedImgs_map.containsKey(ar_key))) {
				for (int i = 0; i < sizes.length; i = i + 2) {
					Integer imgWidth = sizes[i];
					Integer imgHeight = sizes[i + 1];
					String screenShot = "";
					String suffix = "00002.jpg" ;
					if(StorageTypeEnum.KSYUN.getDbValue() == storageType) {
						screenShot =  "@base@tag=imgScale&w=" + imgWidth + "&h=" + imgHeight + "&m=2&c=1" ;
					}
					if(StorageTypeEnum.QINIUYUN.getDbValue() == storageType){
						suffix = "000002.jpg" ;
						screenShot = "?imageView2/1/w/" + imgWidth + "/h/" + imgHeight ;
					}
					resultMap.put(imgWidth + "*" + imgHeight, picUrl + suffix + screenShot);
				}
			} else {
				Map<String, String> picFineshMap = finishedImgs_map.get(ar_key);
				Set<Map.Entry<String, String>> picFineshMapEntry = picFineshMap.entrySet();
				for (Map.Entry<String, String> mapEntry : picFineshMapEntry) {
					mapEntry.getValue();
					resultMap.put(mapEntry.getKey(),domain+ SEPARATE_XIE +mapEntry.getValue());
				}
			}
		}
		videoModel.setAllPicScale(resultMap);
		videoModel.setListPicUrl(resultMap.get("224*126"));
		videoModel.setStorageType(storageType);
	}

	@Override
	public String returnLayerPicAllpicScale(String picOriginal,String picFinishedImg,Integer storageImgId){
		Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
		if (StringUtils.isNotBlank(picFinishedImg)) {
			finishedImgs_map = JSON.parseObject(picFinishedImg, Map.class);
		}

		//存储操作--begin
		StorageModel storage = storageService.getById(storageImgId);
		int storageType = storage.getType().getDbValue();

		String domain = storageService.getDomainSimpleOutByStorageId(storageImgId);
//		picOriginal = domain +Const.SEPARATE_XIE + picOriginal;

		//存储操作--end

		List<Map<String, Object>> result_array = new ArrayList<Map<String, Object>>();

		for (Map.Entry<String, Integer[]> entry : videoImageType.entrySet()) {

			Map<String, Object> result_pic_info = new HashMap<String, Object>();
			String ar_key = entry.getKey();
			Integer[] sizes = entry.getValue();
			// 如果不存在的比例，则通过原视频地址拼接并返回
			String showKey = videoImageScalCp.get(ar_key);
			List<Map<String, String>> fbl_url_list = new ArrayList<Map<String, String>>();

			if (!(finishedImgs_map.containsKey(ar_key))) {
				for (int i = 0; i < sizes.length; i = i + 2) {
					Map<String, String> fbl_url = new HashMap<String, String>();

					Integer imgWidth = sizes[i];
					Integer imgHeight = sizes[i + 1];
					String screenShot = "";
					String suffix = "00002.jpg" ;
					if(StorageTypeEnum.KSYUN.getDbValue() == storageType) {
						screenShot =  "@base@tag=imgScale&w=" + imgWidth + "&h=" + imgHeight + "&m=2&c=1" ;
					}
					if(StorageTypeEnum.QINIUYUN.getDbValue() == storageType){
						suffix = "000002.jpg" ;
						screenShot = "?imageView2/1/w/" + imgWidth + "/h/" + imgHeight ;
					}

					fbl_url.put("fbl", String.valueOf(imgWidth + "*" + imgHeight));
					fbl_url.put("url", StringUtils.isEmpty(picOriginal) ? "" : domain + SEPARATE_XIE +picOriginal + suffix + screenShot);
					fbl_url_list.add(fbl_url);
				}
			} else {
				Map<String, String> fbl_info_map = finishedImgs_map.get(ar_key);
				for (String key : fbl_info_map.keySet()) {
					Map<String, String> fbl_url = new HashMap<String, String>();
					fbl_url.put("fbl", key);
					fbl_url.put("url", domain + SEPARATE_XIE + fbl_info_map.get(key));
					fbl_url_list.add(fbl_url);
				}
			}

			result_pic_info.put("bl", showKey);
			result_pic_info.put("info", fbl_url_list);
			result_array.add(result_pic_info);
		}

		return JSON.toJSONString(result_array);
	}

	@Override
	public void updateStorageBySpid(VideoModel t) {
		videoMapper.updateStorageBySpid(t);
	}
}
