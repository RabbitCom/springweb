package com.cnlive.mam.mapper;

import java.util.List;
import java.util.Map;

import com.cnlive.mam.condition.VideoCondition;
import org.apache.ibatis.annotations.Param;

/**
 * @author GuoYaqi
 */
public interface StatMapper {

	
	List<Map<String, Object>> get7DayCountVideosBySpId(VideoCondition condition);
	List<Map<String, Object>> get7DayCountVideosByCustomId(VideoCondition condition);
	
	List<Map<String, Object>> get7DayCountVideoBySpIdAndStatus(VideoCondition condition);
	List<Map<String, Object>> get7DayCountVideoByCustomIdAndStatus(VideoCondition condition);

	Long getCountAlbumBySpId(@Param("spId") Long spId,@Param("institutionId")String institutionId,@Param("spAdmin")Integer spAdmin);

	Long getCountAlbumByCustomId(Long customId);

	List<Map<String,Object>> getCountGroupByCategory(@Param("spId") Long spId, @Param("institutionId")String institutionId, @Param("spAdmin")Integer spAdmin);

	List<Map<String,Object>> getCountGroupByStatus(VideoCondition condition);
}
