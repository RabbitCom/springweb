package com.cnlive.mam.serviceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.ModelValueConst;
import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.mapper.AlbumMapper;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author zhangxiaobin
 */
@Service("albumService")
public class AlbumServiceImpl implements AlbumService {
	
	private static Logger _log = LoggerFactory.getLogger(AlbumServiceImpl.class);

	public AlbumServiceImpl (){
		
	}
	
	@Resource(name = "videoService")
    VideoService videoService;
    @Resource(name = "customCategoryService")
    CustomCategoryService customCategoryService;
    @Resource(name = "customService")
    CustomService customService;
    @Resource(name = "dictionaryService")
    private DictionaryService dictionaryService;
    @Autowired
    private AlbumMapper albumMapper;
    @Resource(name="storageService")
    private StorageService storageService;

	@Override
	public DataGrid getPageByCondition(AlbumCondition condition) {
		List<AlbumModel> albumModelList = new ArrayList<>();
        Long albumCount = albumMapper.getCountByCondition(condition);
        if(albumCount > 0){
            albumModelList = albumMapper.getPageByCondition(condition);
        }
        albumListAddExp(albumModelList);
        return new DataGrid(albumCount, albumModelList);
	}

	@Override
	public Map<String, Object> getVideoList(Long aId, String videoType) {
		AlbumModel albumModel = this.getById(aId);
        List<VideoModel> videoModelList;
        List<Map<String, Object>> videoMaps = new ArrayList<Map<String, Object>>();
        VideoCondition videoCondition = new VideoCondition();
        videoCondition.setAlbumId(aId);
        if (!(videoType.equals("-1"))) {
            videoCondition.setVideoType(Integer.parseInt(videoType));
        }
        videoModelList = videoService.getVideoInfoByCondition(videoCondition);
        Map<String, Object> resMap = new HashMap<String, Object>();
        if (videoModelList != null && videoModelList.size() > 0) {
            resMap.put("albumId", albumModel.getAlbumId());
            resMap.put("customCategoryId", albumModel.getCustomCategoryId());
            resMap.put("albumName", albumModel.getAlbumName());
            resMap.put("category", albumModel.getCategory());
            resMap.put("videos", videoMaps);
        }
        return resMap;
	}

	@Override
	public AlbumModel getById(Long id) {
        if(id == null)return null;
        String albumCacheKey = Const.REDIS_KEY_ALBUM + id ;
        AlbumModel albumModel = CacheUtils.getJson(albumCacheKey, AlbumModel.class);
        if(albumModel == null){
            albumModel= albumMapper.selectById(id);
            if (albumModel == null)return null;
            setImgInfo(albumModel);
            setExpInfo(albumModel);
            CacheUtils.setJson(albumCacheKey,albumModel, ExpireTime.NONE);
        }
        return albumModel;
	}

	@Override
	public AlbumModel save(AlbumModel t) {
		if (t.getAlbumId() == null) {
            return create(t);
        } else {
            return modify(t);
        }
	}

	@Override
	public AlbumModel create(AlbumModel t) {
		 albumMapper.insert(t);
		 return t;
	}

	@Override
	public AlbumModel modify(AlbumModel t) {
		albumMapper.update(t);
        String cacheKey = Const.REDIS_KEY_ALBUM + t.getAlbumId() ;
        CacheUtils.del(cacheKey);
		return t;
	}

    @Override
    public void delete(AlbumModel t) {
        if(t==null)return;
        albumMapper.delete(t);
        String cacheKey = Const.REDIS_KEY_ALBUM + t.getAlbumId() ;
        CacheUtils.del(cacheKey);
    }

    @Override
	public int getAlbumByCustomCategory(Long customCatgroyId) {
		 AlbumCondition albumCondition = new AlbumCondition();
	        albumCondition.setCustomCategoryId(customCatgroyId);
	        Long cutAlbum = albumMapper.getCountByCondition(albumCondition);
	        return cutAlbum == null ? 0 : Integer.parseInt(cutAlbum.toString());
	}

	@Override
	public Map<Long, Long> getAlbumCountByCustomCategoryId(List<CustomCategoryVo> customCategoryList) {
		List<Map<String, Object>> albumCountByCustomCategoryId = albumMapper.getAlbumCountByCustomCategoryId(customCategoryList);
        Map<Long, Long> resMap = new HashMap<Long, Long>();
        for (Map<String, Object> album : albumCountByCustomCategoryId) {
            Long customCategoryId = Long.parseLong(album.get("customCategoryId").toString());
            Long count = Long.parseLong(album.get("count").toString());
            resMap.put(customCategoryId, count);
        }
        return resMap;
	}

	@Override
	public boolean checkCanAddVideo(Long albumId) {
		List<VideoModel> videos = videoService.getByAlbumId(albumId);
        if (videos.size() >= Const.MaxVideoSizeInAlbum) {
            _log.error("该专辑albumid={}超出最大视频数量限制={}", albumId, Const.MaxVideoSizeInAlbum);
            return false;
        }
        return true;
	}

	@Override
	public List<AlbumModel> getAlbumInfoByCondition(AlbumCondition condition) {
		List<AlbumModel> albumModelList = albumMapper.getAlbumInfoByCondition(condition);
        return albumModelList;
	}

	@Override
	public List<Map<String, String>> getAlbumAll(Long customId) {
		AlbumCondition condition = new AlbumCondition();
        condition.setCustomId(customId);
        List<AlbumModel> albumAllList = this.getAlbumInfoByCondition(condition);
        List<CustomCategoryModel> customCategoryByCustomId = customCategoryService.getCustomCategoryByCustomId(customId);
        Map<String, Map<String, String>> customCategoryMap = new HashMap<String, Map<String, String>>();
        for (CustomCategoryModel customCategoryModel : customCategoryByCustomId) {
            Map<String, String> pmap = new HashMap<String, String>();
            pmap.put("level", customCategoryModel.getLevel().toString());
            pmap.put("parentId", customCategoryModel.getParentCustomCategoryId().toString());
            customCategoryMap.put(customCategoryModel.getCustomCategoryId().toString(), pmap);
        }
        List<Map<String, String>> reMap = new ArrayList<Map<String, String>>();
        for (AlbumModel albumModel : albumAllList) {
            if (customCategoryMap.containsKey(albumModel.getCustomCategoryId().toString())) {
                Map<String, String> map = new HashMap<String, String>();
                map.put("albumId", albumModel.getAlbumId().toString());
                map.put("albumName", albumModel.getAlbumName().toString());
                map.put("customCategoryId", albumModel.getCustomCategoryId().toString());
                map.put("level", customCategoryMap.get(albumModel.getCustomCategoryId().toString()).get("level"));
                map.put("parentId", customCategoryMap.get(albumModel.getCustomCategoryId().toString()).get("parentId"));
                reMap.add(map);
            }
        }
        return reMap;
	}

	@Override
	public Long checkAlbumNameExist(Long spId, String albumName, Long albumId) {
		AlbumCondition albumCondition = new AlbumCondition();
//        albumCondition.setCustomId(customId);
        albumCondition.setSpId(spId);
        albumCondition.setAlbumName(albumName);
        albumCondition.setAlbumId(albumId);
        Long countRet = albumMapper.checkAlbumName(albumCondition);
        return countRet == null ? 0 : countRet;
	}

	@Override
	public void setCustomCategory(AlbumModel albumModel) {
		List<VideoModel> videoModelList = videoService.getByAlbumId(albumModel.getAlbumId());
        if (videoModelList != null && videoModelList.size() > 0) {
            for (VideoModel video : videoModelList) {
                video.setAlbumId(albumModel.getAlbumId());
                video.setCustomCategoryId(albumModel.getCustomCategoryId());
                video.setCategory(albumModel.getCategory());
                video.setUpdateTime(new Date());
                video.setUpdateUserId(albumModel.getUpdateUserId());
                video.setCustomId(albumModel.getCustomId());
                videoService.modify(video);
            }
        }
		
	}

	public AlbumModel selectByOriginAlbumIdAndCustomId(Long albumId, Long customId) {
		if (albumId == null
                || customId == null
                || albumId.intValue() == 0
                || customId.intValue() == 0) {
            return null;
        }
        AlbumCondition albumCondition = new AlbumCondition();
        albumCondition.setAlbumId(albumId);
        albumCondition.setCustomId(customId);
        List<AlbumModel> albumInfos = albumMapper.getAlbumInfoByCondition(albumCondition);
        if (albumInfos != null && albumInfos.size() > 0) {
            return albumInfos.get(0);
        }
        return null;
	}

    @Override
    public List returnLayerPicAllpicScale(String picFinishedImg, Integer storageImgId) {
        JSONObject finishedImgs_obj = new JSONObject();
        if (StringUtils.isNotBlank(picFinishedImg)) {
            finishedImgs_obj = JSON.parseObject(picFinishedImg);
        }
        String domain = storageService.getDomainSimpleOutByStorageId(storageImgId);
        List<Map<String, Object>> result_array = new ArrayList<Map<String, Object>>();
        for (Map.Entry<String, Integer[]> entry : Const.albumImageType.entrySet()) {

            Map<String, Object> result_pic_info = new HashMap<String, Object>();
            String ar_key = entry.getKey();
            Integer[] sizes = entry.getValue();
            String showKey = Const.videoImageScalCp.get(ar_key);
            result_pic_info.put("bl", showKey);
            result_pic_info.put("info", infoList(sizes, (JSONObject) finishedImgs_obj.get(ar_key),domain));
            result_array.add(result_pic_info);
        }

        return result_array;
    }

    private List<Map<String, String>> infoList(Integer[] sizes, JSONObject o,String domain) {
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();

        for (int i = 0; i < sizes.length - 1; i = i + 2) {
            Map<String, String> map = new HashMap<String, String>();
            String fbl = sizes[i] + "*" + sizes[i + 1];
            map.put("fbl", fbl);
            Object url = o==null ? null : o.get(fbl);
            if (url != null) {
                map.put("url",domain + Const.SEPARATE_XIE +  url.toString());
            } else {
                map.put("url", "");
            }
            list.add(map);
        }
        return list;
    }

    //列表展示的图片
    private void setImgInfo(AlbumModel model) {
        Map<String, String> map = returnAllpicScale(model.getPicFinishedImg(),model.getStorageImgId());
        Integer[] sizes = Const.videoImageType.get("ar169");
        String showPicUrl = map.get(sizes[0] + "*" + sizes[1]);
        if (StringUtils.isNotEmpty(showPicUrl)) {
            model.setListPicUrl(showPicUrl);
        } else {
            model.setListPicUrl("");
        }
    }

    private Map<String, String> returnAllpicScale(String picFinishedImg,Integer storageImgId) {
        Map<String, String> resultMap = new HashMap<String, String>();
        JSONObject finishedImgs_obj = new JSONObject();
        if (StringUtils.isNotBlank(picFinishedImg)) {
            finishedImgs_obj = JSON.parseObject(picFinishedImg);
        }
        String domain = storageService.getDomainSimpleOutByStorageId(storageImgId);
        for (Object value : finishedImgs_obj.values()) {
            JSONObject json = (JSONObject) value;
            for (Map.Entry<String, Object> entry : json.entrySet()) {
                String path = String.valueOf(entry.getValue());
                if(StringUtils.isNotEmpty(path)) {
                    resultMap.put(entry.getKey(),domain + Const.SEPARATE_XIE + path);
                }else{
                    resultMap.put(entry.getKey(),"");
                }
            }
        }
        return resultMap;
    }



	private void albumListAddExp(List<AlbumModel> albumModelList) {
        for (AlbumModel albumModel : albumModelList) {
            setImgInfo(albumModel);
            setExpInfo(albumModel);
        }
    }

    private void setExpInfo(AlbumModel albumModel) {
        if (albumModel.getCustomId() != null) {
            CustomModel customModel = customService.getById(albumModel.getCustomId());
            if (customModel != null) {
                albumModel.setCustomName(customModel.getContacts());
                albumModel.setInstitutionName(customModel.getInstitutionName());
            }
        }
        if(albumModel.getUpdateUserId() != null){
            CustomModel customModel = customService.getById(albumModel.getUpdateUserId());
            if (customModel != null) {
                albumModel.setUpdateCustomName(customModel.getContacts());
            }
        }
        if (albumModel.getCustomCategoryId() != null && albumModel.getCustomCategoryId().intValue() != 0) {
            CustomCategoryModel ccm = customCategoryService.getById(albumModel.getCustomCategoryId());
            if (ccm != null) {
                albumModel.setCustomCategoryName(ccm.getCustomCategoryName());
            }
        }
        // 添加数据分类名称返回
        if (albumModel.getCategory() != null && albumModel.getCategory().intValue() != 0) {
            Dictionary dictionary = dictionaryService.getDictionaryByDicValue(ModelValueConst.DIC_DICWORD_CATEGORY, albumModel.getCategory());
            if (dictionary != null) {
                albumModel.setCategoryName(dictionary.getShowName());
            }
        }
    }


}
