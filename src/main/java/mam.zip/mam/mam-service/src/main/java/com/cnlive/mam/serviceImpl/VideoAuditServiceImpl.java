package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.mapper.VideoAuditMapper;
import com.cnlive.mam.model.VideoAuditModel;
import com.cnlive.mam.service.VideoAuditService;
import com.cnlive.mam.vo.DataGrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("videoAuditService")
public class VideoAuditServiceImpl implements VideoAuditService{

    @Autowired
    private VideoAuditMapper videoAuditMapper;


    public VideoAuditServiceImpl() {
    }
    

    @Override
    public void create(VideoAuditModel model) {
        videoAuditMapper.insert(model);
    }

    public void save(VideoAuditModel t) {
       create(t);
    }

    @Override
    public DataGrid getByCondition(VideoAuditCondition condition) {
        List<VideoAuditModel> list = videoAuditMapper.getByCondition(condition);
        Long count = videoAuditMapper.getByConditionCount(condition);
        return new DataGrid(count,list);
    }

	@Override
	public List<VideoAuditModel> getVideoAuditInfoByCondition(VideoAuditCondition condition) {
		return videoAuditMapper.getVideoAuditInfoByCondition(condition);
	}
	
	public void update(VideoAuditModel videoAuditModel){
		videoAuditMapper.update(videoAuditModel);
	}

}
