package com.cnlive.mam.mapper;

import java.util.List;

import com.cnlive.mam.condition.VideoRemoveCondition;
import com.cnlive.mam.model.VideoRemoveModel;
import com.cnlive.mam.vo.DataGrid;

/**
 * Created by zhangxiaobin on 16/7/12.
 */
public interface VideoRemoveMapper {

    public void insert(VideoRemoveModel entity);
    
    public List<VideoRemoveModel> getRemoveVideo(VideoRemoveCondition video);

	public VideoRemoveModel getRemoveOne(long id);
	
	public void deleteRemoveVideo(long id);

	Long pageCountRemoveVideo(VideoRemoveCondition removeCondition);

    List<VideoRemoveModel> pageRemoveVideo(VideoRemoveCondition removeCondition);
}
