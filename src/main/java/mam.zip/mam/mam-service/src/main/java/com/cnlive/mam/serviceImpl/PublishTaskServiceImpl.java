package com.cnlive.mam.serviceImpl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.cnlive.mam.condition.VideoPublishCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.PublishTaskMapper;
import com.cnlive.mam.mapper.VideoMapper;
import com.cnlive.mam.model.PublishTaskModel;
import com.cnlive.mam.service.PublishTaskService;
import com.cnlive.mam.vo.JsonResult;

@Service("publishTaskService")
public class PublishTaskServiceImpl implements PublishTaskService {

	private static Logger _log = LoggerFactory.getLogger(PublishTaskServiceImpl.class);
	
    @Autowired
    private PublishTaskMapper publishTaskMapper;
    
    @Autowired
    private VideoMapper videoMapper;
    
	 /**
     * @Description:添加到发布任务列表
     */
	@Override
	public void insert(PublishTaskModel publishTaskModel) {
		try {
			publishTaskMapper.insert(publishTaskModel);
		} catch (Exception e) {
			_log.error("添加到发布任务列表失败：_____________"+e.getMessage());
		}
	}

	/**
     * @Description:根据任务状态获取任务列表
     */
	@Override
	public List<PublishTaskModel> getAll() {
		return publishTaskMapper.getAll();
	}

	@Override
	public List<PublishTaskModel> getTaskListByState(PublishTaskModel publishTaskModel) {
		Long count = publishTaskMapper.getTaskListByStateCount(publishTaskModel);
		if(count > 0) {
			return publishTaskMapper.getTaskListByState(publishTaskModel);
		}
		return null;
	}

	@Override
	public void update(PublishTaskModel publishTaskModel) {
		publishTaskMapper.update(publishTaskModel);
	}

	@Override
	public void delete(Long taskId) {
		publishTaskMapper.delete(taskId);
	}

	@Override
	public List<PublishTaskModel> getTaskByCondition(PublishTaskModel publishTaskModel) {
		return publishTaskMapper.getTaskByCondition(publishTaskModel);
	}
	
	   
    /**
     * 取消定时发布
     */
	@Override
    public JsonResult cancelPublish(PublishTaskModel publishTaskModel){
		try{
			List<PublishTaskModel> taskList = publishTaskMapper.getTaskByCondition(publishTaskModel);
	    	if(taskList!=null && taskList.size()>0){
	    		for (int i = 0; i < taskList.size(); i++) {
	    			PublishTaskModel taskModel = taskList.get(i);
	    			if(taskModel!=null && taskModel.getPrePublishedTime()!=null){
	    				if(taskModel.getPrePublishedTime().after(getTimeByMinute(3))){//如果发布时间距离当前时间大于3分钟，取消定时发布
	    					publishTaskMapper.delete(taskModel.getTaskId());
	    					continue;
	    				}else{
	    					return JsonResult.createErrorInstance("发布时间距离当前时间小于3分钟，不能取消定时发布");
	    				}
	    			}else{
	    				 return JsonResult.createErrorInstance("取消定时发布失败");
	    			}
				}
	    	}else{
	    		 return JsonResult.createErrorInstance("取消定时发布失败");
	    	}
		} catch (Exception e) {
			_log.error("取消定时发布失败：_____________"+e.getMessage());
			 return JsonResult.createErrorInstance("取消定时发布失败");
		}
		return JsonResult.createSuccessInstance(null);
    }

	@Override
	public List<PublishTaskModel> PagePublishTaskInfos(VideoPublishCondition condition) {
		Long count = publishTaskMapper.PageCountPublishTaskInfos(condition);
    	if(count >0 ){
    		return publishTaskMapper.PagePublishTaskInfos(condition);
		}
		return null;
	}

	@Override
	public Long PageCountPublishTaskInfos(VideoPublishCondition condition) {
		return publishTaskMapper.PageCountPublishTaskInfos(condition);
	}


	public static Date getTimeByMinute(Integer minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, minute);
        return calendar.getTime();
    }

}
