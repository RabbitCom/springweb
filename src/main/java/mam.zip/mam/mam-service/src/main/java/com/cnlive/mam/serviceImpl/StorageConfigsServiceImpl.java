package com.cnlive.mam.serviceImpl;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.StorageConfigsMapper;
import com.cnlive.mam.model.StorageConfigsModel;
import com.cnlive.mam.service.StorageConfigsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 7/28/2017.
 */
@Service("storageConfigsService")
public class StorageConfigsServiceImpl implements StorageConfigsService {
    @Autowired
    private StorageConfigsMapper storageConfigsMapper;

    @Override
    public void save(StorageConfigsModel storageConfigsModel) {
        storageConfigsMapper.insert(storageConfigsModel);
    }

    @Override
    public void delete(Integer id) {
        if(id == null)return;
        storageConfigsMapper.delete(id);
        String cacheKey = Const.REDIS_KEY_STORAGE_CONFIG + id ;
        CacheUtils.del(cacheKey);
    }

    @Override
    public void modify(StorageConfigsModel storageConfigsModel) {
        storageConfigsMapper.update(storageConfigsModel);
        Integer storageId = storageConfigsModel.getStorageId();
        String cacheKey = Const.REDIS_KEY_STORAGE_CONFIG + storageConfigsModel.getId() ;
        String configcacheKey = Const.REDIS_KEY_STORAGE_CONFIGS + storageId;
        String cacheKey_domain = Const.REDIS_KEY_STORAGE_DOMAIN_WEIGHT + storageId;
        CacheUtils.del(cacheKey,configcacheKey,cacheKey_domain);
        getOutDomainWeightByStorageId(storageId);
    }

    @Override
    public StorageConfigsModel getById(Integer id) {
        if(id == null)return null;
        String cacheKey = Const.REDIS_KEY_STORAGE_CONFIG + id ;
        StorageConfigsModel model = CacheUtils.getJson(cacheKey, StorageConfigsModel.class);
        if(model == null) {
            model = storageConfigsMapper.getById(id);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public List<StorageConfigsModel> getByStorageId(Integer storageId) {
        String cacheKey = Const.REDIS_KEY_STORAGE_CONFIGS + storageId ;
        List<StorageConfigsModel> list = CacheUtils.get(cacheKey,List.class);
        if(list == null || list.size() == 0) {
            list = storageConfigsMapper.getByStorageId(storageId);
            if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public List<Map<String, String>> getOutDomainWeightByStorageId(Integer storageId) {
        if(storageId == null || storageId.intValue() == 0)return null;
        String cacheKey = Const.REDIS_KEY_STORAGE_DOMAIN_WEIGHT + storageId ;
        List<Map<String,String>> domainAndWeightMaps = CacheUtils.getJson(cacheKey, List.class);
        if(domainAndWeightMaps == null || domainAndWeightMaps.size() == 0) {
            domainAndWeightMaps = new ArrayList<Map<String, String>>();
            List<StorageConfigsModel> storageConfigs = getByStorageId(storageId);
            for (StorageConfigsModel model : storageConfigs) {
                if(model.getIoType() != null  &&
                        (2 == model.getIoType().intValue() || 3== model.getIoType().intValue())){
                    Map<String, String> map = new HashMap<>();
                    map.put("domain", model.getHostName());
                    map.put("weight", String.valueOf(model.getWeight()));
                    domainAndWeightMaps.add(map);
                }
            }
            if (domainAndWeightMaps != null && domainAndWeightMaps.size() > 0) {
                CacheUtils.setJson(cacheKey,domainAndWeightMaps,ExpireTime.NONE);
            }
        }
        return domainAndWeightMaps;
    }
}
