package com.cnlive.mam.mapper;

import com.cnlive.mam.condition.LogInfoCondition;
import com.cnlive.mam.model.OptionLogInfo;

import java.util.List;

/**
 * Created by zhangxiaobin on 2017/5/2.
 */
public interface OptionLogInfoMapper {

    void insert(OptionLogInfo optionLogInfo);

    List<OptionLogInfo> pageInfoByCondition(LogInfoCondition condition);

    Long pageInfoCount(LogInfoCondition condition);

    List<OptionLogInfo> selectByVideoId(String videoId);

}
