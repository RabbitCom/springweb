package com.cnlive.mam.mapper;

import com.cnlive.mam.model.StorageConfigsModel;

import java.util.List;

public interface StorageConfigsMapper {
    void insert(StorageConfigsModel storageConfigsModel);

    void delete(Integer id);

    void update(StorageConfigsModel storageConfigsModel);

    StorageConfigsModel getById(Integer id);

    List<StorageConfigsModel> getByStorageId(Integer storageId);
}
