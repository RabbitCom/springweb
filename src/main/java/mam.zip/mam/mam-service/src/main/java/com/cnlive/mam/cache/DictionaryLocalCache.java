package com.cnlive.mam.cache;

import com.cnlive.mam.mapper.DictionaryMapper;
import com.cnlive.mam.model.Dictionary;
import com.google.common.base.Strings;
import com.google.common.cache.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhagnxiaobin
 */
@Component("dictionaryLocalCache")
public class DictionaryLocalCache implements InitializingBean {

    private static Logger LOGGER = LoggerFactory.getLogger(DictionaryLocalCache.class);

    @Autowired
    private DictionaryMapper dictionaryMapper;

    //dicWord
    public static LoadingCache<String, List<Dictionary>> localCacheMap;

    /**
     * 初始化缓存
     * @return
     */
    protected LoadingCache<String, List<Dictionary>> fetchLoadingCache() {
        if (localCacheMap == null) {
            synchronized (this) {
                if (localCacheMap == null) {
                    localCacheMap = CacheBuilder.newBuilder()
                            //设置并发级别为2，并发级别是指可以同时写缓存的线程数
                            .concurrencyLevel(2)
                                    //设置写缓存10分钟后过期
                            .expireAfterWrite(10, TimeUnit.MINUTES)
                                    //设置缓存容器的初始容量为10
                            .initialCapacity(12)
                                    //设置缓存最大容量为100
                            .maximumSize(200)
                                    //设置要统计缓存的命中率
                            .recordStats()
                                    //设置缓存的移除通知
                            .removalListener(new RemovalListener<Object, Object>() {
                                @Override
                                public void onRemoval(RemovalNotification<Object, Object> notification) {
                                    LOGGER.info("DictionaryLocalCache={} was removed, cause={} ", notification.getKey(), notification.getCause());
                                }
                            })
                            .build(new CacheLoader<String, List<Dictionary>>() {
                                       @Override
                                       public List<Dictionary> load(String dicWord) throws Exception {
                                           return loadFromDb(dicWord);
                                       }
                                   }
                            );
                }
            }
        }

        return localCacheMap;
    }


    /**
     * 从数据库中获取字典数据
     * @param dicWord
     * @return
     * @throws Exception
     */
    public List<Dictionary> loadFromDb(String dicWord) throws Exception {
        return dictionaryMapper.selectByWord(dicWord);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOGGER.info("DictionaryLocalCache init ");
        localCacheMap = fetchLoadingCache();
        invalidateAll();

    }

    /**
     * 清空所有缓存
     */
    private void invalidateAll() {
        localCacheMap.invalidateAll();
    }

    /**
     * 获取缓存信息
     * @param dicWord
     * @return
     */
    public List<Dictionary> getDictionaryByCache(String dicWord) {
        try {
            if (Strings.isNullOrEmpty(dicWord)) return null;
            return localCacheMap.get(dicWord);
        } catch (ExecutionException e) {
            LOGGER.error("localCacheMap get error: ", e);
            return null;
        }
    }
}
