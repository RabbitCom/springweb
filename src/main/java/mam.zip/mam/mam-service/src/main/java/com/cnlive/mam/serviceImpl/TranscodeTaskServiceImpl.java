package com.cnlive.mam.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.mapper.TranscodeTaskMapper;
import com.cnlive.mam.model.TranscodeTaskModel;
import com.cnlive.mam.service.TranscodeTaskService;

/**
 * @author wangchaojie
 */
@Service("transcodeTaskService")
public class TranscodeTaskServiceImpl implements TranscodeTaskService {

    public TranscodeTaskServiceImpl() {
    }

    @Autowired
    private TranscodeTaskMapper transcodeTaskMapper;

    @Override
    public List<TranscodeTaskModel> getAll() {
        Long count = transcodeTaskMapper.getAllCount();
        if(count > 0){
            return transcodeTaskMapper.getAll();
        }
        return null;
    }

    @Override
    public TranscodeTaskModel create(TranscodeTaskModel t) {
    	transcodeTaskMapper.insert(t);
        return t;
    }
    
    @Override
    public void modify(TranscodeTaskModel t) {
    	transcodeTaskMapper.update(t);
    }

    @Override
    public void delete(TranscodeTaskModel t) {
    	transcodeTaskMapper.delete(t);
    }

	@Override
	public TranscodeTaskModel findById(Long id) {
		return transcodeTaskMapper.selectById(id);
	}
	
	@Override
	public TranscodeTaskModel findByFileTaskId(String fileTaskId) {
		return transcodeTaskMapper.selectByFileTaskId(fileTaskId);
	}
}
