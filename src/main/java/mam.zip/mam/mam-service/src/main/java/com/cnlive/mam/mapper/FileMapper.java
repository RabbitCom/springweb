package com.cnlive.mam.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.cnlive.mam.model.FileModel;

public interface FileMapper {
	void insert(FileModel t);

	void update(FileModel t);

	FileModel selectById(Long id);

	FileModel getFileByIdAndVid(@Param("fileId") Long fileId,@Param("vid")long vid);
	
	List<FileModel> getFileByVid(Long vid);

	void deleteFile(FileModel fileModel);
	
	void deleteFileByVideoId(Long videoId);
	
	List<FileModel> getFileByVidAndCoderate(@Param("vid")Long vid,@Param("codeRate")Integer codeRate);

	FileModel getFileByVidAndCoderateAndTransCodeFmt(@Param("vid")Long vid,@Param("codeRate")Integer codeRate,@Param("transCodeFmt")String transCodeFmt);
	
	List<FileModel> getByTaskId(String taskId);

	FileModel getByTaskIdAndUuid(@Param("taskId")String taskId,@Param("uuid")String uuid);
	
	FileModel getByTaskIdAndTransCodeFmtAndCodeRate(@Param("taskId")String taskId,@Param("transCodeFmt")String transCodeFmt,@Param("codeRate")Integer codeRate);

	List<FileModel> getByVidAndTransCodeFmt(@Param("vid")Long vid,@Param("transCodeFmt")String transCodeFmt);
	
}
