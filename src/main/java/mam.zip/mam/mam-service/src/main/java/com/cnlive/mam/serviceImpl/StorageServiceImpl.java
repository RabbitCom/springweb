package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.enums.StorageUsageEnum;
import com.cnlive.mam.common.enums.StorageUseStateEnum;
import com.cnlive.mam.condition.StorageCondition;
import com.cnlive.mam.common.enums.*;
import com.cnlive.mam.common.utils.CacheUtils;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.mapper.StorageMapper;
import com.cnlive.mam.model.StorageConfigsModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.service.StorageConfigsService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.vo.DataGrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cuilongcan on 7/28/2017.
 */
@Service("storageService")
public class StorageServiceImpl implements StorageService {
    @Autowired
    private StorageMapper storageMapper;

    @Autowired
    private StorageConfigsService storageConfigsService;

    @Value("#{configProperties['bucket_default']}")
    private String bucket_default;
    @Value("#{configProperties['bucket_qiniu']}")
    private String bucket_qiniu;
    @Value("#{configProperties['playDomain_default']}")
    private String playDomain_default;
    @Value("#{configProperties['playDomain_qiniu']}")
    private String playDomain_qiniu;
    @Value("#{configProperties['imgDomain_default']}")
    private String imgDomain_default;
    @Value("#{configProperties['imgDomain_qiniu']}")
    private String imgDomain_qiniu;

    @Override
    public StorageModel save(StorageModel storageModel) {
        storageMapper.insert(storageModel);
        return storageModel;
    }

    @Override
    public void delete(Integer id) {
        if (id == null) return;
        storageMapper.delete(id);
        String storageKey = Const.REDIS_KEY_STORAGE + id;
        CacheUtils.del(storageKey );
    }

    @Override
    public void modify(StorageModel storageModel) {
        storageMapper.update(storageModel);
        String storageKey = Const.REDIS_KEY_STORAGE + storageModel.getId();
        String sp_cache = Const.REDIS_KEY_SP + storageModel.getSpid();
        String storageSpKey = Const.REDIS_KEY_STORAGE_ALL_SP + storageModel.getSpid();
        String storageSpEnableKey = Const.REDIS_KEY_STORAGE_ENABLE_SP + storageModel.getSpid();
        String spExpCache = Const.REDIS_KEY_SP_EXP_SPID + storageModel.getSpid();
        CacheUtils.del(sp_cache,storageKey,storageSpKey,storageSpEnableKey,spExpCache );
    }

    @Override
    public StorageModel getById(Integer id) {
        if(id == null)return null;
        String cacheKey = Const.REDIS_KEY_STORAGE + id;
        StorageModel model = CacheUtils.getJson(cacheKey,StorageModel.class);
        if(model == null) {
            model = storageMapper.getStorageById(id);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    @Override
    public List<StorageModel> getStorageAllBySpid(Long spid) {
        String cacheKey = Const.REDIS_KEY_STORAGE_ALL_SP + spid ;
        List<StorageModel> list = CacheUtils.get(cacheKey, List.class);
        if(list == null || list.size() == 0) {
            list = storageMapper.getStorageAllBySpId(spid);
            if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public List<StorageModel> getStorageEnableBySpid(Long spid) {
        String cacheKey = Const.REDIS_KEY_STORAGE_ENABLE_SP + spid ;
        List<StorageModel> list = CacheUtils.get(cacheKey, List.class);
        if(list == null || list.size() == 0) {
            StorageModel StorageModel = new StorageModel();
            StorageModel.setSpid(spid);
            StorageModel.setUseState(StorageUseStateEnum.Used);
            list = storageMapper.getByStorage(StorageModel);
            if(list!=null&&list.size()>0)CacheUtils.set(cacheKey,list,ExpireTime.NONE);
        }
        return list;
    }

    @Override
    public List<StorageModel> getByStorage(StorageModel storageModel) {
        return storageMapper.getByStorage(storageModel);
    }

    @Override
    public Boolean checkStorageComplete(Long spid) {
        List<StorageModel> list = getStorageEnableBySpid(spid);
        if(list == null){
            return false;
        }
        boolean imgStorage = false;
        boolean videoStorage = false;
        boolean equalsType = true;
        int typeVal = 0;
        for (StorageModel storageModel : list) {
            int contentType = storageModel.getContentType().getDbValue();
            if (StorageContentTypeEnum.MediaAndPicture.getDbValue() == contentType) {
                imgStorage = true;videoStorage = true;equalsType=true;
                break;
            }
            if(StorageContentTypeEnum.Media.getDbValue() == contentType){
                if(typeVal == 0){
                    typeVal = storageModel.getType().getDbValue();
                }else {
                    if(storageModel.getType().getDbValue() != typeVal){
                        equalsType = false;
                        break;
                    }
                }
                videoStorage = true;
            }
            if(StorageContentTypeEnum.Picture.getDbValue() == contentType){
                if(typeVal == 0){
                    typeVal = storageModel.getType().getDbValue();
                }else {
                    if(storageModel.getType().getDbValue() != typeVal){
                        equalsType = false;
                        break;
                    }
                }
                imgStorage = true;
            }

        }
        if (imgStorage && videoStorage && equalsType) {
            return true;
        }
        return false;
    }

    @Override
    public void insertDefaultStorage(Long spId) {
        saveKsDefaultStorage(spId);
        saveQnDefaultStorage(spId);
    }

    @Override
    public StorageModel getStorageInBySpId(Long spId,StorageContentTypeEnum contentType) {
        StorageModel storageModel = new StorageModel();
        List<StorageModel> storageBySpid = getStorageEnableBySpid(spId);
        for(StorageModel s : storageBySpid){
            int usage = s.getYongtu().getDbValue();
            if(StorageUsageEnum.Production.getDbValue()  == usage ||
                    StorageUsageEnum.ProductionAndOperation.getDbValue() == usage){
                if(contentType.getDbValue() == s.getContentType().getDbValue() ||
                        StorageContentTypeEnum.MediaAndPicture.getDbValue() == s.getContentType().getDbValue()) {
                    storageModel = s;
                    break;
                }
            }
        }
        return storageModel;
    }

    @Override
    public StorageModel getStorageOutBySpId(Long spId,StorageContentTypeEnum contentType) {
        StorageModel storageModel = new StorageModel();
        List<StorageModel> storageBySpid = this.getStorageEnableBySpid(spId);
        for(StorageModel s : storageBySpid){
            int usage = s.getYongtu().getDbValue();
            if(StorageUsageEnum.Operation.getDbValue()  == usage ||
                    StorageUsageEnum.ProductionAndOperation.getDbValue() == usage){
                if(contentType.getDbValue() == s.getContentType().getDbValue() ||
                        StorageContentTypeEnum.MediaAndPicture.getDbValue() == s.getContentType().getDbValue()) {
                    storageModel = s;
                    break;
                }
            }
        }
        return storageModel;
    }

    @Override
    public List<String> getDomainAllInBySpId(Long spId,StorageContentTypeEnum contentType)  {
        List<String> domainArrays = new ArrayList<>();
        StorageModel storageIn = this.getStorageInBySpId(spId,contentType);
        List<StorageConfigsModel> storageAcessList = storageConfigsService.getByStorageId(storageIn.getId());
        for(StorageConfigsModel scm : storageAcessList){
            int inputType = scm.getIoType().intValue();
            if( 1 == inputType || 3 == inputType){
                domainArrays.add(scm.getHostName());
            }
        }
        return domainArrays;
    }

    @Override
    public List<String> getDomainAllOutBySpId(Long spId,StorageContentTypeEnum contentType)  {
        List<String> domainArrays = new ArrayList<>();
        StorageModel storageIn = this.getStorageOutBySpId(spId,contentType);
        List<StorageConfigsModel> storageAcessList = storageConfigsService.getByStorageId(storageIn.getId());
        for(StorageConfigsModel scm : storageAcessList){
            int inputType = scm.getIoType().intValue();
            if( 2 == inputType || 3 == inputType){
                domainArrays.add(scm.getHostName());
            }
        }
        return domainArrays;
    }

    @Override
    public String getDomainSimpleInBySpId(Long spId,StorageContentTypeEnum contentType)  {
        List<String> allInDomainBySpId = this.getDomainAllInBySpId(spId,contentType);
        if(allInDomainBySpId.size() > 0){
            return getRandom(allInDomainBySpId);
        }
        return "";
    }

    @Override
    public String getDomainSimpleOutBySpId(Long spId,StorageContentTypeEnum contentType)  {
        List<String> allOutDomainBySpId = this.getDomainAllOutBySpId(spId,contentType);
        if(allOutDomainBySpId.size() > 0){
            return getRandom(allOutDomainBySpId);
        }
        return "";
    }

    @Override
    public String getDomainSimpleInByStorageId(Integer storageId) {
        List<String> domainArrays = getDomainAllInByStorageId(storageId);
        if(domainArrays.size() > 0){
            return getRandom(domainArrays);
        }
        return "";
    }

    @Override
    public String getDomainSimpleOutByStorageId(Integer storageId) {
        List<String> domainArrays = getDomainAllOutByStorageId(storageId);
        if(domainArrays.size() > 0){
            return getRandom(domainArrays);
        }
        return "";
    }

    @Override
    public List<String> getDomainAllInByStorageId(Integer storageId) {
        List<String> domainArrays = new ArrayList<>();
        List<StorageConfigsModel> storageAcessList = storageConfigsService.getByStorageId(storageId);
        for(StorageConfigsModel scm : storageAcessList){
            int inputType = scm.getIoType().intValue();
            if( 1 == inputType || 3 == inputType){
                domainArrays.add(scm.getHostName());
            }
        }
        return domainArrays;
    }

    @Override
    public List<String> getDomainAllOutByStorageId(Integer storageId) {
        List<String> domainArrays = new ArrayList<>();
        List<StorageConfigsModel> storageAcessList = storageConfigsService.getByStorageId(storageId);
        for(StorageConfigsModel scm : storageAcessList){
            int inputType = scm.getIoType().intValue();
            if( 2 == inputType || 3 == inputType){
                domainArrays.add(scm.getHostName());
            }
        }
        return domainArrays;
    }

    @Override
    public StorageModel getStorageByTypeAndContentTypeAndName(StorageTypeEnum typeEnum,
                                                              StorageContentTypeEnum contentTypeEnum,
                                                              String bucketName,
                                                              Long spId) {
        String name = bucketName.trim();
        StorageModel storageModel = new StorageModel();
        storageModel.setName(name);
        storageModel.setType(typeEnum);
        storageModel.setContentType(contentTypeEnum);
        storageModel.setSpid(spId);
        List<StorageModel> storages = getByStorage(storageModel);
        if(storages == null || storages.size() <= 0){
            return null;
        }
        return storages.get(0);
    }

    @Override
    public boolean checkNameExtis(String bucketName, StorageTypeEnum typeEnum,
                                                              StorageContentTypeEnum contentTypeEnum,
                                                              Long spId,
                                                              StorageUsageEnum usageEnum) {
        StorageModel storageModel = new StorageModel();
        storageModel.setName(bucketName.trim());
        storageModel.setSpid(spId);
        storageModel.setType(typeEnum);
        storageModel.setContentType(contentTypeEnum);
        storageModel.setYongtu(usageEnum);
        Long ct = storageMapper.checkNameExtis(storageModel);
        if(ct > 0){
            return true;
        }
        return false;
    }

    @Override
    public StorageTypeEnum getStorageTypeBySpId(Long spId,StorageContentTypeEnum contentTypeEnum) {
        List<StorageModel> enableStorage = getStorageEnableBySpid(spId);
        if(enableStorage != null || enableStorage.size() > 0){
            for (StorageModel m : enableStorage){
                if( 3 == m.getContentType().getDbValue() ||
                        contentTypeEnum.getDbValue() == m.getContentType().getDbValue()){
                    return m.getType();
                }
            }
        }
        return StorageTypeEnum.KSYUN;
    }

    @Override
    public DataGrid getPageByCondition(StorageCondition condition) {
        Long count = storageMapper.getCountByCondition(condition);
        List<StorageModel> storageList = new ArrayList<>();
        if (count > 0) {
            storageList = storageMapper.getPageByCondition(condition);
        }
        return new DataGrid(count, storageList);
    }

    private String getRandom(List<String> strArray){
        int index = (int) (Math.random() * strArray.size());
        return strArray.get(index);

    }

    /**
     * 保存默认的七牛存储
     * @param spId
     */
    private void saveQnDefaultStorage(Long spId){
        //媒体
        StorageModel storageVideo = new StorageModel();
        storageVideo.setName(bucket_qiniu);
        storageVideo.setSpid(spId);
        storageVideo.setType(StorageTypeEnum.QINIUYUN);
        storageVideo.setContentType(StorageContentTypeEnum.Media);
        storageVideo.setDefaultStorage(1);
        storageVideo.setYongtu(StorageUsageEnum.ProductionAndOperation);
        storageVideo.setUseState(StorageUseStateEnum.UsedBefore);
        storageVideo.setShowName("七牛视音频存储");
        storageMapper.insert(storageVideo);
        StorageConfigsModel videoStorageConfig = new StorageConfigsModel();
        videoStorageConfig.setIoType(3);
        videoStorageConfig.setStorageId(storageVideo.getId());
        videoStorageConfig.setHostName(playDomain_qiniu);
        videoStorageConfig.setProtocol(1);
        storageConfigsService.save(videoStorageConfig);
        //图片
        StorageModel storageImg = new StorageModel();
        storageImg.setName(bucket_qiniu);
        storageImg.setSpid(spId);
        storageImg.setType(StorageTypeEnum.QINIUYUN);
        storageImg.setContentType(StorageContentTypeEnum.Picture);
        storageImg.setDefaultStorage(1);
        storageImg.setYongtu(StorageUsageEnum.ProductionAndOperation);
        storageImg.setShowName("七牛图片存储");
        storageImg.setUseState(StorageUseStateEnum.UsedBefore);
        storageMapper.insert(storageImg);
        StorageConfigsModel imgStorageConfig = new StorageConfigsModel();
        imgStorageConfig.setIoType(3);
        imgStorageConfig.setStorageId(storageImg.getId());
        imgStorageConfig.setHostName(imgDomain_qiniu);
        imgStorageConfig.setProtocol(1);
        storageConfigsService.save(imgStorageConfig);
    }

    /**
     * 保存默认的金山存储
     * @param spId
     */
    private void saveKsDefaultStorage(Long spId){
        //媒体
        StorageModel storageVideo = new StorageModel();
        storageVideo.setName(bucket_default);
        storageVideo.setSpid(spId);
        storageVideo.setType(StorageTypeEnum.KSYUN);
        storageVideo.setContentType(StorageContentTypeEnum.Media);
        storageVideo.setDefaultStorage(1);
        storageVideo.setYongtu(StorageUsageEnum.ProductionAndOperation);
        storageVideo.setUseState(StorageUseStateEnum.Used);
        storageVideo.setShowName("金山视音频存储");
        storageMapper.insert(storageVideo);
        StorageConfigsModel videoStorageConfig = new StorageConfigsModel();
        videoStorageConfig.setIoType(3);
        videoStorageConfig.setStorageId(storageVideo.getId());
        videoStorageConfig.setHostName(playDomain_default);
        videoStorageConfig.setProtocol(1);
        storageConfigsService.save(videoStorageConfig);
        //图片
        StorageModel storageImg = new StorageModel();
        storageImg.setName(bucket_default);
        storageImg.setSpid(spId);
        storageImg.setType(StorageTypeEnum.KSYUN);
        storageImg.setContentType(StorageContentTypeEnum.Picture);
        storageImg.setDefaultStorage(1);
        storageImg.setYongtu(StorageUsageEnum.ProductionAndOperation);
        storageImg.setUseState(StorageUseStateEnum.Used);
        storageImg.setShowName("金山图片存储");
        storageMapper.insert(storageImg);
        StorageConfigsModel imgStorageConfig = new StorageConfigsModel();
        imgStorageConfig.setIoType(3);
        imgStorageConfig.setStorageId(storageImg.getId());
        imgStorageConfig.setHostName(imgDomain_default);
        imgStorageConfig.setProtocol(1);
        storageConfigsService.save(imgStorageConfig);
    }
}
