package com.cnlive.mam.serviceImpl;

import com.cnlive.mam.service.CategoryFreeReviewService;
import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.cnlive.mam.mapper.CategoryFreeReviewMapper;
import com.cnlive.mam.model.CategoryFreeReviewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by zhangxiaobin
 */
@Service("categoryFreeReviewService")
public class CategoryFreeReviewImpl implements CategoryFreeReviewService {

    @Autowired
    private CategoryFreeReviewMapper categoryFreeReviewMapper;


    @Override
    public int create(CategoryFreeReviewModel t) {
        return categoryFreeReviewMapper.insert(t);
    }

    @Override
    public int modify(CategoryFreeReviewModel t) {
        Preconditions.checkNotNull(t.getCustomId(), "customId is null");
        return categoryFreeReviewMapper.update(t);
    }

    @Override
    public int delete(CategoryFreeReviewModel t) {
        return categoryFreeReviewMapper.delete(t);
    }

    @Override
    public CategoryFreeReviewModel getByCustomId(Long customId) {
        Preconditions.checkNotNull(customId, "customId is null");
        return categoryFreeReviewMapper.selectByCustomId(customId);
    }

    @Override
    public Boolean isCategoryFreeReview(Long customId, String category) {
        CategoryFreeReviewModel categoryFreeReviewModel = getByCustomId(customId);
        if (categoryFreeReviewModel == null || categoryFreeReviewModel.getCategoryIds() == null) return false;
        return Splitter.on(",")
                .omitEmptyStrings()
                .trimResults()
                .splitToList(categoryFreeReviewModel.getCategoryIds())
                .contains(category);
    }
}
