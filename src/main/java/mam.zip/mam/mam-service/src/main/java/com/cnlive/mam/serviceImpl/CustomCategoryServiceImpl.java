package com.cnlive.mam.serviceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cnlive.mam.common.enums.ExpireTime;
import com.cnlive.mam.common.utils.CacheUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.resultMessage.CommonResultMessage;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.CustomCategoryCondition;
import com.cnlive.mam.mapper.CategoryRelationMapper;
import com.cnlive.mam.mapper.CustomCategoryMapper;
import com.cnlive.mam.model.CategoryRelation;
import com.cnlive.mam.model.CustomCategoryModel;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.AlbumService;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.CustomCategoryTree;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.DataGrid;

/**
 * Created by zhangxiaobin
 */
@Service("customCategoryService")
public class CustomCategoryServiceImpl implements CustomCategoryService {

	@Autowired
    private CustomCategoryMapper customCategoryMapper;
	@Autowired
    private CategoryRelationMapper categoryRelationMapper;
    @Autowired
    private VideoService videoService;
    @Autowired
    private AlbumService albumService;
    @Autowired
    private DictionaryService dictionaryService;

    Logger logger = LoggerFactory.getLogger(CustomCategoryServiceImpl.class);

    public CustomCategoryServiceImpl() {

    }


    public CustomCategoryModel getById(Long id) {
        if(id == null)return null;
        String cacheKey = Const.REDIS_KEY_CATEGORY_CUSTOM + id ;
        CustomCategoryModel model = CacheUtils.getJson(cacheKey, CustomCategoryModel.class);
        if(model == null){
            model= customCategoryMapper.selectById(id);
            if(model != null)CacheUtils.setJson(cacheKey,model, ExpireTime.NONE);
        }
        return model;
    }

    public CustomCategoryModel save(CustomCategoryModel t) {

        if (t.getCustomCategoryId() == null) {
            return create(t);
        } else {
            return modify(t);
        }
    }

    @Override
    public CustomCategoryModel create(CustomCategoryModel t) {
    	customCategoryMapper.insert(t);
        return t;
    }

    @Override
    public CustomCategoryModel modify(CustomCategoryModel t) {
        customCategoryMapper.update(t);
        String cacheKey = Const.REDIS_KEY_CATEGORY_CUSTOM + t.getCustomCategoryId() ;
        CacheUtils.del(cacheKey);
        return t;
    }

    @Override
    public List<CustomCategoryModel> getInfosByCondition(CustomCategoryCondition customCategoryCondition) {
        return customCategoryMapper.selectInfosByCondition(customCategoryCondition);
    }

    @Override
    public Boolean checkContent(CustomCategoryModel customCategoryModel) {
        int albumByCustomCatgoey = 0;
        int videoByCustomCatgoey = 0;
        if (customCategoryModel.getCustomCategoryId() != null && customCategoryModel.getCustomCategoryId() != 0) {
            videoByCustomCatgoey = videoService.getVideoByCustomCategory(customCategoryModel.getCustomCategoryId());
            albumByCustomCatgoey = albumService.getAlbumByCustomCategory(customCategoryModel.getCustomCategoryId());
        }
        return !(videoByCustomCatgoey >= 1 || albumByCustomCatgoey >= 1);
    }

    @Override
    public List<CustomCategoryVo> integratedData(CustomCategoryCondition customCategoryCondition, Long customId) {
        List<CustomCategoryModel> byCondition;
        List<Dictionary> dicList;
        customCategoryCondition.setCustomId(customId);
        byCondition = this.getInfosByCondition(customCategoryCondition);
        dicList = dictionaryService.getCategorys();
        Map<Long, String> parentCustomCategoryMap = new HashMap<Long, String>();
        Map<Integer, String> dicMap = new HashMap<Integer, String>();
        List<CustomCategoryModel> parentCustomCategoryList = this.getParentCustomCategory(customCategoryCondition.getSpId());
        for (Dictionary dic : dicList) {
            dicMap.put(dic.getDicValue(), dic.getShowValue());
        }
        for (CustomCategoryModel customCategoryModel : parentCustomCategoryList) {
            parentCustomCategoryMap.put(customCategoryModel.getCustomCategoryId(),
                    customCategoryModel.getCustomCategoryName());
        }
        parentCustomCategoryMap.put(0L, "顶级分类");
        List<CustomCategoryVo> list = new ArrayList<CustomCategoryVo>();
        for (CustomCategoryModel ccm : byCondition) {
            CustomCategoryVo ccv = new CustomCategoryVo();
            ccv.setCategory(dicMap.get(ccm.getCategory()));
            ccv.setCategoryId(ccm.getCategory());
            ccv.setParentCustomCategory(parentCustomCategoryMap.get(ccm.getParentCustomCategoryId()));
            ccv.setParentCustomCategoryId(ccm.getParentCustomCategoryId());
            ccv.setCustomCategoryName(ccm.getCustomCategoryName());
            ccv.setCustomCategoryId(ccm.getCustomCategoryId());
            ccv.setLevel(ccm.getLevel());
            ccv.setAuditSetting(ccm.getAuditSetting());
            ccv.setCustomId(customId);
            ccv.setSpId(ccm.getSpId());
            list.add(ccv);
        }
        return list;
    }

    @Override
    public List<CustomCategoryModel> getCustomCategoryByCustomId(Long customId) {
        CustomCategoryCondition customCategoryCondition = new CustomCategoryCondition();
        customCategoryCondition.setCustomId(customId);
        return this.getInfosByCondition(customCategoryCondition);
    }

    @Override
    public void checkCustomCategoryCanAddVideo(Long customId, Long customCategoryId) throws BusinessException {
        CustomCategoryModel customCategoryModel = getById(customCategoryId);
        if (customCategoryModel == null) {
            throw new BusinessException(CommonResultMessage.UNKOWN_ERROR);
        } else {
            if (customCategoryModel.isLeafLevel()) {
                return ;
            } else {
                CustomCategoryCondition condition = new CustomCategoryCondition();
                condition.setParentCustomCategoryId(customCategoryId.toString());
                condition.setCustomId(customId);
                Long countByCondition = this.getCountByCondition(condition);
                if(countByCondition > 0){
                    logger.error("当前分类customCategoryId={}下包含子分类，无法继续添加视频",customCategoryId);
                    throw new BusinessException(CommonResultMessage.UNKOWN_ERROR);
                }
            }
        }
    }


    @Override
    public void delete(CustomCategoryModel t) {
    	customCategoryMapper.delete(t);
        String cacheKey = Const.REDIS_KEY_CATEGORY_CUSTOM + t.getCustomCategoryId() ;
        CacheUtils.del(cacheKey);
    }

    @Override
    public Map<String, CustomCategoryTree> getCustomCategoryData(List<CustomCategoryVo> list,
                                                                 Map<String, CustomCategoryTree> map) {
        // 获取 分类下所有专辑的个数
        Map<Long, Long> albumCountMap = albumService.getAlbumCountByCustomCategoryId(list);
        // 获取 分类下所有视频的个数
        Map<Long, Long> videoCountMap = videoService.getVideoCountByCustomCategoryId(list);
        
        List<Dictionary> dictionary = dictionaryService.getDictionary(Dictionary.CATEGORY_DIC_WORD, -1);
        Map<Integer, String> dicMap = new HashMap<Integer, String>();
        for (Dictionary dic : dictionary) {
            dicMap.put(dic.getDicValue(), dic.getShowValue());
        }
        Collections.sort(list, new Comparator<CustomCategoryVo>() {
            @Override
            public int compare(CustomCategoryVo o1, CustomCategoryVo o2) {
                return o1.getParentCustomCategoryId().compareTo(o2.getParentCustomCategoryId());
            }
        });
        for (CustomCategoryVo customCategoryVo : list) {
            Long customCategoryId = customCategoryVo.getCustomCategoryId();
            
//            CategoryRelation categoryRelation = new CategoryRelation();
//            categoryRelation.setCustomId(customCategoryVo.getCustomId());
//            categoryRelation.setCustomCategoryId(customCategoryVo.getCustomCategoryId());
			CategoryRelation relation = this.getRelationBySpidAndCustomCategory(customCategoryVo.getCustomCategoryId(),customCategoryVo.getSpId());
            
            String pid =  customCategoryVo.getParentCustomCategoryId().toString();
            Integer categoryId = customCategoryVo.getCategoryId();
            Long albumCount_1 = albumCountMap.containsKey(customCategoryId) ? albumCountMap.get(customCategoryId) : 0L;
            Long videoCount_1 = videoCountMap.containsKey(customCategoryId) ? videoCountMap.get(customCategoryId) : 0L;
            CustomCategoryTree customCategoryTree = new CustomCategoryTree();
            if(relation != null){
            	customCategoryTree.setCategoryRelation(relation.getIcmsCategoryName());
            }else{
            	customCategoryTree.setCategoryRelation("暂无");
            }
            customCategoryTree.setText(customCategoryVo.getCustomCategoryName());
            customCategoryTree.setId(customCategoryId.toString());
            customCategoryTree.setPid(pid);
            customCategoryTree.setAlbumCount(albumCount_1);
            customCategoryTree.setVideoCount(videoCount_1);
            customCategoryTree.setCategoryName(dicMap.get(categoryId));
            customCategoryTree.setCategory(categoryId);
            customCategoryTree.setAuditSetting(customCategoryVo.getAuditSetting());
            if (map.containsKey(pid)) {
                CustomCategoryTree customCategory = map.get(pid);
                customCategory.getChildren().add(customCategoryTree);
                if (!customCategory.getPid().equals("0")) {
                    Long albumCount_2 = customCategory.getAlbumCount();
                    albumCount_2 += albumCount_1;
                    customCategory.setAlbumCount(albumCount_2);
                    Long videoCount_2 = customCategory.getVideoCount();
                    videoCount_2 += videoCount_1;
                    customCategory.setVideoCount(videoCount_2);
                }
                map.put(customCategoryId.toString(), customCategoryTree);
            }
        }
        List<CustomCategoryTree> children = map.get("0").getChildren();
        for (CustomCategoryTree child : children) {
            Long albumCountP = child.getAlbumCount();
            Long videoCountP = child.getVideoCount();
            List<CustomCategoryTree> children1 = child.getChildren();
            for (CustomCategoryTree customCategoryTree : children1) {
                albumCountP += customCategoryTree.getAlbumCount();
                videoCountP += customCategoryTree.getVideoCount();
            }
            child.setAlbumCount(albumCountP);
            child.setVideoCount(videoCountP);
        }
        return map;
    }

    @Override
    public CustomCategoryModel create(CustomCategoryModel customCategoryModel, Long customId) throws BusinessException {
        int level = checkCustomCategoryCanAdd(customCategoryModel, customId);
        customCategoryModel.setCustomId(customId);
        customCategoryModel.setLevel(level);
        return this.save(customCategoryModel);
    }

    private Integer checkCustomCategoryCanAdd(CustomCategoryModel customCategoryModel, Long customId) {
        if (customId == null || customId == 0L) {
            throw new BusinessException(CommonResultMessage.CONTENT_WRONG);
        }
        if (!StringUtils.isNotEmpty(customCategoryModel.getCustomCategoryName())) {
            throw new BusinessException(CommonResultMessage.DYNAMIC_EXCEPTION_INFORMATION, "分类名称必填！");
        }
        int level = Const.CustomCategory_Level_Step;
        Long parentCustomCategoryId = customCategoryModel.getParentCustomCategoryId();
        if (parentCustomCategoryId == null || parentCustomCategoryId == 0L) {
            customCategoryModel.setParentCustomCategoryId(0L);
        }
        CustomCategoryModel customCategory_Parent = this.getById(parentCustomCategoryId);
        Boolean checkContentRes = true;
        if (customCategory_Parent != null) {
            level = customCategory_Parent.getLevel() + Const.CustomCategory_Level_Step;
            if (level > Const.CustomCategory_Level_Max) {
                throw new BusinessException(CommonResultMessage.DYNAMIC_EXCEPTION_INFORMATION, "只能有三级目录，该目录以是最后一级！");
            }
            customCategoryModel.setCategory(customCategory_Parent.getCategory());
            checkContentRes = this.checkContent(customCategory_Parent);
        }
        if (!checkContentRes) {
            throw new BusinessException(CommonResultMessage.DYNAMIC_EXCEPTION_INFORMATION, "该分类下已有视频或专辑！");
        }
        return level;
    }

    @Override
    public void customCategoryFreeAuditSettingByIds(Map<String, String[]> parameterMap) {
        String[] offids = parameterMap.get("offIds");
        String[] openids = parameterMap.get("openIds");
        if (offids != null && offids.length > 0) {
            // 1、关闭分类免审核
            Map<String, Object> params_off = new HashMap<String, Object>();
            params_off.put("customCategoryIds", offids);
            this.closeFreeAudit(offids);
        }
        if (openids != null && openids.length > 0) {
            // 2、打开分类免审核
            Map<String, Object> params_open = new HashMap<String, Object>();
            params_open.put("customCategoryIds", openids);
            this.openFreeAudit(openids);
        }

    }

    @Override
    public void closeFreeAudit(String[] offids) {

        for (int i = 0; i < offids.length; i++) {
            Long id = Long.parseLong(offids[i]);
            CustomCategoryModel cmc = getById(id);
            if(cmc == null)continue;
            cmc.setAuditSetting(0);
            modify(cmc);
        }

    }

    @Override
    public void openFreeAudit(String[] openids) {

        for (int i = 0; i < openids.length; i++) {
            Long id = Long.parseLong(openids[i]);
            CustomCategoryModel cmc = getById(id);
            if(cmc == null)continue;
            cmc.setAuditSetting(1);
            modify(cmc);
        }
    }

    @Override
    public Long getCountByCondition(CustomCategoryCondition customCategoryCondition) {
        return customCategoryMapper.getCountByCondition(customCategoryCondition);
    }


    @Override
    public DataGrid dataGrid(CustomCategoryCondition customCategoryCondition) {
        List<CustomCategoryVo> responseList = new ArrayList<>();
        List<CustomCategoryModel> pageByCondition = this.getPageByCondition(customCategoryCondition);

        //数据分类的名称
        List<Dictionary> categorys = dictionaryService.getCategorys();
        Map<Integer, String> dicMap = new HashMap<Integer, String>();
        for (Dictionary dic : categorys) {
            dicMap.put(dic.getDicValue(), dic.getShowValue());
        }

        //获取父级分类名称存放到map中
        Map<Long, String> yijiCustomCategoryMap = new HashMap<Long, String>();
        for(CustomCategoryModel customCategoryModel : pageByCondition){
            Long parentId = customCategoryModel.getParentCustomCategoryId();
            if(parentId != null && parentId.intValue() != 0){
                CustomCategoryModel parentModel =  this.getById(parentId);
                yijiCustomCategoryMap.put(parentModel.getCustomCategoryId(), parentModel.getCustomCategoryName());
            }
        }

        for (CustomCategoryModel ccm : pageByCondition) {
            CustomCategoryVo ccv = new CustomCategoryVo();
            ccv.setCategory(dicMap.get(ccm.getCategory()));
            ccv.setCategoryId(ccm.getCategory());
            ccv.setParentCustomCategory(yijiCustomCategoryMap.get(ccm.getParentCustomCategoryId()));
            ccv.setParentCustomCategoryId(ccm.getParentCustomCategoryId());
            ccv.setCustomCategoryName(ccm.getCustomCategoryName());
            ccv.setCustomCategoryId(ccm.getCustomCategoryId());
            ccv.setLevel(ccm.getLevel());
            ccv.setAuditSetting(ccm.getAuditSetting());
            responseList.add(ccv);
        }

        Long countByCondition = this.getCountByCondition(customCategoryCondition);
        DataGrid dg = new DataGrid();
        dg.setTotal(countByCondition);
        dg.setRows(responseList);
        return dg;
    }

    @Override
    public List<CustomCategoryModel> getParentCustomCategory(Long spid) {
        return customCategoryMapper.getParentCustomCategory(spid);
    }

    @Override
    public List<CustomCategoryModel> getPageByCondition(CustomCategoryCondition customCategoryCondition) {
        return customCategoryMapper.selectPageByCondition(customCategoryCondition);
    }

    @Override
    public List<CustomCategoryModel> getCustomCategorysByParentIds(List<String> customCategoryIds) {
        return customCategoryMapper.selectByParentIds(customCategoryIds);
    }

    @Override
    public CustomCategoryModel getParentCustomCategoryByLeafCustomCategory(CustomCategoryModel customCategoryModel) {
        if(customCategoryModel == null){
            return null;
        }
        if(customCategoryModel.getLevel()!=null && customCategoryModel.getLevel() ==1){
            return customCategoryModel;
        }else{
            CustomCategoryModel parentModel = this.getById(customCategoryModel.getParentCustomCategoryId());
            return getParentCustomCategoryByLeafCustomCategory(parentModel);
        }
    }
    
    @Override
    public void saveCategoryRelation(CategoryRelation categoryRelation){
    	categoryRelationMapper.insert(categoryRelation);
    }
    
    @Override
    public CategoryRelation getRelationBySpidAndCustomCategory(Long customCategoryId,Long spId){
    	return categoryRelationMapper.getRelationBySpidAndCustomCategory(customCategoryId,spId);
    }
    
    @Override
    public CategoryRelation getRelationBySpidAndCategory(Integer categoryDicValue,Long spId){
    	return categoryRelationMapper.getRelationBySpidAndCategory(categoryDicValue,spId);
    }
    
    @Override
    public void deleteByCustomCategoryId(Long customCategoryId){
    	categoryRelationMapper.deleteByCustomCategoryId(customCategoryId);
    }
    
    @Override
    public void deleteByCategoryRelationId(Long categoryRelationId){
    	categoryRelationMapper.deleteByCategoryRelationId(categoryRelationId);
    }
    
    @Override
    public void updateCategoryRelation(CategoryRelation categoryRelation){
    	categoryRelationMapper.updateCategoryRelation(categoryRelation);
    }

    @Override
    public CategoryRelation getPublishCategoryRelation(CategoryRelation categoryRelation){
    	CategoryRelation returnCategoryRelation = new CategoryRelation();
    	Long customCategoryId = categoryRelation.getCustomCategoryId();
    	if(customCategoryId != 0){
    		CategoryRelation relation = this.getRelationBySpidAndCustomCategory(categoryRelation.getCustomCategoryId(),categoryRelation.getSpId());
    		if(relation != null){
    			//返回参数
    			returnCategoryRelation = relation;
    		}else{
    			CustomCategoryModel customCategoryModel = this.getById(customCategoryId);
    			if(customCategoryModel != null){
    				Long parentCustomCategoryId = customCategoryModel.getParentCustomCategoryId();
    				if(parentCustomCategoryId != 0){//自己是子类
    					CustomCategoryModel parentCustomCategoryModel = this.getById(parentCustomCategoryId);
    					categoryRelation.setCustomCategoryId(parentCustomCategoryModel.getCustomCategoryId());
    					CategoryRelation parentRelation = this.getRelationBySpidAndCustomCategory(categoryRelation.getCustomCategoryId(),categoryRelation.getSpId());
    					if(parentRelation != null){
    						//返回参数
    						returnCategoryRelation = parentRelation;
    					}else{
    						//查找大分类是否保存了关系
    						CategoryRelation infosByDicValueAndCustomId = categoryRelationMapper.getRelationBySpidAndCategory(categoryRelation.getCategoryDicValue(),categoryRelation.getSpId());
    						if(infosByDicValueAndCustomId != null){
    							//返回参数
    							returnCategoryRelation = infosByDicValueAndCustomId;
    						}else{
    							//没有数据
    							return null;
    						}
    					}
    				}else{//自己是父类
    					categoryRelation.setCustomCategoryId(customCategoryModel.getCustomCategoryId());
    					CategoryRelation parentRelation2 = this.getRelationBySpidAndCustomCategory(categoryRelation.getCustomCategoryId(),categoryRelation.getSpId());
    					if(parentRelation2 != null){
    						//返回数据
    						returnCategoryRelation = parentRelation2;
    					}else{
    						//查找大分类是否保存了关系
    						CategoryRelation infosByDicValueAndCustomId2 = categoryRelationMapper.getRelationBySpidAndCategory(categoryRelation.getCategoryDicValue(),categoryRelation.getSpId());
    						if(infosByDicValueAndCustomId2 != null){
    							//返回参数
    							returnCategoryRelation = infosByDicValueAndCustomId2;
    						}else{
    							//没有数据
    							return null;
    						}
    					}
    				}
    			}
    		}
    	}else{
    		//查找大分类是否保存了关系
			CategoryRelation infosByDicValueAndCustomId3 = categoryRelationMapper.getRelationBySpidAndCategory(categoryRelation.getCategoryDicValue(),categoryRelation.getSpId());
			if(infosByDicValueAndCustomId3 != null){
				//返回参数
				returnCategoryRelation = infosByDicValueAndCustomId3;
			}else{
				//没有数据
				return null;
			}
    	}
		return returnCategoryRelation;
    }
    
    
}
