package com.cnlive.mam.mapper;

import com.cnlive.mam.model.SpExpModel;

import java.util.List;

/**
 * Created by zhangxiaobin on 2017/8/15.
 */
public interface SpExpMapper {

    void insert(SpExpModel model);

    void update(SpExpModel model);

    SpExpModel selectById(Long id);

    List<SpExpModel> selectBySpId(Long spId);

}
