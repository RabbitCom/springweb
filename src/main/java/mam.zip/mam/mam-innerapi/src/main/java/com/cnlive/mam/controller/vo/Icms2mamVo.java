package com.cnlive.mam.controller.vo;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.VideoModel;

/**
 * Created by zhangxiaobin on 2017/5/22.
 */

/**
 * 参数按照接口文档上的参数定义 接口文档地址 ：
 * http://zhishi.cnlive.com/pages/viewpage.action?pageId=364294
 */
public class Icms2mamVo {

    private String videoUUID;// 视频唯一标识

    private String videoName;// 视频名称

    private String videoTag;// 视频标签

    private String videoDes;// 视频简介

    private Integer category;// 分类，默认为100026（其他）

    private Long duration;// 时长

    private JSONObject imgInfos;// 四种比例

    private String showUrl;// ICMS内容展示地址

    private Long spid;

    private Long customId;

    private JSONArray playInfos;// 视频播放地址信息

    private String subTitle;// 副标题

    private Integer episode;// 当前集数

    private String imgUrl;// 图片地址，取最大的一张	接收图片以后更新视频表的 picFinishedImg 属性；

    private Long fileSize;// 文件大小

    private Integer codeRate;// 码率

    private String gfmt;// 格式

    private String originUri;// 原视频地址，外网地址	更新file表中的 originUri 属性

    private String resOrigin;//  更新file表中的 resOrigin 属性

    private String sizeOrigin;// 更新file表中的 sizeOrigin 属性

    private String vbrOrigin;// 原视频码流 更新file表中的 vbrOrigin;属性

    private String ratioOrigin;// 原视频比例	更新file表中的 ratioOrigin 属性

    private String createTime;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getVideoUUID() {
        return videoUUID;
    }

    public void setVideoUUID(String videoUUID) {
        this.videoUUID = videoUUID;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getVideoTag() {
        return videoTag;
    }

    public void setVideoTag(String videoTag) {
        this.videoTag = videoTag;
    }

    public String getVideoDes() {
        return videoDes;
    }

    public void setVideoDes(String videoDes) {
        this.videoDes = videoDes;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public JSONObject getImgInfos() {
        return imgInfos;
    }

    public void setImgInfos(JSONObject imgInfos) {
        this.imgInfos = imgInfos;
    }

    public String getShowUrl() {
        return showUrl;
    }

    public void setShowUrl(String showUrl) {
        this.showUrl = showUrl;
    }

    public Long getSpid() {
        return spid;
    }

    public void setSpid(Long spid) {
        this.spid = spid;
    }

    public Long getCustomId() {
        return customId;
    }

    public void setCustomId(Long customId) {
        this.customId = customId;
    }

    public JSONArray getPlayInfos() {
        return playInfos;
    }

    public void setPlayInfos(JSONArray playInfos) {
        this.playInfos = playInfos;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public Integer getEpisode() {
        return episode;
    }

    public void setEpisode(Integer episode) {
        this.episode = episode;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getOriginUri() {
        return originUri;
    }

    public void setOriginUri(String originUri) {
        this.originUri = originUri;
    }

    public String getResOrigin() {
        return resOrigin;
    }

    public void setResOrigin(String resOrigin) {
        this.resOrigin = resOrigin;
    }

    public String getSizeOrigin() {
        return sizeOrigin;
    }

    public void setSizeOrigin(String sizeOrigin) {
        this.sizeOrigin = sizeOrigin;
    }

    public String getVbrOrigin() {
        return vbrOrigin;
    }

    public void setVbrOrigin(String vbrOrigin) {
        this.vbrOrigin = vbrOrigin;
    }

    public String getRatioOrigin() {
        return ratioOrigin;
    }

    public void setRatioOrigin(String ratioOrigin) {
        this.ratioOrigin = ratioOrigin;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public Integer getCodeRate() {
        return codeRate;
    }

    public void setCodeRate(Integer codeRate) {
        this.codeRate = codeRate;
    }

    public String getGfmt() {
        return gfmt;
    }

    public void setGfmt(String gfmt) {
        this.gfmt = gfmt;
    }

    @Override
    public String toString() {
        return "Icms2mamVo{" +
                "videoUUID='" + videoUUID + '\'' +
                ", videoName='" + videoName + '\'' +
                ", videoTag='" + videoTag + '\'' +
                ", videoDes='" + videoDes + '\'' +
                ", category=" + category +
                ", duration=" + duration +
                ", imgInfos=" + imgInfos +
                ", showUrl='" + showUrl + '\'' +
                ", spid=" + spid +
                ", customId=" + customId +
                ", playInfos=" + playInfos +
                ", subTitle='" + subTitle + '\'' +
                ", episode=" + episode +
                ", imgUrl='" + imgUrl + '\'' +
                ", originUri='" + originUri + '\'' +
                ", resOrigin='" + resOrigin + '\'' +
                ", sizeOrigin='" + sizeOrigin + '\'' +
                ", vbrOrigin='" + vbrOrigin + '\'' +
                ", ratioOrigin='" + ratioOrigin + '\'' +
                ", createTime='" + createTime + '\'' +
                '}';
    }

    public Icms2mamVo() {
        super();
    }

    public Icms2mamVo(String videoUUID, String videoName, String videoTag, String videoDes, Integer category,
                      Long duration, JSONObject imgInfos, String showUrl, Long spid, Long customId, JSONArray playInfos,
                      String subTitle, Integer episode) {
        super();
        this.videoUUID = videoUUID;
        this.videoName = videoName;
        this.videoTag = videoTag;
        this.videoDes = videoDes;
        this.category = category;
        this.duration = duration;
        this.imgInfos = imgInfos;
        this.showUrl = showUrl;
        this.spid = spid;
        this.customId = customId;
        this.playInfos = playInfos;
        this.subTitle = subTitle;
        this.episode = episode;
    }

    /**
     * Icms2mamVo转videoModel
     *
     * @param vo
     * @return VideoModel
     */
    public VideoModel Icms2mamVoToVideoModel() {
        VideoModel videoModel = new VideoModel();
        videoModel.setBusinessUUID(this.getVideoUUID());
        videoModel.setVideoName(this.getVideoName());
        videoModel.setTag(this.getVideoTag());
        videoModel.setSynopsis(this.getVideoDes());
        videoModel.setCategory(this.getCategory());
        videoModel.setDuration(this.getDuration());
//        videoModel.setPicFinishedImg(this.getImgInfos().toJSONString());
        videoModel.setVideoPlyUrl(this.getShowUrl());
        videoModel.setSpid(this.getSpid());
        videoModel.setCustomId(this.getCustomId());
        videoModel.setSubTitle(this.getSubTitle());
        videoModel.setEpisode(this.getEpisode());
        return videoModel;
    }

    /**
     * Icms2mamVo转videoModel
     *
     * @param vo
     * @return VideoModel
     */
    public List<FileModel> Icms2mamVoToFileModel() {
        JSONArray playInfos = this.getPlayInfos();
        List<FileModel> list = new ArrayList<>();
        for (Object object : playInfos) {
            JSONObject jo = (JSONObject) object;
            FileModel fileModel = JSONObject.toJavaObject(jo, FileModel.class);
            list.add(fileModel);
        }
        return list;
    }

}
