package com.cnlive.mam.controller.vo;

public class TransCodeItem {
	
	private String f; //格式
	private Integer vbr; //码率
	private String res; //分辨率
	private String uuid; //媒体id
	private String code; // 状态码 0:初始化 2：进行中 3:成功 4：失败
	private String key; //外网播放地址
	private String rateMark; //码率标识 1：流畅 2：标清 3：高清 4：超清
	private String errorCode;//错误编码
	private String errorMsg;//错误描述
//	private Long duration; //时长
	
//	public Long getDuration() {
//		return duration;
//	}
//	public void setDuration(Long duration) {
//		this.duration = duration;
//	}
	public String getF() {
		return f;
	}
	public void setF(String f) {
		this.f = f;
	}
	public Integer getVbr() {
		return vbr;
	}
	public void setVbr(Integer vbr) {
		this.vbr = vbr;
	}
	public String getRes() {
		return res;
	}
	public void setRes(String res) {
		this.res = res;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getRateMark() {
		return rateMark;
	}
	public void setRateMark(String rateMark) {
		this.rateMark = rateMark;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
