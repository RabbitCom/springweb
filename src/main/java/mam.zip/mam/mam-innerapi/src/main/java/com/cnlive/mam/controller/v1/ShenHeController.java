package com.cnlive.mam.controller.v1;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.cnlive.mam.common.enums.FileStatus;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.enums.VideoAuditStatus;
import com.cnlive.mam.common.utils.CodecUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.VideoAuditCondition;
import com.cnlive.mam.model.VideoAuditModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.VideoAuditService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.ShenHeMessageVo;
import com.google.common.base.Splitter;

@RequestMapping("/v1/inner/ShenHeInfo")
@Controller
public class ShenHeController {
	
	private static Logger _log = LoggerFactory.getLogger(ShenHeController.class);
	
	@Resource(name = "videoService")
    private VideoService videoService;
	
	@Resource(name = "videoAuditService")
    private VideoAuditService videoAuditService;
	
	
    /**
     * 
     * @Description:审核回调接口
     */
    @RequestMapping(value = "/shenheNotify", method = {RequestMethod.POST})
    @ResponseBody
	@SignCheck(value = {SignType.TRUSTSYS}, supportPlatform = {SignPlatform.AUDIT})
    public JsonResult shenheNotify(String param){
    	if(StringUtils.isBlank(param)){
			return JsonResult.createErrorInstance("参数为空");
		}
		_log.info("审核回调信息notifyMessage++++++++++++++++++++++++++++++："+param);
		ShenHeMessageVo shenHeMessageVo = JSONObject.parseObject(param, ShenHeMessageVo.class);
    	Integer state = shenHeMessageVo.getState();
    	ModelStatus videoStatus = null;
    	if(3 == state){
    		videoStatus = ModelStatus.AuditSuccess;
    	}
    	if(4 == state){
    		videoStatus = ModelStatus.AuditFail;
    	}
    	if(videoStatus == null){
    		_log.error("审核云返回 state 参数异常，state={}：",state);
    		return JsonResult.createErrorInstance(" state 参数异常");
    	}
    	
    	String businessUUID = Splitter.on(Const.XIA_HUA_XIAN).splitToList(shenHeMessageVo.getVideo_id()).get(1);
    	VideoModel video = videoService.getByBusinessUUID(businessUUID);
    	if(video == null){
    		_log.error("审核回调接口通过 bussinessId 未找到相关视频，bussinessUUID={}",businessUUID);
    		return JsonResult.createErrorInstance("视频不存在");
    	}

		this.saveVideoAudit(shenHeMessageVo,video);
		updateVideoStatus(video.getVideoId(),video.getCustomId(), videoStatus,video.getFileStatus());
		return JsonResult.createSuccessInstance("success");
	}
    
    
    private void updateVideoStatus(Long videoId,Long customId,ModelStatus videoStatus,FileStatus fileStatus){
    	_log.info("审核回调更新视频信息begin");
    	VideoModel update = new VideoModel();
    	update.setVideoId(videoId);
    	update.setUpdateTime(new Date());
    	update.setStatus(videoStatus);
    	update.setCustomId(customId);
    	update.setFileStatus(fileStatus);
    	videoService.modify(update);
		_log.info("审核回调更新视频信息end");
    }
    
    private void saveVideoAudit(ShenHeMessageVo shenHeMessageVo,VideoModel video){
    	_log.info("保存审核日志begin");
    	try{
			VideoAuditModel videoAuditModel = new VideoAuditModel();

			VideoAuditCondition condition = new VideoAuditCondition();
			condition.setVideoId(video.getVideoId());
			List<VideoAuditModel> videoAuditInfo = videoAuditService.getVideoAuditInfoByCondition(condition);

			String auditMessage = StringEscapeUtils.unescapeJava(shenHeMessageVo.getAttr_tags())+Const.VALUE_DECOLLATOR+StringEscapeUtils.unescapeJava(shenHeMessageVo.getMsg());

			if(videoAuditInfo.size() > 0){//修改
				videoAuditModel = videoAuditInfo.get(0);
				videoAuditModel.setAuditTime(new Date());
				videoAuditModel.setAuditMessage(auditMessage);
				Integer state = shenHeMessageVo.getState();
				videoAuditModel.setAuditTime(new Date());
				if(3 == state){
					videoAuditModel.setVideoStatus(VideoAuditStatus.AuditPass);
				}
				if(4 == state){
					videoAuditModel.setVideoStatus(VideoAuditStatus.AuditNoPass);
				}
				videoAuditService.update(videoAuditModel);
			}else{//添加
				videoAuditModel.setVideoId(video.getVideoId());
				videoAuditModel.setVideoName(video.getVideoName());
				videoAuditModel.setCustomId(video.getCustomId());
				videoAuditModel.setAuditMessage(auditMessage);
				Integer state = shenHeMessageVo.getState();
				videoAuditModel.setAuditTime(new Date());
				if(3 == state){
					videoAuditModel.setVideoStatus(VideoAuditStatus.AuditPass);
				}
				if(4 == state){
					videoAuditModel.setVideoStatus(VideoAuditStatus.AuditNoPass);
				}
				videoAuditService.create(videoAuditModel);
			}
		}catch (Exception ex){
			_log.info("保存审核日志error，{}",ex);
		}
		_log.info("保存审核日志end");
    }

}
