package com.cnlive.mam.controller.v1;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.model.*;
import com.cnlive.mam.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.common.enums.TransCodeCallStatus;
import com.cnlive.mam.common.enums.TransCodeType;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.controller.vo.TransCodeCallVo;
import com.cnlive.mam.controller.vo.TransCodeItem;
import com.google.common.collect.ImmutableMap;

@RequestMapping("/v1/inner/transInfo")
@Controller
public class TransCodeController {
	
	private static Logger _log = LoggerFactory.getLogger(TransCodeController.class);
	
	@Resource(name = "transcodeTaskService")
	private TranscodeTaskService transcodeTaskService;

	@Resource(name = "transcodeHistoryService")
	private TranscodeHistoryService transcodeHistoryService;
	
    @Resource(name = "fileService")
    private FileService fileService;
    
    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "customSpInfoService")
    private CustomSpInfoService customSpInfoService;
    
    
	/**
     * 转码完成以后回调接口
     */
    @RequestMapping(value = "transCodeCall",method=RequestMethod.POST)
    @ResponseBody
    @SignCheck(value = {SignType.TRUSTSYS}, supportPlatform = {SignPlatform.TRANSCODE})
    public Map<String,Integer> transCodeCall(@RequestBody TransCodeCallVo transCodeCallVo , HttpServletRequest request, HttpServletResponse response){
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        _log.info("转码系统回调参数.....{}", JSON.toJSON(transCodeCallVo).toString());

        try{
        	boolean result = false;
        	String type =transCodeCallVo.getType();
        	if(TransCodeType.avinfo.getStrValue().equals(type)){
				_log.info("进入avinfo几路码率....");
				result = avinfo(transCodeCallVo);
        	}
        	
        	if(TransCodeType.avop.getStrValue().equals(type)){
				_log.info("进入avop转码....");
				result = avop(transCodeCallVo);
        	}

        	if(TransCodeType.avsample.getStrValue().equals(type)){
				_log.info("进入avsample抽帧....");
				result = avsample(transCodeCallVo);
			}
        	return result ? ImmutableMap.of("code",1):  ImmutableMap.of("code",-1);
        }catch(Exception ex){
        	_log.error("transCodeCall error ,msg = {}",ex.getMessage());
			return ImmutableMap.of("code",-1);
        }
    }
    
    /**
     * 几路码率的信息
     */
    private boolean avinfo(TransCodeCallVo transCodeCallVo) {
    	try{
			if(TransCodeCallStatus.SUCCESS.getValue() != transCodeCallVo.getCode()){//成功转码完成
				List<FileModel> fileModels= fileService.getByTaskId(transCodeCallVo.getTaskId());

				JSONObject formatJsonObj = transCodeCallVo.getFormat();
				Long durationOrigin = formatJsonObj.getLongValue("duration");
				String raioOrigin = formatJsonObj.getString("display_aspect_ratio");
				String resOrigin = formatJsonObj.getString("res");
				String sizeOrigin = formatJsonObj.getString("size");
				String vbrOrigin = formatJsonObj.getString("vbr");

				if(fileModels.size() >0 ){
					if(transCodeCallVo.getItems().size()>0){
						for(TransCodeItem item : transCodeCallVo.getItems()){
	                        FileModel codeRateFile = 
	                        		fileService.getByTaskIdAndTransCodeFmtAndCodeRate(transCodeCallVo.getTaskId(),item.getF(),item.getVbr());
	                        if(codeRateFile != null){
	                        	codeRateFile.setMuuid(item.getUuid());
	                        	codeRateFile.setStoreUri(item.getKey());
	                        	codeRateFile.setRes(item.getRes());
	                        	codeRateFile.setDuration(durationOrigin*1000);
	                        	codeRateFile.setStatus(FileStatus.TranscodingIng);
	                        	codeRateFile.setRatioOrigin(raioOrigin);
								codeRateFile.setResOrigin(resOrigin);
								codeRateFile.setSizeOrigin(sizeOrigin);
								codeRateFile.setVbrOrigin(vbrOrigin);
	                        	fileService.modify(codeRateFile);
	                        }
						}
					}
				}
			}
			return true;
		}catch(Exception ex){
			_log.error("视频几路码率回调异常，参数信息：{},错误信息{}",JSON.toJSONString(transCodeCallVo),ex);
			return false;
		}

	}
    
    /**
     * 转码完成的信息
     */
    @Transactional
    private boolean avop(TransCodeCallVo transCodeCallVo){
    	try{
    		String taskId = transCodeCallVo.getTaskId();
    		TranscodeTaskModel task = transcodeTaskService.findByFileTaskId(taskId);
    		List<FileModel> files = fileService.getByTaskId(taskId);
    		if (TransCodeCallStatus.SUCCESS.getValue() == transCodeCallVo.getCode() && files.size() > 0) {//成功转码完成
    			//转码过程中，每转码完成一种码率，会生成对应的文件，就会调用一次该方法。
    			if(transCodeCallVo.getDetail() != null) {
					updateFileStatus(files,transCodeCallVo.getDetail().getUuid(),FileStatus.TranscodingSuccess);
					createTaskHistory(task,files,transCodeCallVo.getDetail().getUuid(),Const.TRANSCODEHISTORY_SUCCESS);
    			//全部转码完成后，回调的参数中，没有detail。
    			}else {
    				VideoModel videoModel = videoService.getById(files.get(0).getVideoId());
    				//避免重复回调已经转码完成的数据
    				if(videoModel.getFileStatus().getDbValue() != FileStatus.TranscodingSuccess.getDbValue()){
    					FileStatus fileStatus = videoService.transcodeSuccessCheck(videoModel.getVideoId());
    					VideoModel update = new VideoModel();
						update.setVideoId(videoModel.getVideoId());
						update.setFileStatus(fileStatus);
						update.setDuration(files.get(0).getDuration());
						update.setUpdateTime(new Date());
						update.setCustomId(videoModel.getCustomId());
    					videoService.modify(update);
    				}
    				transcodeTaskService.delete(task);
    			}
    		}
    		//转码失败，更新视频、文件信息
    		if (TransCodeCallStatus.ERROR.getValue() == transCodeCallVo.getCode() && files.size() > 0) {//转码失败
				//
				if(transCodeCallVo.getDetail() != null) {
					updateFileStatus(files,transCodeCallVo.getDetail().getUuid(),FileStatus.TranscodingFail);
					this.createTaskHistory(task,files,transCodeCallVo.getDetail().getUuid(),Const.TRANSCODEHISTORY_FAIL,
							transCodeCallVo.getDetail().getErrorCode(),transCodeCallVo.getDetail().getErrorMsg());
				}else {
					Long videoId = files.size() > 0 ? files.get(0).getVideoId() : 0L;
					VideoModel videoModel = videoService.getById(videoId);
					FileStatus fileStatus = videoService.transcodeSuccessCheck(videoId);
					VideoModel update = new VideoModel();
					update.setFileStatus(fileStatus);
					update.setVideoId(videoModel.getVideoId());
					update.setUpdateTime(new Date());
					update.setCustomId(videoModel.getCustomId());
					videoService.modify(update);
					transcodeTaskService.delete(task);
				}
    		}
    		return true;
    	}catch(Exception ex){
    		_log.error("转码回调异常，参数信息：{},错误信息{}",JSON.toJSONString(transCodeCallVo),ex);
			return false;
    	}
    }

    private void updateFileStatus(List<FileModel> files,String uuid,FileStatus status){
    	for (FileModel file : files) {
			if (uuid.equals(file.getMuuid())) {
				file.setStatus(status);
				file.setUpdateTime(new Date());
				file.setTranscodeEtime(new Date());
				fileService.modify(file);
				
			}
		}
	}
    
    /**
     * 
      * 转码成功，将转码任务保存至转码历史记录表中，清除任务表中对应的数据
      * @param task 任务
      * @param files 文件
      * @param uuid
      * @param transCodeStatus 转码状态 
      * @author  wangchaojie　2017年4月5日
      *
     */
    private void createTaskHistory(TranscodeTaskModel task, List<FileModel> files, String uuid, Integer transCodeStatus){
    	for (FileModel file : files) {
			if (uuid.equals(file.getMuuid()) && task != null) {
				TranscodeHistoryModel history = new TranscodeHistoryModel(task.getVideoId(),task.getCustomId(),
						transCodeStatus,file.getFileId(),task.getFileTaskId());
				transcodeHistoryService.create(history);
			}
		}
    }
    
    /**
     * 
      * 转码失败，将转码任务保存至转码历史记录表中，清除任务表中对应的数据
      * @param task 任务
      * @param files 文件
      * @param uuid 
      * @param transCodeStatus 转码状态
      * @param errorCode 错误编号
      * @param errorMsg 错误描述
      * @author  wangchaojie　2017年4月5日
      *
     */
    private void createTaskHistory(TranscodeTaskModel task, List<FileModel> files, String uuid, Integer transCodeStatus,
    		String errorCode, String errorMsg){
    	boolean updateFlag=false;
    	for (FileModel file : files) {
			if (uuid.equals(file.getMuuid()) && task != null) {
				TranscodeHistoryModel history = new TranscodeHistoryModel(task.getVideoId(),task.getCustomId(),
						transCodeStatus,file.getFileId(),task.getFileTaskId());
				history.setErrorCode(errorCode);
				history.setErrorMsg(errorMsg);
				transcodeHistoryService.create(history);
			}
			if(DefinitionEnum.SD.getDefinitionId().intValue() == file.getCodeRate()){
				updateFlag = true;
			}
		}
		if(updateFlag){
    		VideoModel updateVideo = new VideoModel();
    		updateVideo.setVideoId(task.getVideoId());
    		updateVideo.setUpdateTime(new Date());
    		updateVideo.setFileStatus(FileStatus.TranscodingFail);
    		videoService.save(updateVideo);
		}
    }

    /**
	 * 采样截图
	 * @param transCodeCallVo
	 */
	private boolean avsample(TransCodeCallVo transCodeCallVo){
		try{
			if(TransCodeCallStatus.ERROR.getValue() != transCodeCallVo.getCode()){//抽帧成功
				VideoModel videoModel = videoService.getbyChouZhenTaskId(transCodeCallVo.getTaskId());
				if(videoModel != null){

//					CustomSpInfoModel spInfoModel = customSpInfoService.getBySpId(videoModel.getSpid());
//					String imgDomain  = spInfoModel.getImgDomain();

//					String imgUrl = imgDomain +Const.SEPARATE_XIE + picOrigin.substring(0, picOrigin.lastIndexOf(Const.SEPARATE_XIE) + 1);
					String picOrigin = transCodeCallVo.getImages().get(0).toString();
					String imgUrl = picOrigin.substring(0, picOrigin.lastIndexOf(Const.SEPARATE_XIE) + 1);
					VideoModel update = new VideoModel();
					update.setVideoId(videoModel.getVideoId());
					update.setUpdateTime(new Date());
					update.setChouzhenEtime(new Date());
					update.setPicOriginal(imgUrl);
					update.setCustomId(videoModel.getCustomId());
					videoService.save(update);
					return true;
				}else {
					_log.error("视频抽帧回调返回，通过任务id未找到相关视频，taskId={}",transCodeCallVo.getTaskId());
					return false;
				}
			}
			return false;
		}catch(Exception ex){
			_log.error("视频抽帧回调异常，参数信息：{},错误信息{}",JSON.toJSONString(transCodeCallVo),ex);
			return false;
		}
    }

}
