package com.cnlive.mam.controller.v1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin on 2017/8/15.
 */
public class BaseController {

    protected Map<String,Object> createSucessMap(Object obj){
        Map<String,Object> sucessMap = new HashMap();
        sucessMap.put("errorMessage","请求成功");
        sucessMap.put("errorCode",0);
        sucessMap.put("data",obj);
        return sucessMap;
    }

    protected Map<String,Object> createFailMap(String errMsg,Object obj){
        Map<String,Object> failMap = new HashMap();
        failMap.put("errorMessage",errMsg);
        failMap.put("errorCode",-1);
        failMap.put("data",obj);
        return failMap;
    }

}
