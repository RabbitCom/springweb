package com.cnlive.mam.filter;

import org.apache.http.HttpStatus;
import org.jboss.netty.handler.codec.http.HttpMethod;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by zhangxiaobin on 2017/8/23.
 */
@Component
public class CORSFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse res = (HttpServletResponse)response;
        String reqMethod = req.getMethod();

        /**
         * Access-Control-Allow-Origin 允许的域名
         * Access-Control-Allow-Credentials  是否允许cookie
         * Access-Control-Allow-Methods CORS请求会用到哪些HTTP方法
         * Content-Type 取值 ： application/json  非简单请求
         */
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
        res.setHeader("Content-Type", "application/json;charset=utf-8");

        if(HttpMethod.OPTIONS.getName().equals(reqMethod)){
            res.setStatus(HttpStatus.SC_OK);
        }
        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {

    }
}
