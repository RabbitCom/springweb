package com.cnlive.mam.controller.v1;

import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.common.utils.HttpClientUtils;
import com.cnlive.mam.common.utils.MD5Util;
import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.cnlive.mam.vo.UnrealLiveResult;
import com.cnlive.mam.vo.UnrealLiveVo;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RequestMapping("/v1/inner/liveFalse")
@Controller
/**
 * 假直播controller
 *
 * @author 姜名
 *
 */
public class LiveFalseController {

    private static Logger _log = LoggerFactory.getLogger(LiveFalseController.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "dictionaryService")
    private DictionaryService dictionaryService;

    @Resource(name = "storageService")
    private StorageService storageService;

    @Value("#{configProperties['liveCloud_treeUrl']}")
    private String liveCloud_treeUrl;
    @Value("#{configProperties['liveCloud_programList']}")
    private String liveCloud_programList;
    @Value("#{configProperties['liveCloud_programListByKeyword']}")
    private String liveCloud_programListByKeyword;

    /**
     * 获取列表树
     *
     * @param request
     * @param unrealLiveVo
     * @return
     */
    @RequestMapping(value = "/getMaterialCategoryTree", method = {RequestMethod.POST})
    @ResponseBody
    public UnrealLiveResult getMaterialCategoryTree(HttpServletRequest request, UnrealLiveVo unrealLiveVo) {
        UnrealLiveResult result = new UnrealLiveResult();
        String sign = unrealLiveVo.getSign();
        String platform = unrealLiveVo.getPlatform();
        Long spId = unrealLiveVo.getSpId();
        _log.info("getMaterialCategoryTree_api parameter: sign={},platform={}", sign, platform);
        if (checkSign(request, sign, platform)) {
            if ("LIVECOULD".equals(platform)) {//是否请求直播云内容
                Map<String, String> map = new HashedMap();
                map.put("spId", String.valueOf(spId));
                String resultJson = HttpClientUtils.post(liveCloud_treeUrl, map, 5000);
                if ("".equals(resultJson)) {
                    result.setDone("请求直播云出错");
                    return result;
                } else {
                    JSONObject parseObject = JSONObject.parseObject(resultJson);
                    String errorCode = parseObject.getString("errorCode");
                    if ("0".equals(errorCode)) {
                        String data = parseObject.getString("data");
                        JSONObject dataObject = JSONObject.parseObject(data);
                        String columnTree = dataObject.getString("columnTree");
                        List list = JSONObject.parseArray(columnTree);
                        result.setList(list);
                    } else {
                        result.setDone(parseObject.getString("errorMessage"));
                    }
                    return result;
                }
            }
            List<Dictionary> list = dictionaryService.getCategorys();
            List<Map<String, Object>> categoryTree = new ArrayList<>();
            for (Dictionary dictionary : list) {
                Map<String, Object> map = new HashMap<>();
                map.put("id", dictionary.getDicValue());
                map.put("label", dictionary.getShowName());
                map.put("pId", "");
                categoryTree.add(map);
            }
            result.setList(categoryTree);
        } else {
            result.setDone("校验加密参数错误");
        }
        return result;
    }

    /**
     * 获取假直播内容
     *
     * @param request
     * @param unrealLiveVo
     * @return
     */
    @RequestMapping(value = "/getProgramList", method = {RequestMethod.POST})
    @ResponseBody
    public UnrealLiveResult getProgramList(HttpServletRequest request, UnrealLiveVo unrealLiveVo) {
        UnrealLiveResult result = new UnrealLiveResult();
        Long spId = unrealLiveVo.getSpId();
        if (spId == null) {
            result.setDone("spId不能为空");
            return result;
        }

        List<StorageModel> storages = storageService.getStorageEnableBySpid(spId);
        boolean isKsYun = true;
        for(StorageModel storageModel : storages){
            if(!(StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue())){
                isKsYun = false;
                break;
            }
        }

        if (!isKsYun) {
            result.setList(null);
            result.setTotal(0);
            return result;
        }

        StorageModel outStorageBySpId = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Media);
        String bucketName = outStorageBySpId.getName();

        Long id = unrealLiveVo.getId();
        Integer page = unrealLiveVo.getPage();
        if (page == null) {
            page = 1;
        }
        Integer pageNumber = unrealLiveVo.getPageNumber();
        if (pageNumber == null) {
            pageNumber = 50;
        }
        String sign = unrealLiveVo.getSign();
        String platform = unrealLiveVo.getPlatform();
        _log.info("getProgramList_api parameter: spId={},id={},page={},pageNumber={}", spId, id, page, pageNumber);
        _log.info("getProgramList_api parameter: sign={},platform={}", sign, platform);
        if (checkSign(request, sign, platform)) {
            if ("LIVECOULD".equals(platform)) {//是否请求直播云内容
                Map<String, String> map = new HashedMap();
                map.put("id", String.valueOf(id));
                map.put("spId", String.valueOf(spId));
                map.put("page", String.valueOf(page));
                map.put("pageNumber", String.valueOf(pageNumber));
                String resultJson = HttpClientUtils.post(liveCloud_programList, map, 5000);
                if ("".equals(resultJson)) {
                    result.setDone("请求直播云出错");
                    return result;
                }
                JSONObject parseObject = JSONObject.parseObject(resultJson);
                String errorCode = parseObject.getString("errorCode");
                if ("0".equals(errorCode)) {
                    String data = parseObject.getString("data");
                    JSONObject dataObject = JSONObject.parseObject(data);
                    String programList = dataObject.getString("list");
                    Integer total = dataObject.getInteger("total");
                    List list = JSONObject.parseArray(programList);
                    result.setList(list);
                    result.setTotal(total);
                } else {
                    result.setDone(parseObject.getString("errorMessage"));
                }
                return result;
            }
            SuperSpCondition condition = new SuperSpCondition();
            condition.setPage(page);
            condition.setRows(pageNumber);
            condition.setSpId(spId);
            condition.setCategory(id);
            condition.setOnoffStatusArray(new String[]{"5", "8"}); //上线|发布成功
            condition.setFileStatus(2); //转码成功
            condition.setIsIcms2MamForLiveFalse(0); //过滤掉老数据
            DataGrid dataGrid = videoService.getPageByCondition(condition);
            Long videoCount = dataGrid.getTotal();
            List<Map<String, Object>> list = new ArrayList<>();
            if (videoCount > 0) {

                List<VideoModel> videoModels = dataGrid.getRows();
                list = getResultList(list, videoModels, bucketName);
            }
            result.setList(list);
            result.setTotal(list.size());
        } else {
            result.setDone("校验加密参数错误");
        }
        return result;
    }

    /**
     * 关键字搜索假直播内容
     *
     * @param request
     * @param unrealLiveVo
     * @return
     */
    @RequestMapping(value = "/getProgramListByKeyword", method = {RequestMethod.POST})
    @ResponseBody
    public UnrealLiveResult getProgramListByKeyword(HttpServletRequest request, UnrealLiveVo unrealLiveVo) {
        UnrealLiveResult result = new UnrealLiveResult();
        Long spId = unrealLiveVo.getSpId();
        if (spId == null) {
            result.setDone("spId不能为空");
            return result;
        }

        List<StorageModel> storages = storageService.getStorageEnableBySpid(spId);
        boolean isKsYun = true;
        for(StorageModel storageModel : storages){
            if(!(StorageTypeEnum.KSYUN.getDbValue() == storageModel.getType().getDbValue())){
                isKsYun = false;
                break;
            }
        }

        if (!isKsYun) {
            result.setList(null);
            result.setTotal(0);
            return result;
        }

        StorageModel outStorageBySpId = storageService.getStorageOutBySpId(spId, StorageContentTypeEnum.Media);
        String bucketName = outStorageBySpId.getName();

        Integer page = unrealLiveVo.getPage();
        if (page == null) {
            page = 1;
        }
        Integer pageNumber = unrealLiveVo.getPageNumber();
        if (pageNumber == null) {
            pageNumber = 50;
        }
        String keyWord = unrealLiveVo.getKeyWord();
        String sign = unrealLiveVo.getSign();
        String platform = unrealLiveVo.getPlatform();
        _log.info("getProgramListByKeyword_api parameter: spId={},keyword={},page={},pageNumber={}", spId, keyWord, page, pageNumber);
        _log.info("getProgramListByKeyword_api parameter: sign={},platform={}", sign, platform);
        if (checkSign(request, sign, platform)) {
            if ("LIVECOULD".equals(platform)) {//是否请求直播云内容
                Map<String, String> map = new HashedMap();
                map.put("keyWord", keyWord);
                map.put("page", String.valueOf(page));
                map.put("pageNumber", String.valueOf(pageNumber));
                map.put("spId", String.valueOf(spId));
                String resultJson = HttpClientUtils.post(liveCloud_programListByKeyword, map, 5000);
                if ("".equals(resultJson)) {
                    result.setDone("请求直播云出错");
                    return result;
                }
                JSONObject parseObject = JSONObject.parseObject(resultJson);
                String errorCode = parseObject.getString("errorCode");
                if ("0".equals(errorCode)) {
                    String data = parseObject.getString("data");
                    JSONObject dataObject = JSONObject.parseObject(data);
                    String programList = dataObject.getString("list");
                    Integer total = dataObject.getInteger("total");
                    List list = JSONObject.parseArray(programList);
                    result.setList(list);
                    result.setTotal(total);
                } else {
                    result.setDone(parseObject.getString("errorMessage"));
                }
                return result;
            }
            SuperSpCondition condition = new SuperSpCondition();
            condition.setPage(page);
            condition.setRows(pageNumber);
            condition.setSpId(spId);
            condition.setIsIcms2MamForLiveFalse(0); //过滤数据
            List<Map<String, Object>> list = new ArrayList<>();

            if (keyWord.contains(",")) {
                String[] keyWords = keyWord.split(",");
                for (String videoName : keyWords) {
                    condition.setVideoName(videoName);
                    condition.setOnoffStatusArray(new String[]{"5", "8"}); //上线|发布成功
                    condition.setFileStatus(2); //转码成功
                    DataGrid dataGrid = videoService.getPageByCondition(condition);
                    Long videoCount = dataGrid.getTotal();
                    if (videoCount > 0) {
                        List<VideoModel> videoModels = dataGrid.getRows();
                        getResultList(list, videoModels, bucketName);
                    }
                }
                Set<Map<String, Object>> set = new HashSet<>(list);
                list.clear();
                list.addAll(set);
                result.setList(list);
                result.setTotal(list.size());
            } else {
                condition.setVideoName(keyWord);
                condition.setOnoffStatusArray(new String[]{"5", "8"}); //上线|发布成功
                condition.setFileStatus(2); //转码成功
                DataGrid dataGrid = videoService.getPageByCondition(condition);
                Long videoCount = dataGrid.getTotal();
                if (videoCount > 0) {
                    List<VideoModel> videoModels = dataGrid.getRows();
                    list = getResultList(list, videoModels, bucketName);
                }
                result.setList(list);
                result.setTotal(list.size());
            }
        } else {
            result.setDone("校验加密参数错误");
        }
        return result;
    }

    private List<Map<String, Object>> getResultList(List list, List<VideoModel> videoModels, String bucketName) {
        String path = "http://" + bucketName + ".ks3-cn-beijing-internal.ksyun.com/";
        String replacePath = "http://video-web.ks3-cn-beijing-internal.ksyun.com";
        String[] strArray = new String[]{"wideo00.cnlive.com", "wideo01.cnlive.com", "wideo02.cnlive.com", "wideo03.cnlive.com"};
        String[] splStr = new String[2];
        for (VideoModel video : videoModels) {
            Map<String, Object> map = new HashMap<>();
            Map<String, String> picMap = video.getAllPicScale();
            FileModel fileModel = fileService.getFileByVidAndCoderateAndTransCodeFmt(video.getVideoId(), Integer.valueOf(Const.SD), Const.FMT_MP4);
            map.put("id", video.getBusinessUUID());
            map.put("title", video.getVideoName());
            map.put("image", picMap.get("224*126"));
            map.put("time", video.getUpdateTime().getTime());
            String storeUri = fileModel.getStoreUri();
            if (!StringUtils.isEmpty(storeUri) && storeUri.startsWith("http://")) {
                for (String s : strArray) {
                    if (storeUri.contains(s)) {
                        splStr = storeUri.split(s, 2);
                        storeUri = replacePath + splStr[1];
                        break;
                    }
                }
            } else {
                storeUri = path + fileModel.getStoreUri();
            }
            map.put("path", storeUri != null ? storeUri : "");
            map.put("publishId", "");
            list.add(map);
        }
        return list;
    }

    private Boolean checkSign(HttpServletRequest request, String sign, String platform) {
        String requestURI = request.getRequestURI();
        SignPlatform signPlatform = SignPlatform.getInstanceByName(platform);
        if (signPlatform == null) {
            return false;
        }
        String platformkey = signPlatform.getCode();
        String md5String = requestURI + platform + platformkey;
        try {
            String md5 = MD5Util.md5(md5String);
            if (md5.equals(sign)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
