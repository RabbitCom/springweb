package com.cnlive.mam.controller.vo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.cnlive.mam.common.enums.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin on 2017/8/11.
 */
public class VideoInfo {

    // 视频ID
    private String videoId;
    // 视频名称
    private String videoName;
    // 所属根分类
    private String categoryName;
    // 所属客户分类
    private String customCategoryName;
    // 标签 使用逗号分隔
    private String tag;
    // 时长
    private Long duration;
    //副标题
    private String subTitle;
    //简介
    private String desc; // 简介
    //详细描述 富文本
    private String descDetail;
    //所属sp
    private Long spid;
    //机构名称
    private String institutionName;
    // 文件大小
    private Long showFileSize;
    //视频播放地址 [{"codeRate":800,"fmt":"hls","url":"http://xxx.m3u8"},{"codeRate":800,"fmt":"mp4","url":"http://xxx.mp4"}]
    private JSONArray playUrls;
    //视频图片信息
    private Map<String, String> imginfos ;
    //清晰度 清晰度标识，多个用逗号隔开： 流畅版=1，清晰版=2，高清版=3，超高清=4
    private String rates ;

    private String subCategorys;//影片分类

    private String videoType;//视频类型

    private String directors = "";//导演

    private String actors= "";//演员

    private String screenwriters = "";//编剧

    private String filmProduces = ""; //制片人

    private String guests = ""; //嘉宾

    private String hosts = ""; //主持人

    private String lyricss = ""; //作词

    private String composers = "";//作曲

    private String singers = "";//歌手

    private String originals = "";//原创

    private String creatives = "";//主创

    private String gamePlayers = "";//玩家

    private String master = ""; //达人

    private String lecturer = "";//讲师

    private String releaseDates; //上映日期

    private String languages;

    private String areas;

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCustomCategoryName() {
        return customCategoryName;
    }

    public void setCustomCategoryName(String customCategoryName) {
        this.customCategoryName = customCategoryName;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Long getSpid() {
        return spid;
    }

    public void setSpid(Long spid) {
        this.spid = spid;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public Long getShowFileSize() {
        return showFileSize;
    }

    public void setShowFileSize(Long showFileSize) {
        this.showFileSize = showFileSize;
    }

    public JSONArray getPlayUrls() {
        return playUrls;
    }

    public void setPlayUrls(JSONArray playUrls) {
        this.playUrls = playUrls;
    }

    public String getRates() {
        return rates;
    }

    public void setRates(String rates) {
        this.rates = rates;
    }

    public Map<String, String> getImginfos() {
        return imginfos;
    }

    public void setImginfos(Map<String, String> imginfos) {
        this.imginfos = imginfos;
    }

    public String getSubCategorys() {
        return subCategorys;
    }

    public void setSubCategorys(String subCategorys) {
        this.subCategorys = subCategorys;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getDirectors() {
        return directors;
    }

    public void setDirectors(String directors) {
        this.directors = directors;
    }

    public String getActors() {
        return actors;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }

    public String getScreenwriters() {
        return screenwriters;
    }

    public void setScreenwriters(String screenwriters) {
        this.screenwriters = screenwriters;
    }

    public String getFilmProduces() {
        return filmProduces;
    }

    public void setFilmProduces(String filmProduces) {
        this.filmProduces = filmProduces;
    }

    public String getReleaseDates() {
        return releaseDates;
    }

    public void setReleaseDates(String releaseDates) {
        this.releaseDates = releaseDates;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public String getAreas() {
        return areas;
    }

    public void setAreas(String areas) {
        this.areas = areas;
    }

    public String getGuests() {
        return guests;
    }

    public void setGuests(String guests) {
        this.guests = guests;
    }

    public String getHosts() {
        return hosts;
    }

    public void setHosts(String hosts) {
        this.hosts = hosts;
    }

    public String getLyricss() {
        return lyricss;
    }

    public void setLyricss(String lyricss) {
        this.lyricss = lyricss;
    }

    public String getComposers() {
        return composers;
    }

    public void setComposers(String composers) {
        this.composers = composers;
    }

    public String getSingers() {
        return singers;
    }

    public void setSingers(String singers) {
        this.singers = singers;
    }

    public String getOriginals() {
        return originals;
    }

    public void setOriginals(String originals) {
        this.originals = originals;
    }

    public String getCreatives() {
        return creatives;
    }

    public void setCreatives(String creatives) {
        this.creatives = creatives;
    }

    public String getGamePlayers() {
        return gamePlayers;
    }

    public void setGamePlayers(String gamePlayers) {
        this.gamePlayers = gamePlayers;
    }

    public String getMaster() {
        return master;
    }

    public void setMaster(String master) {
        this.master = master;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public String getDescDetail() {
        return descDetail;
    }

    public void setDescDetail(String descDetail) {
        this.descDetail = descDetail;
    }
}
