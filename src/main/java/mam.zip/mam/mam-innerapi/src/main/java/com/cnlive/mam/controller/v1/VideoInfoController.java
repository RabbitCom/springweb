package com.cnlive.mam.controller.v1;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.enums.ModelStatus;
import com.cnlive.mam.common.resultMessage.CnliveResultMessage;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.controller.result.ApiResult;
import com.cnlive.mam.controller.vo.VideoInfo;
import com.cnlive.mam.model.*;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.StorageService;
import com.cnlive.mam.service.VideoService;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;

/**
 * Created by zhangxiaobin on 2017/8/11.
 */
@Controller
@RequestMapping("/v1/inner/videoInfo")
public class VideoInfoController extends BaseController{

    private static Logger _log = LoggerFactory.getLogger(VideoInfoController.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "storageService")
    private StorageService storageService;

    @Resource(name = "dictionaryService")
    private DictionaryService dictionaryService;

    @RequestMapping("getSimple")
    @ResponseBody
    public ApiResult getSimple(String appId, String vId) {
        _log.info("third party plat request params : appId={},videoId={}",appId,vId);
        if(StringUtils.isEmpty(appId) || !(appId.contains(Const.XIA_HUA_XIAN))){
            return ApiResult.createInstance(CnliveResultMessage.PARAM_ERROR);
        }
        String spIdStr = Splitter.on(Const.XIA_HUA_XIAN).omitEmptyStrings().splitToList(appId).get(0);
        if(StringUtils.isEmpty(spIdStr)){
            return ApiResult.createInstance(CnliveResultMessage.PARAM_ERROR);
        }
        Long spId  = 0L;
        try{
            spId = Long.valueOf(spIdStr);
        }catch (Exception ex){
            _log.error("third party plat request  appId error ;appId={}",appId);
            return ApiResult.createInstance(CnliveResultMessage.PARAM_ERROR);
        }

        if(StringUtils.isEmpty(vId)){
            _log.error("third party plat request  vId is empty ;vId={}",vId);
            return ApiResult.createInstance(CnliveResultMessage.PARAM_ERROR);
        }
        VideoModel video = videoService.getByBusinessUUID(vId);
        if(video == null){
            return ApiResult.createInstance(CnliveResultMessage.VIDEO_NOT_EXITS);
        }
        int videoStatusVal = video.getStatus().getDbValue();
        List<Integer> statusVals = ModelStatus.getCanUsedValues();
        if(!statusVals.contains(videoStatusVal)){
            return ApiResult.createInstance(CnliveResultMessage.VIDEO_NOT_USED);
        }

        VideoInfo videoInfo = new VideoInfo();
        videoInfo.setVideoId(video.getBusinessUUID());
        videoInfo.setCategoryName(video.getCategoryName());
        videoInfo.setCustomCategoryName(video.getCustomCategoryName());
        videoInfo.setCategoryName(video.getCategoryName());
        videoInfo.setDesc(video.getSynopsis());
        videoInfo.setDuration(video.getDuration());
        videoInfo.setInstitutionName(video.getInstitutionName());
        videoInfo.setShowFileSize(video.getShowFileSize());
        videoInfo.setSubTitle(video.getSubTitle());
        videoInfo.setTag(editVal(video.getTag()));
        videoInfo.setVideoName(video.getVideoName());
        videoInfo.setImginfos(video.getAllPicScale());
        videoInfo.setSpid(spId);
        videoInfo.setDescDetail(StringUtils.isEmpty(video.getDescription()) ? "" : video.getDescription());
        createResultFile(video.getVideoId(),videoInfo);

        Integer category = video.getCategory();
        //上映年份
        if(video.getReleaseDate() != null){
            videoInfo.setReleaseDates(CalendarUtil.getFormatDateString(video.getReleaseDate(),"yyyy"));
        }
        // 视频类型
        if(video.getVideoType() != null && video.getVideoType().intValue() != 0){
            Dictionary dicinfo = dictionaryService.getDictionaryByDicValue("videoType", video.getVideoType());
            if(dicinfo != null){
                videoInfo.setVideoType(dicinfo.getShowName());
            }else {
                videoInfo.setVideoType("");
            }
        }
        //影视分类
        if(StringUtils.isNotBlank(video.getSubCategory())) {
            String subCategorys = getShowNames(video.getSubCategory(), category, "subCategory");
            videoInfo.setSubCategorys(subCategorys);
        }
        //语言
        if(StringUtils.isNotBlank(video.getLanguage())) {
            String languages = getShowNames(video.getLanguage(), category, "language");
            videoInfo.setLanguages(languages);
        }
        //地区
        if(StringUtils.isNotBlank(video.getArea())) {
            String areas = getShowNames(video.getArea(), category, "area");
            videoInfo.setAreas(areas);
        }
        //处理扩展信息
        extendPropertiesValues(video.getExtendProperties(),videoInfo,category.intValue());
        return ApiResult.createInstanceSuccess(videoInfo);
    }

    private void createResultFile(Long vid,VideoInfo videoInfo){
        List<FileModel> files = fileService.getByVid(vid);
        Long spId = videoInfo.getSpid();
        List<String> rateList = new ArrayList<>();
        String playDomain = "";
        JSONArray array = new JSONArray();
        if(files != null && files.size() > 0){
            for (FileModel file : files){
                JSONObject object = new JSONObject();
                if(StringUtils.isEmpty(playDomain)){
                    playDomain = storageService.getDomainSimpleOutByStorageId(file.getStorageTranscode());
                }
                int codeRate = file.getCodeRate().intValue();
                if(DefinitionEnum.SMOOTH.getDefinitionId().intValue() == codeRate){
                    if(!rateList.contains("1")){
                        rateList.add("1");
                    }
                    object.put("rate",1);
                }
                if(DefinitionEnum.SD.getDefinitionId().intValue() == codeRate){
                    if(!rateList.contains("2")){
                        rateList.add("2");
                    }
                    object.put("rate",2);
                }
                if(DefinitionEnum.HD.getDefinitionId().intValue() == codeRate){
                    if(!rateList.contains("3")){
                        rateList.add("3");
                    }
                    object.put("rate",3);
                }
                if(DefinitionEnum.ULTRA_HD.getDefinitionId().intValue() == codeRate){
                    if(!rateList.contains("4")){
                        rateList.add("4");
                    }
                    object.put("rate",4);
                }
                object.put("fmt",file.getTransCodeFmt());
                object.put("url",playDomain + Const.SEPARATE_XIE + file.getStoreUri());
                array.add(object);
            }
        }
        if (spId.intValue() == 3)videoInfo.setPlayUrls(array);
        videoInfo.setRates(Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(rateList).toString());
    }

    private String getShowNames(String values,Integer category,String dicWord){
        List<String> showNames = new ArrayList<>();
        Map<String, String> languageMap = dictionaryService.getDicInfo(dicWord, values, category);
        for (String key : languageMap.keySet()) {
            showNames.add(languageMap.get(key));
        }
        String s = Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(showNames).toString();
        return StringUtils.isBlank(s)?"":s;
    }

    private void extendPropertiesValues(String extendProperties,VideoInfo videoInfo,int category){
        if(StringUtils.isEmpty(extendProperties)){
            return;
        }
        Map<String, String> extendPropertiesMap = new HashMap<String, String>();
        ObjectMapper mapper = new ObjectMapper();
        try {
            extendPropertiesMap = mapper.readValue(extendProperties, Map.class);
        } catch (JsonParseException e) {
            _log.error(e.getMessage());
        } catch (JsonMappingException e) {
            _log.error(e.getMessage());
        } catch (IOException e) {
            _log.error(e.getMessage());
        }
        if(extendPropertiesMap != null) {
            if (category == Const.CHANNEL_FILM.intValue() || category == Const.CHANNEL_TV.intValue()) {
                videoInfo.setDirectors(editVal(extendPropertiesMap.get("director")));
                videoInfo.setActors(editVal(extendPropertiesMap.get("actor")));
                videoInfo.setScreenwriters(editVal(extendPropertiesMap.get("screenwriter")));
                videoInfo.setFilmProduces(editVal(extendPropertiesMap.get("filmProduce")));
            }

            if (category == Const.CHANNEL_VARIETY.intValue() || category == Const.CHANNEL_ENTERTAIN.intValue() ||
                    category == Const.CHANNEL_FASHION.intValue() || category == Const.CHANNEL_HEALTHY.intValue()) {
                videoInfo.setGuests(editVal(extendPropertiesMap.get("guest")));
            }
            if (category == Const.CHANNEL_FASHION.intValue() || category == Const.CHANNEL_HEALTHY.intValue()) {
                videoInfo.setHosts(editVal(extendPropertiesMap.get("host")));
            }
            if (category == Const.CHANNEL_SPORTS.intValue()) {
                videoInfo.setActors(editVal(extendPropertiesMap.get("actor")));
            }
            if (category == Const.CHANNEL_MUSIC.intValue()) {
                videoInfo.setLyricss(editVal(extendPropertiesMap.get("lyrics")));
                videoInfo.setComposers(editVal(extendPropertiesMap.get("composer")));
                videoInfo.setFilmProduces(editVal(extendPropertiesMap.get("filmProduce")));
                videoInfo.setDirectors(editVal(extendPropertiesMap.get("director")));
            }
        }
    }

    private String editVal(String vals){
        if(StringUtils.isBlank(vals)){
            return "";
        }
        List<String> tags = Splitter.on(Const.SEPARATE_XIE).omitEmptyStrings().splitToList(vals);
        String s = Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(tags).toString();
        return StringUtils.isEmpty(s) ? "" : s;
    }
}
