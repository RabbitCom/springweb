package com.cnlive.mam.controller.v1;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.enums.*;
import com.cnlive.mam.common.utils.CalendarUtil;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.controller.vo.Icms2mamVo;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.model.*;
import com.cnlive.mam.service.*;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Joiner;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by zhangxiaobin on 2017/5/22.
 */
@RequestMapping("/v1/inner/DataSyn")
@Controller
public class DataSynController {

    private static Logger _log = LoggerFactory.getLogger(DataSynController.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "customService")
    private CustomService customService;

    @Resource(name = "dictionaryService")
    private DictionaryService dictionaryService;

    @Resource(name = "storageService")
    private StorageService storageService;

    @Resource(name = "storageConfigsService")
    private StorageConfigsService storageConfigsService;

    /**
     * icms同步老媒资数据到新媒资接口
     * 接口文档地址地址：http://zhishi.cnlive.com/pages/viewpage.action?pageId=364294
     */
    @RequestMapping(value = "/icms2mam", method = {RequestMethod.POST})
    @ResponseBody
    @SignCheck(value = {SignType.TRUSTSYS}, supportPlatform = {SignPlatform.ICMS})
    // TODO: 2017/5/22 接收请求参数并进行相应的校验，入库
    public JsonResult icms2mam(@RequestBody Icms2mamVo paramVo, HttpServletRequest request) {
        _log.info("icms 从老媒资同步数据信息，vo={}", JSON.toJSONString(paramVo));
        boolean infoBoolean = false;
        try {
            List<Integer> categoryList = this.listCategoryCode();
            List<String> errList = new ArrayList<>();
            if (StringUtils.isEmpty(paramVo.getVideoUUID())) {
                errList.add("videoUUID不可为空");
            }
            if (StringUtils.isEmpty(paramVo.getVideoName())) {
                errList.add("videoName不可为空");
            }
            if (StringUtils.isEmpty(paramVo.getVideoTag())) {
                paramVo.setVideoTag(paramVo.getVideoName());
            }
            if (StringUtils.isEmpty(paramVo.getVideoDes())) {
                paramVo.setVideoDes(paramVo.getVideoName());
            }
            if (paramVo.getCategory() == null) {
                paramVo.setCategory(Const.CHANNEL_OTHER);
            } else if (!categoryList.contains(paramVo.getCategory())) {
                errList.add("category不符合要求");
            }
            if (paramVo.getDuration() == null) {
                errList.add("duration不可为空");
            }
//            if (paramVo.getImgInfos() == null) {
//                errList.add("imgInfos不可为空");
//            }
//            if (StringUtils.isEmpty(paramVo.getShowUrl())) {
//                errList.add("showUrl不可为空");
//            }
            if (paramVo.getSpid() == null || paramVo.getSpid() == 0) {
//                errList.add("spid不可为空且不可为0");
                paramVo.setSpid(82L);
            }

            if (StringUtils.isEmpty(paramVo.getImgUrl())) {
                infoBoolean = true;
                // 校验图片信息
                if (!verifyImgInfos(paramVo.getImgInfos())) {
                    errList.add("ImgUrl、imgInfos不能同时为空!");
                }
            }
            if (StringUtils.isEmpty(paramVo.getOriginUri())) {
                errList.add("originUri不可为空");
            }
//            if (StringUtils.isEmpty(paramVo.getResOrigin())) {
//                errList.add("resOrigin不可为空");
//            }
            if (StringUtils.isEmpty(paramVo.getSizeOrigin())) {
                errList.add("sizeOrigin不可为空");
            }

            if (paramVo.getCustomId() == null) {
                Long customId = customService.getParentCutsomerBySpId(paramVo.getSpid());
                paramVo.setCustomId(customId);
            }
//            JSONArray playInfos = paramVo.getPlayInfos();
//            if (playInfos.size() == 0) {
//                errList.add("playInfos不可为空");
//            } else {
//                for (int i = 0; i < playInfos.size(); i++) {
//                    JSONObject jo = (JSONObject) playInfos.get(i);
//                    if (!jo.containsKey("storeUri")) {
//                        errList.add("playInfos必需包含 storeUri");
//                    } else {
//                        String storeUri = (String) jo.get("storeUri");
//                        if (!StringUtils.isNotBlank(storeUri)) {
//                            errList.add("storeUri不可为空");
//                        }
//                    }
//                }
//            }
            // 校验播放信息
            // 暂时先去掉码率的校验，接收所有码率
            // verifyPlayInfo(paramVo.getPlayInfos());
            if (errList.size() != 0) {
                String msg = Joiner.on(";").join(errList).toString();
                _log.info("同步失败原因：{}", msg);
                return JsonResult.createErrorInstance(msg);
            }
        } catch (Exception ex) {
            _log.error("icms 同步老媒资数据error,校验参数出错，msg={}，ex={}", ex.getMessage(), ex);
            return JsonResult.createErrorInstance("同步信息出错：媒资校验参数error");
        }

        try {
            String imgHost = "";
            String videoHost = "";

            String replaceImg = "";
            String replaceVideo = "";
            if (infoBoolean) {
                imgHost = splitHost(paramVo.getImgInfos().toJSONString());
                videoHost = splitHost(paramVo.getPlayInfos().toJSONString());
                replaceImg = replaceHost(paramVo.getImgInfos().toJSONString());
                replaceVideo = replaceHost(JSONObject.parseObject(paramVo.getPlayInfos().get(0).toString()).getString("storeUri"));
            } else {
                imgHost = splitHost(paramVo.getImgUrl());
                videoHost = splitHost(paramVo.getOriginUri());
                replaceImg = replaceHost(paramVo.getImgUrl());
                replaceVideo = replaceHost(paramVo.getOriginUri());
            }

            Date createTime = CalendarUtil.parseDefaultDate(paramVo.getCreateTime());
            Date nowDate = new Date();
            String videoUUID = paramVo.getVideoUUID();
            VideoModel byBusinessUUID = videoService.getByBusinessUUID(videoUUID);
            if (byBusinessUUID != null) {
                if (byBusinessUUID.getIsIcms2Mam() == null || VideoSources.mam == byBusinessUUID.getIsIcms2Mam()) {
                    return JsonResult.createErrorInstance("同步信息出错：uuid与点播云内uuid重复，uuid=" + videoUUID);
                }
                VideoModel updateVideo = new VideoModel();
                updateVideo.setVideoId(byBusinessUUID.getVideoId());
                if (infoBoolean) {
                    updateVideo.setPicFinishedImg(replaceImg);
                } else {
                    updateVideo.setPicFinishedImg(replaceImgUrl(replaceImg));
                }
                Integer storageImgId = getStorage(byBusinessUUID.getStorageImgId(), imgHost, StorageContentTypeEnum.Picture, paramVo.getSpid());
                Integer storageId = getStorage(byBusinessUUID.getStorageId(), videoHost, StorageContentTypeEnum.Media, paramVo.getSpid());
                if (storageImgId == null || storageId == null) {
                    return JsonResult.createErrorInstance("同步信息出错：未配置相关存储，uuid=" + videoUUID);
                }
                updateVideo.setStorageImgId(storageImgId);
                updateVideo.setStorageId(storageId);
//                updateVideo.setSpid(paramVo.getSpid());
//                updateVideo.setCustomId(paramVo.getCustomId());
//                updateVideo.setCreateUserId(paramVo.getCustomId());
//                updateVideo.setUpdateUserId(paramVo.getCustomId());
                updateVideo.setCreateTime(createTime == null ? nowDate : createTime);
                updateVideo.setUpdateTime(createTime == null ? nowDate : createTime);
                videoService.modify(updateVideo);


                List<FileModel> fileList = fileService.getByVid(byBusinessUUID.getVideoId());
                for (FileModel fileModel : fileList) {
                    FileModel updateFile = new FileModel();
                    updateFile.setFileId(fileModel.getFileId());
                    updateFile.setVideoId(byBusinessUUID.getVideoId());
                    updateFile.setOriginUri(replaceVideo);
                    updateFile.setStoreUri(replaceVideo);
                    updateFile.setResOrigin(paramVo.getResOrigin());
                    updateFile.setSizeOrigin(paramVo.getSizeOrigin());
                    updateFile.setFileSize(paramVo.getFileSize());
                    updateFile.setVbrOrigin(paramVo.getVbrOrigin());
                    updateFile.setRatioOrigin(paramVo.getRatioOrigin());
                    updateFile.setStorageTranscode(storageId);
                    updateFile.setStorageDistribute(storageId);
                    fileService.modify(updateFile);
//                    String originUri = paramVo.getOriginUri();
//                if (StringUtils.isEmpty(originUri) && originUri.length() > 3) {
//                    updateFile.setTransCodeFmt(paramVo.getGfmt());
//                }
//                    updateFile.setStoreUri(originUri);
//                    updateFile.setCodeRate(paramVo.getCodeRate());
                }

                return JsonResult.createSuccessInstance("同步信息成功！");
            }

            Integer storageImgId = getStorage(null, imgHost, StorageContentTypeEnum.Picture, paramVo.getSpid());
            Integer storageId = getStorage(null, videoHost, StorageContentTypeEnum.Media, paramVo.getSpid());
            if (storageImgId == null || storageId == null) {
                return JsonResult.createErrorInstance("同步信息出错：未配置相关存储，uuid=" + videoUUID);
            }
            VideoModel icms2mamVoToVideoModel = paramVo.Icms2mamVoToVideoModel();
            if (infoBoolean) {
                icms2mamVoToVideoModel.setPicFinishedImg(replaceImg);
            } else {
                icms2mamVoToVideoModel.setPicFinishedImg(replaceImgUrl(replaceImg));
            }
            icms2mamVoToVideoModel.setCreateTime(createTime == null ? nowDate : createTime);
            icms2mamVoToVideoModel.setCreateUserId(paramVo.getCustomId());
            icms2mamVoToVideoModel.setUpdateTime(createTime == null ? nowDate : createTime);
            icms2mamVoToVideoModel.setPublishTime(createTime == null ? nowDate : createTime);
            icms2mamVoToVideoModel.setUpdateUserId(paramVo.getCustomId());
            icms2mamVoToVideoModel.setIsIcms2Mam(VideoSources.old2mam);
            icms2mamVoToVideoModel.setMmsType(MmsTypeEnum.COMMON);
            icms2mamVoToVideoModel.setStatus(ModelStatus.OnLine);
            icms2mamVoToVideoModel.setFileStatus(FileStatus.TranscodingSuccess);
            icms2mamVoToVideoModel.setStorageImgId(storageImgId);
            icms2mamVoToVideoModel.setStorageId(storageId);
            VideoModel videoModel = videoService.createIcms2MamModel(icms2mamVoToVideoModel);
            if (!infoBoolean) {
                FileModel saveFile = new FileModel();
                saveFile.setVideoId(videoModel.getVideoId());
                saveFile.setVideoName(videoModel.getVideoName());
                saveFile.setFileSize(paramVo.getFileSize());
                saveFile.setDuration(paramVo.getDuration());
                saveFile.setStatus(FileStatus.TranscodingSuccess);
                saveFile.setCreateTime(nowDate);
                saveFile.setUpdateTime(nowDate);
                saveFile.setCodeRate(paramVo.getCodeRate());
                saveFile.setTransCodeFmt(paramVo.getGfmt());
                saveFile.setOriginUri(replaceVideo);
                saveFile.setResOrigin(paramVo.getResOrigin());
                saveFile.setSizeOrigin(paramVo.getSizeOrigin());
                saveFile.setFileSize(paramVo.getFileSize());
                saveFile.setVbrOrigin(paramVo.getVbrOrigin());
                saveFile.setRatioOrigin(paramVo.getRatioOrigin());
                saveFile.setStoreUri(replaceVideo);

                saveFile.setStorageTranscode(storageId);
                saveFile.setStorageDistribute(storageId);
                fileService.save(saveFile);
            } else {
                List<FileModel> icms2mamVoToFileModel = paramVo.Icms2mamVoToFileModel();
                for (FileModel fileModel : icms2mamVoToFileModel) {
                    FileModel fileByVidAndCoderateAndTransCodeFmt = fileService.getFileByVidAndCoderateAndTransCodeFmt(videoModel.getVideoId(), fileModel.getCodeRate(), fileModel.getTransCodeFmt());
                    if (fileByVidAndCoderateAndTransCodeFmt != null) {
                        continue;
                    }
                    fileModel.setVideoId(videoModel.getVideoId());
                    fileModel.setVideoName(videoModel.getVideoName());
                    fileModel.setStatus(FileStatus.TranscodingSuccess);
                    fileModel.setCreateTime(nowDate);
                    fileModel.setUpdateTime(nowDate);
                    fileModel.setStoreUri(replaceHost(fileModel.getStoreUri()));
                    fileModel.setOriginUri(fileModel.getStoreUri());
                    fileModel.setResOrigin(paramVo.getResOrigin());
                    fileModel.setSizeOrigin(paramVo.getSizeOrigin());
                    fileModel.setVbrOrigin(paramVo.getVbrOrigin());
                    fileModel.setRatioOrigin(paramVo.getRatioOrigin());

                    fileModel.setStorageTranscode(storageId);
                    fileModel.setStorageDistribute(storageId);
                    fileService.save(fileModel);
                }
            }
            return JsonResult.createSuccessInstance("同步信息成功！");
        } catch (Exception ex) {
            _log.error("icms 同步老媒资数据error，保存数据出错，msg={}，ex={}", ex.getMessage(), ex);
            return JsonResult.createErrorInstance("同步信息出错：媒资保存数据error");
        }
    }

    private Integer getStorage(Integer storageId, String host, StorageContentTypeEnum contentType, Long spid) {
        if (storageId == null) {
            if (StorageContentTypeEnum.Media == contentType) {
                StorageModel storageVideo = new StorageModel();
                storageVideo.setType(StorageTypeEnum.Definition);
                storageVideo.setName(host);
                storageVideo.setContentType(StorageContentTypeEnum.Media);
                List<StorageModel> videoUrlList = storageService.getByStorage(storageVideo);
                if (videoUrlList.size() > 0) {
                    StorageModel oldStorage = videoUrlList.get(0);
                    storageId = oldStorage.getId();
                    if (StorageUseStateEnum.UsedBefore != oldStorage.getUseState()) {
                        oldStorage.setUseState(StorageUseStateEnum.UsedBefore);
                        storageService.modify(oldStorage);
                    }
                } else {
                    StorageModel storageModel = new StorageModel();
                    storageModel.setType(StorageTypeEnum.Definition);
                    storageModel.setName(host);
                    storageModel.setContentType(StorageContentTypeEnum.MediaAndPicture);
                    List<StorageModel> mediaAndImg = storageService.getByStorage(storageModel);
                    if (mediaAndImg.size() > 0) {
                        StorageModel oldStorage = mediaAndImg.get(0);
                        storageId = mediaAndImg.get(0).getId();
                        if (StorageUseStateEnum.UsedBefore != oldStorage.getUseState()) {
                            oldStorage.setUseState(StorageUseStateEnum.UsedBefore);
                            storageService.modify(oldStorage);
                        }
                    }
                }
//                else {
//                    StorageModel videohost = new StorageModel();
//                    videohost.setContentType(StorageContentTypeEnum.Media);
//                    videohost.setSpid(spid);
//                    videohost.setType(StorageTypeEnum.Definition);
//                    videohost.setName(host);
//                    videohost.setYongtu(StorageUsageEnum.ProductionAndOperation);
//                    videohost.setUseState(StorageUseStateEnum.UsedBefore);
//                    videohost = storageService.save(videohost);
//                    storageId = videohost.getId();
//                }
            } else if (StorageContentTypeEnum.Picture == contentType) {
                StorageModel storageImg = new StorageModel();
                storageImg.setType(StorageTypeEnum.Definition);
                storageImg.setName(host);
                storageImg.setContentType(StorageContentTypeEnum.Picture);
                List<StorageModel> imgUrlList = storageService.getByStorage(storageImg);
                if (imgUrlList.size() > 0) {
                    StorageModel oldStorage = imgUrlList.get(0);
                    storageId = oldStorage.getId();
                    if (StorageUseStateEnum.UsedBefore != oldStorage.getUseState()) {
                        oldStorage.setUseState(StorageUseStateEnum.UsedBefore);
                        storageService.modify(oldStorage);
                    }
                } else {
                    StorageModel storageModel = new StorageModel();
                    storageModel.setType(StorageTypeEnum.Definition);
                    storageModel.setName(host);
                    storageModel.setContentType(StorageContentTypeEnum.MediaAndPicture);
                    List<StorageModel> mediaAndImg = storageService.getByStorage(storageModel);
                    if (mediaAndImg.size() > 0) {
                        StorageModel oldStorage = mediaAndImg.get(0);
                        storageId = oldStorage.getId();
                        if (StorageUseStateEnum.UsedBefore != oldStorage.getUseState()) {
                            oldStorage.setUseState(StorageUseStateEnum.UsedBefore);
                            storageService.modify(oldStorage);
                        }
                    }
                }
            }

        }
        return storageId;
    }

    @RequestMapping(value = "saveHost")
    @ResponseBody
    public JsonResult saveStorage(@RequestBody String body) {
        JSONObject param = JSONObject.parseObject(body);
        Long spId = Long.valueOf(param.getString("spId"));
        JSONArray images = param.getJSONArray("image");
        for (int i = 0; i < images.size(); i++) {
            String image = images.getString(i);
            if (StringUtils.isNotEmpty(image)) {
                StorageModel oldeStorage = new StorageModel();
                oldeStorage.setType(StorageTypeEnum.Definition);
                oldeStorage.setSpid(spId);
                oldeStorage.setYongtu(StorageUsageEnum.ProductionAndOperation);
                oldeStorage.setName(image);
                oldeStorage.setContentType(StorageContentTypeEnum.Picture);
                List<StorageModel> storageModels = storageService.getByStorage(oldeStorage);
                if (storageModels.size() > 0) {
                    continue;
                }
                StorageModel imghost = new StorageModel();
                imghost.setContentType(StorageContentTypeEnum.Picture);
                imghost.setSpid(spId);
                imghost.setType(StorageTypeEnum.Definition);
                imghost.setName(image);
                imghost.setYongtu(StorageUsageEnum.ProductionAndOperation);
                imghost.setUseState(StorageUseStateEnum.UsedBefore);
                imghost = storageService.save(imghost);
                StorageConfigsModel storageConfigsModel = new StorageConfigsModel();
                storageConfigsModel.setStorageId(imghost.getId());
                storageConfigsModel.setProtocol(1);
                storageConfigsModel.setIoType(3);
                storageConfigsModel.setHostName(image.substring(0, image.lastIndexOf("/")));
                storageConfigsService.save(storageConfigsModel);
            }
        }
        JSONArray videos = param.getJSONArray("video");
        for (int i = 0; i < videos.size(); i++) {
            String video = videos.getString(i);
            if (StringUtils.isNotEmpty(video)) {
                StorageModel oldeStorage = new StorageModel();
                oldeStorage.setSpid(spId);
                oldeStorage.setType(StorageTypeEnum.Definition);
                oldeStorage.setYongtu(StorageUsageEnum.ProductionAndOperation);
                oldeStorage.setName(video);
                oldeStorage.setContentType(StorageContentTypeEnum.Media);
                List<StorageModel> storageModels = storageService.getByStorage(oldeStorage);
                if (storageModels.size() > 0) {
                    continue;
                }
                StorageModel videoHost = new StorageModel();
                videoHost.setContentType(StorageContentTypeEnum.Media);
                videoHost.setSpid(spId);
                videoHost.setType(StorageTypeEnum.Definition);
                videoHost.setName(video);
                videoHost.setYongtu(StorageUsageEnum.ProductionAndOperation);
                videoHost.setUseState(StorageUseStateEnum.UsedBefore);
                videoHost = storageService.save(videoHost);
                StorageConfigsModel storageConfigsModel = new StorageConfigsModel();
                storageConfigsModel.setStorageId(videoHost.getId());
                storageConfigsModel.setProtocol(1);
                storageConfigsModel.setIoType(3);
                storageConfigsModel.setHostName(video.substring(0, video.lastIndexOf("/")));
                storageConfigsService.save(storageConfigsModel);
            }
        }
        return JsonResult.createSuccessInstance("success");
    }

    private String replaceImgUrl(String imgUrl) {
        Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
        String scalKey = "";
        for (Map.Entry entry : Const.videoImageScalCp.entrySet()) {
            scalKey = String.valueOf(entry.getKey());
            Integer[] resolutions = Const.videoImageType.get(scalKey);
            Map<String, String> fbl_map = new HashMap<String, String>();
            for (int i = 0; i < resolutions.length; i = i + 2) {
                String pic_fbl = resolutions[i] + "*" + resolutions[i + 1];
                String pic_url = "";
                pic_url = imgUrl;
                fbl_map.put(pic_fbl, pic_url);
            }
            finishedImgs_map.put(scalKey, fbl_map);
        }

        return JSON.toJSONString(finishedImgs_map);
    }

    /**
     * 校验图片
     *
     * @param imgInfos
     * @return
     */
    private boolean verifyImgInfos(JSONObject imgInfos) {
        Set<String> keySet = imgInfos.keySet();
        Map<String, Integer[]> videoimagetype = Const.videoImageType;
        Set<String> interator = videoimagetype.keySet();
        if (!keySet.equals(interator)) {
            return false;
        }
        for (String key : interator) {
            JSONObject jsonObject = null;
            if (imgInfos.containsKey(key)) {
                jsonObject = (JSONObject) imgInfos.get(key);
            } else {
                return false;
            }
            // 图片的尺寸是否全
            Integer[] integers = videoimagetype.get(key);
            // 每个key所包含的全部尺寸
            Set<String> sizeSet = new HashSet<>();
            for (int i = 0; i < integers.length; i = i + 2) {
                int length = integers[i];
                int width = integers[i + 1];
                String size = length + "*" + width;
                sizeSet.add(size);
            }
            if (!jsonObject.keySet().equals(sizeSet)) {
                _log.error("4中比例不全，接收到的imgInfos={}", imgInfos.toJSONString());
                return false;
            }
        }
        return true;
    }

    /**
     * 校验播放信息
     *
     * @param playInfos
     */
    private void verifyPlayInfo(JSONArray playInfos) {
        List<Integer> definitionCodes = getDefinitionCodes();
        for (int i = 0; i < playInfos.size(); i++) {
            JSONObject jsonObject = (JSONObject) playInfos.get(i);
            Integer codeRate = jsonObject.getInteger("codeRate");
            boolean flag = false;
            if (definitionCodes.contains(codeRate)) {
                flag = true;
            }
            // 码流不符合要求,则为流畅（400）
            if (!flag) {
                _log.error("码流不符合要求，接收到的码流为codeRate={}", codeRate);
                codeRate = DefinitionEnum.SMOOTH.getDefinitionId();
                jsonObject.put("codeRate", codeRate);
            }

        }
    }

    private List<Integer> getDefinitionCodes() {
        List<Integer> definitionCodes = new ArrayList<>();
        for (DefinitionEnum codeRateEnum : DefinitionEnum.values()) {
            definitionCodes.add(codeRateEnum.getDefinitionId());
        }
        return definitionCodes;
    }

    private List<Integer> listCategoryCode() {
        return dictionaryService.getDictionaryValues(Dictionary.CATEGORY_DIC_WORD, -1);
    }

    /**
     * 切割hostname
     *
     * @param imgUrl
     * @return
     */
    private String splitHost(String imgUrl) {
        String hostname = "";
        if (StringUtils.isNotEmpty(imgUrl)) {
            Pattern pattern = Pattern.compile("[a-zA-z]+://(.+?)/");
            Matcher matcher = pattern.matcher(imgUrl);
            if (matcher.find()) {
                hostname = matcher.group();
            }
        }
        return hostname;
    }

    /**
     * 替换hostname
     *
     * @param imgUrl
     * @return
     */
    private String replaceHost(String imgUrl) {
        if (StringUtils.isNotEmpty(imgUrl)) {
            Pattern pattern = Pattern.compile("[a-zA-z]+://(.+?)/");
            Matcher matcher = pattern.matcher(imgUrl);
            imgUrl = matcher.replaceAll("");
        }
        return imgUrl;
    }
}
