package com.cnlive.mam.controller.v1;

import com.cnlive.mam.common.enums.StorageContentTypeEnum;
import com.cnlive.mam.common.enums.StorageTypeEnum;
import com.cnlive.mam.common.enums.StorageUsageEnum;
import com.cnlive.mam.common.enums.StorageUseStateEnum;
import com.cnlive.mam.condition.AlbumCondition;
import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.AlbumModel;
import com.cnlive.mam.model.StorageModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cuilongcan on 8/2/2017.
 */

@Controller
@RequestMapping("/inner/synData")
public class DataSynBucketController {
    private static Logger _log = LoggerFactory.getLogger(DataSynBucketController.class);
    @Resource(name = "videoService")
    private VideoService videoService;
    @Resource(name = "fileService")
    private FileService fileService;
    @Resource(name = "storageService")
    private StorageService storageService;
    @Resource(name = "albumService")
    private AlbumService albumService;
    @Resource(name = "customSpInfoService")
    private CustomSpInfoService customSpInfoService;
//    @Resource(name = "videoDeleteTaskService")
//    private VideoDeleteTaskService videoDeleteTaskService;

    @RequestMapping("/synBucket")
    public void synBucket(Integer rows, Long spId, Integer source, Integer storageId, Integer storageImgId) {
        if (rows == null || rows.intValue() == 0 || rows.intValue() > 10000) {
            rows = 10000;
        }
        //更新video的storageId,以及stroageImgId
//        if ("".equals(updateStorage(spId, source))) {
//            return "先插入storage表";
//        }
        //更新customSpInfo
//        synCustomSpInfo(rows, spId);
        //更新album
        synAlbum(spId);
        //更新video
        synVideoInfo(rows, spId, source, storageId, storageImgId);
        //删除
//        deleteVideo(rows, spId, source);
    }

//    private String updateStorage(Long spId, Integer source) {
//        VideoModel videoModel = new VideoModel();
//        switch (source) {
//            case 0:
//                videoModel.setStorageId(1);
//                videoModel.setStorageImgId(2);
//                videoModel.setSpid(spId);
//                videoModel.setIsIcms2Mam(VideoSources.mam);
//                videoService.updateStorageBySpid(videoModel);
//                break;
//            case 1:
//                videoModel.setStorageId(1);
//                videoModel.setStorageImgId(2);
//                videoModel.setSpid(spId);
//                videoModel.setIsIcms2Mam(VideoSources.old2mam);
//                videoService.updateStorageBySpid(videoModel);
//                break;
//            case 2:
//                videoModel.setStorageId(1);
//                videoModel.setStorageImgId(2);
//                videoModel.setSpid(spId);
//                videoModel.setIsIcms2Mam(VideoSources.live2mam);
//                videoService.updateStorageBySpid(videoModel);
//                break;
//            default:
//                return "";
//        }
//        return "finish";
//    }

//    private void synCustomSpInfo(Integer rows, Long spId) {
//        AdminCondition adminCondition = new AdminCondition();
//        adminCondition.setSpId(Integer.parseInt(String.valueOf(spId)));
//        adminCondition.setRows(rows);
//        DataGrid dataGrid = customSpInfoService.pageSpInfoForAdmin(adminCondition);
//        List<CustomSpInfoModel> customSpInfoList = dataGrid.getRows();
//        for (CustomSpInfoModel spinfo : customSpInfoList) {
//            CustomSpInfoModel updateSpInfo = new CustomSpInfoModel();
//            updateSpInfo.setSpId(spinfo.getSpId());
//            updateSpInfo.setLogoPicUrl(replaceHost(spinfo.getLogoPicUrl()));
//            customSpInfoService.modify(updateSpInfo);
//        }
//    }

    private void synAlbum(Long spId) {
        AlbumCondition albumCondition = new AlbumCondition();
        albumCondition.setSpId(spId);
        List<AlbumModel> albumList = albumService.getAlbumInfoByCondition(albumCondition);
        for (AlbumModel albumModel : albumList) {
            AlbumModel updateAlbum = new AlbumModel();
            updateAlbum.setAlbumId(albumModel.getAlbumId());
            updateAlbum.setPicFinishedImg(replaceHost(albumModel.getPicFinishedImg()));
            albumService.modify(updateAlbum);
        }
    }

    private void synVideoInfo(Integer rows, Long spId, Integer source, Integer storageId, Integer storageImgId) {
        Long startTime = System.currentTimeMillis();
        VideoCondition condition = new VideoCondition();
        condition.setRows(rows);
        condition.setSpid(spId);
        condition.setSucai(source);
        int i = 1;
        Map<String, Integer> hostMap = Collections.synchronizedMap(new HashMap<>());
        Map<String, Integer> fileMap = Collections.synchronizedMap(new HashMap<>());

        while (true) {
            condition.setPage(i);
            List<Integer> vids = videoService.getVideoInfoForSolr(condition);
            if (vids.size() > 0) {
                ExecutorService pool = Executors.newFixedThreadPool(5);
                Future future = pool.submit(new Runnable() {
                    public void run() {
                        for (Integer vid : vids) {
                            VideoModel videoModel = videoService.getById(Long.parseLong(String.valueOf(vid)));
                            VideoModel updateModel = new VideoModel();
                            updateModel.setVideoId(videoModel.getVideoId());
                            if (videoModel.getPicFinishedImg() == null && videoModel.getPicOriginal() == null) {
                                continue;
                            }
//                            Integer storageId;
//                            Integer storageIdPic = saveHost(videoModel.getPicFinishedImg(), hostMap, spId, StorageContentTypeEnum.Picture);
//                            Integer storageIdOri = saveHost(videoModel.getPicOriginal(), hostMap, spId, StorageContentTypeEnum.Picture);
//                            if (storageIdPic != null) {
//                                storageId = storageIdPic;
//                            } else if (storageIdOri != null) {
//                                storageId = storageIdOri;
//                            } else {
//                                continue;
//                            }
                            updateModel.setPicFinishedImg(replaceHost(videoModel.getPicFinishedImg()));
                            updateModel.setPicOriginal(replaceHost(videoModel.getPicOriginal()));
//                            updateModel.setStorageId(storageId);

//                            Integer storageImgId = null;
//                            List<FileModel> fileList = fileService.getByVid(Long.valueOf(vid));
//                            for (FileModel fileModel : fileList) {
//                                if (fileModel.getStoreUri() == null && fileModel.getOriginUri() == null) {
//                                    continue;
//                                }
//
////                                Integer imgIdStore = saveHost(fileModel.getStoreUri(), fileMap, spId, StorageContentTypeEnum.Media);
////                                Integer imgIdOri = saveHost(fileModel.getOriginUri(), fileMap, spId, StorageContentTypeEnum.Media);
////                                if (imgIdStore != null) {
////                                    storageImgId = imgIdStore;
////                                } else if (imgIdOri != null) {
////                                    storageImgId = imgIdOri;
////                                } else {
////                                    continue;
////                                }
//
//                                FileModel updateFile = new FileModel();
//                                updateFile.setFileId(fileModel.getFileId());
//                                updateFile.setStoreUri(replaceHost(fileModel.getStoreUri()));
//                                updateFile.setOriginUri(replaceHost(fileModel.getOriginUri()));
//                                updateFile.setStorageTranscode(storageImgId);
//                                updateFile.setStorageDistribute(storageImgId);
//                                fileService.modify(updateFile);
//                            }
//
//                            updateModel.setStorageImgId(storageImgId);
                            videoService.modify(updateModel);
                        }
                        pool.shutdown();
                    }
                });
                i++;
                _log.info("video update spend time = {},page={}", startTime - System.currentTimeMillis(), i);
            } else {
                break;
            }
        }
    }

    private Integer saveHost(String imgUrl, Map map, Long spId, StorageContentTypeEnum typeEnum) {
        Integer id = null;
        if (imgUrl != null) {
            Pattern pattern = Pattern.compile("[a-zA-z]+://(.+?)/");
            Matcher matcher = pattern.matcher(imgUrl);
            if (matcher.find()) {
                String updateUrl = matcher.group();
                StorageModel imghost = new StorageModel();
                imghost.setContentType(typeEnum);
                imghost.setSpid(spId);
                imghost.setType(StorageTypeEnum.Definition);
                imghost.setName(updateUrl);
                imghost.setYongtu(StorageUsageEnum.ProductionAndOperation);
                imghost.setUseState(StorageUseStateEnum.NotUse);
                if (!map.containsKey(updateUrl)) {
                    imghost = storageService.save(imghost);
                    id = imghost.getId();
                    map.put(updateUrl, id);
                } else {
                    id = (Integer) map.get(updateUrl);
                }
            }
        }
        return id;
    }

    private String replaceHost(String imgUrl) {
        if (imgUrl != null) {
            Pattern pattern = Pattern.compile("[a-zA-z]+://(.+?)/");
            Matcher matcher = pattern.matcher(imgUrl);
            imgUrl = matcher.replaceAll("");
        }
        return imgUrl;
    }

//    private void deleteVideo(Integer rows, Long spId, Integer source) {
//        VideoCondition condition = new VideoCondition();
//        condition.setRows(rows);
//        condition.setSpid(spId);
//        condition.setSucai(1);
//        List<Integer> vids = videoService.getVideoInfoForSolr(condition);
//        for (Integer vid : vids) {
//            videoDeleteTaskService.delVideoAndFile(Long.valueOf(vid));
//        }
//    }
}
