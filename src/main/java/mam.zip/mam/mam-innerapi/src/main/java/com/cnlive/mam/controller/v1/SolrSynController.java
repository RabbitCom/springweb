package com.cnlive.mam.controller.v1;

import com.cnlive.mam.condition.VideoCondition;
import com.cnlive.mam.model.CustomModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.SolrRetrieveService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by cuilongcan on 7/18/2017.
 */
@RequestMapping("/solrSyn")
@Controller
public class SolrSynController {
    private static Logger _log = LoggerFactory.getLogger(ShenHeController.class);
    @Resource(name = "solrRetrieveService")
    private SolrRetrieveService solrRetrieveService;
    @Resource(name = "videoService")
    private VideoService videoService;
    @Resource(name = "customService")
    private CustomService customService;

    @RequestMapping(value = "/synVideo", method = RequestMethod.GET)
    public void synVideoInfo(Integer rows,Long spId) {
        Long startAllTime = System.currentTimeMillis();
        VideoCondition condition = new VideoCondition();
        if(rows == null || rows.intValue() == 0 || rows.intValue() > 10000){
            rows = 10000;
        }
        condition.setRows(rows);
        condition.setSpid(spId);
        int i = 1;
        Map<String,String> custominfos = new HashMap<>();
        while (true) {
            condition.setPage(i);
            Long startTime = System.currentTimeMillis();
            List<Integer>  vids = videoService.getVideoInfoForSolr(condition);
            if (vids.size() > 0) {
                ExecutorService pool = Executors.newFixedThreadPool(5);
                Future future = pool.submit(new Runnable() {
                    public void run() {
                        for (Integer vid : vids) {
                            VideoModel videoModel = videoService.getById(Long.parseLong(String.valueOf(vid)));
                            String customidStr = String.valueOf(videoModel.getCustomId());
                            if(!custominfos.containsKey(customidStr)){
                                CustomModel customModel = customService.getById(videoModel.getCustomId());
                                custominfos.put(customidStr,customModel.getContacts());
                            }
                            videoModel.setCustomName(custominfos.get(customidStr));
                            solrRetrieveService.add(videoModel);
                        }
                        pool.shutdown();
                    }
                });
                _log.info("solr synchronize page={},rows={} end time={}",i,rows, System.currentTimeMillis()-startTime);
                i++;
            } else {
                _log.info("solr synchronize allpage={},rows={} end alltime={}",i,rows, System.currentTimeMillis()-startAllTime);
                break;
            }
        }
    }
}
