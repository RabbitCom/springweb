package com.cnlive.mam.controller.v1;

import com.cnlive.mam.common.App;
import com.cnlive.mam.common.enums.DefinitionEnum;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.condition.SuperSpCondition;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.DataGrid;
import com.cnlive.mam.vo.JsonResult;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by cuilongcan on 2017/6/27.
 */
@Controller
@RequestMapping("/v1/inner/appData")
public class AppContoller extends BaseController{

    private static Logger _log = LoggerFactory.getLogger(AppContoller.class);

    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @RequestMapping(value = "pageVideoInfos", method = RequestMethod.POST)
    @ResponseBody
    public Map pageVideoInfos(String appId, Integer pageNumber, Integer pageSize) {
        _log.info("app request data : appId={},pageNumber={},pageSize={}",appId,pageNumber,pageSize);
        Map<String,Object> resMap = new HashMap();
        List<Map<String,Object>> videoInfos = new ArrayList<>();
        if(StringUtils.isEmpty(appId) || !(appId.contains(Const.XIA_HUA_XIAN))){
            return createFailMap("appId与约定不符",videoInfos);
        }
        String spIdStr = Splitter.on(Const.XIA_HUA_XIAN).omitEmptyStrings().splitToList(appId).get(0);
        if(StringUtils.isEmpty(spIdStr)){
            return createFailMap("appId参数不合法",videoInfos);
        }
        Long spId  = 0L;
        try{
            spId = Long.valueOf(spIdStr);
        }catch (Exception ex){
            _log.error("appId error ;appId={}",appId);
            return createFailMap("appId参数不合法",videoInfos);
        }

        SuperSpCondition condition = new SuperSpCondition();
        if (pageNumber == null || pageNumber == 0) {
            pageNumber = 1;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize = 10;
        }
        if (pageSize > 100) {
            pageSize = 100;
        }
        condition.setPage(pageNumber);
        condition.setRows(pageSize);
        condition.setSpId(spId);

        condition.setOnoffStatusArray(new String[]{"5","8"}); //上线|发布成功
        condition.setFileStatus(2); //转码成功

        DataGrid dataGrid = videoService.getPageByCondition(condition);

        if(dataGrid.getTotal() > 0){
            List<VideoModel> list = dataGrid.getRows();
            for (VideoModel videoModel : list){
                Map<String,Object> videoMap = new HashMap();
                videoMap.put("type","vod");
                videoMap.put("vId",videoModel.getBusinessUUID());
                videoMap.put("title",videoModel.getVideoName());
                videoMap.put("subTitle",videoModel.getSubTitle());
                videoMap.put("img",videoModel.getListPicUrl());
                videoMap.put("description",videoModel.getSynopsis());
                if(StringUtils.isNotBlank(videoModel.getTag())){
                    List<String> tags = Splitter.on(Const.SEPARATE_XIE).omitEmptyStrings().splitToList(videoModel.getTag());
                    videoMap.put("tag", Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(tags).toString());
                }else {
                    videoMap.put("tag", "");
                }
                videoMap.put("category",videoModel.getCategory());
                List<FileModel> fileModels = fileService.getByVidAndTransCodeFmt(videoModel.getVideoId(),Const.FMT_MP4);
                List<String> rateList = new ArrayList<>();
                for (FileModel file : fileModels){
                    int codeRate = file.getCodeRate().intValue();
                    if(DefinitionEnum.SMOOTH.getDefinitionId().intValue() == codeRate){
                        if(!rateList.contains("1")){
                            rateList.add("1");
                        }
                    }
                    if(DefinitionEnum.SD.getDefinitionId().intValue() == codeRate){
                        if(!rateList.contains("2")){
                            rateList.add("2");
                        }
                    }
                    if(DefinitionEnum.HD.getDefinitionId().intValue() == codeRate){
                        if(!rateList.contains("3")){
                            rateList.add("3");
                        }
                    }
                    if(DefinitionEnum.ULTRA_HD.getDefinitionId().intValue() == codeRate){
                        if(!rateList.contains("4")){
                            rateList.add("4");
                        }
                    }
                }
                videoMap.put("rates", Joiner.on(Const.VALUE_DECOLLATOR).skipNulls().join(rateList).toString());
                videoInfos.add(videoMap);
            }
        }
        return createSucessMap(videoInfos);
    }
}
