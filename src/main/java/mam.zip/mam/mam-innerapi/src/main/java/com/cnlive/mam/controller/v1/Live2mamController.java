package com.cnlive.mam.controller.v1;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.enums.FileStatus;
import com.cnlive.mam.common.utils.Const;
import com.cnlive.mam.controller.vo.Live2mamVo;
import com.cnlive.mam.model.FileModel;
import com.cnlive.mam.model.VideoModel;
import com.cnlive.mam.service.CustomService;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.service.FileService;
import com.cnlive.mam.service.VideoService;
import com.cnlive.mam.vo.JsonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.util.*;

/**
 * Created by zhangxiaobin on 2017/7/24.
 */
@Controller
@RequestMapping("/v1/inner/live2mam")
public class Live2mamController {

    private static Logger _log = LoggerFactory.getLogger(Live2mamController.class);
    @Resource(name = "videoService")
    private VideoService videoService;

    @Resource(name = "fileService")
    private FileService fileService;

    @Resource(name = "customService")
    private CustomService customService;

    @Resource(name = "dictionaryService")
    private DictionaryService dictionaryService;

    @RequestMapping("syncData")
    @ResponseBody
    @SignCheck(value = {SignType.TRUSTSYS}, supportPlatform = {SignPlatform.LIVE2MAM})
    public JsonResult syncData(@RequestBody Live2mamVo vo, HttpServletRequest request) {
        return JsonResult.createSuccessInstance("系统升级中");
//        try {
//            List<Integer> categoryList = dictionaryService.getDictionaryValues(Dictionary.CATEGORY_DIC_WORD, -1);
//
//            List<String> errList = new ArrayList<>();
//            Long spId = vo.getSpId();
//            if (spId == null) {
//                errList.add("spId不能为空");
//            }
//            if (StringUtils.isEmpty(vo.getUuid())) {
//                errList.add("videoUUID不可为空");
//            }
//            if (StringUtils.isEmpty(vo.getVideoName())) {
//                errList.add("videoName不可为空");
//            }
//            if (StringUtils.isEmpty(vo.getTag())) {
//                String tag = vo.getVideoName();
//                if (StringUtils.isNotEmpty(vo.getSubTitle())) {
//                    tag += "/" + vo.getSubTitle();
//                }
//                vo.setTag(tag);
//            }
//            if (StringUtils.isEmpty(vo.getDescription())) {
//                vo.setDescription(vo.getVideoName());
//            }
//            if (vo.getCategory() == null) {
//                vo.setCategory(Const.CHANNEL_OTHER);
//            } else if (!categoryList.contains(vo.getCategory())) {
//                errList.add("category不符合要求");
//            }
//            if (vo.getCustomCategory() == null) {
//                vo.setCustomCategory(0);
//            }
//            if (vo.getDuration() == null) {
//                errList.add("duration不可为空");
//            }
//            if (StringUtils.isEmpty(vo.getImgUrl())) {
//                errList.add("imgUrl不可为空");
//            }
//            List<JSONObject> fileInfos = vo.getFileInfos();
//            for (JSONObject fileInfo : fileInfos) {
//                if (fileInfo.getInteger("codeRate") == null)
//                    errList.add("codeRate不可为空");
//                if (fileInfo.getInteger("fileSize") == null)
//                    errList.add("fileSize不可为空");
//                if (fileInfo.getInteger("duration") == null)
//                    errList.add("duration不可为空");
//                if (StringUtils.isEmpty(fileInfo.getString("transCodeFmt")))
//                    errList.add("transCodeFmt不可为空");
//                if (StringUtils.isEmpty(fileInfo.getString("storeUri")))
//                    errList.add("storeUri不可为空");
//                if (StringUtils.isEmpty(fileInfo.getString("originUri")))
//                    errList.add("originUri不可为空");
//                if (StringUtils.isEmpty(fileInfo.getString("gfmt")))
//                    errList.add("gfmt不可为空");
//            }
//            if (vo.getCustomId() == null) {
//                Long customId = customService.getParentCutsomerBySpId(vo.getSpId());
//                if (customId == null) {
//                    errList.add("未查到该sp的customId");
//                } else {
//                    vo.setCustomId(Integer.valueOf(customId.toString()));
//                }
//            }
//            if (errList.size() != 0) {
//                String msg = Joiner.on(";").join(errList).toString();
//                _log.info("同步失败原因：{}", msg);
//                return JsonResult.createErrorInstance(msg);
//            }
//            VideoModel mamVideo = videoService.getByBusinessUUID(vo.getUuid());
//            Date createTime = CalendarUtil.parseDefaultDate(vo.getCreateTime());
//            Date nowDate = new Date();
//            if (mamVideo != null) {//update
//                VideoModel updateVideo = new VideoModel();
//                updateVideo.setVideoId(mamVideo.getVideoId());
//                updateVideo = vo.voToVideo(updateVideo);
//                updateVideo.setCustomCategoryId(Long.valueOf(vo.getCustomCategory()));
//                updateVideo.setPicFinishedImg(replaceImgUrl(vo.getImgUrl()));
//                updateVideo.setCreateTime(createTime == null ? nowDate : createTime);
//                updateVideo.setCreateUserId(Long.valueOf(vo.getCustomId()));
//                updateVideo.setUpdateTime(createTime == null ? nowDate : createTime);
//                updateVideo.setPublishTime(createTime == null ? nowDate : createTime);
//                updateVideo.setUpdateUserId(Long.valueOf(vo.getCustomId()));
//                videoService.modify(updateVideo);
//                saveFile(nowDate, fileInfos, updateVideo);
//            } else {//save
//                VideoModel videoModel = new VideoModel();
//                videoModel = vo.voToVideo(videoModel);
//                videoModel.setBusinessUUID(vo.getUuid());
//                videoModel.setCustomCategoryId(Long.valueOf(vo.getCustomCategory()));
//                videoModel.setPicFinishedImg(replaceImgUrl(vo.getImgUrl()));
//                videoModel.setCreateTime(createTime == null ? nowDate : createTime);
//                videoModel.setCreateUserId(Long.valueOf(vo.getCustomId()));
//                videoModel.setUpdateTime(createTime == null ? nowDate : createTime);
//                videoModel.setPublishTime(createTime == null ? nowDate : createTime);
//                videoModel.setUpdateUserId(Long.valueOf(vo.getCustomId()));
//                videoModel.setIsIcms2Mam(VideoSources.live2mam);
//                videoModel.setStatus(ModelStatus.ReleaseSuccess);
//                videoModel.setFileStatus(FileStatus.TranscodingSuccess);
//                videoModel.setMmsType(MmsTypeEnum.COMMON);
//                CustomModel customModel = customService.getById(Long.valueOf(vo.getCustomId()));
//                videoModel.setInstitutionId(customModel.getInstitutionId());
//                VideoModel savedVideo = videoService.save(videoModel);
//                saveFile(nowDate, fileInfos, savedVideo);
//            }
//            return JsonResult.createSuccessInstance("UUID");
//        } catch (BusinessException exception) {
//            _log.error("live2mam syncData error,er={}", exception);
//            return JsonResult.createErrorInstance("mam error,please try again!");
//        }
    }
    //保存file表
    private void saveFile(Date nowDate, List<JSONObject> fileInfos, VideoModel savedVideo) {
        Long videoId = savedVideo.getVideoId();
        for (JSONObject fileInfo : fileInfos) {
            Integer codeRate = fileInfo.getInteger("codeRate");
            String transCodeFmt = fileInfo.getString("gfmt");
            FileModel updateFile = fileService.getFileByVidAndCoderateAndTransCodeFmt(videoId, codeRate, transCodeFmt);
            if (updateFile == null) {
                FileModel saveFile = new FileModel();
                saveFile.setVideoId(savedVideo.getVideoId());
                saveFile.setVideoName(savedVideo.getVideoName());
                saveFile.setFileSize(fileInfo.getLong("fileSize"));
                saveFile.setDuration(fileInfo.getLong("duration"));
                saveFile.setStatus(FileStatus.TranscodingSuccess);
                saveFile.setCreateTime(nowDate);
                saveFile.setUpdateTime(nowDate);
                saveFile.setCodeRate(fileInfo.getInteger("codeRate"));
                saveFile.setTransCodeFmt(fileInfo.getString("gfmt"));
                saveFile.setOriginUri(fileInfo.getString("originUri"));
                saveFile.setResOrigin(fileInfo.getString("resOrigin"));
                saveFile.setSizeOrigin(fileInfo.getString("sizeOrigin"));
                saveFile.setVbrOrigin(fileInfo.getString("vbrOrigin"));
//                        saveFile.setRatioOrigin(vo.getRatioOrigin());
                saveFile.setStoreUri(fileInfo.getString("originUri"));
                fileService.save(saveFile);
            } else {
                updateFile.setVideoId(savedVideo.getVideoId());
                updateFile.setVideoName(savedVideo.getVideoName());
                updateFile.setFileSize(fileInfo.getLong("fileSize"));
                updateFile.setDuration(fileInfo.getLong("duration"));
                updateFile.setStatus(FileStatus.TranscodingSuccess);
                updateFile.setCreateTime(nowDate);
                updateFile.setUpdateTime(nowDate);
                updateFile.setCodeRate(fileInfo.getInteger("codeRate"));
                updateFile.setTransCodeFmt(fileInfo.getString("gfmt"));
                updateFile.setOriginUri(fileInfo.getString("originUri"));
                updateFile.setResOrigin(fileInfo.getString("resOrigin"));
                updateFile.setSizeOrigin(fileInfo.getString("sizeOrigin"));
                updateFile.setVbrOrigin(fileInfo.getString("vbrOrigin"));
//                        updateFile.setRatioOrigin(vo.getRatioOrigin());
                updateFile.setStoreUri(fileInfo.getString("originUri"));
                fileService.modify(updateFile);
            }
        }
    }

    //替换imgUrl地址
    private String replaceImgUrl(String imgUrl) {
        Map<String, Map<String, String>> finishedImgs_map = new HashMap<String, Map<String, String>>();
        String scalKey = "";
        for (Map.Entry entry : Const.videoImageScalCp.entrySet()) {
            scalKey = String.valueOf(entry.getKey());
            Integer[] resolutions = Const.videoImageType.get(scalKey);
            Map<String, String> fbl_map = new HashMap<String, String>();
            for (int i = 0; i < resolutions.length; i = i + 2) {
                String pic_fbl = resolutions[i] + "*" + resolutions[i + 1];
                String pic_url = "";
                pic_url = imgUrl;
                fbl_map.put(pic_fbl, pic_url);
            }
            finishedImgs_map.put(scalKey, fbl_map);
        }

        return JSON.toJSONString(finishedImgs_map);
    }

}
