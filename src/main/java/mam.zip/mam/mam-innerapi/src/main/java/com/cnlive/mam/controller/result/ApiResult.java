package com.cnlive.mam.controller.result;

import com.cnlive.mam.common.resultMessage.CnliveResultMessage;

import java.io.Serializable;

/**
 * Created by zhangxiaobin on 2017/8/15.
 */
public class ApiResult implements Serializable{

    private Integer errorCode ;

    private String errorMessage = "";

    private Object data = null;

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public ApiResult(){}

    public ApiResult(int code, String message) {
        this.errorCode = code;
        this.errorMessage = message;
    }

    public ApiResult(int code, String message, Object data) {
        this.errorCode = code;
        this.errorMessage = message;
        this.data = data;
    }

    public static ApiResult createInstance(CnliveResultMessage resultMessage){
        return new ApiResult(resultMessage.getCode(),resultMessage.getMessage());
    }

    public static ApiResult createInstance(CnliveResultMessage resultMessage, Object object){
        return new ApiResult(resultMessage.getCode(),resultMessage.getMessage(),object);
    }

    public static ApiResult createInstanceSuccess(){
        CnliveResultMessage success = CnliveResultMessage.SUCCESS;
        return new ApiResult(success.getCode(),success.getMessage());
    }

    public static ApiResult createInstanceSuccess(Object data){
        CnliveResultMessage success = CnliveResultMessage.SUCCESS;
        return new ApiResult(success.getCode(),success.getMessage(),data);
    }

    public static ApiResult createInstanceSystemErr(){
        CnliveResultMessage error = CnliveResultMessage.SYSTEM_ERROR;
        return new ApiResult(error.getCode(),error.getMessage());
    }

    public static ApiResult createInstanceSystemErr(Object data){
        CnliveResultMessage error = CnliveResultMessage.SYSTEM_ERROR;
        return new ApiResult(error.getCode(),error.getMessage(),data);
    }

}
