package com.cnlive.mam.controller.vo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.Map;

public class TransCodeCallVo {
	
	private String taskId;
	
	private List<TransCodeItem> items;
	
	private Integer code; // 状态码 0:初始化 2：进行中 3:成功 4：失败
	
	private String type; //avop 几路码率信息    
	
//	private Long duration;
	
	private TransCodeItem detail;

	private List images;

	private JSONObject format;

	public List getImages() {
		return images;
	}

	public void setImages(List images) {
		this.images = images;
	}

	public JSONObject getFormat() {
		return format;
	}

	public void setFormat(JSONObject format) {
		this.format = format;
	}

//	public Long getDuration() {
//		return duration;
//	}
//
//	public void setDuration(Long duration) {
//		this.duration = duration;
//	}

	public TransCodeItem getDetail() {
		return detail;
	}

	public void setDetail(TransCodeItem detail) {
		this.detail = detail;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public List<TransCodeItem> getItems() {
		return items;
	}

	public void setItems(List<TransCodeItem> items) {
		this.items = items;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
