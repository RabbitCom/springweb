package com.cnlive.mam.web;

import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.common.resultMessage.CommonResultMessage;
import com.cnlive.mam.common.utils.MD5Util;
import com.google.common.collect.Lists;

/**
 * @author zhangxiaobin
 */

public class SignInterceptor implements HandlerInterceptor, InitializingBean {

    private static Logger _log = LoggerFactory.getLogger(SignInterceptor.class);
    // 是否是开发模式
    @Value("#{configProperties['devMode']}")
    private String devMode = "false";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Boolean falg = true;
        if (handler == null || !(handler instanceof HandlerMethod)) {
            _log.error("url error, HandlerMethod can not found , url={0}", request.getRequestURL());
            throw new BusinessException(CommonResultMessage.SIGN_URL_INVALID);
        }
        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();
        SignCheck annotation = method.getAnnotation(SignCheck.class);
        if (annotation != null) {
            if (!Boolean.parseBoolean(devMode)) {
                //客户相关的验证签名
                if (annotation.customRelated()) {
                    SignType[] signType = annotation.value();
                    List<SignType> signTypeList = Lists.newArrayList(signType);
                    String tsString = (String) request.getParameter("ts");
                   /* ParamCheck.isNotNull(tsString, "ts");
                    ParamCheck.isPositiveInteger(tsString, "ts");
                    Date now = new Date();
                    long nowTime = now.getTime() / 1000;
                    long ts = Long.parseLong(tsString);
                    ParamCheck.inRange(ts, nowTime, 100, "ts");*/


                    String platform = request.getParameter("platform");
                    String token = request.getParameter("token");
//                    String customIdStr = request.getAttribute("spId") == null ? request.getParameter("spId") : String.valueOf(request.getAttribute("spId"));
//                    String customToken = request.getParameter("customToken");

                    if (signTypeList.isEmpty() || signTypeList.contains(SignType.TRUSTSYS))
                    {
                        if (platform != null && token != null)
                        {
                            /** 校验是否是支持的平台 */
                            SignPlatform[] signPlatforms = annotation.supportPlatform();
                            List<SignPlatform> signPlatformList = Lists.newArrayList(signPlatforms);
                            SignPlatform requestSignPlatform = SignPlatform.getInstanceByName(platform);
                            if (requestSignPlatform == null || (!signPlatformList.isEmpty() && !signPlatformList.contains(requestSignPlatform)))
                            {
                                throw new BusinessException(CommonResultMessage.SECURITY_PLATFORM_NOTSUPPORT);
                            }

                            String platformKey = requestSignPlatform.getCode();
                            String requestURI = request.getRequestURI();
                            String md5String = requestURI + platform + platformKey;
                            //32位加密
                            String md5 = MD5Util.md5(md5String);
                            if (!md5.equals(token))
                            {
                                _log.error("sign not success! url token :{} , md5:{},requestURI:{},platform:{},platformKey:{}", token, md5, requestURI, platform, platformKey);
                                throw new BusinessException(CommonResultMessage.SECURITY_PLATFORM_MD5ERROR);
                            } else
                            {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return falg;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                                Object o, Exception e) throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {

    }
}