package com.cnlive.mam.controller.vo;

import com.cnlive.mam.model.VideoModel;

import java.util.Date;
import java.util.List;

/**
 * Created by zhangxiaobin on 2017/7/24.
 */
public class Live2mamVo {

    private String uuid;
    private Long spId;
    private String videoName;
    private String tag;
    private String subTitle;
    private String description;
    private String createTime;
    private Integer customId;
    private Integer category;
    private Integer customCategory;
    private String videoPlyUrl;
    private String imgUrl;
    private Integer duration;
    private List fileInfos;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getCustomId() {
        return customId;
    }

    public void setCustomId(Integer customId) {
        this.customId = customId;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Integer getCustomCategory() {
        return customCategory;
    }

    public void setCustomCategory(Integer customCategory) {
        this.customCategory = customCategory;
    }

    public String getVideoPlyUrl() {
        return videoPlyUrl;
    }

    public void setVideoPlyUrl(String videoPlyUrl) {
        this.videoPlyUrl = videoPlyUrl;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public List getFileInfos() {
        return fileInfos;
    }

    public void setFileInfos(List fileInfos) {
        this.fileInfos = fileInfos;
    }

    public VideoModel voToVideo(VideoModel video) {
        video.setSpid(this.getSpId());
        video.setVideoName(this.getVideoName());
        video.setTag(this.getTag());
        video.setSubTitle(this.getSubTitle());
        video.setSynopsis(this.getDescription());
        video.setCustomId(Long.valueOf(this.getCustomId()));
        video.setCategory(this.getCategory());
        video.setVideoPlyUrl(this.getVideoPlyUrl());
        video.setDuration(Long.valueOf(this.getDuration()));
        return video;
    }
}
