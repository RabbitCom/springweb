package com.cnlive.mam.controller.vo;

import com.cnlive.mam.vo.CustomCategoryTree;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by zhangxiaobin on 2017/7/24.
 */
public class CategorysVo implements Serializable{

    private Integer id;
    private String text;
    private Integer pid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }
}
