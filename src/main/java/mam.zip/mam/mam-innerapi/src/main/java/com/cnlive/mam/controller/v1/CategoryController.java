package com.cnlive.mam.controller.v1;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cnlive.mam.common.annotation.SignCheck;
import com.cnlive.mam.common.annotation.SignPlatform;
import com.cnlive.mam.common.annotation.SignType;
import com.cnlive.mam.common.exception.BusinessException;
import com.cnlive.mam.condition.CustomCategoryCondition;
import com.cnlive.mam.controller.vo.CategorysVo;
import com.cnlive.mam.controller.vo.Live2mamVo;
import com.cnlive.mam.model.CustomCategoryModel;
import com.cnlive.mam.model.Dictionary;
import com.cnlive.mam.service.CustomCategoryService;
import com.cnlive.mam.service.DictionaryService;
import com.cnlive.mam.vo.CustomCategoryVo;
import com.cnlive.mam.vo.JsonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangxiaobin on 2017/7/24.
 */
@Controller
@RequestMapping("/v1/inner/category")
public class CategoryController {

    private static Logger _log = LoggerFactory.getLogger(CategoryController.class);

    @Resource(name = "dictionaryService")
    DictionaryService dictionaryService;

    @Resource(name = "customCategoryService")
    private CustomCategoryService customCategoryService;

    @RequestMapping("categoryBySp")
    @ResponseBody
    @SignCheck(value = {SignType.TRUSTSYS}, supportPlatform = {SignPlatform.CATEGORY})
    public JsonResult categoryBySp(Long spId){
        if(spId== null){
            return JsonResult.createErrorInstance("参数与约定不符");
        }
        List<CategorysVo> categoryTreeVos = new ArrayList<>();
        try{

            //根分类
            List<Dictionary> categorys = dictionaryService.getCategorys(); //根分类
            for (Dictionary dic : categorys) {
                CategorysVo tree = new CategorysVo();
                tree.setId(dic.getDicValue());
                tree.setPid(0);
                tree.setText(dic.getShowValue());
                categoryTreeVos.add(tree);
            }

            //一级分类
            CustomCategoryCondition conditionLevel1 = new CustomCategoryCondition();
            conditionLevel1.setSpId(spId);
            conditionLevel1.setLevel(1);
            List<CustomCategoryModel> level1Infos = customCategoryService.getInfosByCondition(conditionLevel1);
            for(CustomCategoryModel ccm : level1Infos){
                CategorysVo tree = new CategorysVo();
                tree.setId(Integer.parseInt(String.valueOf(ccm.getCustomCategoryId())));
                tree.setPid(ccm.getCategory());
                tree.setText(ccm.getCustomCategoryName());
                categoryTreeVos.add(tree);
            }

            //二级分类
            CustomCategoryCondition conditionLevel2 = new CustomCategoryCondition();
            conditionLevel2.setSpId(spId);
            conditionLevel2.setLevel(2);
            List<CustomCategoryModel> level2Infos = customCategoryService.getInfosByCondition(conditionLevel2);
            for(CustomCategoryModel ccm : level2Infos){
                CategorysVo tree = new CategorysVo();
                tree.setId(Integer.parseInt(String.valueOf(ccm.getCustomCategoryId())));
                tree.setPid(Integer.parseInt(String.valueOf(ccm.getParentCustomCategoryId())));
                tree.setText(ccm.getCustomCategoryName());
                categoryTreeVos.add(tree);
            }
        }catch (BusinessException exception){
            _log.error("getCategory error,er={}",exception);
        }
        return JsonResult.createSuccessInstance(categoryTreeVos);
    }
}
